while true;do
su -c iptables --flush
sleep 5
awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list > /data/media/0/UID;
UID=$(cat /data/media/0/UID);
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c ip6tables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c ip6tables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
ip6tables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
ip6tables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
sleep 10
echo "done"
done