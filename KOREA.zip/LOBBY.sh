
rm -rf /data/data/$PKG/{f*,a*,c*}
lib="/data/data/com.pubg.imobile/lib"
PKG="/data/data/com.pubg.imobile/"
rm -rf $lib/libtersafe.so
rm -rf $lib/libTDataMaster.so
mv $lib/{1,libtersafe.so}
mv $lib/{2,libUE4.so}
mv $lib/{3,libtprt.so}
mv $lib/{4,libTDataMaster.so}
mv $lib/{5,libgcloud.so}
chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null
chmod 777 /data/media/0/Android/data/com.pakage.upsilon/files/BEAST
exec /data/media/0/Android/data/com.pakage.upsilon/files/BEAST LOGO &> /dev/null