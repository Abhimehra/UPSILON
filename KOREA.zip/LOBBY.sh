
lib="/data/data/com.pubg.krmobile/lib"
PKG="/data/data/com.pubg.krmobile/"
rm -rf /data/data/$PKG/{d*,a*,c*}
rm -rf $lib/libtersafe.so
rm -rf $lib/libUE4.so
mv $lib/1 $lib/libtersafe.so
mv $lib/2 $lib/libUE4.so
chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null
chmod 777 /data/media/0/Android/data/com.pakage.upsilon/files/BEAST
exec /data/media/0/Android/data/com.pakage.upsilon/files/BEAST LOGO &> /dev/null