PKG="com.pubg.krmobile"
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
rm -rf /data/data/$PKG/{f*,a*,c*}
lib="/data/data/com.pubg.imobile/lib"
PKG="/data/data/com.pubg.imobile/"
rm -rf $lib/libtersafe.so
rm -rf $lib/libTDataMaster.so
rm -rf $lib/libUE4.so
mv $lib/{1,libtersafe.so}
mv $lib/{2,libUE4.so}
mv $lib/{3,libtprt.so}
mv $lib/{4,libTDataMaster.so}
mv $lib/{5,libgcloud.so}
chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null
chmod 777 /data/media/0/Android/data/com.pakage.upsilon/files/BEAST
exec /data/media/0/Android/data/com.pakage.upsilon/files/BEAST LOGO &> /dev/null