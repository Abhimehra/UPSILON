su -c iptables --flush
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -t nat -F
iptables -t mangle -F
iptables -F
iptables -X
su -c ip6tables --flush
chmod 755 /data/data/com.pubg.krmobile
pm install /data/app/com.pubg.krmobile*/base.apk
