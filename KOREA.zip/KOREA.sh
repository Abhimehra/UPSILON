

DD="/data/data"
DMAD="/data/media/0/Android/data"
FU="files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
DM0="/data/media/0"
PKG="com.pubg.krmobile"
sleep 1
echo
   sleep .1
for pkg in $PKG android.chrome com.android.vending com.android.vending com.facebook.appmanager com.facebook.services com.facebook.system com.google.android.apps.translate com.google.android.gm com.google.android.gms com.google.android.keep com.google.android.play.games com.google.android.youtube com.gcvip; do
   am force-stop $pkg
done
echo
sleep 1
rm -f /data/cache/magisk.log &> /dev/null
rm -f /data/cache/magisk.log.bak &> /dev/null
su -c chmod -R 777 $DMAD/$PKG $DD/$PKG &> /dev/null
su -c chmod -R 777 /legacy $DM0/.mcs $DM0/.tbs $DM0/tbs $DM0/MT2 $DM0/.backups $DM0/QTAudioEngine $DM0/MidasOversea $DM0/tencent $DM0/osmini $DM0/.zzz $DM0/.m $DM0/.tbs $DM0/.turing.dat $DM0/.turingdebug $DM0/baidu $DM0/.profig.os  > /dev/null 2>&1
su -c rm -rf $DM0/legacy $DM0/.mcs $DM0/.tbs $DM0/tbs $DM0/MT2 $DM0/.backups $DM0/QTAudioEngine $DM0/MidasOversea $DM0/tencent $DM0/osmini $DM0/.zzz $DM0/.m $DM0/.tbs $DM0/.turing.dat $DM0/.turingdebug $DM0/baidu $DM0/.profig.os  > /dev/null 2>&1

ver(){
chmod -R 2775 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks{game_patch_*pak,core_patch_*.pak,res_puffer_*.pak} &> /dev/null
}  
PKG="com.pubg.krmobile"
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
rm -rf /data/data/$PKG/{f*,a*,c*}
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
while [ ! -f $LOGO ]; do sleep 0.01; done
mv $lib/{libtersafe.so,1}
mv $lib/{libUE4.so,2}
mkdir $lib/libtersafe.so
mkdir $lib/libUE4.so
