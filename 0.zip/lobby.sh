#BEEASTYTOFFICIAL
for PID in $(pidof com.pubg.imobile | awk '{print $1}');do busybox mount --bind /proc/cpuinfo;done;