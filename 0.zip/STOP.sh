paks="/data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/"
touch $paks/game_patch_1.9.0.16107.pak
touch $paks/game_patch_1.9.0.16108.pak
touch $paks/game_patch_1.9.0.16111.pak
touch $paks/game_patch_1.9.0.16113.pak
touch $paks/game_patch_1.9.0.16114.pak
touch $paks/game_patch_1.9.0.16115.pak
touch $paks/game_patch_1.9.0.16117.pak
touch $paks/game_patch_1.9.0.16120.pak
touch $paks/game_patch_1.9.0.16122.pak
touch $paks/game_patch_1.9.0.16123.pak
touch $paks/game_patch_1.9.0.16124.pak
APK=$(pm path com.pubg.imobile)
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null
