
awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list > /data/media/0/uidinf
UID=$(cat /data/media/0/uidinf)
iptables iptables -A OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &> /dev/null









