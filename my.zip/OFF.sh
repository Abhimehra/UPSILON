
su -c iptables -F
