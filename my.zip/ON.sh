awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list > /data/media/0/UID;
UID=$(cat /data/media/0/UID);
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c ip6tables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c ip6tables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
ip6tables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
ip6tables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -N bw_FORWARD
iptables -N bw_INPUT
iptables -N bw_OUTPUT
iptables -N bw_costly_shared
iptables -N bw_data_saver
iptables -N bw_global_alert
iptables -N bw_happy_box
iptables -N bw_penalty_box
iptables -N fw_FORWARD
iptables -N fw_INPUT
iptables -N fw_OUTPUT
iptables -N oem_cta_all
iptables -N oem_cta_mobile
iptables -N oem_data
iptables -N oem_fwd
iptables -N oem_in
iptables -N oem_out
iptables -N oem_priot
iptables -N oem_priou
iptables -N st_OUTPUT
iptables -N st_clear_caught
iptables -N st_clear_detect
iptables -N st_penalty_log
iptables -N st_penalty_reject
iptables -N tc_limiter
iptables -N tetherctrl_FORWARD
iptables -N tetherctrl_counters
iptables -A INPUT -j bw_INPUT
iptables -A INPUT -j fw_INPUT
iptables -A INPUT -j oem_in
iptables -A FORWARD -j oem_fwd
iptables -A FORWARD -j fw_FORWARD
iptables -A FORWARD -j bw_FORWARD
iptables -A FORWARD -j tetherctrl_FORWARD
iptables -A OUTPUT -j oem_out
iptables -A OUTPUT -j fw_OUTPUT
iptables -A OUTPUT -j st_OUTPUT
iptables -A OUTPUT -j bw_OUTPUT
iptables -A bw_INPUT -j bw_global_alert
iptables -A bw_INPUT -p esp -j RETURN
iptables -A bw_INPUT -m mark --mark 0x100000/0x100000 -j RETURN
iptables -A bw_INPUT -j MARK --set-xmark 0x100000/0x100000
iptables -A bw_OUTPUT -j bw_global_alert
iptables -A bw_OUTPUT -o ipsec+ -j RETURN
iptables -A bw_OUTPUT -m policy --dir out --pol ipsec -j RETURN
iptables -A bw_costly_shared -j bw_penalty_box
iptables -A bw_data_saver -j RETURN
iptables -A bw_happy_box -m bpf --object-pinned /sys/fs/bpf/prog_netd_skfilter_whitelist_xtbpf -j RETURN
iptables -A bw_happy_box -j bw_data_saver
iptables -A bw_penalty_box -m bpf --object-pinned /sys/fs/bpf/prog_netd_skfilter_blacklist_xtbpf -j REJECT 
iptables -A bw_penalty_box -j bw_happy_box
iptables -A oem_data -j oem_priou
iptables -A oem_data -j oem_priot
iptables -A oem_out -o ppp+ -j oem_cta_mobile
iptables -A oem_out -o ccmni+ -j oem_cta_mobile
iptables -A oem_out -o ccemni+ -j oem_cta_mobile
iptables -A oem_out -o usb+ -j oem_cta_mobile
iptables -A oem_out -o cc2mni+ -j oem_cta_mobile
iptables -A oem_out -j oem_cta_all
iptables -A oem_out -j oem_data
iptables -A st_clear_detect -m connmark --mark 0x2000000/0x2000000 -j REJECT 
iptables -A st_clear_detect -m connmark --mark 0x1000000/0x1000000 -j RETURN
iptables -A st_clear_detect -p tcp -m u32 --u32 "0x0>>0x16&0x3c@0xc>>0x1a&0x3c@0x0&0xffff0000=0x16030000&&0x0>>0x16&0x3c@0xc>>0x1a&0x3c@0x4&0xff0000=0x10000" -j CONNMARK --set-xmark 0x1000000/0x1000000
iptables -A st_clear_detect -p udp -m u32 --u32 "0x0>>0x16&0x3c@0x8&0xffff0000=0x16fe0000&&0x0>>0x16&0x3c@0x14&0xff0000=0x10000" -j CONNMARK --set-xmark 0x1000000/0x1000000
iptables -A st_clear_detect -m connmark --mark 0x1000000/0x1000000 -j RETURN
iptables -A st_clear_detect -p tcp -m state --state ESTABLISHED -m u32 --u32 "0x0>>0x16&0x3c@0xc>>0x1a&0x3c@0x0&0x0=0x0" -j st_clear_caught
iptables -A st_clear_detect -p udp -j st_clear_caught
iptables -A st_penalty_log -j CONNMARK --set-xmark 0x1000000/0x1000000
iptables -A st_penalty_log -j NFLOG
iptables -A st_penalty_reject -j CONNMARK --set-xmark 0x2000000/0x2000000
iptables -A st_penalty_reject -j NFLOG
iptables -A st_penalty_reject -j REJECT 
iptables -A tetherctrl_FORWARD -j DROP
