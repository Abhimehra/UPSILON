su -c iptables --flush
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null

iptables -I INPUT -s ns-1972.awsdns-54.co.uk -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-1972.awsdns-54.co.uk -j REJECT &>/dev/null
iptables -I INPUT -s ns-1219.awsdns-24.org -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-1219.awsdns-24.org -j REJECT &>/dev/null
iptables -I INPUT -s ns-376.awsdns-47.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-376.awsdns-47.com -j REJECT &>/dev/null
iptables -I INPUT -s ns-616.awsdns-13.net -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-616.awsdns-13.net -j REJECT &>/dev/null
iptables -I INPUT -s dns4.p08.nsone.net -j REJECT &>/dev/null
iptables -I OUTPUT -s dns4.p08.nsone.net -j REJECT &>/dev/null
iptables -I INPUT -s dns3.p08.nsone.net -j REJECT &>/dev/null
iptables -I OUTPUT -s dns3.p08.nsone.net -j REJECT &>/dev/null
iptables -I INPUT -s dns2.p08.nsone.net -j REJECT &>/dev/null
iptables -I OUTPUT -s dns2.p08.nsone.net -j REJECT &>/dev/null
iptables -I INPUT -s dns1.p08.nsone.net -j REJECT &>/dev/null
iptables -I OUTPUT -s dns1.p08.nsone.net -j REJECT &>/dev/null
iptables -I INPUT -s ns-823.awsdns-38.net -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-823.awsdns-38.net -j REJECT &>/dev/null
iptables -I INPUT -s ns-172.awsdns-21.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-172.awsdns-21.com -j  &>/dev/null
iptables -I INPUT -s ns-1693.awsdns-19.co.uk -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-1693.awsdns-19.co.uk -j REJECT &>/dev/null
iptables -I INPUT -s ns-1285.awsdns-32.org -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-1285.awsdns-32.org -j REJECT &>/dev/null
iptables -I INPUT -s ns4.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns4.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s ns3.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns3.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s ns2.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns2.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s ns1.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns1.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s ns-open3.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-open3.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s ns-open2.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-open2.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s ns-open1.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-open1.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s ns4.dnsv5.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns4.dnsv5.com -j REJECT &>/dev/null
iptables -I INPUT -s ns3.dnsv5.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns3.dnsv5.com -j REJECT &>/dev/null
iptables -I INPUT -s f1g1ns1.dnspod.net -j REJECT &>/dev/null
iptables -I OUTPUT -s f1g1ns1.dnspod.net -j REJECT &>/dev/null
iptables -I INPUT -s f1g1ns2.dnspod.net -j REJECT &>/dev/null
iptables -I OUTPUT -s f1g1ns2.dnspod.net -j REJECT &>/dev/null
iptables -I INPUT -s 216.58.212.106 -j REJECT &>/dev/null
iptables -I OUTPUT -s 216.58.212.106 -j REJECT &>/dev/null
iptables -I INPUT -s 182.254.116.117 -j REJECT &>/dev/null
iptables -I OUTPUT -s 182.254.116.117 -j REJECT &>/dev/null
iptables -I INPUT -s min-pay.globh.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.globh.com -j REJECT &>/dev/null
iptables -I INPUT -s 20.40.443.235 -j REJECT &>/dev/null
iptables -I OUTPUT -s 20.40.443.235 -j REJECT &>/dev/null
iptables -I INPUT -s sandbox.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s 183.61.41.148 -j REJECT &>/dev/null
iptables -I OUTPUT -s 183.61.41.148 -j REJECT &>/dev/null
iptables -I INPUT -s dev.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s dev.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s szmg.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s szmg.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I INPUT -s pay.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s pay.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I INPUT -s 129.226.3.30 -j REJECT &>/dev/null
iptables -I OUTPUT -s 129.226.3.30 -j REJECT &>/dev/null
iptables -I INPUT -ssandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I INPUT -s 101.32.133.41 -j REJECT &>/dev/null
iptables -I OUTPUT -s 101.32.133.41 -j REJECT &>/dev/null
iptables -I INPUT -ssandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.42.152 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.42.152 -j REJECT &>/dev/null
iptables -I INPUT -idcconfig.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s idcconfig.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s tglog.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s tglog.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s down.anticheatexpert.com.cdn.ettdnsv.com -j DROP &>/dev/null
iptables -I OUTPUT -s down.anticheatexpert.com.cdn.ettdnsv.com -j DROP &>/dev/null
iptables -I INPUT -s cloud.gsdk.proximabeta.com -j DROP &>/dev/null
iptables -I OUTPUT -s cloud.gsdk.proximabeta.com -j DROP &>/dev/null
iptables -I INPUT -s down.anticheatexpert.com.akamaized.net -j DROP &>/dev/null
iptables -I OUTPUT -s down.anticheatexpert.com.akamaized.net -j DROP &>/dev/null
iptables -I INPUT -s asia.csoversea.mbgame.anticheatexpert.com -j DROP &>/dev/null
iptables -I OUTPUT -s asia.csoversea.mbgame.anticheatexpert.com -j DROP &>/dev/null
iptables -I INPUT -s ig-us-sdkapi.igamecj.com -j DROP &>/dev/null
iptables -I OUTPUT -s ig-us-sdkapi.igamecj.com -j DROP &>/dev/null
iptables -I INPUT -s sg.tdatamaster.com -j DROP &>/dev/null
iptables -I OUTPUT -s sg.tdatamaster.com -j DROP &>/dev/null
iptables -I INPUT -s tglog.gcloudsdk.com -j DROP &>/dev/null
iptables -I OUTPUT -s tglog.gcloudsdk.com -j DROP &>/dev/null
iptables -I INPUT -s qosidc.gcloudsdk.com -j DROP &>/dev/null
iptables -I OUTPUT -s qosidc.gcloudsdk.com -j DROP &>/dev/null
iptables -I INPUT -s cdn.cn.gcloudcs.com -j DROP &>/dev/null
iptables -I OUTPUT -s cdn.cn.gcloudcs.com -j DROP &>/dev/null
iptables -I INPUT -s a1904.v.akamai.net -j DROP &>/dev/null
iptables -I OUTPUT -s a1904.v.akamai.net -j DROP &>/dev/null
iptables -I INPUT -s a1869.d.akamai.net -j DROP &>/dev/null
iptables -I OUTPUT -s a1869.d.akamai.net -j DROP &>/dev/null
iptables -I INPUT -s news.qq.com.edgekey.net -j DROP &>/dev/null
iptables -I OUTPUT -s news.qq.com.edgekey.net -j DROP &>/dev/null
iptables -I INPUT -s e6156.dscf.akamaiedge.net -j DROP &>/dev/null
iptables -I OUTPUT -s e6156.dscf.akamaiedge.net -j DROP &>/dev/null
iptables -I INPUT -s gsdk.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s gsdk.qq.com -j DROP &>/dev/null
iptables -I INPUT -s in-f.globh.com -j DROP &>/dev/null
iptables -I OUTPUT -s in-f.globh.com -j DROP &>/dev/null
iptables -I INPUT -s in-f.globh.com.akamaized.net -j DROP &>/dev/null
iptables -I OUTPUT -s in-f.globh.com.akamaized.net -j DROP &>/dev/null
iptables -I INPUT -s pandora.game.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s pandora.game.qq.com -j DROP &>/dev/null
iptables -I INPUT -s napubgm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I OUTPUT -s napubgm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I INPUT -s nawzryhwatm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I OUTPUT -s nawzryhwatm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I INPUT -s sandbox.api.unipay.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s sandbox.api.unipay.qq.com -j DROP &>/dev/null
iptables -I INPUT -s ssandbox.centauriglobal.com -j DROP &>/dev/null
iptables -I OUTPUT -s ssandbox.centauriglobal.com -j DROP &>/dev/null
iptables -I INPUT -s szmg.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s szmg.qq.com -j DROP &>/dev/null
iptables -I INPUT -s idcconfig.gcloudsdk.com -j DROP &>/dev/null
iptables -I OUTPUT -s idcconfig.gcloudsdk.com -j DROP &>/dev/null
iptables -I INPUT -s 49.51.42.110 -j DROP &>/dev/null
iptables -I OUTPUT -s 49.51.42.110 -j DROP &>/dev/null
iptables -I INPUT -s 49.51.67.140 -j DROP &>/dev/null
iptables -I OUTPUT -s 49.51.67.140 -j DROP &>/dev/null
iptables -I INPUT -s 52.252.216.247 -j DROP &>/dev/null
iptables -I OUTPUT -s 52.252.216.247 -j DROP &>/dev/null
iptables -I INPUT -s 173.223.163.200 -j DROP &>/dev/null
iptables -I OUTPUT -s 173.223.163.200 -j DROP &>/dev/null
iptables -I INPUT -s 173.223.163.212 -j DROP &>/dev/null
iptables -I OUTPUT -s 173.223.163.212 -j DROP &>/dev/null
iptables -I INPUT -s 49.51.134.54 -j DROP &>/dev/null
iptables -I OUTPUT -s 49.51.134.54 -j DROP &>/dev/null
iptables -I INPUT -s 49.51.136.156 -j DROP &>/dev/null
iptables -I OUTPUT -s 49.51.136.156 -j DROP &>/dev/null
iptables -I INPUT -s 14.18.161.126 -j DROP &>/dev/null
iptables -I OUTPUT -s 14.18.161.126 -j DROP &>/dev/null
iptables -I INPUT -s 183.61.41.148 -j DROP &>/dev/null
iptables -I OUTPUT -s 183.61.41.148 -j DROP &>/dev/null
iptables -I INPUT -s 59.36.121.210 -j DROP &>/dev/null
iptables -I OUTPUT -s 59.36.121.210 -j DROP &>/dev/null
iptables -I INPUT -s 49.51.42.152 -j DROP &>/dev/null
iptables -I OUTPUT -s 49.51.42.152 -j DROP &>/dev/null
iptables -I INPUT -s 183.61.41.148 -j DROP &>/dev/null
iptables -I OUTPUT -s 183.61.41.148 -j DROP &>/dev/null
iptables -I INPUT -s 59.36.121.210 -j DROP &>/dev/null
iptables -I OUTPUT -s 59.36.121.210 -j DROP &>/dev/null
iptables -I INPUT -s 176.255.202.114 -j DROP &>/dev/null
iptables -I OUTPUT -s 176.255.202.114 -j DROP &>/dev/null
iptables -I INPUT -s 49.51.129.54 -j DROP &>/dev/null
iptables -I OUTPUT -s 49.51.129.54 -j DROP &>/dev/null
iptables -I INPUT -s 49.51.130.93 -j DROP &>/dev/null
iptables -I OUTPUT -s 49.51.130.93 -j DROP &>/dev/null
iptables -I INPUT -s 203.205.235.68 -j DROP &>/dev/null
iptables -I OUTPUT -s 203.205.235.68 -j DROP &>/dev/null
iptables -I INPUT -s 61.151.166.208 -j DROP &>/dev/null
iptables -I OUTPUT -s 61.151.166.208 -j DROP &>/dev/null
iptables -I INPUT -s 36.152.4.34 -j DROP &>/dev/null
iptables -I OUTPUT -s 36.152.4.34 -j DROP &>/dev/null
iptables -I INPUT -s 129.226.2.165 -j DROP &>/dev/null
iptables -I OUTPUT -s 129.226.2.165 -j DROP &>/dev/null
iptables -I INPUT -s 129.226.2.165 -j DROP &>/dev/null
iptables -I OUTPUT -s 129.226.2.165 -j DROP &>/dev/null
iptables -I INPUT -s 101.91.63.139 -j DROP &>/dev/null
iptables -I OUTPUT -s 101.91.63.139 -j DROP &>/dev/null
iptables -I INPUT -s 180.163.25.202 -j DROP &>/dev/null
iptables -I OUTPUT -s 180.163.25.202 -j DROP &>/dev/null
iptables -I INPUT -s 211.152.148.32 -j DROP &>/dev/null
iptables -I OUTPUT -s 211.152.148.32 -j DROP &>/dev/null
iptables -I INPUT -s 211.152.148.45 -j DROP &>/dev/null
iptables -I OUTPUT -s 211.152.148.45 -j DROP &>/dev/null
iptables -I INPUT -s 23.62.230.111 -j DROP &>/dev/null
iptables -I OUTPUT -s 23.62.230.111 -j DROP &>/dev/null
iptables -I INPUT -s 23.62.230.119 -j DROP &>/dev/null
iptables -I OUTPUT -s 23.62.230.119 -j DROP &>/dev/null
iptables -I INPUT -s 95.178.84.73 -j DROP &>/dev/null
iptables -I OUTPUT -s 95.178.84.73 -j DROP &>/dev/null 
iptables -I INPUT -s 119.28.229.113 -j DROP &>/dev/null
iptables -I OUTPUT -s 119.28.229.113 -j DROP &>/dev/null 
iptables -I INPUT -s 192.168.1.1 -j DROP &>/dev/null
iptables -I OUTPUT -s 192.168.1.1 -j DROP &>/dev/null 
iptables -A INPUT -m string --algo bm --string "szmg" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "szmg" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "idcconfig" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "idcconfig" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "report" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "report" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "cheat" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "cheat" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "anti" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "anti" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "down" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "down" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "gcloudsdk" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "gcloudsdk" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "gcloudsdk" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "gcloudsdk" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "globh" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "globh" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "pgtom" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "pgtom" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "ssandbox" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "ssandbox" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "tglog" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "tglog" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "centauriglobal" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "centauriglobal" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "tersafe" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "tersafe" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "check" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "check" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "lib" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "lib" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "obb" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "obb" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "pak" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "pak" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "amsoveasea" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "amsoveasea" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "bugly" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "bugly" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "pandora" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "pandora" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "config2" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "config2" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "config3" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "config3" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "dyncures" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "dyncures" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "mbgame" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "mbgame" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "csoversea" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "csoversea" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "lobby" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "lobby" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "akamaized" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "akamaized" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "2139" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "2139" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "iedsafe" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "iedsafe" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "mrpcs" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "mrpcs" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "Akamai" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "Akamai" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "xml" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "xml" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "ini" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "ini" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "txt" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "txt" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "config" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "config" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "TGPA" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "TGPA" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "tglog" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "tglog" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "midas" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "midas" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "pandora" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "pandora" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "amsoveasea" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "amsoveasea" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "broker" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "broker" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "ettdnsv" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "ettdnsv" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "sdkapi" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "sdkapi" -j DROP &>/dev/null
iptables -A INPUT -m string --algo bm --string "shadow" -j DROP &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "shadow" -j DROP &>/dev/null
iptables -I INPUT -p udp --dport 18081 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 18081 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 18081 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 18081 -j DROP &>/dev/null
iptables -I INPUT -p udp --dport 17000 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 17000 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 17000 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 17000 -j DROP &>/dev/null
iptables -I INPUT -p udp --dport 20002 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 20002 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 20002 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 20002 -j DROP &>/dev/null
iptables -I INPUT -p udp --dport 20001 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 20001 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 20001 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 20001 -j DROP &>/dev/null
iptables -I INPUT -p udp --dport 9030 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 9030 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 9030 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 9030 -j DROP &>/dev/null
iptables -I INPUT -p udp --dport 4433 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 4433 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 4433 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 4433 -j DROP &>/dev/null  
iptables -I INPUT -p udp --dport 80 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 80 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 80 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 80 -j DROP &>/dev/null  
iptables -I INPUT -p udp --dport 20371 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 20371 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 20371 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 20371 -j DROP &>/dev/null  
iptables -I INPUT -p udp --dport 15692 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 15692 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 15692 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 15692 -j DROP &>/dev/null 
iptables -I INPUT -p udp --dport 17000 -j REJECT
iptables -I OUTPUT -p udp --dport 1700 -j REJECT
iptables -I INPUT -p udp --dport 17000 -j REJECT
iptables -I OUTPUT -p udp --dport 1700 -j REJECT
iptables -A INPUT -p icmp -j REJECT
iptables -A OUTPUT -p icmp -j REJECT
iptables -I INPUT -p tcp --dport 443 -j DROP
iptables -I OUTPUT -p tcp --dport 443 -j DROP
iptables -I INPUT -p tcp --dport 80 -j DROP
iptables -I INPUT -p tcp --dport 8080 -j DROP
iptables -I INPUT -p tcp --dport 18081 -j DROP
iptables -I INPUT -p tcp --dport 3013 -j DROP
iptables -I INPUT -p tcp --dport 1112 -j DROP
iptables -I INPUT -p tcp --dport 114443 -j DROP
iptables -I INPUT -p tcp --dport 53 -j DROP
iptables -I OUTPUT -p tcp --dport 53 -j DROP
iptables -I OUTPUT -p tcp --dport 80 -j DROP
iptables -I OUTPUT -p tcp --dport 8080 -j DROP
iptables -I OUTPUT -p tcp --dport 18081 -j DROP
iptables -I OUTPUT -p tcp --dport 3013 -j DROP
iptables -I OUTPUT -p tcp --dport 1112 -j DROP
iptables -I OUTPUT -p tcp --dport 114443 -j DROP
iptables -I OUTPUT -p udp --dport 81 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 111 -j DROP
iptables -I OUTPUT -p udp --dport 11038 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 20001 -j DROP
iptables -I INPUT -p tcp --dport 80 -j REJECT
iptables -I INPUT -p tcp --dport 8080 -j REJECT
iptables -I INPUT -p tcp --dport 8085 -j REJECT
iptables -I INPUT -p tcp --dport 8086 -j REJECT
iptables -I INPUT -p tcp --dport 8088 -j REJECT
iptables -I INPUT -p tcp --dport 18081 -j REJECT
iptables -I INPUT -p tcp --dport 3013 -j REJECT
iptables -I INPUT -p tcp --dport 1112 -j REJECT
iptables -I INPUT -p tcp --dport 114443 -j REJECT
iptables -I INPUT -p tcp --dport 53 -j REJECT
iptables -I OUTPUT -p tcp --dport 53 -j REJECT
iptables -I OUTPUT -p tcp --dport 80 -j REJECT
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT
iptables -I OUTPUT -p tcp --dport 8085 -j REJECT
iptables -I OUTPUT -p tcp --dport 8086 -j REJECT
iptables -I OUTPUT -p tcp --dport 8088 -j REJECT
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
iptables -I OUTPUT -p tcp --dport 3013 -j REJECT
iptables -I OUTPUT -p tcp --dport 1112 -j REJECT
iptables -I OUTPUT -p tcp --dport 114443 -j REJECT
iptables -I OUTPUT -p tcp --dport 443 -j REJECT
iptables -I INPUT -p tcp --dport 443 -j REJECT
i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   15692  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   53  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   20371  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   3013  - j   D R O P 