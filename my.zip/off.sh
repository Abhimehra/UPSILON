su -c iptables --flush
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -t nat -F
iptables -t mangle -F
iptables -F
iptables -X
su -c ip6tables --flush
export Storage="/storage/emulated/0" &> /dev/null
export Storage_Two="/storage/emulated/0/Android/data" &> /dev/null
export Media="/data/media/0" &> /dev/null
export Media_Two="/data/media/0/Android/data" &> /dev/null
export Data="/data/data" &> /dev/null
export App="/data/app" &> /dev/null
export PKG="com.pubg.imobile" &> /dev/null
killall $PKG >/dev/null 2>/dev/null
chmod -R 755 $App/$PKG*/lib/arm/libUE4.so &> /dev/null
su -c iptables -F &> /dev/null
su -c iptables -X &> /dev/null
su -c iptables --flush &> /dev/null
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events &> /dev/null
cd /proc/sys/fs/inotify && echo "128" > max_user_instances &> /dev/null
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches &> /dev/null
rm -rf $Storage/.* &> /dev/null
rm -rf $Storage/at &> /dev/null
rm -rf $Storage/.xlDownload &> /dev/null
rm -rf $Storage/libs &> /dev/null
rm -rf $Storage/amap &> /dev/null
rm -rf $Storage/sitemp &> /dev/null
rm -rf $Storage/tencent &> /dev/null
rm -rf $Storage/Tencent &> /dev/null
rm -rf $Storage/MT2 &> /dev/null
rm -rf $Storage/backups &> /dev/null
rm -rf $Storage_Two/$PKG/cache &> /dev/null
rm -rf $Storage_Two/$PKG/files/TGPA &> /dev/null
rm -rf $Storage_Two/$PKG/files/ca* &> /dev/null
rm -rf $Storage_Two/$PKG/files/login* &> /dev/null
rm -rf $Storage_Two/$PKG/files/hawk_data &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/Engine &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/Epic* &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs0 &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs1 &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*.json &> /dev/null
pm install -r /data/app/$PKG*/base.apk /data/app/$PKG*/base.apk  &> /dev/null
chmod -R 755 $App/$PKG*/lib/arm/* &> /dev/null
rm -rf /data/cache/magisk.log
rm -rf $Data/$PKG/app_appcache &> /dev/null
rm -rf $Data/$PKG/app_databases &> /dev/null
rm -rf $Data/$PKG/app_flutter &> /dev/null
rm -rf $Data/$PKG/app_geolocation &> /dev/null
rm -rf $Data/$PKG/app_textures &> /dev/null
rm -rf $Data/$PKG/app_webview_meemo &> /dev/null
rm -rf $Data/$PKG/code_cache &> /dev/null
rm -rf $Data/$PKG/files/* &> /dev/null
rm -rf $Data/$PKG/app_crashrecord/* &> /dev/null
rm -rf $Data/$PKG/shared_prefs/!("device_id.xml")
su -c am force-stop $PKG &> /dev/null
sleep 1
su -c am kill $PKG &> /dev/null
chmod 755 /data/data/com.pubg.imobile
pm install /data/app/com.pubg.imobile*/base.apk
