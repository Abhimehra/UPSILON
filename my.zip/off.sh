su -c iptables --flush
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -t nat -F
iptables -t mangle -F
iptables -F
iptables -X
su -c ip6tables --flush
pm install /data/app/com.pubg.imobile*/base.apk
