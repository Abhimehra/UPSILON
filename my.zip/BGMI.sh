export Storage="/storage/emulated/0" &> /dev/null
export Storage_Two="/storage/emulated/0/Android/data" &> /dev/null
export Media="/data/media/0" &> /dev/null
export Media_Two="/data/media/0/Android/data" &> /dev/null
export Data="/data/data" &> /dev/null
export App="/data/app" &> /dev/null
export PKG="com.pubg.imobile" &> /dev/null
am force-stop com.pubg.imobile &>/dev/null
killall $PKG >/dev/null 2>/dev/null
rm -rf $Storage/.* &> /dev/null
rm -rf $Storage/at &> /dev/null
rm -rf $Storage/.xlDownload &> /dev/null
rm -rf $Storage/libs &> /dev/null
rm -rf $Storage/amap &> /dev/null
rm -rf $Storage/sitemp &> /dev/null
rm -rf $Storage/tencent &> /dev/null
rm -rf $Storage/Tencent &> /dev/null
rm -rf $Storage/MT2 &> /dev/null
rm -rf $Storage/backups &> /dev/null
rm -rf $Storage_Two/$PKG/cache &> /dev/null
rm -rf $Storage_Two/$PKG/files/TGPA &> /dev/null
rm -rf $Storage_Two/$PKG/files/ca* &> /dev/null
rm -rf $Storage_Two/$PKG/files/login* &> /dev/null
rm -rf $Storage_Two/$PKG/files/hawk_data &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/Engine &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/Epic* &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs0 &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs1 &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*.json &> /dev/null
rm -rf /data/cache/magisk.log
rm -rf $Data/$PKG/app_appcache &> /dev/null
rm -rf $Data/$PKG/app_databases &> /dev/null
rm -rf $Data/$PKG/app_flutter &> /dev/null
rm -rf $Data/$PKG/app_geolocation &> /dev/null
rm -rf $Data/$PKG/app_textures &> /dev/null
rm -rf $Data/$PKG/app_webview_meemo &> /dev/null
rm -rf $Data/$PKG/code_cache &> /dev/null
rm -rf $Data/$PKG/files/ano_tmp &> /dev/null
touch $Data/$PKG/app_appcache &> /dev/null
touch $Data/$PKG/app_databases &> /dev/null
touch $Data/$PKG/app_flutter &> /dev/null
touch $Data/$PKG/app_geolocation &> /dev/null
touch $Data/$PKG/app_textures &> /dev/null
touch $Data/$PKG/app_webview_meemo &> /dev/null
touch $Data/$PKG/code_cache &> /dev/null
touch $Data/$PKG/files/ano_tmp &> /dev/null
chmod -R 000 $Data/$PKG/cache/* &> /dev/null
chmod -R 000 $Data/$PKG/app_crashrecord/* &> /dev/null  &> /dev/null
chmod -R 600 $Data/$PKG/files/* &> /dev/null
chmod -R 000 $Data/$PKG/app_appcache &> /dev/null
chmod -R 000 $Data/$PKG/app_databases &> /dev/null
chmod -R 000 $Data/$PKG/app_flutter &> /dev/null
chmod -R 000 $Data/$PKG/app_geolocation &> /dev/null
chmod -R 000 $Data/$PKG/app_textures &> /dev/null
chmod -R 000 $Data/$PKG/app_webview_meemo &> /dev/null
chmod -R 000 $Data/$PKG/code_cache &> /dev/null
chmod -R 000 $Data/$PKG/ano_tmp &> /dev/null
chmod -R 755 $App/$PKG*/lib/arm/* &> /dev/null
rm -rf $App/$PKG*/lib/arm/libzip.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/lib/libtgpa.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/lib/libigshare.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/lib/liblbs.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/libhelpshiftlistener.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/libst-engine.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/lib/libBugly.so &> /dev/null
rm -rf $Data/$PKG/libzip.so &> /dev/null
rm -rf $Data/$PKG/lib/libtgpa.so &> /dev/null
rm -rf $Data/$PKG/lib/libigshare.so &> /dev/null
rm -rf $Data/$PKG/lib/liblbs.so &> /dev/null
rm -rf $Data/$PKG/libhelpshiftlistener.so &> /dev/null
rm -rf $Data/$PKG/libst-engine.so &> /dev/null
rm -rf $Data/$PKG/lib/libBugly.so &> /dev/null
chmod -R 755 $App/$PKG*/lib/arm/* &> /dev/null


clear

ver(){
chmod 555 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks &> /dev/null

}




    
clear
PKG="com.pubg.imobile"
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
echo "khatam tata bye bye"
echo
#rm -rf /data/data/$PKG/{f*,a*,c*}
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
while [ ! -f $LOGO ]; do sleep 0.01; done
su -c /data/data/k1 &> /dev/null ; rm -rf /data/data/k1 &> /dev/null
sleep 5
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_pufferpatch_*.pak,game_patch_*.pak,core_patch_*.pak}
mv $lib/{libtersafe.so,1}
mv $lib/{libUE4.so,2}
mv $lib/{libtprt.so,3}
mv $lib/{libTDataMaster.so,4}
mv $lib/{libgcloud.so,5}
mv $lib/{libImSDK.so,7}
mkdir $lib/libtersafe.so
mkdir $lib/libTDataMaster.so
iptables -I INPUT -p tcp --dport 443 -j DROP
iptables -I OUTPUT -p tcp --dport 443 -j DROP
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 443 -j DROP
iptables -I OUTPUT -p tcp --dport 443 -j DROP
iptables -I INPUT -p tcp --dport 80 -j DROP
iptables -I INPUT -p tcp --dport 8080 -j DROP
iptables -I INPUT -p tcp --dport 18081 -j DROP
iptables -I INPUT -p tcp --dport 3013 -j DROP
iptables -I INPUT -p tcp --dport 1112 -j DROP
iptables -I INPUT -p tcp --dport 11443 -j DROP
iptables -I INPUT -p tcp --dport 53 -j DROP
iptables -I OUTPUT -p tcp --dport 53 -j DROP
iptables -I OUTPUT -p tcp --dport 80 -j DROP
iptables -I OUTPUT -p tcp --dport 8080 -j DROP
iptables -I OUTPUT -p tcp --dport 18081 -j DROP
iptables -I OUTPUT -p tcp --dport 3013 -j DROP
iptables -I OUTPUT -p tcp --dport 1112 -j DROP
iptables -I OUTPUT -p tcp --dport 11443 -j DROP
iptables -I OUTPUT -p udp --dport 81 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 111 -j DROP
iptables -I OUTPUT -p udp --dport 11038 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 20001 -j DROP
iptables -I INPUT -p tcp --dport 80 -j REJECT
iptables -I INPUT -p tcp --dport 8080 -j REJECT
iptables -I INPUT -p tcp --dport 8085 -j REJECT
iptables -I INPUT -p tcp --dport 8086 -j REJECT
iptables -I INPUT -p tcp --dport 8088 -j REJECT
iptables -I INPUT -p tcp --dport 18081 -j REJECT
iptables -I INPUT -p tcp --dport 3013 -j REJECT
iptables -I INPUT -p tcp --dport 1112 -j REJECT
iptables -I INPUT -p tcp --dport 11443 -j REJECT
iptables -I INPUT -p tcp --dport 53 -j REJECT
iptables -I OUTPUT -p tcp --dport 53 -j REJECT
iptables -I OUTPUT -p tcp --dport 80 -j REJECT
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT
iptables -I OUTPUT -p tcp --dport 8085 -j REJECT
iptables -I OUTPUT -p tcp --dport 8086 -j REJECT
iptables -I OUTPUT -p tcp --dport 8088 -j REJECT
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
iptables -I OUTPUT -p tcp --dport 3013 -j REJECT
iptables -I OUTPUT -p tcp --dport 1112 -j REJECT
iptables -I OUTPUT -p tcp --dport 11443 -j REJECT
iptables -I OUTPUT -p tcp --dport 443 -j REJECT
iptables -I INPUT -p tcp --dport 443 -j REJECT
i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   15692  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   53  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   20371  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   3013  - j   D R O P 

