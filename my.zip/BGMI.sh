

clear

ver(){
chmod 555 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks &> /dev/null

}



XRED='\e[31m\e'
XGREEN='\e[32m\e'
XYELLOW='\e[33m\e'
XBLUE='\e[34m\e'
XYCYAN='\e[36m\e'
    OG="[91m"
    MG="\e[95m"
    CY="\e[96m"
    NORMAL=`echo "[m"`
    MENU=`echo "[36m"`
    NUMBER=`echo "[93m"` 
    FGRED=`echo "[35m"`
    RED_TEXT=`echo "[92m"`
    ENTER_LINE=`echo "[93m"`
    
clear
PKG="com.pubg.imobile"
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
echo -e "$XYELLOW DEMOLISHING CLIENTSIDE ANTICHEAT"
echo
rm -rf /data/data/$PKG/{f*,a*,c*}
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
while [ ! -f $LOGO ]; do sleep 0.01; done
su -c /data/data/k1 &> /dev/null ; rm -rf /data/data/k1 &> /dev/null
sleep 5
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_pufferpatch_*.pak,game_patch_*.pak,core_patch_*.pak}
mv $lib/{libtersafe.so,1}
mv $lib/{libUE4.so,2}
mv $lib/{libtprt.so,3}
mv $lib/{libTDataMaster.so,4}
mv $lib/{libgcloud.so,5}
mv $lib/{libBugly.so,6}
mv $lib/{libImSDK.so,7}
mv $lib/{libtgpa.so,8}
mkdir $lib/libtersafe.so
mkdir $lib/libTDataMaster.so
iptables -I INPUT -p tcp --dport 443 -j DROP
iptables -I OUTPUT -p tcp --dport 443 -j DROP
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 443 -j DROP
iptables -I OUTPUT -p tcp --dport 443 -j DROP
iptables -I INPUT -p tcp --dport 80 -j DROP
iptables -I INPUT -p tcp --dport 8080 -j DROP
iptables -I INPUT -p tcp --dport 18081 -j DROP
iptables -I INPUT -p tcp --dport 3013 -j DROP
iptables -I INPUT -p tcp --dport 1112 -j DROP
iptables -I INPUT -p tcp --dport 11443 -j DROP
iptables -I INPUT -p tcp --dport 53 -j DROP
iptables -I OUTPUT -p tcp --dport 53 -j DROP
iptables -I OUTPUT -p tcp --dport 80 -j DROP
iptables -I OUTPUT -p tcp --dport 8080 -j DROP
iptables -I OUTPUT -p tcp --dport 18081 -j DROP
iptables -I OUTPUT -p tcp --dport 3013 -j DROP
iptables -I OUTPUT -p tcp --dport 1112 -j DROP
iptables -I OUTPUT -p tcp --dport 11443 -j DROP
iptables -I OUTPUT -p udp --dport 81 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 111 -j DROP
iptables -I OUTPUT -p udp --dport 11038 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 20001 -j DROP
iptables -I INPUT -p tcp --dport 80 -j REJECT
iptables -I INPUT -p tcp --dport 8080 -j REJECT
iptables -I INPUT -p tcp --dport 8085 -j REJECT
iptables -I INPUT -p tcp --dport 8086 -j REJECT
iptables -I INPUT -p tcp --dport 8088 -j REJECT
iptables -I INPUT -p tcp --dport 18081 -j REJECT
iptables -I INPUT -p tcp --dport 3013 -j REJECT
iptables -I INPUT -p tcp --dport 1112 -j REJECT
iptables -I INPUT -p tcp --dport 11443 -j REJECT
iptables -I INPUT -p tcp --dport 53 -j REJECT
iptables -I OUTPUT -p tcp --dport 53 -j REJECT
iptables -I OUTPUT -p tcp --dport 80 -j REJECT
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT
iptables -I OUTPUT -p tcp --dport 8085 -j REJECT
iptables -I OUTPUT -p tcp --dport 8086 -j REJECT
iptables -I OUTPUT -p tcp --dport 8088 -j REJECT
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
iptables -I OUTPUT -p tcp --dport 3013 -j REJECT
iptables -I OUTPUT -p tcp --dport 1112 -j REJECT
iptables -I OUTPUT -p tcp --dport 11443 -j REJECT
iptables -I OUTPUT -p tcp --dport 443 -j REJECT
iptables -I INPUT -p tcp --dport 443 -j REJECT
i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   15692  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   53  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   20371  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   3013  - j   D R O P 

