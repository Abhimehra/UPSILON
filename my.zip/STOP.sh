
if [ $(pidof com.tencent.ig) ]; then
iptables -F
su -c iptables --flush
iptables --flush
iptables -F
iptables -X
ip6tables --flush
ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
chmod 755 /data/data/com.tencent.ig
pm install /data/app/com.tencent.ig*/base.apk
elif [ $(pidof com.pubg.krmobile) ]; then
iptables -F
su -c iptables --flush
iptables --flush
iptables -F
iptables -X
ip6tables --flush
ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
chmod 755 /data/data/com.pubg.krmobile
pm install /data/app/com.pubg.krmobile*/base.apk
elif [ $(pidof com.pubg.imobile) ]; then
iptables -F
su -c iptables --flush
iptables --flush
iptables -F
iptables -X
ip6tables --flush
ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
chmod 755 /data/data/com.pubg.imobile
pm install /data/app/com.pubg.imobile*/base.apk
else
echo "No Process Running"
fi








