
iptables -F
su -c iptables --flush
iptables --flush
iptables -F
iptables -X
ip6tables --flush
ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
chmod 755 /data/data/com.tencent.ig
pm install /data/app/com.tencent.ig*/base.apk
pm install /data/app/com.pubg.imobile*/base.apk
pm install /data/app/com.pubg.krmobile*/base.apk










