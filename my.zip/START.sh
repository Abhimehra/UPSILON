export Storage="/storage/emulated/0" &> /dev/null
export Storage_Two="/storage/emulated/0/Android/data" &> /dev/null
export Media="/data/media/0" &> /dev/null
export Media_Two="/data/media/0/Android/data" &> /dev/null
export Data="/data/data" &> /dev/null
export App="/data/app" &> /dev/null
export PKG="com.pubg.imobile" &> /dev/null
am force-stop com.pubg.imobile &>/dev/null
killall $PKG >/dev/null 2>/dev/null
rm -rf $Storage/.* &> /dev/null
rm -rf $Storage/at &> /dev/null
rm -rf $Storage/.xlDownload &> /dev/null
rm -rf $Storage/libs &> /dev/null
rm -rf $Storage/amap &> /dev/null
rm -rf $Storage/sitemp &> /dev/null
rm -rf $Storage/tencent &> /dev/null
rm -rf $Storage/Tencent &> /dev/null
rm -rf $Storage/MT2 &> /dev/null
rm -rf $Storage/backups &> /dev/null
rm -rf $Storage_Two/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*.json &> /dev/null
rm -rf /data/cache/magisk.log
rm -rf $Data/$PKG/app_appcache &> /dev/null
rm -rf $Data/$PKG/app_databases &> /dev/null
rm -rf $Data/$PKG/app_flutter &> /dev/null
rm -rf $Data/$PKG/app_geolocation &> /dev/null
rm -rf $Data/$PKG/app_textures &> /dev/null
rm -rf $Data/$PKG/app_webview_meemo &> /dev/null
rm -rf $Data/$PKG/code_cache &> /dev/null
rm -rf $Data/$PKG/files/ano_tmp &> /dev/null
touch $Data/$PKG/app_appcache &> /dev/null
touch $Data/$PKG/app_databases &> /dev/null
touch $Data/$PKG/app_flutter &> /dev/null
touch $Data/$PKG/app_geolocation &> /dev/null
touch $Data/$PKG/app_textures &> /dev/null
touch $Data/$PKG/app_webview_meemo &> /dev/null
touch $Data/$PKG/code_cache &> /dev/null
touch $Data/$PKG/files/ano_tmp &> /dev/null
chmod -R 000 $Data/$PKG/cache/* &> /dev/null
chmod -R 000 $Data/$PKG/app_crashrecord/* &> /dev/null  &> /dev/null
chmod -R 600 $Data/$PKG/files/* &> /dev/null
chmod -R 000 $Data/$PKG/app_appcache &> /dev/null
chmod -R 000 $Data/$PKG/app_databases &> /dev/null
chmod -R 000 $Data/$PKG/app_flutter &> /dev/null
chmod -R 000 $Data/$PKG/app_geolocation &> /dev/null
chmod -R 000 $Data/$PKG/app_textures &> /dev/null
chmod -R 000 $Data/$PKG/app_webview_meemo &> /dev/null
chmod -R 000 $Data/$PKG/code_cache &> /dev/null
chmod -R 000 $Data/$PKG/ano_tmp &> /dev/null
chmod -R 755 $App/$PKG*/lib/arm/* &> /dev/null
rm -rf $App/$PKG*/lib/arm/libzip.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/lib/libtgpa.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/lib/libigshare.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/lib/liblbs.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/libhelpshiftlistener.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/libst-engine.so &> /dev/null
rm -rf $App/$PKG*/lib/arm/lib/libBugly.so &> /dev/null
rm -rf $Data/$PKG/libzip.so &> /dev/null
rm -rf $Data/$PKG/lib/libtgpa.so &> /dev/null
rm -rf $Data/$PKG/lib/libigshare.so &> /dev/null
rm -rf $Data/$PKG/lib/liblbs.so &> /dev/null
rm -rf $Data/$PKG/libhelpshiftlistener.so &> /dev/null
rm -rf $Data/$PKG/libst-engine.so &> /dev/null
rm -rf $Data/$PKG/lib/libBugly.so &> /dev/null
chmod -R 755 $App/$PKG*/lib/arm/* &> /dev/null
