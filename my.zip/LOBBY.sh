export Storage="/storage/emulated/0" &> /dev/null
export Storage_Two="/storage/emulated/0/Android/data" &> /dev/null
export Media="/data/media/0" &> /dev/null
export Media_Two="/data/media/0/Android/data" &> /dev/null
export Data="/data/data" &> /dev/null
export App="/data/app" &> /dev/null

rm -rf $Storage/.* &> /dev/null
rm -rf $Storage/at &> /dev/null
rm -rf $Storage/.xlDownload &> /dev/null
rm -rf $Storage/libs &> /dev/null
rm -rf $Storage/amap &> /dev/null
rm -rf $Storage/sitemp &> /dev/null
rm -rf $Storage/tencent &> /dev/null
rm -rf $Storage/Tencent &> /dev/null
rm -rf $Storage/MT2 &> /dev/null
rm -rf $Storage/backups &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/cache &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/TGPA &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/ca* &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/login* &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/hawk_data &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/Engine &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/Epic* &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs0 &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs1 &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo &> /dev/null
rm -rf $Storage_Two/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*.json &> /dev/null
rm -rf /data/cache/magisk.log
rm -rf $Data/com.pubg.imobile/app_appcache &> /dev/null
rm -rf $Data/com.pubg.imobile/app_databases &> /dev/null
rm -rf $Data/com.pubg.imobile/app_flutter &> /dev/null
rm -rf $Data/com.pubg.imobile/app_geolocation &> /dev/null
rm -rf $Data/com.pubg.imobile/app_textures &> /dev/null
rm -rf $Data/com.pubg.imobile/app_webview_meemo &> /dev/null
rm -rf $Data/com.pubg.imobile/code_cache &> /dev/null
rm -rf $Data/com.pubg.imobile/files/ano_tmp &> /dev/null
touch $Data/com.pubg.imobile/app_appcache &> /dev/null
touch $Data/com.pubg.imobile/app_databases &> /dev/null
touch $Data/com.pubg.imobile/app_flutter &> /dev/null
touch $Data/com.pubg.imobile/app_geolocation &> /dev/null
touch $Data/com.pubg.imobile/app_textures &> /dev/null
touch $Data/com.pubg.imobile/app_webview_meemo &> /dev/null
touch $Data/com.pubg.imobile/code_cache &> /dev/null
touch $Data/com.pubg.imobile/files/ano_tmp &> /dev/null
chmod -R 000 $Data/com.pubg.imobile/cache/* &> /dev/null
chmod -R 000 $Data/com.pubg.imobile/app_crashrecord/* &> /dev/null  &> /dev/null
chmod -R 600 $Data/com.pubg.imobile/files/* &> /dev/null
chmod -R 000 $Data/com.pubg.imobile/app_appcache &> /dev/null
chmod -R 000 $Data/com.pubg.imobile/app_databases &> /dev/null
chmod -R 000 $Data/com.pubg.imobile/app_flutter &> /dev/null
chmod -R 000 $Data/com.pubg.imobile/app_geolocation &> /dev/null
chmod -R 000 $Data/com.pubg.imobile/app_textures &> /dev/null
chmod -R 000 $Data/com.pubg.imobile/app_webview_meemo &> /dev/null
chmod -R 000 $Data/com.pubg.imobile/code_cache &> /dev/null
chmod -R 000 $Data/com.pubg.imobile/ano_tmp &> /dev/null
chmod -R 755 $App/com.pubg.imobile*/lib/arm/* &> /dev/null
lib="/data/data/com.pubg.imobile/lib"
PKG="/data/data/com.pubg.imobile/"
#rm -rf /data/data/$PKG/{d*,a*,c*}
rm -rf $lib/libtersafe.so
rm -rf $lib/libTDataMaster.so
mv $lib/1 $lib/libtersafe.so
mv $lib/2 $lib/libUE4.so
mv $lib/3 $lib/libtprt.so
mv $lib/4 $lib/libTDataMaster.so
mv $lib/5 $lib/libgcloud.so
mv $lib/6 $lib/libBugly.so
mv $lib/7 $lib/libImSDK.so
mv $lib/8 $lib/libtgpa.so
chmod 000 /data/data/com.pubg.imobile
chmod 777 $PKG/lib*/
chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null
chmod 777 /data/media/0/Android/data/com.pakage.upsilon/files/BEAST
exec /data/media/0/Android/data/com.pakage.upsilon/files/BEAST LOGO &> /dev/null