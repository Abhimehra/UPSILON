dp="/data/app/com.pubg.imobile*/lib/arm64"
rm -rf $dp/{libtersafe.so,libUE4.so,libtprt.so,libTDataMaster.so,libgcloud.so,libapp.so,libflutter.so,libBugly.so,libImSDK.so,libmmkv.so}
clear

ver(){

chmod 777 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks &> /dev/null
}
clear
PKG="com.pubg.imobile"
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
mv $lib/{1,libtersafe.so}
mv $lib/{2,libUE4.so}
mv $lib/{3,libtprt.so}
mv $lib/{4,libTDataMaster.so}
mv $lib/{5,libgcloud.so}
mv $lib/{6,libapp.so}
mv $lib/{7,libflutter.so}
mv $lib/{8,libBugly.so}
mv $lib/{9,libImSDK.so}
mv $lib/{10,libmmkv.so}

chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null




