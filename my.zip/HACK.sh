chmod 777 /data/media/0/Android/data/com.pakage.upsilon/files/hack
exec /data/media/0/Android/data/com.pakage.upsilon/files/hack BEAST