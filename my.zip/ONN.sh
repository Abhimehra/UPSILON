awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list > /data/media/0/uidinf
UID=$(cat /data/media/0/uidinf)
iptables -D OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 443 -j REJECT
iptables -I OUTPUT -p udp --dport 443 -j DROP
iptables -I INPUT -p tcp --dport 443 -j REJECT
iptables -I INPUT -p udp --dport 443 -j DROP