chattr -i /data/data/com.pubg.imobile/files
su -c iptables --flush
APK=$(pm path com.pubg.imobile)
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null
am force-stop com.pubg.imobile