#BEEASTYTOFFICIAL
sudo kill -9 16912
killall com.pubg.imobile
sleep 2
chmod 777 /data/media/0/logos
exec /data/media/0/logos 