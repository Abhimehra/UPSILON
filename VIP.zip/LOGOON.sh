rm -rf /data/data/com.pubg.imobile/lib/libgcloud.so
rm -rf /data/data/com.pubg.imobile/lib/libITOP.so
rm -rf /data/data/com.pubg.imobile/lib/libmmkv.so
rm -rf /data/data/com.pubg.imobile/lib/libtersafe.so
rm -rf /data/data/com.pubg.imobile/lib/libtprt.so
rm -rf /data/data/com.pubg.imobile/lib/libUE4.so

cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/yaaugaugksd.so /data/data/com.pubg.imobile/lib/libgcloud.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/fuagiagiajvp.so /data/data/com.pubg.imobile/lib/libITOP.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/kbsohsihgsift.so /data/data/com.pubg.imobile/lib/libtprt.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/uvauvaugaiahv.so /data/data/com.pubg.imobile/lib/libmmkv.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/vuaugaiahiae.so /data/data/com.pubg.imobile/lib/libtersafe.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/hlhoakywgmvma4.so /data/data/com.pubg.imobile/lib/libUE4.so
chmod 755 /data/data/com.pubg.imobile/lib/*
chmod 755 /data/data/com.pubg.imobile/lib*/