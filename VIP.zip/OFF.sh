echo "Game Version - v1.6 BGMI 32 BiT "

echo "🆂🆃🅾🅿🅿🅸🅽🅶 🅰🅽🆃🅸🅱🅰🅽 - V2 [ REAL VIP ]"

####donot edit any code
sleep 1
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
chmod 777 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf  /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData


##############
##############
am force-stop com.pubg.imobile
pkill com.pubg.imobile
chmod 777 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /data/data/com.pubg.imobile/*
rm -rf /data/data/com.pubg.imobile/files
rm -rf /data/data/com.pubg.imobile/app_appcache
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/app_bugly
rm -rf /data/data/com.pubg.imobile/no_backup
rm -rf /data/data/com.pubg.imobile/shared_prefs
rm -rf /data/data/com.pubg.imobile/app_webview
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/app_textures
rm -rf /data/data/com.pubg.imobile/databases
rm -rf /data/data/com.pubg.imobile/app_crashrecord
rm -rf /data/data/com.pubg.imobile/code_cache
rm -rf /data/data/com.pubg.imobile/app_databases
rm -rf /data/data/com.pubg.imobile/app_webview_imsdk_inner_webview
rm -rf /data/data/com.pubg.imobile/files/app
rm -rf /data/data/com.pubg.imobile/files/data
rm -rf /data/data/com.pubg.imobile/files/hawk_data_init
rm -rf /data/data/com.pubg.imobile/files/iMSDK
rm -rf /data/data/com.pubg.imobile/files/local_crash_lock
rm -rf /data/data/com.pubg.imobile/files/TAPM_CM_AUDIT
rm -rf /data/media/0/MidasOversea
rm -rf /data/media/0/tencent
rm -rf /data/media/0/MIUI
rm -rf /data/media/0/MT2
rm -rf /data/media/0/QTAudioEngine
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
rm -rf /data/media/0/.backups/com.pubg.imobile/helpshift/database
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /data/media/0/.backups
rm -rf /data/media/0/Tencent
rm -rf /data/media/0/Android/data/com.pubg.imobile/cache
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/tbslog
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.66998.pak
pm install -r /data/app/com.pubg.imobile*/base.apk
chmod -R 755 /data/data/com.pubg.imobile/lib/*
iptables -I INPUT -p tcp -j ACCEPT
su -c iptables --flush
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
##############
##############


echo "🅰🅽🆃🅸🅱🅰🅽 🆂🆃🅾🅿🅿🅴🅳 - V2 [ REAL VIP ]"