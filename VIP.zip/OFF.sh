chmod 755 /data/app/com.pubg.imobile/*
chmod 755 /data/app/com.pubg.imobile*/base.apk
chmod 755 /data/app/com.pubg.imobile*/lib

chmod 755 /data/data/com.pubg.imobile/*

chmod 755 /data/media/0/Android/data/com.pubg.imobile*/
chmod 755 /data/media/0/Android/data/com.pubg.imobile/*

chmod 770 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
chmod 770 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved*/