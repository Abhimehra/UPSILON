

if [ $(pidof com.tencent.ig) ]; then
rm -rf /data/data/com.tencent.ig/lib/libtersafe.so
rm -rf /data/data/com.tencent.ig/lib/libtprt.so
rm -rf /data/data/com.tencent.ig/lib/libUE4.so

cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/libtersafe.so /data/data/com.tencent.ig/lib/libtersafe.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/i.so /data/data/com.tencent.ig/lib/libtprt.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/j.so /data/data/com.tencent.ig/lib/libUE4.so

chmod 755 /data/data/com.tencent.ig/lib/*
chmod 755 /data/data/com.tencent.ig/lib*/
elif [ $(pidof com.pubg.krmobile) ]; then
rm -rf /data/data/com.pubg.krmobile/lib/libtersafe.so
rm -rf /data/data/com.pubg.krmobile/lib/libtprt.so
rm -rf /data/data/com.pubg.krmobile/lib/libUE4.so

cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/libtersafe.so /data/data/com.pubg.krmobile/lib/libtersafe.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/i.so /data/data/com.pubg.krmobile/lib/libtprt.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/j.so /data/data/com.pubg.krmobile/lib/libUE4.so

chmod 755 /data/data/com.pubg.krmobile/lib/*
chmod 755 /data/data/com.pubg.krmobile/lib*/
elif [ $(pidof com.pubg.imobile) ]; then
rm -rf /data/data/com.pubg.imobile/lib/libtersafe.so
rm -rf /data/data/com.pubg.imobile/lib/libtprt.so
rm -rf /data/data/com.pubg.imobile/lib/libUE4.so

cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/libtersafe.so /data/data/com.pubg.imobile/lib/libtersafe.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/i.so /data/data/com.pubg.imobile/lib/libtprt.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/j.so /data/data/com.pubg.imobile/lib/libUE4.so

chmod 755 /data/data/com.pubg.imobile/lib/*
chmod 755 /data/data/com.pubg.imobile/lib*/
else
echo "No Process Running"
fi










