su -c chmod -R 777 /data/media/0/LOGO
su -c exec /data/media/0/LOGO BEAST