rm -rf /data/data/com.pubg.imobile/lib/libtersafe.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/a.so /data/data/com.pubg.imobile/lib/libtersafe.so
chmod 755 /data/data/com.pubg.imobile/lib/*
chmod 755 /data/data/com.pubg.imobile/lib*/