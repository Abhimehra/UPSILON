cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/hosts /system/etc/

sleep 1

echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
date
export PKG="com.pubg.imobile"
export lib="/data/data/$PKG/lib"
killall $PKG >/dev/null 2>/dev/null
clear
date
sleep 1
chmod 777 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.8.0.649.pak  >/dev/null 2>/dev/null
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_1.8.0.649.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.8.0.649.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_1.8.0.649.pak  >/dev/null 2>/dev/null
chmod 777 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
rm -rf /storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 755 $lib/*
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo "[/Script/Client.GDolphinUpdater]
Disable=true" > /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini

rm -rf /storage/emulated/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
echo '[version]
appversion=1.6.0.15522
srcversion=0.22.0.15545' >> /storage/emulated/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
rm -rf /storage/emulated/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 555 /data/media/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 555 /data/media/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
echo "  

kkk3o" >> /storage/emulated/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
cp /storage/emulated/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz /storage/emulated/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /storage/emulated/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz

am force-stop com.pubg.imobile;
am force-stop com.android.chrome;
am force-stop com.android.vending;
am force-stop com.android.vending;
am force-stop com.facebook.appmanager;
am force-stop com.facebook.services;
am force-stop com.facebook.system;
am force-stop com.google.android.apps.translate;
am force-stop com.google.android.gm;
am force-stop com.google.android.gms;
am force-stop com.google.android.keep;
am force-stop com.google.android.play.games;
am force-stop com.google.android.youtube
iptables -F;
iptables -F;
iptables --flush;
iptables --flush
iptables -P INPUT ACCEPT;
iptables -P FORWARD ACCEPT;
iptables -P OUTPUT ACCEPT;
iptables -F;
iptables -t nat -F;
iptables -t mangle -F;
iptables -X;
iptables --flush;
iptables -F;
iptables --flush;
iptables -F;
iptables -X;
rm -rf /data/data/com.pubg.imobile/app*;
rm -rf /data/data/com.pubg.imobile/lib/{libapp.so,libBugly.so,libc++_shared.so,libflutter.so,libgamemaster.so,libgcloudarch.so,libhelpshiftlistener.so,libigshare.so,libImSDK.so,libkk-image.so,liblbs.so,libmarsxlog.so,libmmkv.so,libnpps-jni.so,libsentry.so,libsentry-android.so,libsoundtouch.so,libst-engine.so,libtgpa.so,libzip.so} > /dev/null 2>&1
chmod -R 755 /data/data/com.pubg.imobile/lib/*;
rm -rf /data/data/com.pubg.imobile/files/ano_tmp/*;
chmod -R 000 /data/data/com.pubg.imobile/files/ano_tmp;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*/*/*/*/*/*;
chmod 640 /data/system/packages.list
rm -rf /data/media/0/AHMEDQILAHMEDQIL
GL='com.pubg.imobile'
KR='com.pubg.krmobile'
VN='com.vng.pubgmobile'
su -c iptables --flush
iptables --flush
iptables -F
ip6tables -F
awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list > /data/media/0/AHMEDQILBBB
AHMEDQIL=$(cat /data/media/0/AHMEDQILBBB)
iptables -I INPUT -m owner --uid-owner $AHMEDQIL -p tcp --dport 443 -j DROP
iptables -I OUTPUT -m owner --uid-owner $AHMEDQIL -p tcp --dport 443 -j DROP
iptables -I INPUT -m owner --uid-owner $AHMEDQIL -p tcp --sport 443 -j DROP
iptables -I OUTPUT -m owner --uid-owner $AHMEDQIL -p tcp --sport 443 -j DROP


iptables -I INPUT -m owner --uid-owner $AHMEDQIL -p tcp --dport 80 -j DROP
iptables -I OUTPUT -m owner --uid-owner $AHMEDQIL -p tcp --dport 80 -j DROP
iptables -I INPUT -m owner --uid-owner $AHMEDQIL -p tcp --sport 80 -j DROP
iptables -I OUTPUT -m owner --uid-owner $AHMEDQIL -p tcp --sport 80 -j DROP


am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity > /dev/null 2>&1;
