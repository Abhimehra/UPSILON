# !/bin/bash
#Type your login details
read -p 'Username: ' user
read -sp 'Password: ' pass

if (( $user == "admin" && $pass == "admin123" ))
then
	echo -e "\nWelcome! You are Sucessfull login\n"
else
	echo -e "\nUnsuccessful login\n"
fi


#!/system/bin/sh
clear
alias R="rm -rf"
alias E="echo -e"
alias S="sleep"
alias SP="chmod"
alias T="touch"
red='\e[0;31m'
red2='\e[0;41m'
blue='\e[0;34m'
blue2='\e[0;44m'
green='\e[0;32m'
pink='\e[1;35m'
black='\e[0;30m'
black2='\e[0;40m'
gray='\e[0;36m'
no='\e[0m'
bro='\e[0;33'
M=`getprop ro.product.model`
D=`getprop ro.product.brand`
C=`getprop gsm.operator.iso-country`
Z=`getprop persist.sys.timezone`
GPU=`getprop ro.hardware.egl`
CPU=`getprop ro.hardware`
S=`getprop ro.build.version.sdk`
T=`date`
E
E
E "\n\e[46m\t                             \e[0m\n\e[80m\t    \e[1;32m       R O H A N   \e[1m        \e[0m\n\e[0;43m\a\t                             \e[0m\n"
E
E "   ${black2}           ${red2}DEIZZER X UPLISON${pink}vip${black2}           ${no}"
E
E ________________________________
E  ${red}Company: ${pink}$D${no}
E  ${red}Model: ${pink}$M${no}
E  ${red}Time zone: ${pink}$Z${no}
E  ${red}Time: ${pink}$T${no}
E  ${red}Country: ${pink}$C${no}
E ________________________________

E   ${green}CPU: ${gray}$CPU${no} »  ${green}GPU: ${gray}$GPU${no} »  ${green}SDK VERSION: ${gray}$S${no}
E ________________________________
E "${blue}This shell file made by${no}
\t├>${black2}MAKER ${red2}ROHAN OP${no}
\t├>${black2}PARTNER ${red2}BEAST YT${no}
\t├>${black2} SUPPORT ${red2}@ROHAN @BEAST${no}"
E
E ${red}▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔${no}


E ${red2}WE ARE GOING TO DUMP ANTICHEAT SYSTEM${no}
S 1
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/EnjoyCJZC.ini
S 1
cd /data/data/com.pubg.imobile && rm -rf app_crashrecord && echo > app_crashrecord
iptables -A INPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p udp -m udp --dport 20001 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 11038 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 111 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 81 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18600 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18600 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18600 -j REJECT
iptables -A OUTPUT -p tcp -m tcp --dport 18600 -j REJECT
S 1
echo 16384 > /proc/sys/fs/inotify/max_queued_events
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 8192 > /proc/sys/fs/inotify/max_user_watches
rm -rf src/main/java/com/google/errorprone/annotations
rm -rf src/main/java/com/google/errorprone/annotations/concurrent
rm -rf third_party.java_src.error_prone.project.annotations.Google_internal
S 0.5
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
echo '128' > /proc/sys/fs/inotify/max_user_instances
echo '8192' > /proc/sys/fs/inotify/max_user_watches
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"
S 1
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
pm path com.pubg.imobile &> /dev/null
killall com.pubg.imobile 2&> /dev/null
DUMP() {
pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
lib=`ls -mR $(DUMP com.pubg.imobile legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v sosna`
SAVE(){
cp $lib/$1 $lib/$1.bak
}
RETURN(){
mv $lib/$1.bak $lib/$1
}
SP -R 755 /data/data/com.pubg.imobile/lib/*
SP 755 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
touch /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak
cp -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.76262.pak
R /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
E '[version]
appversion=1.6.0.15522
srcversion=1.6.0.91911' >> /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
R /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
SP 550 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
SP 555 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
R /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
E " null " >> /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
cp /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
R /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
R /data/cache/magisk.log
R /data/cache/magisk.log.bak
SP 755 /data/data/com.pubg.imobile/lib/*
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
R /sdcard/Android/data/com.pubg.imobile/files/TGPA
R /sdcard/Android/data/com.pubg.imobile/cache
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
R /data/media/0/ꜰᴜᴄᴋᴘᴜʙɢᴀɴᴛɪᴄʜᴇᴀᴛ
mkdir /data/media/0/ꜰᴜᴄᴋᴘᴜʙɢᴀɴᴛɪᴄʜᴇᴀᴛ
SP -R 755 /data/data/com.pubg.imobile/lib/*
R $lib/{libzip.so,libBugly.so,libgamemaster.so,libgcloudarch.so,libhelpshiftlistener.so,libigshare.so,liblbs.so-libnpps-jni.so,libst-engine.so,libtgpa.so}
SP -R 755 /data/data/com.pubg.imobile/lib/*
SAVE libtprt.so
SAVE libUE4.so
sleep 1
am force-stop com.pubg.imobile
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/shared_prefs
rm -rf /data/data/com.pubg.imobile/app_bugly
rm -rf /data/data/com.pubg.imobile/app_crashrecord
rm -rf /data/data/com.pubg.imobile/no_backup
sleep 1
rm -rf /data/data/com.pubg.imobile/files
rm -rf /data/data/com.pubg.imobile/app_crashrecord
rm -rf /data/data/com.pubg.imobile/app_bugly
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/code_cache
S 1
touch /data/data/com.pubg.imobile/files
touch /data/data/com.pubg.imobile/app_crashrecord
touch /data/data/com.pubg.imobile/app_bugly
touch /data/data/com.pubg.imobile/cache
touch /data/data/com.pubg.imobile/code_cache
S 1
chmod -R 000 /data/data/com.pubg.imobile/files
chmod -R 000  /data/data/com.pubg.imobile/app_crashrecord
chmod -R 000 /data/data/com.pubg.imobile/app_bugly
chmod -R 000 /data/data/com.pubg.imobile/cache
chmod -R 000 /data/data/com.pubg.imobile/code_cache
echo ${pink}START PROCESSING PLEASE WAIT......${no}
E
E
S 3
E ${pink} DUMPING.. ${no}'\033[1;37m  □□□□□□□□□□0% \r'
S 1
E  ${pink} DUMPING.. ${no}'\033[1;31m  ■□□□□□□□□□10% \r'
S 1
E  ${pink} DUMPING.. ${no}'\033[1;31m  ■■□□□□□□□□20% \r'
S 1
E  ${pink} DUMPING.. ${no}'\033[1;33m  ■■■□□□□□□□30% \r'
S 1
E  ${pink} DUMPING.. ${no}'\033[1;33m  ■■■■□□□□□□40% \r'
S 1
E  ${pink} DUMPING.. ${no}'\033[1;33m  ■■■■■□□□□□50% \r'
S 1
E  ${pink} DUMPING.. ${no}'\033[1;36m  ■■■■■■□□□□60% \r'
S 1
E  ${pink} DUMPING.. ${no}'\033[1;36m  ■■■■■■■□□□70% \r'
S 1
E  ${pink} DUMPING.. ${no}'\033[1;36m  ■■■■■■■■□□80% \r'
S 1
E  ${pink} DUMPING.. ${no}'\033[1;32m  ■■■■■■■■■□90% \r'
S 1
E  ${pink} DUMPING.. ${no}'\033[1;32m  ■■■■■■■■■■100% \r'
S 2
E
E
echo ${black2}${pink}SUCCESS..........${black2}${no}
sleep 1
E
E
echo ${red2} OPENING PUBG MOBILE PLEASE WAIT....${no}
E
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_pufferpatch_*.pak,game_patch_*.pak,core_patch_*.pak}
E
S  3
E -ne '     \033[1;37m  □□□□□□□□□□0% \r'
S 0.1
E -ne '     \033[1;31m  ■□□□□□□□□□10% \r'
S 0.1
E -ne '     \033[1;31m  ■■□□□□□□□□20% \r'
S 0.1
E -ne '     \033[1;33m  ■■■□□□□□□□30% \r'
S 0.1
E -ne '     \033[1;33m  ■■■■□□□□□□40% \r'
S 0.1
E -ne '     \033[1;33m  ■■■■■□□□□□50% \r'
S 0.1
E -ne '     \033[1;36m  ■■■■■■□□□□60% \r'
S 0.1
E -ne '     \033[1;36m  ■■■■■■■□□□70% \r'
S 0.1
E -ne '     \033[1;36m  ■■■■■■■■□□80% \r'
S 0.1
E -ne '     \033[1;32m  ■■■■■■■■■□90% \r'
S 0.1
E -ne '     \033[1;32m  ■■■■■■■■■■100% \r'
am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity > /dev/null
sleep 15
echo ${black2} "FLUSHING SERVER BAN IN BACKGROUND"${no}
ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
S 7
R $lib/{libUE4.so,libtprt.so}
S 3
RETURN libtprt.so
RETURN libUE4.so
SP 755 /data/data/com.pubg.imobile/lib/*
S 1
R /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/Android/Updater.ini
S 15
echo ${red2} CLEARING LOGS ${no}
rm -rf /data/media/0/Android/data/com.pubg.imobile/cache
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/ProgramBinaryCache
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs

touch /data/media/0/Android/data/com.pubg.imobile/cache
touch /data/media/0/Android/data/com.pubg.imobile/files/ProgramBinaryCache
touch /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
touch /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs

echo ${red2} DONE BY DEIZZER X UPLISON TEAM ${no}