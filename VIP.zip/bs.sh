echo '[/Script/PlayerAntiCheatManager]
Disable=true
Disable=true' > /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini

rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_pufferpatch_*.pak,game_patch_*.pak,core_patch_*.pak}
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
PKG=com.pubg.imobile
data=/data/data/$PKG
lib=$data/lib
Saved=/storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

cp $lib/libtprt.so $lib/libtprt.so.bak
cp $lib/libUE4.so $lib/libUE4.so.bak
cp $lib/libtersafe.so $lib/libtersafe.so.bak
rm -rf $lib/{libtgpa.so,libBugly.so}
chmod 755 $lib/*
rm -rf $data/files
pm disable $PKG/com.tencent.midas.oversea.newnetwork.service.APNetDetectService
touch $data/files
chmod 0 $data/files
echo "[/Script/Client.GDolphinUpdater]\nDisable=true" > $Saved/Config/Android/Updater.ini
touch $Saved/Paks/game_patch_1.6.0.15566.pak
rm -rf $Saved/LightData/LightData3036393187.ltz
touch $Saved/LightData/LightData3036393187.ltz
echo "  

kkk3o" > $Saved/LightData/LightData3036393187.ltz
echo '[version]
appversion=1.6.0.15522
srcversion=1.6.0.25731' > $Saved/SrcVersion.ini
ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables
iptables -I OUTPUT -p tcp -m string --string "in-cloudctrl.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "in-cloudctrl.globh.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "pubgmobile.helpshift.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "pubgmobile.helpshift.com" --algo kmp -j DROP
iptables -I INPUT -s 127.0.0.1 20.195.57.74 -j DROP &>/dev/null
iptables -I INPUT -s 20.195.57.74 -j DROP
iptables -I OUTPUT -d 20.195.57.74 -j DROP
iptables -I INPUT -s 127.0.0.1 54.176.234.221 -j DROP &>/dev/null
iptables -I INPUT -s 54.176.234.221 -j DROP
iptables -I OUTPUT -d 54.176.234.221 -j DROP
iptables -I INPUT -s 127.0.0.1 20.193.133.152 -j DROP &>/dev/null
iptables -I INPUT -s 20.193.133.152 -j DROP
iptables -I OUTPUT -d 20.193.133.152 -j DROP
iptables -I INPUT -s 127.0.0.1 20.44.195.154 -j DROP &>/dev/null
iptables -I INPUT -s 20.44.195.154 -j DROP
iptables -I OUTPUT -d 20.44.195.154 -j DROP
iptables -I OUTPUT -p tcp -m string --string "tdm.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "tdm.globh.com" --algo kmp -j DROP
iptables -I INPUT -s 127.0.0.1 79.140.80.10 -j DROP &>/dev/null
iptables -I INPUT -s 79.140.80.10 -j DROP
iptables -I OUTPUT -d 79.140.80.10 -j DROP
iptables -I INPUT -s 127.0.0.1 185.151.204.32 -j DROP &>/dev/null
iptables -I INPUT -s 185.151.204.32 -j DROP
iptables -I OUTPUT -d 185.151.204.32 -j DROP
iptables -I OUTPUT -p tcp -m string --string "app.adjust.net.in" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "app.adjust.net.in" --algo kmp -j DROP
iptables -I INPUT -s 127.0.0.1 79.140.80.33 -j DROP &>/dev/null
iptables -I INPUT -s 79.140.80.33 -j DROP
iptables -I OUTPUT -d 79.140.80.33 -j DROP
iptables -I INPUT -s 127.0.0.1 20.193.133.81 -j DROP &>/dev/null
iptables -I INPUT -s 20.193.133.81 -j DROP
iptables -I OUTPUT -d 20.193.133.81 -j DROP
iptables -I INPUT -s 127.0.0.1 20.193.134.93 -j DROP &>/dev/null
iptables -I INPUT -s 20.193.134.93 -j DROP
iptables -I OUTPUT -d 20.193.134.93 -j DROP
iptables -I OUTPUT -p tcp -m string --string "gcloud.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "gcloud.globh.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "in-gcloud.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "in-gcloud.globh.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "3002-shadow.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "3002-shadow.globh.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "3001-shadow.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "3001-shadow.globh.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "in-csoversea.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "in-csoversea.globh.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "in-bugly-android.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "in-bugly-android.globh.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "shadow.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "shadow.globh.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "in-tdm.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "in-tdm.globh.com" --algo kmp -j DROP
iptables -I INPUT -s 127.0.0.1 45.11.57.36 -j DROP &>/dev/null
iptables -I INPUT -s 45.11.57.36 -j DROP
iptables -I OUTPUT -d 45.11.57.36 -j DROP
iptables -I OUTPUT -p tcp -m string --string "ubam.broker.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "ubam.broker.amsoveasea.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "broker.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "broker.amsoveasea.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "m.broker.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "m.broker.amsoveasea.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "nawzryhwatm.broker.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "nawzryhwatm.broker.amsoveasea.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "napubgm.broker.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "napubgm.broker.amsoveasea.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "na.apps.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "na.apps.amsoveasea.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "pandora.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "pandora.amsoveasea.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "amsoveasea.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "pandoracdn.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "pandoracdn.amsoveasea.com" --algo kmp -j DROP
iptables -I INPUT -s 127.0.0.1 129.226.2.165 -j DROP &>/dev/null
iptables -I INPUT -s 129.226.2.165 -j DROP
iptables -I OUTPUT -d 129.226.2.165 -j DROP
iptables -I INPUT -s 127.0.0.1 180.163.25.202 -j DROP &>/dev/null
iptables -I INPUT -s 180.163.25.202 -j DROP
iptables -I OUTPUT -d 180.163.25.202 -j DROP
iptables -I INPUT -s 127.0.0.1 45.32.185.198 -j DROP &>/dev/null
iptables -I INPUT -s 45.32.185.198 -j DROP
iptables -I OUTPUT -d 45.32.185.198 -j DROP
iptables -I INPUT -s 127.0.0.1 199.59.242.154 -j DROP &>/dev/null
iptables -I INPUT -s 199.59.242.154 -j DROP
iptables -I OUTPUT -d 199.59.242.154 -j DROP
iptables -I INPUT -s 127.0.0.1 129.226.2.165 -j DROP &>/dev/null
iptables -I INPUT -s 129.226.2.165 -j DROP
iptables -I OUTPUT -d 129.226.2.165 -j DROP
iptables -I INPUT -s 127.0.0.1 129.226.2.89 -j DROP &>/dev/null
iptables -I INPUT -s 129.226.2.89 -j DROP
iptables -I OUTPUT -d 129.226.2.89 -j DROP
iptables -I INPUT -s 127.0.0.1 45.11.57.36 -j DROP &>/dev/null
iptables -I INPUT -s 45.11.57.36 -j DROP
iptables -I OUTPUT -d 45.11.57.36 -j DROP
iptables -I INPUT -s 127.0.0.1 23.194.116.58 -j DROP &>/dev/null
iptables -I INPUT -s 23.194.116.58 -j DROP
iptables -I OUTPUT -d 23.194.116.58 -j DROP
iptables -I OUTPUT -p tcp -m string --string "dlied1.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "dlied1.qq.com" --algo kmp -j DROP
iptables -I INPUT -s 127.0.0.1 119.28.164.32 -j DROP &>/dev/null
iptables -I INPUT -s 119.28.164.32 -j DROP
iptables -I OUTPUT -d 119.28.164.32 -j DROP
iptables -I OUTPUT -p tcp -m string --string "astat.bugly.qcloud.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "astat.bugly.qcloud.com" --algo kmp -j DROP
iptables -I INPUT -s 127.0.0.1 150.109.29.135 -j DROP &>/dev/null
iptables -I INPUT -s 150.109.29.135 -j DROP
iptables -I OUTPUT -d 150.109.29.135 -j DROP
iptables -I OUTPUT -p tcp -m string --string "in-bugly-android.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "in-bugly-android.globh.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "abs.twimg.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "abs.twimg.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "pbs.twimg.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "pbs.twimg.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "lh3.googleusercontent.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "lh3.googleusercontent.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "asping.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "asping.globh.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "in3-f.globh.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "in3-f.globh.com" --algo kmp -j DROP

am start -n $PKG/com.epicgames.ue4.SplashActivity
sleep 5
rm -rf $lib/{libUE4.so,libtprt.so,libtersafe.so}
mv $lib/libtprt.so.bak $lib/libtprt.so
mv $lib/libUE4.so.bak $lib/libUE4.so
mv $lib/libtersafe.so.bak $lib/libtersafe.so
chmod 755 $lib/*

echo " REAL VIP Server 2 ON \n"
echo " Play With Only Hack Ids "