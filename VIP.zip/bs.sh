am force-stop com.pubg.imobile;
am force-stop com.android.chrome;
am force-stop com.android.vending;
am force-stop com.android.vending;
am force-stop com.facebook.appmanager;
am force-stop com.facebook.services;
am force-stop com.facebook.system;
am force-stop com.google.android.apps.translate;
am force-stop com.google.android.gm;
am force-stop com.google.android.gms;
am force-stop com.google.android.keep;
am force-stop com.google.android.play.games;
am force-stop com.google.android.youtube;
iptables -F;
iptables -F;
iptables --flush;
iptables --flush;
iptables -P INPUT ACCEPT;
iptables -P FORWARD ACCEPT;
iptables -P OUTPUT ACCEPT;
iptables -F;
iptables -t nat -F;
iptables -t mangle -F;
iptables -X;
iptables --flush;
iptables -F;
iptables --flush;
iptables -F;
iptables -X;
rm -rf /data/media/0/Download/BEAST;
rm -rf /data/media/0/Download/BEAST*;
rm -rf /data/data/com.pakage.upsilon/cache/BEAST;
rm -rf /data/data/com.pakage.upsilon/cache/SRC*;


cp SRC /data/data/com.pakage.upsilon/cache/SRC;
cp BEAST /data/data/com.pakage.upsilon/cache/BEAST;

chmod -R 777 /data/data/com.pakage.upsilon/cache/SRC;
chmod -R 777 /data/data/com.pakage.upsilon/cache/BEAST;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/com.pubg.imobile/*/*/*/*/*/*/*/*;
chmod 755 /data/data/com.pubg.imobile/lib/*;
rm -rf /data/data/com.pubg.imobile/files/ano_tmp/*;
chmod -R 000 /data/data/com.pubg.imobile/files/ano_tmp;
rm -rf /data/data/com.pubg.imobile/databases;
chmod 640 /data/system/packages.list;
rm -rf /data/media/0/BEAST;
GL='com.pubg.imobile';
KR='com.pubg.krmobile';
VN='com.vng.pubgmobile';
awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list > /data/media/0/BEAST;
BEAST=$(cat /data/media/0/BEAST);
su -c iptables -I INPUT -m owner --uid-owner $BEAST -p tcp -j DROP &>/dev/null;
su -c iptables -I OUTPUT -m owner --uid-owner $BEAST -p tcp -j DROP &>/dev/null;
su -c ip6tables -I INPUT -m owner --uid-owner $BEAST -p tcp -j DROP &>/dev/null;
su -c ip6tables -I OUTPUT -m owner --uid-owner $BEAST -p tcp -j DROP &>/dev/null;
iptables -I INPUT -m owner --uid-owner $BEAST -p tcp -j DROP &>/dev/null;
iptables -I OUTPUT -m owner --uid-owner $BEAST -p tcp -j DROP &>/dev/null;
ip6tables -I INPUT -m owner --uid-owner $BEAST -p tcp -j DROP &>/dev/null;
ip6tables -I OUTPUT -m owner --uid-owner $BEAST -p tcp -j DROP &>/dev/null;


am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity > /dev/null 2>&1;
sleep 10



chmod -R 777 /data/data/com.pakage.upsilon/cache/BEAST
su -c /data/data/com.pakage.upsilon/cache/BEAST;
rm -rf /data/media/0/Download/BEAST;
rm -rf /data/media/0/Download/BEAST*;
rm -rf /data/data/com.pakage.upsilon/cache/BEAST;
rm -rf /data/data/com.pakage.upsilon/cache/BEAST*;
chmod -R 777 /data/data/com.pakage.upsilon/cache/SRC;
su -c /data/data/com.pakage.upsilon/cache/SRC;
rm -rf /data/media/0/Download/SRC;
rm -rf /data/media/0/Download/SRC*;
rm -rf /data/data/com.pakage.upsilon/cache/SRC;
rm -rf /data/data/com.pakage.upsilon/cache/SRC*;
chmod 777 /data/media/0/Android/data/com.pakage.upsilon/files/LESS
exec /data/media/0/Android/data/com.pakage.upsilon/files/LESS BEAST
iptables -F;
iptables -F;
iptables --flush;
iptables --flush;
iptables -P INPUT ACCEPT;
iptables -P FORWARD ACCEPT;
iptables -P OUTPUT ACCEPT;
iptables -F;
iptables -t nat -F;
iptables -t mangle -F;
iptables -X;
iptables --flush;
iptables -F;
iptables --flush;
iptables -F;
iptables -X;
echo "done"