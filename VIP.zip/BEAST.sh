su -c chmod -R 777 /data/media/0/BEAST
su -c exec /data/media/0/BEAST BEAST