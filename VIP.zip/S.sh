#PUBGINDIA

rm -rf /data/data/com.pubg.imobile/files
rm -rf /data/data/com.pubg.imobile/app_crashrecord
rm -rf /data/data/com.pubg.imobile/app_bugly
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/code_cache

touch /data/data/com.pubg.imobile/files
touch /data/data/com.pubg.imobile/app_crashrecord
touch /data/data/com.pubg.imobile/app_bugly
touch /data/data/com.pubg.imobile/cache
touch /data/data/com.pubg.imobile/code_cache

chmod -R 000 /data/data/com.pubg.imobile/files
chmod -R 000  /data/data/com.pubg.imobile/app_crashrecord
chmod -R 000 /data/data/com.pubg.imobile/app_bugly
chmod -R 000 /data/data/com.pubg.imobile/cache
chmod -R 000 /data/data/com.pubg.imobile/code_cache

echo "FIX CRASH DONE BY BEAST"