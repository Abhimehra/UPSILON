su -c chmod -R 777 /data/media/0/LOBBY
su -c exec /data/media/0/LOBBY BEAST