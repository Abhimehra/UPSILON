chmod 777 /data/media/0/Android/data/com.pakage.upsilon/files/LOBBY
exec /data/media/0/Android/data/com.pakage.upsilon/files/LOBBY BEAST