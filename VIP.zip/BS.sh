PKG='com.pubg.imobile'
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_pufferpatch_*.pak,game_patch_*.pak,Core_patch_*.pak}
echo '[/Script/PlayerAntiCheatManager]
Disable=true
Disable=true

[/Script/bShouldReportAntiCheat]
Disable=true

[/Script/ReportAntiCheatInfo]
Disable=true

[/Script/MoveAntiCheatComponent]
Disable=true

[/Script/VehicleShootAntiCheat]
Disable=true

[/Script/bEnableAntiCheat]
Disable=true

[/Script/VehicleAntiCheatTask]
Disable=true

[/Script/WeaponAntiCheatComp]
Disable=true

[/Script/EntityAntiCheatComponent]
Disable=true

[/Script/bUseTimeSpeedAntiCheatCheck]
Disable=true

[/Script/CatchReportAntiCheatDetailData]
Disable=true

[/Script/AntiCheatDetailData]
Disable=true

[/Script/ReportAntiCheatDetailData]
Disable=true

[/Script/BugReporter]
Disable=true

[/Script/PingReportInterval]
Disable=true

[/Script/ReportPlayers]
Disable=true

[/Script/EnableReportALLAbroad]
Disable=true

[Config]
AntiCheat.ini=false

[/Script/Client.GDolphinUpdater]
Disable=true
Enable=false

[Core.Log]
LogOnline=log
LogOnlineGame=log
LogHttp=log
LogSTEOnlineGame=log
LogCircle=log
LogItemGeneratorBase=log
LogBulletHitImpact=log
LogGCloud=log
LogClass=log
LogSTCharMoveSpecial=log
LogAntiCheat=log

[ShippingCore.Log]
LogInit=log
LogTaskGraph=log
LogDevObjectVersion=log
LogMemory=log
LogTextLocalizationManager=log
LogObj=log
LogExit=log
LogPlatformFile=log
LogOnline=log
LogOnlineGame=log
LogHttp=log
LogSTEOnlineGame=log
LogCircle=log
LogItemGeneratorBase=log
LogBulletHitImpact=log
LogTemp=log
LogScriptPlugin=log
LogUMG=log
LogSecurityInfoCollector=log
AttrModifyComponent=log
LogNearDeath=log
LogSkinnedMeshComp=log
LogNetPartialBunch=log
LogDoor=log
LogBackPack=log
LogPickUp=log
LogIOS=log
LogAndroid=log
LogGCloud=log
LogGameInfo=log
LogNet=log
LogAirAttack=log
LogSTCharacterMovement=log
LogWeaponImportant=log
LogClient=log
LogAvatar=log
LogLandscape=log
LogMidasInterface=log
LogNula=log
LogChangeWearing=log
LogSTCharMoveSpecial=log
LogParticleCache=log
LogVehicle=log
LogVehicleSync=log
LogSkillEditorSkill=log
LogSkillPoolManager=log
LogAIActing=log
LogSTExtraPetCharacter=log
LogCharacterState=log
LogCharacterDamage=log
LogCharParachute=log
LogPetAnimInstance=log
LogPetEventManagerComponent=log
LogNetPlayerMovement=log
LogAntiCheat=log
LogRep=log
LogFPP=log
LogTimeLineSync=log
LogSecurityCoronaLab=log
LogGeneratorItem=log
LogGeneratorTriggerItem=log
LogCharAnim=log
LogParachuteAnimComp=log
LogSTExtraAnimInstance=log
LogSTExtraVehicleAnimInstance=log
LogMonsterAnimInstance=log
LogSimpleAnimList=log
LogInfectionAnimList=log
LogPlayEmote=log
LogLobbyPlayEmoteCom=log
LogActivity=log
LogSpotGroupObject=log
LogFilterConfig=log
LogCharacterParachute=log
MyLandscape=log
PandoraSlua=log
LogSkill=log
LogLevelStreaming=log
LogAkAudio=log
LogGarbage=log
LogTaskTrigger=log
LogWeapon=log
LogWeaponNew=log
LogBackPackComp=log
LogGameplay=log' > /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini