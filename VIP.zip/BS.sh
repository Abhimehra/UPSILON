iptables -t filter -A INPUT -m string --algo bm --string 'fbsbx.com' -j DROP &>/dev/null
iptables -A INPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p udp -m udp --dport 20001 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 11038 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 111 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 81 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18600 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18600 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18600 -j REJECT
iptables -A OUTPUT -p tcp -m tcp --dport 18600 -j REJECT
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/EnjoyCJZC.ini
PKG='com.pubg.imobile'
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_pufferpatch_*.pak,game_patch_*.pak,core_patch_*.pak}
echo '[/Script/PlayerAntiCheatManager]
Disable=true
Disable=true

[/Script/bShouldReportAntiCheat]
Disable=true

[/Script/ReportAntiCheatInfo]
Disable=true

[/Script/MoveAntiCheatComponent]
Disable=true

[/Script/VehicleShootAntiCheat]
Disable=true

[/Script/bEnableAntiCheat]
Disable=true

[/Script/VehicleAntiCheatTask]
Disable=true

[/Script/WeaponAntiCheatComp]
Disable=true

[/Script/EntityAntiCheatComponent]
Disable=true

[/Script/bUseTimeSpeedAntiCheatCheck]
Disable=true

[/Script/CatchReportAntiCheatDetailData]
Disable=true

[/Script/AntiCheatDetailData]
Disable=true

[/Script/ReportAntiCheatDetailData]
Disable=true

[/Script/BugReporter]
Disable=true

[/Script/PingReportInterval]
Disable=true

[/Script/ReportPlayers]
Disable=true

[/Script/EnableReportALLAbroad]
Disable=true

[Config]
AntiCheat.ini=false

[/Script/Client.GDolphinUpdater]
Disable=true
Enable=false

[Core.Log]
LogOnline=log
LogOnlineGame=log
LogHttp=log
LogSTEOnlineGame=log
LogCircle=log
LogItemGeneratorBase=log
LogBulletHitImpact=log
LogGCloud=log
LogClass=log
LogSTCharMoveSpecial=log
LogAntiCheat=log

[ShippingCore.Log]
LogInit=log
LogTaskGraph=log
LogDevObjectVersion=log
LogMemory=log
LogTextLocalizationManager=log
LogObj=log
LogExit=log
LogPlatformFile=log
LogOnline=log
LogOnlineGame=log
LogHttp=log
LogSTEOnlineGame=log
LogCircle=log
LogItemGeneratorBase=log
LogBulletHitImpact=log
LogTemp=log
LogScriptPlugin=log
LogUMG=log
LogSecurityInfoCollector=log
AttrModifyComponent=log
LogNearDeath=log
LogSkinnedMeshComp=log
LogNetPartialBunch=log
LogDoor=log
LogBackPack=log
LogPickUp=log
LogIOS=log
LogAndroid=log
LogGCloud=log
LogGameInfo=log
LogNet=log
LogAirAttack=log
LogSTCharacterMovement=log
LogWeaponImportant=log
LogClient=log
LogAvatar=log
LogLandscape=log
LogMidasInterface=log
LogNula=log
LogChangeWearing=log
LogSTCharMoveSpecial=log
LogParticleCache=log
LogVehicle=log
LogVehicleSync=log
LogSkillEditorSkill=log
LogSkillPoolManager=log
LogAIActing=log
LogSTExtraPetCharacter=log
LogCharacterState=log
LogCharacterDamage=log
LogCharParachute=log
LogPetAnimInstance=log
LogPetEventManagerComponent=log
LogNetPlayerMovement=log
LogAntiCheat=log
LogRep=log
LogFPP=log
LogTimeLineSync=log
LogSecurityCoronaLab=log
LogGeneratorItem=log
LogGeneratorTriggerItem=log
LogCharAnim=log
LogParachuteAnimComp=log
LogSTExtraAnimInstance=log
LogSTExtraVehicleAnimInstance=log
LogMonsterAnimInstance=log
LogSimpleAnimList=log
LogInfectionAnimList=log
LogPlayEmote=log
LogLobbyPlayEmoteCom=log
LogActivity=log
LogSpotGroupObject=log
LogFilterConfig=log
LogCharacterParachute=log
MyLandscape=log
PandoraSlua=log
LogSkill=log
LogLevelStreaming=log
LogAkAudio=log
LogGarbage=log
LogTaskTrigger=log
LogWeapon=log
LogWeaponNew=log
LogBackPackComp=log
LogGameplay=log' > /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo "🅦︎🅔︎🅛︎🅒︎🅞︎🅜︎🅔︎   🅣︎🅞  ︎ 🅓︎🅔︎🅘︎🅩︎🅩︎🅔︎🅡︎  🅥︎🅘︎🅟︎      🥰 ⚡"
sleep 3
echo "Kᴇᴇᴘ ᴘᴀᴛɪᴇɴᴄᴇ ᴀɴᴅ ᴡᴀɪᴛ︎"
sleep 1
echo "Ⓢ🅣︎Ⓐ︎🅡︎Ⓣ︎🅘︎Ⓝ︎🅖︎ Ⓐ︎🅝︎Ⓣ︎🅘︎Ⓑ︎🅐︎Ⓝ︎"
sleep 3
sleep 3
cd /data/data/com.pubg.imobile && rm -rf app_crashrecord && echo > app_crashrecord
sleep 3
rm -rf /data/data/com.pubg.imobile/lib/libflutter.so
rm -rf /data/data/com.pubg.imobile/lib/libgcloud.so
rm -rf /data/data/com.pubg.imobile/lib/libtersafe.so
rm -rf /data/data/com.pubg.imobile/lib/libtgpa.so
sleep 0.1
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/libflutter.so /data/data/com.pubg.imobile/lib/libflutter.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/libgcloud.so /data/data/com.pubg.imobile/lib/libgcloud.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/libtersafe.so /data/data/com.pubg.imobile/lib/libtersafe.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/libtgpa.so /data/data/com.pubg.imobile/lib/libtgpa.so
sleep 0.5
chmod 755 /data/data/com.pubg.imobile/lib/*
chmod 755 /data/data/com.pubg.imobile/lib*/
echo " 𝙾𝚗𝚕𝚢 @𝚁𝚘𝙷𝚊𝚗_Oᴘ1 sᴇʟʟs ᴛʜɪs "
echo " ᴡᴀɪᴛ ғᴏʀ ʙɢᴍɪ ᴛᴏ ᴏᴘᴇɴ"
echo " 𝖲𝗍𝖺𝗋𝗍𝗂𝗇𝗀 𝖾𝗋𝗋𝗈𝗋 𝗋𝖾𝗉𝗅𝗂𝖼𝗂𝗌𝖺𝗍𝗂𝗈𝗇 "
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
date
echo '128' > /proc/sys/fs/inotify/max_user_instances
echo '8192' > /proc/sys/fs/inotify/max_user_watches
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
rm -rf /data/data/com.pubg.imobile/app_appcache
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/app_bugly
rm -rf /data/data/com.pubg.imobile/no_backup
rm -rf /data/data/com.pubg.imobile/shared_prefs
rm -rf /data/data/com.pubg.imobile/app_webview
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/app_textures
rm -rf /data/data/com.pubg.imobile/app_crashrecord
rm -rf /data/data/com.pubg.imobile/code_cache
rm -rf /data/data/com.pubg.imobile/app_webview_imsdk_inner_webview
rm -rf /data/data/com.pubg.imobile/files/app
rm -rf /data/data/com.pubg.imobile/files/data
rm -rf /data/data/com.pubg.imobile/files/hawk_data_init
rm -rf /data/data/com.pubg.imobile/files/iMSDK
rm -rf /data/data/com.pubg.imobile/files/local_crash_lock
rm -rf /data/data/com.pubg.imobile/files/ss_tmp
rm -rf /data/data/com.pubg.imobile/files/TAPM_CM_AUDIT
alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"
E
E
E
E "\033[1;37m                _______________________  \033[0m"
E "\033[1;37m                 \033[41m  𝐔𝐒𝐄 𝐖𝐈𝐓𝐇 𝐃𝐄𝐈𝐙𝐙𝐄𝐑 𝐌𝐎𝐃𝐔𝐋𝐄𝐒 𝐎𝐍𝐋𝐘  \033[0m"
E "\033[1;37m                ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾  \033[0m"
S 1
E -n "𝙳𝙰𝚃𝙴 ��𝙽�� 𝚃𝙸𝙼𝙴: "
date "+%a %d %b %Y %Z %H:%M:%S"
S 1
E -n "𝙲𝙾𝚄𝙽𝚃𝚁𝚈: "
getprop gsm.operator.iso-country
S 1
E -n "𝙳𝙴𝚅𝙸𝙲𝙴 ��𝚁��𝙽��: "
getprop ro.product.brand
S 1
E -n "𝙳𝙴𝚅𝙸𝙲𝙴 ��𝙾��𝙴��: "
getprop ro.product.model
E ki
E 𝙼𝙰𝙳𝙴 B𝚈 @ROHAN_OP
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
pm path com.pubg.imobile &> /dev/null
killall com.pubg.imobile 2&> /dev/null
DUMP() {
pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
lib=`ls -mR $(DUMP com.pubg.imobile legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v sosna`
SAVE(){
cp $lib/$1 $lib/$1.bak
}
RETURN(){
mv $lib/$1.bak $lib/$1
}
chmod 777 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
cp -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/map_allstar_1.6.0.15522.pak /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch_1.6.0.15545.pak
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
echo '[version]
appversion=1.6.0.15522
srcversion=1.6.0.15545' >> /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 550 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 555 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
echo "  

mvpjo" >> /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
cp /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
R /data/cache/magisk.log
R /data/cache/magisk.log.bak
SP 755 /data/data/com.pubg.imobile/lib/*
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
R /sdcard/Android/data/com.pubg.imobile/files/TGPA
R /sdcard/Android/data/com.pubg.imobile/cache
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
R /data/media/0/ꜰᴜᴄᴋᴘᴜʙɢᴀɴᴛɪᴄʜᴇᴀᴛ
mkdir /data/media/0/ꜰᴜᴄᴋᴘᴜʙɢᴀɴᴛɪᴄʜᴇᴀᴛ
SP -R 755 /data/data/com.pubg.imobile/lib/*
R $lib/{libzip.so,libBugly.so,libgamemaster.so,libgcloudarch.so,libhelpshiftlistener.so,libigshare.so,liblbs.so-libnpps-jni.so,libst-engine.so,libtgpa.so}
SP -R 755 /data/data/com.pubg.imobile/lib/*
SAVE libtprt.so
SAVE libUE4.so
E
E -ne '                   \033[1;37m  □□□□□□□□□□0% \r'
S 0.1
E -ne '                   \033[1;31m  ■□□□□□□□□□10% \r'
S 0.1
E -ne '                   \033[1;31m  ■■□□□□□□□□20% \r'
S 0.1
E -ne '                   \033[1;33m  ■■■□□□□□□□30% \r'
S 0.1
E -ne '                   \033[1;33m  ■■■■□□□□□□40% \r'
S 0.1
E -ne '                   \033[1;33m  ■■■■■□□□□□50% \r'
S 0.1
E -ne '                   \033[1;36m  ■■■■■■□□□□60% \r'
S 0.1
E -ne '                   \033[1;36m  ■■■■■■■□□□70% \r'
S 0.1
E -ne '                   \033[1;36m  ■■■■■■■■□□80% \r'
S 0.1
E -ne '                   \033[1;32m  ■■■■■■■■■□90% \r'
S 0.1
E -ne '                   \033[1;32m  ■■■■■■■■■■100% \r'
S 0.1
E -ne '                   \033[1;32m  🥃𝕋𝔼𝕃𝔼𝔾ℝ𝔸𝕄 :- @𝔻𝕖𝕚𝕫𝕫𝕖𝕣_ℂ𝕙𝕖𝕒𝕥⚡ \r'
S 0.1
E -ne ' \n'
E "                   \033[0m"
am force-stop com.pubg.imobile
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/shared_prefs
rm -rf /data/data/com.pubg.imobile/app_bugly
rm -rf /data/data/com.pubg.imobile/app_crashrecord
rm -rf /data/data/com.pubg.imobile/no_backup
echo " [⚡ ʀᴏʜᴀɴ ᴏᴘ ʙᴏʟᴛᴇ ⚡]\n\n\ 𝗔𝗡𝗧𝗜 𝗖𝗛𝗘𝗔𝗧 𝗕𝗬𝗘 𝗕𝗬𝗘  \n\n\n⚡ 𝕄𝕒𝕕𝕖 𝙱𝚈 ℝ𝕆ℍ𝔸ℕ 𝕆ℙ "
S 3
echo " [⚡ ᴅᴇɪᴢᴢᴇʀ ᴄʜᴇᴀᴛ ⚡]\n\n\ 𝐁𝐆𝐌𝐈 32 𝐁𝐈𝐓  𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂\n\n\ "
echo " [⚡ ᴅᴇɪᴢᴢᴇʀ ᴄʜᴇᴀᴛ ⚡]\n\n\  𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂\n\n\n⚡ 𝙼𝙰𝙳𝙴 ��𝚈 𝔻𝕖𝕚𝕫𝕫𝕖𝕣 ℂ𝕙𝕖𝕒𝕥 "
S 3
am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity > /dev/null
S 3.5
ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables
uptime
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
S 7
R $lib/{libUE4.so,libtprt.so}
S 3
RETURN libtprt.so
RETURN libUE4.so
SP 755 /data/data/com.pubg.imobile/lib/*
SP 550 /data/data/com.pubg.imobile/files
R /data/data/com.pubg.imobile/files/*
S 0.5
touch /data/data/com.pubg.imobile/files/ano_tmp
SP 000 /data/data/com.pubg.imobile/files/ano_tmp
SP 550 /data/data/com.pubg.imobile/files
R /data/data/com.pubg.imobile/app_crashrecord
touch /data/data/com.pubg.imobile/app_crashrecord
S 1
R /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/Android/Updater.ini
echo " [⚡𝙳𝚎𝚒𝚣𝚣𝚎𝚛 𝙲𝚑𝚎𝚊𝚝 ] "
