
iptables -A INPUT -p icmp --icmp-type echo-request -j REJECT
iptables -A OUTPUT -p icmp --icmp-type echo-reply -j REJECT
iptables -A OUTPUT -p icmp --icmp-type echo-request -j REJECT
iptables -A INPUT -p icmp --icmp-type echo-reply -j REJECT
iptables -I INPUT -p tcp --dport 17500 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 17500 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 17500 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 17500 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp -m string --string "gamesafe.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "gamesafe.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "dlied1.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "dlied1.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "gfm.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "gfm.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "gcloud.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "gcloud.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "mdt.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "mdt.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "bugly.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "bugly.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "gtimg.cn" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "gtimg.cn" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "wetest.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "wetest.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "qlogo.cn" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "qlogo.cn" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "imtt.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "imtt.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "connect.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "connect.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "ipv6.mainconn.gamesafe.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "ipv6.mainconn.gamesafe.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "cs.mainconn.gamesafe.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "cs.mainconn.gamesafe.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "tel.exp.omd.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "tel.exp.omd.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "mtt.eve.mdt.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "mtt.eve.mdt.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "yyb.eve.mdt.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "yyb.eve.mdt.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "game.eve.mdt.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "game.eve.mdt.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "oth.eve.mdt.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "oth.eve.mdt.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "mig.eve.mdt.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "mig.eve.mdt.qq.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "t.dp.myapp.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "t.dp.myapp.com" --algo kmp -j DROP
iptables -I OUTPUT -p tcp -m string --string "dlied1.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p udp -m string --string "dlied1.qq.com" --algo kmp -j DROP
iptables -I INPUT -s 192.168.1.139 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 101.32.143.64 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 101.32.143.247 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.2.142 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.1.157 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.3.232 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 101.32.143.171 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.2.37 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 101.32.143.142 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.2.231 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 101.32.143.232 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.2.220 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.0.38 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.3.213 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.2.69 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.0.45 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.2.34 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.2.43 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.3.123 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 119.28.121.174 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.29.150 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 119.28.111.214 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 119.28.251.26 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 119.28.251.75 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 119.28.252.132 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 124.156.12.89 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 124.156.40.207 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 124.156.64.48 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.155.66 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.157.232 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.20.153 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.20.193 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.22.150 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.95.159 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.119.160 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.15.62 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.16.231 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.172.198 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.21.169 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.33.191 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.33.44 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.52.107 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.52.168 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.53.108 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.53.122 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.53.125 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.53.143 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.53.16 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.53.45 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.54.114 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.54.201 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.55.12 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.55.121 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.64.144 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.67.162 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.67.171 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 162.62.9.214 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.135.20 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.136.25 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.138.76 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.142.167 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.142.37 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.143.62 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.150.100 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.150.142 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.150.233 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.152.197 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.153.41 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.153.48 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.153.65 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.155.13 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.155.48 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.160.130 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.171.29 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.172.17 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.172.17 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.173.156 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.173.90 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 192.168.1.1 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.42.152 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 119.28.121.174 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 119.28.121.174 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 119.28.121.174 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.2.165 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.2.165 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 129.226.3.134 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 13.127.247.216 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 13.56.162.236 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.0.38 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.0.38 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.0.38 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.0.45 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.0.45 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.0.45 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.29.150 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.29.150 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 150.109.29.150 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 49.51.235.24 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 52.52.167.221 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 52.53.117.29 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 52.53.50.155 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 52.9.249.157 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 54.177.243.193 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 54.183.150.176 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s 54.193.83.164 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 101.32.143.64 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 101.32.143.247 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.2.142 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.1.157 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.3.232 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 101.32.143.171 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.2.37 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 101.32.143.142 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.2.231 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 101.32.143.232 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.2.220 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.0.38 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.3.213 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.2.69 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.0.45 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.2.34 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.2.43 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.3.123 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 119.28.121.174 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.29.150 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 119.28.111.214 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 119.28.251.26 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 119.28.251.75 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 119.28.252.132 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 124.156.12.89 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 124.156.40.207 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 124.156.64.48 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.155.66 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.157.232 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.20.153 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.20.193 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.22.150 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.95.159 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.119.160 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.15.62 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.16.231 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.172.198 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.21.169 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.33.191 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.33.44 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.52.107 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.52.168 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.53.108 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.53.122 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.53.125 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.53.143 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.53.16 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.53.45 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.54.114 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.54.201 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.55.12 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.55.121 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.64.144 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.67.162 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.67.171 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 162.62.9.214 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.135.20 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.136.25 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.138.76 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.142.167 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.142.37 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.143.62 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.150.100 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.150.142 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.150.233 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.152.197 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.153.41 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.153.48 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.153.65 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.155.13 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.155.48 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.160.130 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.171.29 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.172.17 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.172.17 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.173.156 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.173.90 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 192.168.1.1 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.42.152 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 119.28.121.174 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 119.28.121.174 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 119.28.121.174 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.2.165 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.2.165 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 129.226.3.134 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 13.127.247.216 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 13.56.162.236 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.0.38 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.0.38 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.0.38 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.0.45 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.0.45 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.0.45 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.29.150 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.29.150 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 150.109.29.150 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 49.51.235.24 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 52.52.167.221 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 52.53.117.29 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 52.53.50.155 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 52.9.249.157 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 54.177.243.193 -j DROP -p icmp --icmp-type echo-request
iptables -I OUTPUT -d 54.183.150.176 -j DROP -p icmp --icmp-type echo-request
iptables -I INPUT -s -j DROP
iptables -I INPUT -s 101.32.143.64 -j DROP
iptables -I INPUT -s 101.32.143.247 -j DROP
iptables -I INPUT -s 129.226.2.142 -j DROP
iptables -I INPUT -s 129.226.1.157 -j DROP
iptables -I INPUT -s 129.226.3.232 -j DROP
iptables -I INPUT -s 101.32.143.171 -j DROP
iptables -I INPUT -s 129.226.2.37 -j DROP
iptables -I INPUT -s 101.32.143.142 -j DROP
iptables -I INPUT -s 129.226.2.231 -j DROP
iptables -I INPUT -s 101.32.143.232 -j DROP
iptables -I INPUT -s 129.226.2.220 -j DROP
iptables -I INPUT -s 150.109.0.38 -j DROP
iptables -I INPUT -s 129.226.3.213 -j DROP
iptables -I INPUT -s 129.226.2.69 -j DROP
iptables -I INPUT -s 150.109.0.45 -j DROP
iptables -I INPUT -s 129.226.2.34 -j DROP
iptables -I INPUT -s 129.226.2.43 -j DROP
iptables -I INPUT -s 129.226.3.123 -j DROP
iptables -I INPUT -s 119.28.121.174 -j DROP
iptables -I INPUT -s 150.109.29.150 -j DROP
iptables -I INPUT -s 119.28.111.214 -j DROP
iptables -I INPUT -s 119.28.251.26 -j DROP
iptables -I INPUT -s 119.28.251.75 -j DROP
iptables -I INPUT -s 119.28.252.132 -j DROP
iptables -I INPUT -s 124.156.12.89 -j DROP
iptables -I INPUT -s 124.156.40.207 -j DROP
iptables -I INPUT -s 124.156.64.48 -j DROP
iptables -I INPUT -s 129.226.155.66 -j DROP
iptables -I INPUT -s 129.226.157.232 -j DROP
iptables -I INPUT -s 129.226.20.153 -j DROP
iptables -I INPUT -s 129.226.20.193 -j DROP
iptables -I INPUT -s 129.226.22.150 -j DROP
iptables -I INPUT -s 150.109.95.159 -j DROP
iptables -I INPUT -s 162.62.119.160 -j DROP
iptables -I INPUT -s 162.62.15.62 -j DROP
iptables -I INPUT -s 162.62.16.231 -j DROP
iptables -I INPUT -s 162.62.172.198 -j DROP
iptables -I INPUT -s 162.62.21.169 -j DROP
iptables -I INPUT -s 162.62.33.191 -j DROP
iptables -I INPUT -s 162.62.33.44 -j DROP
iptables -I INPUT -s 162.62.52.107 -j DROP
iptables -I INPUT -s 162.62.52.168 -j DROP
iptables -I INPUT -s 162.62.53.108 -j DROP
iptables -I INPUT -s 162.62.53.122 -j DROP
iptables -I INPUT -s 162.62.53.125 -j DROP
iptables -I INPUT -s 162.62.53.143 -j DROP
iptables -I INPUT -s 162.62.53.16 -j DROP
iptables -I INPUT -s 162.62.53.45 -j DROP
iptables -I INPUT -s 162.62.54.114 -j DROP
iptables -I INPUT -s 162.62.54.201 -j DROP
iptables -I INPUT -s 162.62.55.12 -j DROP
iptables -I INPUT -s 162.62.55.121 -j DROP
iptables -I INPUT -s 162.62.64.144 -j DROP
iptables -I INPUT -s 162.62.67.162 -j DROP
iptables -I INPUT -s 162.62.67.171 -j DROP
iptables -I INPUT -s 162.62.9.214 -j DROP
iptables -I INPUT -s 49.51.135.20 -j DROP
iptables -I INPUT -s 49.51.136.25 -j DROP
iptables -I INPUT -s 49.51.138.76 -j DROP
iptables -I INPUT -s 49.51.142.167 -j DROP
iptables -I INPUT -s 49.51.142.37 -j DROP
iptables -I INPUT -s 49.51.143.62 -j DROP
iptables -I INPUT -s 49.51.150.100 -j DROP
iptables -I INPUT -s 49.51.150.142 -j DROP
iptables -I INPUT -s 49.51.150.233 -j DROP
iptables -I INPUT -s 49.51.152.197 -j DROP
iptables -I INPUT -s 49.51.153.41 -j DROP
iptables -I INPUT -s 49.51.153.48 -j DROP
iptables -I INPUT -s 49.51.153.65 -j DROP
iptables -I INPUT -s 49.51.155.13 -j DROP
iptables -I INPUT -s 49.51.155.48 -j DROP
iptables -I INPUT -s 49.51.160.130 -j DROP
iptables -I INPUT -s 49.51.171.29 -j DROP
iptables -I INPUT -s 49.51.172.17 -j DROP
iptables -I INPUT -s 49.51.172.17 -j DROP
iptables -I INPUT -s 49.51.173.156 -j DROP
iptables -I INPUT -s 49.51.173.90 -j DROP
iptables -I INPUT -s 192.168.1.1 -j DROP
iptables -I INPUT -s 49.51.42.152 -j DROP
iptables -I INPUT -s 119.28.121.174 -j DROP
iptables -I INPUT -s 119.28.121.174 -j DROP
iptables -I INPUT -s 119.28.121.174 -j DROP
iptables -I INPUT -s 129.226.2.165 -j DROP
iptables -I INPUT -s 129.226.2.165 -j DROP
iptables -I INPUT -s 129.226.3.134 -j DROP
iptables -I INPUT -s 13.127.247.216 -j DROP
iptables -I INPUT -s 13.56.162.236 -j DROP
iptables -I INPUT -s 150.109.0.38 -j DROP
iptables -I INPUT -s 150.109.0.38 -j DROP
iptables -I INPUT -s 150.109.0.38 -j DROP
iptables -I INPUT -s 150.109.0.45 -j DROP
iptables -I INPUT -s 150.109.0.45 -j DROP
iptables -I INPUT -s 150.109.0.45 -j DROP
iptables -I INPUT -s 150.109.29.150 -j DROP
iptables -I INPUT -s 150.109.29.150 -j DROP
iptables -I INPUT -s 150.109.29.150 -j DROP
iptables -I INPUT -s 49.51.235.24 -j DROP
iptables -I INPUT -s 52.52.167.221 -j DROP
iptables -I INPUT -s 52.53.117.29 -j DROP
iptables -I INPUT -s 52.53.50.155 -j DROP
iptables -I INPUT -s 52.9.249.157 -j DROP
iptables -I INPUT -s 54.177.243.193 -j DROP
iptables -I INPUT -s 54.183.150.176 -j DROP
iptables -I INPUT -s 54.193.83.164 -j DROP
iptables -I OUTPUT -d -j DROP
iptables -I OUTPUT -d 101.32.143.64 -j DROP
iptables -I OUTPUT -d 101.32.143.247 -j DROP
iptables -I OUTPUT -d 129.226.2.142 -j DROP
iptables -I OUTPUT -d 129.226.1.157 -j DROP
iptables -I OUTPUT -d 129.226.3.232 -j DROP
iptables -I OUTPUT -d 101.32.143.171 -j DROP
iptables -I OUTPUT -d 129.226.2.37 -j DROP
iptables -I OUTPUT -d 101.32.143.142 -j DROP
iptables -I OUTPUT -d 129.226.2.231 -j DROP
iptables -I OUTPUT -d 101.32.143.232 -j DROP
iptables -I OUTPUT -d 129.226.2.220 -j DROP
iptables -I OUTPUT -d 150.109.0.38 -j DROP
iptables -I OUTPUT -d 129.226.3.213 -j DROP
iptables -I OUTPUT -d 129.226.2.69 -j DROP
iptables -I OUTPUT -d 150.109.0.45 -j DROP
iptables -I OUTPUT -d 129.226.2.34 -j DROP
iptables -I OUTPUT -d 129.226.2.43 -j DROP
iptables -I OUTPUT -d 129.226.3.123 -j DROP
iptables -I OUTPUT -d 119.28.121.174 -j DROP
iptables -I OUTPUT -d 150.109.29.150 -j DROP
iptables -I OUTPUT -d 119.28.111.214 -j DROP
iptables -I OUTPUT -d 119.28.251.26 -j DROP
iptables -I OUTPUT -d 119.28.251.75 -j DROP
iptables -I OUTPUT -d 119.28.252.132 -j DROP
iptables -I OUTPUT -d 124.156.12.89 -j DROP
iptables -I OUTPUT -d 124.156.40.207 -j DROP
iptables -I OUTPUT -d 124.156.64.48 -j DROP
iptables -I OUTPUT -d 129.226.155.66 -j DROP
iptables -I OUTPUT -d 129.226.157.232 -j DROP
iptables -I OUTPUT -d 129.226.20.153 -j DROP
iptables -I OUTPUT -d 129.226.20.193 -j DROP
iptables -I OUTPUT -d 129.226.22.150 -j DROP
iptables -I OUTPUT -d 150.109.95.159 -j DROP
iptables -I OUTPUT -d 162.62.119.160 -j DROP
iptables -I OUTPUT -d 162.62.15.62 -j DROP
iptables -I OUTPUT -d 162.62.16.231 -j DROP
iptables -I OUTPUT -d 162.62.172.198 -j DROP
iptables -I OUTPUT -d 162.62.21.169 -j DROP
iptables -I OUTPUT -d 162.62.33.191 -j DROP
iptables -I OUTPUT -d 162.62.33.44 -j DROP
iptables -I OUTPUT -d 162.62.52.107 -j DROP
iptables -I OUTPUT -d 162.62.52.168 -j DROP
iptables -I OUTPUT -d 162.62.53.108 -j DROP
iptables -I OUTPUT -d 162.62.53.122 -j DROP
iptables -I OUTPUT -d 162.62.53.125 -j DROP
iptables -I OUTPUT -d 162.62.53.143 -j DROP
iptables -I OUTPUT -d 162.62.53.16 -j DROP
iptables -I OUTPUT -d 162.62.53.45 -j DROP
iptables -I OUTPUT -d 162.62.54.114 -j DROP
iptables -I OUTPUT -d 162.62.54.201 -j DROP
iptables -I OUTPUT -d 162.62.55.12 -j DROP
iptables -I OUTPUT -d 162.62.55.121 -j DROP
iptables -I OUTPUT -d 162.62.64.144 -j DROP
iptables -I OUTPUT -d 162.62.67.162 -j DROP
iptables -I OUTPUT -d 162.62.67.171 -j DROP
iptables -I OUTPUT -d 162.62.9.214 -j DROP
iptables -I OUTPUT -d 49.51.135.20 -j DROP
iptables -I OUTPUT -d 49.51.136.25 -j DROP
iptables -I OUTPUT -d 49.51.138.76 -j DROP
iptables -I OUTPUT -d 49.51.142.167 -j DROP
iptables -I OUTPUT -d 49.51.142.37 -j DROP
iptables -I OUTPUT -d 49.51.143.62 -j DROP
iptables -I OUTPUT -d 49.51.150.100 -j DROP
iptables -I OUTPUT -d 49.51.150.142 -j DROP
iptables -I OUTPUT -d 49.51.150.233 -j DROP
iptables -I OUTPUT -d 49.51.152.197 -j DROP
iptables -I OUTPUT -d 49.51.153.41 -j DROP
iptables -I OUTPUT -d 49.51.153.48 -j DROP
iptables -I OUTPUT -d 49.51.153.65 -j DROP
iptables -I OUTPUT -d 49.51.155.13 -j DROP
iptables -I OUTPUT -d 49.51.155.48 -j DROP
iptables -I OUTPUT -d 49.51.160.130 -j DROP
iptables -I OUTPUT -d 49.51.171.29 -j DROP
iptables -I OUTPUT -d 49.51.172.17 -j DROP
iptables -I OUTPUT -d 49.51.172.17 -j DROP
iptables -I OUTPUT -d 49.51.173.156 -j DROP
iptables -I OUTPUT -d 49.51.173.90 -j DROP
iptables -I OUTPUT -d 192.168.1.1 -j DROP
iptables -I OUTPUT -d 49.51.42.152 -j DROP
iptables -I OUTPUT -d 119.28.121.174 -j DROP
iptables -I OUTPUT -d 119.28.121.174 -j DROP
iptables -I OUTPUT -d 119.28.121.174 -j DROP
iptables -I OUTPUT -d 129.226.2.165 -j DROP
iptables -I OUTPUT -d 129.226.2.165 -j DROP
iptables -I OUTPUT -d 129.226.3.134 -j DROP
iptables -I OUTPUT -d 13.127.247.216 -j DROP
iptables -I OUTPUT -d 13.56.162.236 -j DROP
iptables -I OUTPUT -d 150.109.0.38 -j DROP
iptables -I OUTPUT -d 150.109.0.38 -j DROP
iptables -I OUTPUT -d 150.109.0.38 -j DROP
iptables -I OUTPUT -d 150.109.0.45 -j DROP
iptables -I OUTPUT -d 150.109.0.45 -j DROP
iptables -I OUTPUT -d 150.109.0.45 -j DROP
iptables -I OUTPUT -d 150.109.29.150 -j DROP
iptables -I OUTPUT -d 150.109.29.150 -j DROP
iptables -I OUTPUT -d 150.109.29.150 -j DROP
iptables -I OUTPUT -d 49.51.235.24 -j DROP
iptables -I OUTPUT -d 52.52.167.221 -j DROP
iptables -I OUTPUT -d 52.53.117.29 -j DROP
iptables -I OUTPUT -d 52.53.50.155 -j DROP
iptables -I OUTPUT -d 52.9.249.157 -j DROP
iptables -I OUTPUT -d 54.177.243.193 -j DROP
iptables -I OUTPUT -d 54.183.150.176 -j DROP
iptables -I OUTPUT -d 54.193.83.164 -j DROP
iptables -I INPUT -p tcp --dport 80 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 80 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 80 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 80 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 443 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 443 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 443 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 443 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 448 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 448 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 448 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 448 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 8011 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 8011 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 8011 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 8011 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 8700 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 8700 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 8700 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 8700 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 10211 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 10211 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 10211 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 10211 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 10012 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 10012 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 10012 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 10012 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 15962 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 15962 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 15962 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 15962 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 17000 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 17000 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 17000 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 17000 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 18081 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 18081 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 18081 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 20000 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 20000 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 20000 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 20000 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 20001 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 20001 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 20001 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 20001 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 20002 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 20002 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 20002 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 20002 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 20371 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 20371 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 20371 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 20371 -j REJECT &> /dev/null
iptables -I INPUT -p tcp --dport 15692 -j DROP &> /dev/null
iptables -I OUTPUT -p tcp --dport 15692 -j DROP &> /dev/null
iptables -I INPUT -p tcp --dport 15692 -j REJECT &> /dev/null
iptables -I OUTPUT -p tcp --dport 15692 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 80 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 80 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 80 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 80 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 443 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 443 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 443 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 443 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 448 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 448 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 448 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 448 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 8011 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 8011 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 8011 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 8011 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 8700 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 8700 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 8700 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 8700 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 10211 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 10211 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 10211 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 10211 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 10012 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 10012 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 10012 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 10012 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 15962 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 15962 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 15962 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 15962 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 17000 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 17000 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 17000 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 17000 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 18081 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 18081 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 18081 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 18081 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 20000 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 20000 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 20000 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 20000 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 20001 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 20001 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 20001 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 20001 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 20002 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 20002 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 20002 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 20002 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 20371 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 20371 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 20371 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 20371 -j REJECT &> /dev/null
iptables -I INPUT -p udp --dport 15692 -j DROP &> /dev/null
iptables -I OUTPUT -p udp --dport 15692 -j DROP &> /dev/null
iptables -I INPUT -p udp --dport 15692 -j REJECT &> /dev/null
iptables -I OUTPUT -p udp --dport 15692 -j REJECT &> /dev/null
iptables -I INPUT -p tcp -j DROP
iptables -I INPUT -p tcp -j DROP
iptables -I INPUT -p tcp -j DROP
iptables -I INPUT -p tcp -j DROP
echo "Fixed"