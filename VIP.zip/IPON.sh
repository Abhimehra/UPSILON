iptables -A INPUT -p tcp -m tcp --dport 17500 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 17500 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 17500 -j REJECT
iptables -A INPUT -p tcp -m tcp --dport 17500 -j REJECT