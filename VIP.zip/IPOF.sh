iptables -I INPUT -p tcp --dport 17500 -j ACCEPT
iptables -I INPUT -p tcp --dport 17500 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT