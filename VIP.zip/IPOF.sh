su -c iptables -F
iptables --flush
iptables -F
iptables -F
iptables -X
iptables -Z
iptables --flush
iptables -L