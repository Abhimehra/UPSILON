#!/system/bin/sh


iptables -I INPUT -p tcp --dport 80 -j ACCEPT
iptables -I INPUT -p tcp --dport 8080 -j ACCEPT
iptables -I INPUT -p tcp --dport 18081 -j ACCEPT
iptables -I INPUT -p tcp --dport 3013 -j ACCEPT
iptables -I INPUT -p tcp --dport 1112 -j ACCEPT
iptables -I INPUT -p tcp --dport 11443 -j ACCEPT
iptables -I INPUT -p tcp --dport 17500 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 80 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 8080 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 18081 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 3013 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 1112 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 11443 -j ACCEPT
iptables -I OUTPUT -p udp --dport 81 -j ACCEPT
iptables -I OUTPUT -p udp --dport 8011 -j ACCEPT
iptables -I OUTPUT -p udp --dport 111 -j ACCEPT
iptables -I OUTPUT -p udp --dport 11038 -j ACCEPT
iptables -I OUTPUT -p udp --dport 8011 -j ACCEPT
iptables -I OUTPUT -p udp --dport 20001 -j ACCEPT
iptables -I INPUT -p tcp --dport 80 -j ACCEPT
iptables -I INPUT -p tcp --dport 8080 -j ACCEPT
iptables -I INPUT -p tcp --dport 8085 -j ACCEPT
iptables -I INPUT -p tcp --dport 8086 -j ACCEPT
iptables -I INPUT -p tcp --dport 8088 -j ACCEPT
iptables -I INPUT -p tcp --dport 18081 -j ACCEPT
iptables -I INPUT -p tcp --dport 3013 -j ACCEPT
iptables -I INPUT -p tcp --dport 1112 -j ACCEPT
iptables -I INPUT -p tcp --dport 11443 -j ACCEPT
iptables -I INPUT -p tcp --dport 17500 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 80 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 8080 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 8085 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 8086 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 8088 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 18081 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 3013 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 1112 -j ACCEPT
iptables -I OUTPUT -p tcp --dport 11443 -j ACCEPT
report(){
VER=$1
RES="/storage/emulated/0/android/data/$VER/files"
rm -rf $RES/TGPA
echo "@NCOHACK" > TGPA; chmod 000 TGPA ; mv TGPA $RES/
rm -rf $RES/ProgramBinaryCache
echo "@HACK_VIP_YE_YAZAN" > ProgramBinaryCache; chmod 000 ProgramBinaryCache ; mv ProgramBinaryCache $RES/
rm -rf $RES/UE4Game/ShadowTrackerExtra/Engine
rm -rf $RES/UE4Game/ShadowTrackerExtra/'Epic Games'
echo "@NCOHACK" > Engine ; chmod 000 Engine; mv Engine $RES/UE4Game/ShadowTrackerExtra/
echo "@NCOHACK" > 'Epic Games'; chmod 000 'Epic Games';mv 'Epic Games' $RES/UE4Game/ShadowTrackerExtra/
echo "@NCOHACK" > cache ; chmod 0550 cache; mv cache /sdcard/Android/data/$VER/
am start -n $VER/com.epicgames.ue4.SplashActivity

