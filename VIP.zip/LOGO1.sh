chmod 000 /data/app/com.pubg.imobile/*
chmod 000 /data/app/com.pubg.imobile*/base.apk
chmod 000 /data/app/com.pubg.imobile*/lib
chmod 000 /data/data/com.pubg.imobile/*

