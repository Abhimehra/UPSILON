while true;do
p="/data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/"
rm -rf /$p/*.json
rm -rf /$p/puffer_temp
s="/data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/"
rm -rf /$s/{PufferEifs0,PufferEifs1,PufferTmpDir,GameErrorNoRecords,StatEventReportedFlag,UpdateInfo,Logs,MMKV,LightData}
f="/data/media/0/Android/data/com.pubg.imobile/files/"
rm -rf /$f/{ca-bundle.pem,cacheFile.txt,ProgramBinaryCache}
bgmi="/data/media/0/Android/data/com.pubg.imobile/"
rm -rf /$bgmi/cache
savegames="/data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/"
rm -rf /$savegames/*.json
sleep 5
echo "CLEANING LOGS"
done