while true;do
rm -rf /data/data/com.pubg.imobile/files/data
touch /data/data/com.pubg.imobile/files/data

rm -rf /data/data/com.pubg.imobile/files/.system_android_l2
touch /data/data/com.pubg.imobile/files/.system_android_l2

rm -rf /data/data/com.pubg.imobile/files/__tsecache.dat
touch /data/data/com.pubg.imobile/files/__tsecache.dat

rm -rf /data/data/com.pubg.imobile/files/AdjustAttribution
touch /data/data/com.pubg.imobile/files/AdjustAttribution

rm -rf /data/data/com.pubg.imobile/files/AdjustIoActivityState
touch /data/data/com.pubg.imobile/files/AdjustIoActivityState

rm -rf /data/data/com.pubg.imobile/files/AdjustIoPackageQueue
touch /data/data/com.pubg.imobile/files/AdjustIoPackageQueue

rm -rf /data/data/com.pubg.imobile/files/apm_cc
touch /data/data/com.pubg.imobile/files/apm_cc

rm -rf /data/data/com.pubg.imobile/files/apm_cc_bak
touch /data/data/com.pubg.imobile/files/apm_cc_bak

rm -rf /data/data/com.pubg.imobile/files/AppEventsLogger.persistedevents
touch /data/data/com.pubg.imobile/files/AppEventsLogger.persistedevents

rm -rf /data/data/com.pubg.imobile/files/hawk_data
touch /data/data/com.pubg.imobile/files/hawk_data

rm -rf /data/data/com.pubg.imobile/files/persisted_config
touch /data/data/com.pubg.imobile/files/persisted_config

rm -rf /data/data/com.pubg.imobile/files/TDM_KV.log.0
touch /data/data/com.pubg.imobile/files/TDM_KV.log.0

rm -rf /data/data/com.pubg.imobile/files/tpnlcache.data
touch /data/data/com.pubg.imobile/files/tpnlcache.data
sleep 5
echo "CLEANING LOGS"
done