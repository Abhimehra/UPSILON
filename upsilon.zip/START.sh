iptables -I INPUT -p all -m string --string "images.metaservices.microsoft.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "images.metaservices.microsoft.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "pandoracdn.itop.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "pandoracdn.itop.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "na.pandora.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "na.pandora.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "pay.igamecj.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "pay.igamecj.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "rov.proximabeta.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "rov.proximabeta.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "gp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "gp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.0.38" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.0.38" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.29.150" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.29.150" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.0.45" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.0.45" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "119.28.121.174" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "119.28.121.174" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "images.metaservices.microsoft.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "images.metaservices.microsoft.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "pandoracdn.itop.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "pandoracdn.itop.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "na.pandora.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "na.pandora.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "pay.igamecj.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "pay.igamecj.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "rov.proximabeta.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "rov.proximabeta.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "gp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "gp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.0.38" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.0.38" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.29.150" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.29.150" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.0.45" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.0.45" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "119.28.121.174" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "119.28.121.174" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "images.metaservices.microsoft.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "images.metaservices.microsoft.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "pandoracdn.itop.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "pandoracdn.itop.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "na.pandora.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "na.pandora.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "pay.igamecj.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "pay.igamecj.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "rov.proximabeta.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "rov.proximabeta.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "gp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "gp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.0.38" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.0.38" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.29.150" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.29.150" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.0.45" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.0.45" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "119.28.121.174" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "119.28.121.174" --algo kmp -j DROP &>/dev/null

rm -rf /data/cache/magisk.log
rm -rf /data/cache/magisk.log.bak

#START BUTTON


su -c iptables -I INPUT -p tcp --dport 8086 -j DROP
su -c iptables -I INPUT -p tcp --dport 8085 -j DROP
su -c iptables -I INPUT -p tcp --dport 90 -j DROP
su -c iptables -I INPUT -p tcp --dport 554 -j DROP
su -c iptables -I INPUT -p tcp --dport 80 -j DROP
su -c iptables -I INPUT -p tcp --dport 443 -j DROP
su -c iptables -I INPUT -p tcp --dport 8013 -j DROP
su -c iptables -I INPUT -p tcp --dport 15692 -j DROP
su -c iptables -I INPUT -p tcp --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 10080 -j DROP
su -c iptables -I INPUT -p tcp --dport 20001 -j DROP
su -c iptables -I INPUT -p tcp --dport 20000 -j DROP
su -c iptables -I INPUT -p tcp --dport 8011 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 20002 -j DROP
su -c iptables -I INPUT -p tcp --dport 17000 -j DROP
su -c iptables -I INPUT -p UDP --dport 8700 -j DROP
su -c iptables -I INPUT -p tcp --dport 20371 -j DROP
su -c iptables -I INPUT -p UDP --dport 9030 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 18600 -j DROP

su -c iptables -I OUTPUT -p tcp --dport 8086 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8085 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 90 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 554 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 80 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 443 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 9031 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10080 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20001 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20002 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 8700 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 9030 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 9031 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18600 -j DROP

