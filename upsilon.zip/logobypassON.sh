
chmod 000 /data/data/com.pubg.krmobile/lib/libUE4.so
chmod 000 /data/data/com.pubg.imobile/lib/libUE4.so
chmod 000 /data/data/com.tencent.ig/lib/libUE4.so




