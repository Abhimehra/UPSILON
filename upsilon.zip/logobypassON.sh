rm -rf /data/data/com.pubg.krmobile/lib/libtersafe.so

cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/h.so /data/data/com.pubg.krmobile/lib/libtersafe.so

rm -rf /data/data/com.tencent.ig/lib/libtersafe.so

cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/h.so /data/data/com.tencent.ig/lib/libtersafe.so

chmod 755 /data/data/com.pubg.krmobile/lib/*
chmod 755 /data/data/com.pubg.krmobile/lib*/
chmod 755 /data/data/com.tencent.ig/lib/*
chmod 755 /data/data/com.tencent.ig/lib*/

sleep 1

chmod 000 /data/data/com.pubg.krmobile/lib/libUE4.so
chmod 000 /data/data/com.pubg.imobile/lib/libUE4.so
chmod 000 /data/data/com.tencent.ig/lib/libUE4.so




