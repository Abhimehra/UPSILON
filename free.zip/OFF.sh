iptables -F
iptables --flush
iptables -X
iptables -F
iptables -F
iptables --flush
iptables --flush
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -F
iptables -t nat -F
iptables -t mangle -F
iptables -X
iptables --flush
iptables -F
iptables --flush
iptables -F
iptables -X

sleep 2

chmod 777 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
chmod 777 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
chmod 777 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
sleep 1
# gl
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/playerprefs.json
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/NewPlayerprefsSwitcher.json
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/MailPhoneLogin.json
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/loginInfoFile.json
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GA.json
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/AgreeIllegalAvatarRule.json
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/BatchButtonClickLog_0.json
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/apollo_loglist.json
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/apollo_uuid_define.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Coverversion.ini
chmod 770 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
#kr
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/playerprefs.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/NewPlayerprefsSwitcher.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/MailPhoneLogin.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/loginInfoFile.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GA.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/AgreeIllegalAvatarRule.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/BatchButtonClickLog_0.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/apollo_loglist.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/apollo_uuid_define.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Coverversion.ini
chmod 770 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
#bgmi
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/playerprefs.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/NewPlayerprefsSwitcher.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/MailPhoneLogin.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/loginInfoFile.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GA.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/AgreeIllegalAvatarRule.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/BatchButtonClickLog_0.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/apollo_loglist.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/apollo_uuid_define.json
chmod 660 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Coverversion.ini
chmod 770 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved


sleep 1 

killall com.tencent.ig >/dev/null 2>/dev/null
killall com.pubg.imobile >/dev/null 2>/dev/null
killall com.pubg.imobile >/dev/null 2>/dev/null
killall com.vng.pubgmobile >/dev/null 2>/dev/null

alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"
alias T="touch"
gl="/data/data/com.pubg.imobile"
kr="/data/data/com.pubg.imobile"
Vn="/data/data/com.vng.pubgmobile"
Tw="/data/data/com.pubg.imobile"
export PKG="com.pubg.imobile"
 rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{game_patch_*.pak,res_pufferpatch*.pak,Core_patch_*.pak}
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/{LightData,SrcVersion.ini,Updater.ini,UserLogSuppression.ini}
pm install /data/app/$PKG*/base.apk >/dev/null 2>/dev/null
export PKG="com.pubg.imobile"
 rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{game_patch_*.pak,res_pufferpatch*.pak,Core_patch_*.pak}
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/{LightData,SrcVersion.ini,Updater.ini,UserLogSuppression.ini}
pm install /data/app/$PKG*/base.apk >/dev/null 2>/dev/null
export PKG="com.tencent.ig"
 rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{game_patch_*.pak,res_pufferpatch*.pak,Core_patch_*.pak}
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/{LightData,SrcVersion.ini,Updater.ini,UserLogSuppression.ini}
pm install /data/app/$PKG*/base.apk >/dev/null 2>/dev/null
E "Flushing iptables rules"
su -c iptables --flush


echo ""
date
getprop ro.product.brand
getprop ro.product.model
sleep 1
echo ""
echo "[5;34m------------------- Ⓜ️|HACK| -------------------"
echo "[5;34m Creator and developer in telegram: @Gxghost"
echo "[5;34m------------------- Ⓜ️|HACK| -------------------"
sleep 1
echo ""
echo ""
echo ""
echo "[5;33m ENABLE PUBGM ANTICHEAT SYSTEM"
echo "[5;33m............................"
sleep 1
GL=com.pubg.imobile
DIR=/storage/emulated/0/Android/data/$GL/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
MAIN=/storage/emulated/0/Android/data/$GL
am force-stop $GL
pkill $GL
iptables --flush
chmod 777 $DIR/SrcVersion.ini
chmod 777 $DIR/Paks
rm -f $DIR/Config/Android/Updater.ini
rm -f $DIR/Paks/core_patch_1.6.0.15566.pak
rm -f /data/cache/magisk.log;
rm -f /data/cache/magisk.log.bak;
sleep 0.5
echo ""
echo ""
echo "[5;32m PUBGM RESTORED SUCCESSFULLY ✅"
echo "[5;32m................"
echo ""


