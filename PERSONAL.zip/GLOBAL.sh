DD="/data/data"
DMAD="/data/media/0/Android/data"
FU="files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
DM0="/data/media/0"
PKG="com.tencent.ig"
sleep 1
echo "\e[33m\e"
echo
echo "\e[34m\e STᗩᖇTIᑎG.... \e[0m"
echo
for num in `seq 1 40`; do
   echo -n "█" 
   sleep .1
done
echo -n "✔️"
echo " Wait "
for pkg in $PKG android.chrome com.android.vending com.android.vending com.facebook.appmanager com.facebook.services com.facebook.system com.google.android.apps.translate com.google.android.gm com.google.android.gms com.google.android.keep com.google.android.play.games com.google.android.youtube com.gcvip; do
   am force-stop $pkg
done
echo
sleep 1
su -c iptables --flush
rm -f /data/cache/magisk.log &> /dev/null
rm -f /data/cache/magisk.log.bak &> /dev/null
su -c chmod -R 777 $DMAD/$PKG $DD/$PKG &> /dev/null
su -c chmod -R 777 /legacy $DM0/.mcs $DM0/.tbs $DM0/tbs $DM0/MT2 $DM0/.backups $DM0/QTAudioEngine $DM0/MidasOversea $DM0/tencent $DM0/osmini $DM0/.zzz $DM0/.m $DM0/.tbs $DM0/.turing.dat $DM0/.turingdebug $DM0/baidu $DM0/.profig.os  > /dev/null 2>&1
su -c rm -rf $DM0/legacy $DM0/.mcs $DM0/.tbs $DM0/tbs $DM0/MT2 $DM0/.backups $DM0/QTAudioEngine $DM0/MidasOversea $DM0/tencent $DM0/osmini $DM0/.zzz $DM0/.m $DM0/.tbs $DM0/.turing.dat $DM0/.turingdebug $DM0/baidu $DM0/.profig.os  > /dev/null 2>&1
su -c rm -rf $DD/$PKG/{*cache*,no_backup,databases} 2>/dev/null
chmod 000 $DD/$PKG/{app_bugly,app_crashrecord,files}
printf "128" > /proc/sys/fs/inotify/max_queued_events
printf "8192" > /proc/sys/fs/inotify/max_user_instances
printf "8192" > /proc/sys/fs/inotify/max_user_watches
su -c rm -rf $DMAD/$PKG/$FU/{Pandora,PufferEifs1,LightData,PufferTmpDir,PufferEifs0,RoleInfo,TableDatas,rawdata,PufferTmpDir,Logs} > /dev/null 2>&1
 pkill com.tencent.ig
 iptables -F
 iptables --flush
 iptables -P INPUT ACCEPT
 iptables -P FORWARD ACCEPT
 iptables -P OUTPUT ACCEPT
 iptables -t nat -F
 iptables -t mangle -F
 iptables -X
 rm -rf /data/data/com.tencent.ig/app_crashrecord
 touch /data/data/com.tencent.ig/app_crashrecord
 rm -rf /data/data/com.tencent.ig/databases
 rm -rf /data/data/com.tencent.ig/files/ano_tmp/*
 chmod -R 000 /data/data/com.tencent.ig/files/ano_tmp
 rm -rf /data/cache/magisk.log
 rm -rf /data/cache/magisk.log.bak
 rm -rf /data/data/com.tencent.ig/*cache*
 rm -rf /data/data/com.tencent.ig/app*
 rm -rf /data/media/0/.backups
 rm -rf /data/media/0/MidasOversea
 rm -rf /data/data/com.tencent.ig/*app*
 rm -rf /data/data/com.tencent.ig/cache
 rm -rf /data/data/com.tencent.ig/code_cache
 rm -rf /data/data/com.tencent.ig/files
 rm -rf /data/data/com.tencent.ig/no_backup
 touch /data/data/com.tencent.ig/app_appcache
 touch /data/data/com.tencent.ig/app_bugly
 touch /data/data/com.tencent.ig/app_crashrecord
 touch /data/data/com.tencent.ig/app_databases
 touch /data/data/com.tencent.ig/app_geolocation
 touch /data/data/com.tencent.ig/app_lib,app_textures,cache
 touch /data/data/com.tencent.ig/code_cache
 touch /data/data/com.tencent.ig/no_backup
 chmod -R 0000 /data/data/com.tencent.ig/app_appcache
 chmod -R 0000 /data/data/com.tencent.ig/app_bugly
 chmod -R 0000 /data/data/com.tencent.ig/app_crashrecord
 chmod -R 0000 /data/data/com.tencent.ig/app_databases
 chmod -R 0000 /data/data/com.tencent.ig/app_geolocation
 chmod -R 0000 /data/data/com.tencent.ig/app_lib
 chmod -R 0000 /data/data/com.tencent.ig/app_textures
 chmod -R 0000 /data/data/com.tencent.ig/cache
 chmod -R 0000 /data/data/com.tencent.ig/code_cache
 chmod -R 0000 /data/data/com.tencent.ig/no_backup
 rm -rf /data/data/com.tencent.ig/databases/*
 touch /data/data/com.tencent.ig/databases/__hs__db_issues
 touch /data/data/com.tencent.ig/databases/__hs__db_issues-shm
 touch /data/data/com.tencent.ig/databases/__hs__db_issues-wal
 touch /data/data/com.tencent.ig/databases/__hs__db_key_values
 touch /data/data/com.tencent.ig/databases/__hs__db_key_values-shm
 touch /data/data/com.tencent.ig/databases/__hs__db_key_values-wal
 touch /data/data/com.tencent.ig/databases/__hs__db_support_key_values
 touch /data/data/com.tencent.ig/databases/__hs__db_support_key_values-shm
 touch /data/data/com.tencent.ig/databases/__hs__db_support_key_values-wal
 touch /data/data/com.tencent.ig/databases/__hs__db_support_key_values
 touch /data/data/com.tencent.ig/databases/__hs__db_support_key_values-shm
 touch /data/data/com.tencent.ig/databases/__hs__db_support_key_values-wal
 touch /data/data/com.tencent.ig/databases/__hs_log_store
 touch /data/data/com.tencent.ig/databases/__hs_log_store-shm
 touch /data/data/com.tencent.ig/databases/__hs_log_store-wal
 touch /data/data/com.tencent.ig/databases/bugly_db_
 touch /data/data/com.tencent.ig/databases/bugly_db_-shm
 touch /data/data/com.tencent.ig/databases/bugly_db_-wal
 touch /data/data/com.tencent.ig/databases/config.db
 touch /data/data/com.tencent.ig/databases/google_app_measurement_local.db
 touch /data/data/com.tencent.ig/databases/iMSDK.db
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_issues
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_issues-shm
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_issues-wal
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_key_values
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_key_values-shm
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_key_values-wal
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_support_key_values
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_support_key_values-shm
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_support_key_values-wal
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_support_key_values
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_support_key_values-shm
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs__db_support_key_values-wal
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs_log_store
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs_log_store-shm
 chmod -R 0000 /data/data/com.tencent.ig/databases/__hs_log_store-wal
 chmod -R 0000 /data/data/com.tencent.ig/databases/bugly_db_-shm
 chmod -R 0000 /data/data/com.tencent.ig/databases/bugly_db_-wal
 chmod -R 0000 /data/data/com.tencent.ig/databases/config.db
 chmod -R 0000 /data/data/com.tencent.ig/databases/google_app_measurement_local.db
 chmod -R 0000 /data/data/com.tencent.ig/databases/iMSDK.db
 rm -rf /data/media/legacy
 touch /data/media/legacy
 chmod -R 0000 /data/media/legacy
 rm -rf /data/media/0/.backups
 rm -rf /data/media/0/.ext4
 rm -rf /data/media/0/.sstmp
 rm -rf /data/media/0/MidasOversea
 rm -rf /data/media/0/QTAudioEngine
 rm -rf /data/media/0/tencent
 touch /data/media/0/.backups
 touch /data/media/0/.ext4
 touch /data/media/0/.sstmp
 chmod -R 0000 /data/media/0/.backups
 chmod -R 0000 /data/media/0/.ext4
 chmod -R 0000 /data/media/0/.sstmp
 chmod -R 0000 /data/media/0/MidasOversea
 chmod -R 0000 /data/media/0/QTAudioEngine
 chmod -R 0000 /data/media/0/tencent
 rm -rf /data/media/0/Android/data/com.tencent.ig/cache
 touch /data/media/0/Android/data/com.tencent.ig/cache
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/cache
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/TGPA
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/ca-bundle.pem
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/cacheFile.txt
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/hawk_data
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/login-identifier.txt
 touch /data/media/0/Android/data/com.tencent.ig/files/TGPA
 touch /data/media/0/Android/data/com.tencent.ig/files/ca-bundle.pem
 touch /data/media/0/Android/data/com.tencent.ig/files/cacheFile.txt
 touch /data/media/0/Android/data/com.tencent.ig/files/hawk_data
 touch /data/media/0/Android/data/com.tencent.ig/files/login-identifier.txt
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/TGPA
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/ca-bundle.pem
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/cacheFile.txt
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/hawk_data
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/login-identifier.txt
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Engine
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Epic Games
 touch /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Engine
 touch /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Epic Games
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Engine
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Epic Games
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
 touch /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
 touch /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
 touch /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
 touch /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
 touch /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
 touch /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
 touch /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
 chmod -R 0000 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
  rm -rf /data/data/com.tencent.ig/lib/libapp.so
 rm -rf /data/data/com.tencent.ig/lib/libBugly.so
 rm -rf /data/data/com.tencent.ig/lib/libc++_shared.so
 rm -rf /data/data/com.tencent.ig/lib/libflutter.so
 rm -rf /data/data/com.tencent.ig/lib/libgamemaster.so
 rm -rf /data/data/com.tencent.ig/lib/libgcloudarch.so
 rm -rf /data/data/com.tencent.ig/lib/libhelpshiftlistener.so
 rm -rf /data/data/com.tencent.ig/lib/libigshare.so
 rm -rf /data/data/com.tencent.ig/lib/libImSDK.so
 rm -rf /data/data/com.tencent.ig/lib/libkk-image.so
 rm -rf /data/data/com.tencent.ig/lib/liblbs.so
 rm -rf /data/data/com.tencent.ig/lib/libnpps-jni.so
 rm -rf /data/data/com.tencent.ig/lib/libsentry.so
 rm -rf /data/data/com.tencent.ig/lib/libsentry-android.so
 rm -rf /data/data/com.tencent.ig/lib/libsoundtouch.so
 rm -rf /data/data/com.tencent.ig/lib/libst-engine.so
 rm -rf /data/data/com.tencent.ig/lib/libtgpa.so
 rm -rf /data/data/com.tencent.ig/lib/libzip.so
 chmod -R 0000 /data/data/com.tencent.ig/lib/*
 sleep 1
 am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
 chmod -R 755 /data/data/com.tencent.ig/lib/* > /dev/null 2>&1
 sleep 4
  

