su -c iptables --flush
pm install /data/app/com.pubg.imobile*/base.apk
