clear
DD="/data/data"
DMAD="/data/media/0/Android/data"
FU="files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
DM0="/data/media/0"
PKG="com.pubg.imobile"
echo
sleep 1
su -c iptables --flush
rm -f /data/cache/magisk.log &> /dev/null
rm -f /data/cache/magisk.log.bak &> /dev/null
su -c chmod -R 777 $DMAD/$PKG $DD/$PKG &> /dev/null
su -c chmod -R 777 /legacy $DM0/.mcs $DM0/.tbs $DM0/tbs $DM0/MT2 $DM0/.backups $DM0/QTAudioEngine $DM0/MidasOversea $DM0/tencent $DM0/osmini $DM0/.zzz $DM0/.m $DM0/.tbs $DM0/.turing.dat $DM0/.turingdebug $DM0/baidu $DM0/.profig.os  > /dev/null 2>&1
su -c rm -rf $DM0/legacy $DM0/.mcs $DM0/.tbs $DM0/tbs $DM0/MT2 $DM0/.backups $DM0/QTAudioEngine $DM0/MidasOversea $DM0/tencent $DM0/osmini $DM0/.zzz $DM0/.m $DM0/.tbs $DM0/.turing.dat $DM0/.turingdebug $DM0/baidu $DM0/.profig.os  > /dev/null 2>&1
su -c rm -rf $DD/$PKG/{*cache*,no_backup,databases} 2>/dev/null
chmod 000 $DD/$PKG/{app_bugly,app_crashrecord,files}
printf "128" > /proc/sys/fs/inotify/max_queued_events
printf "8192" > /proc/sys/fs/inotify/max_user_instances
printf "8192" > /proc/sys/fs/inotify/max_user_watches
PKG="com.pubg.krmobile"
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
rm -rf /data/data/$PKG/{f*,a*,c*}
su -c am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity &> /dev/null
sleep 7
chmod 000 /data/app/com.pubg.imobile*/lib/arm64/libUE4.so
chmod 000 /data/app/com.pubg.imobile*/lib/arm64/libtprt.so
sleep 15
chmod 755 /data/app/com.pubg.imobile*/lib/arm64/libUE4.so
chmod 755 /data/app/com.pubg.imobile*/lib/arm64/libtprt.so
chmod 777 /data/media/0/Android/data/com.pakage.upsilon/files/BEAST
exec /data/media/0/Android/data/com.pakage.upsilon/files/BEAST BEAST
