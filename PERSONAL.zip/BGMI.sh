
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/EnjoyCJZC.ini 
echo '[FansSwitcher]
+CVars=r.PUBGMaxSupportQualityLevel=NULL
+CVars=r.PUBGDeviceFPSLow=60
+CVars=r.PUBGDeviceFPSMid=60
+CVars=r.PUBGDeviceFPSHigh=60
+CVars=r.PUBGDeviceFPSHDR=60
+CVars=r.PUBGMSAASupport=NULL
+CVars=r.PUBGLDR=NULL
[BaseNameProfile]
+CVars=3E1815181A0D101A0A
[FansCustom]
+CVars=0B5734161B10151C3A16170D1C170D2A1A18151C3F181A0D160B4449574F49
+CVars=0B572C0A1C0B313D2B2A1C0D0D10171E444D
+CVars=0B573D1C1F180C150D3F1C180D0C0B1C5738170D10381510180A10171E44495749
+CVars=0B5734161B10151C313D2B44495749574D
+CVars=0B5734161B10151C342A383844485749
+CVars=0B572A11181D160E573D100A0D18171A1C2A1A18151C44495749574A
+CVars=0B573D1C0D18101534161D1C44495749574A
+CVars=0B573418013817100A160D0B160900444157495741
+CVars=0B573D1C090D11361F3F101C151D280C1815100D0044495749574B
+CVars=0B572A0D0B1C181410171E57291616152A10031C4449
+CVars=0B5729180B0D101A151C35363D3B10180A44495749574A
+CVars=0B57292C3B3E2F1C0B0A101617444C5749574C
+CVars=1F161510181E1C5735363D3D100A0D18171A1C2A1A18151C4449574F5749
+CVars=0B5734161B10151C572A1A1C171C3A1615160B3F160B14180D444B5749574B
+CVars=0B572A11181D160E573418013A2A342B1C0A16150C0D101617444D57495741
+CVars=0B5734161B10151C573D00171814101A361B131C1A0D2A11181D160E44495749574A
+CVars=0B5734161B10151C573D00171814101A361B131C1A0D2A11181D160E44495749574A
+CVars=0B572A11181D160E573A2A345734180134161B10151C3A180A1A181D1C0A44495749574B
+CVars=0B5734161B10151C370C143D00171814101A291610170D35101E110D0A444957495748
+CVars=0B5734161B10151C2A101409151C2A11181D1C0B44495749574F
+CVars=0B572C0A1C0B342A38382A1C0D0D10171E44495749
+CVars=0B572C0A1C0B280C1815100D002A1C0D0D10171E4449
+CVars=0B572C0A1C0B2A11181D160E2A0E100D1A114448
+CVars=0B572A11181D160E280C1815100D004449
+CVars=0B5734180D1C0B101815280C1815100D00351C0F1C154449574B5749
[FansEngine]
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E3538343D1A1614090B1C0A0A1C1D382D3A0D1C010D0C0B1C
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E3538343D090B161E0B18141B1017180B00234D4949
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E353C202D0D1C010D0C0B1C1A1614090B1C0A0A1016171D010D48
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E353C202D0D1C010D0C0B1C1A1614090B1C0A0A10161715180D1A
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E353C202D0D1C010D0C0B1C1A1614090B1C0A0A1016170B1E0D1A
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E353C202D0D1C010D0C0B1C1A1614090B1C0A0A1016170A4A0D1A
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E353C202D0D1C010D0C0B1C1F10150D1C0B1817100A160D0B1609101A
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E353C202D0D1C010D0C0B1C1F160B14180D3B3E2B3841414141
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E3510362A0C150D0B180D1C010D0C0B1C
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E35363C2A1A1614090B1C0A0A1C1D3C2D3A482B3E3B410D1C010D0C0B1C
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E3538343D1A1614090B1C0A0A1C1D382D3A0D1C010D0C0B1C
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E3538343D1A1614090B1C0A0A1C1D382D3A0D1C010D0C0B1C
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E3538343D090B161E0B18141B1017180B00234D4949
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E3538343D1A1614090B1C0A0A1C1D382D3A0D1C010D0C0B1C
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E35363C2A1A1614090B1C0A0A1C1D3C2D3A482B3E3B410D1C010D0C0B1C
+CVars=0B5736091C173E35572A0D0B10093C010D1C170A1016170A443E3538343D1A1614090B1C0A0A1C1D382D3A0D1C010D0C0B1C
+CVars=3E35382929353C1A1615160B1B0C1F1F1C0B09181A121C1D1F1516180D
+CVars=3E35382929353C1B10180A1C1D1F10011C1D091610170D1014181E1C1F160B14180D0A
+CVars=3E35382929353C1A150C0D
+CVars=3E35382929353C3A16170D1C010D35161E1E10171E3F0C171A0D1016170A
+CVars=3E35382929353C1C010D08484A
+CVars=3E35382929353C1F10011C1D18150911181A111817171C15160B1D1C0B0A
+CVars=3E35382929353C1E150A11180B10171E
+CVars=3E35382929353C080C1C0B00121C0B171C151718141C0A
+CVars=3E35382929353C2A1C0D341C14361B131C1A0D3D1C0A0D0B0C1A0D160B
+CVars=3E3538343D1A1614090B1C0A0A1C1D382D3A0D1C010D0C0B1C
+CVars=3E3538343D090B161E0B18141B1017180B00
+CVars=3E3538343D1A1614090B1C0A0A1C1D382D3A0D1C010D0C0B1C
+CVars=3E3538343D090B161E0B18141B1017180B00
+CVars=3E3538343D1A1614090B1C0A0A1C1D382D3A0D1C010D0C0B1C
+CVars=3E3538343D090B161E0B18141B1017180B00
+CVars=3E3538343D0D1C010D0C0B1C1A1614090B1C0A0A1016170A4A0D1A
+CVars=3E3538343D0D1C010D0C0B1C180B0B1800
+CVars=3E3538343D0D1C010D0C0B1C1A1614090B1C0A0A1016170A4A0D1A
+CVars=3E35372F1D1C090D111716171510171C180B' > /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/EnjoyCJZC.ini
echo "WAIT "
sleep 3
echo "PLEASE WAIT...."
sleep 1
echo "KEEP MT MANAGER IN THE BACKGROUND"
sleep 3
sleep 3
cd /data/data/com.pubg.imobile && rm -rf app_crashrecord && echo > app_crashrecord
sleep 3
echo " 3"
echo " LETS GO"
echo " Start Bypassing "
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
date
echo '128' > /proc/sys/fs/inotify/max_user_instances
echo '8192' > /proc/sys/fs/inotify/max_user_watches
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
rm -rf /data/data/com.pubg.imobile/app_appcache
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/app_bugly
rm -rf /data/data/com.pubg.imobile/no_backup
rm -rf /data/data/com.pubg.imobile/shared_prefs
rm -rf /data/data/com.pubg.imobile/app_webview
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/app_textures
rm -rf /data/data/com.pubg.imobile/app_crashrecord
rm -rf /data/data/com.pubg.imobile/code_cache
rm -rf /data/data/com.pubg.imobile/app_webview_imsdk_inner_webview
rm -rf /data/data/com.pubg.imobile/files/app
rm -rf /data/data/com.pubg.imobile/files/data
rm -rf /data/data/com.pubg.imobile/files/hawk_data_init
rm -rf /data/data/com.pubg.imobile/files/iMSDK
rm -rf /data/data/com.pubg.imobile/files/local_crash_lock
rm -rf /data/data/com.pubg.imobile/files/ss_tmp
rm -rf /data/data/com.pubg.imobile/files/TAPM_CM_AUDIT
alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"
E
E
E
E "\033[1;37m                _______________________  \033[0m"
E "\033[1;37m                 \033[41m  𝐃𝐄𝐈𝐙𝐙𝐄𝐑 𝐕𝐈𝐏   \033[0m"
E "\033[1;37m                ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾  \033[0m"
S 1
E -n "𝙳𝙰𝚃𝙴 ��𝙽�� 𝚃𝙸𝙼𝙴: "
date "+%a %d %b %Y %Z %H:%M:%S"
S 1
E -n "𝙲𝙾𝚄𝙽𝚃𝚁𝚈: "
getprop gsm.operator.iso-country
S 1
E -n "𝙳𝙴𝚅𝙸𝙲𝙴 ��𝚁��𝙽��: "
getprop ro.product.brand
S 1
E -n "𝙳𝙴𝚅𝙸𝙲𝙴 ��𝙾��𝙴��: "
getprop ro.product.model
E ki
E 𝙼𝙰𝙳𝙴 ��𝚈 @ROHAN_OP
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
pm path com.pubg.imobile &> /dev/null
killall com.pubg.imobile 2&> /dev/null
DUMP() {
pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
lib=`ls -mR $(DUMP com.pubg.imobile legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v sosna`
SAVE(){
cp $lib/$1 $lib/$1.bak
}
RETURN(){
mv $lib/$1.bak $lib/$1
}
SP -R 755 /data/data/com.pubg.imobile/lib/*
SP 755 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
touch /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak
cp -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.76262.pak
R /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
E '[version]
appversion=1.7.0.15710
srcversion=1.7.0.27799' >> /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
R /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
SP 550 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
SP 555 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
R /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
E " null " >> /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
cp /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
R /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
R /data/cache/magisk.log
R /data/cache/magisk.log.bak
SP 755 /data/data/com.pubg.imobile/lib/*
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
R /sdcard/Android/data/com.pubg.imobile/files/TGPA
R /sdcard/Android/data/com.pubg.imobile/cache
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
R /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
R /data/media/0/ꜰᴜᴄᴋᴘᴜʙɢᴀɴᴛɪᴄʜᴇᴀᴛ
mkdir /data/media/0/ꜰᴜᴄᴋᴘᴜʙɢᴀɴᴛɪᴄʜᴇᴀᴛ
SP -R 755 /data/data/com.pubg.imobile/lib/*
R $lib/{libzip.so,libBugly.so,libgamemaster.so,libgcloudarch.so,libhelpshiftlistener.so,libigshare.so,liblbs.so-libnpps-jni.so,libst-engine.so,libtgpa.so}
SP -R 755 /data/data/com.pubg.imobile/lib/*
SAVE libtprt.so
SAVE libUE4.so
E
E -ne '                   \033[1;37m  □□□□□□□□□□0% \r'
S 0.1
E -ne '                   \033[1;31m  ■□□□□□□□□□10% \r'
S 0.1
E -ne '                   \033[1;31m  ■■□□□□□□□□20% \r'
S 0.1
E -ne '                   \033[1;33m  ■■■□□□□□□□30% \r'
S 0.1
E -ne '                   \033[1;33m  ■■■■□□□□□□40% \r'
S 0.1
E -ne '                   \033[1;33m  ■■■■■□□□□□50% \r'
S 0.1
E -ne '                   \033[1;36m  ■■■■■■□□□□60% \r'
S 0.1
E -ne '                   \033[1;36m  ■■■■■■■□□□70% \r'
S 0.1
E -ne '                   \033[1;36m  ■■■■■■■■□□80% \r'
S 0.1
E -ne '                   \033[1;32m  ■■■■■■■■■□90% \r'
S 0.1
E -ne '                   \033[1;32m  ■■■■■■■■■■100% \r'
S 0.1
E -ne '                   \033[1;32m  🥃🇩 🇪 🇮 🇿 🇿 🇪 🇷  🇨 🇭 🇪 🇦 🇹 ⚡ \r'
S 0.1
E -ne ' \n'
E "                   \033[0m"
am force-stop com.pubg.imobile
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/shared_prefs
rm -rf /data/data/com.pubg.imobile/app_bugly
rm -rf /data/data/com.pubg.imobile/app_crashrecord
rm -rf /data/data/com.pubg.imobile/no_backup
echo " [⚡ ʀᴏʜᴀɴ ᴏᴘ ʙᴏʟᴛᴇ ⚡]\n\n\ 𝗔𝗡𝗧𝗜 𝗖��𝗘��𝗧 𝗣𝗔𝗧𝗖𝗛𝗘𝗜𝗡𝗚 \n\n\n⚡ ��𝙰��𝙴 𝙱𝚈 ℝ𝕆ℍ𝔸ℕ 𝕆ℙ "
S 3
echo " [⚡ ᴅᴇɪᴢᴢᴇʀ ᴄʜᴇᴀᴛ ⚡]\n\n\ 𝙋𝙐𝘽𝙂 𝙈��𝘽��𝙇�� 𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂\n\n\ "
echo " [⚡ ᴅᴇɪᴢᴢᴇʀ ᴄʜᴇᴀᴛ ⚡]\n\n\ 𝙋𝙐𝘽𝙂 𝙈��𝘽��𝙇�� 𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂\n\n\n⚡ 𝙼𝙰𝙳𝙴 ��𝚈 𝔻𝕖𝕚𝕫𝕫𝕖𝕣 ℂ𝕙𝕖𝕒𝕥 "
S 3
am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity > /dev/null
S 3.5
ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables
uptime
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
iptables --flush
iptables -F
S 7
R $lib/{libUE4.so,libtprt.so}
S 3
RETURN libtprt.so
RETURN libUE4.so
SP 755 /data/data/com.pubg.imobile/lib/*
SP 550 /data/data/com.pubg.imobile/files
R /data/data/com.pubg.imobile/files/*
S 0.5
touch /data/data/com.pubg.imobile/files/ano_tmp
SP 000 /data/data/com.pubg.imobile/files/ano_tmp
SP 550 /data/data/com.pubg.imobile/files
R /data/data/com.pubg.imobile/app_crashrecord
touch /data/data/com.pubg.imobile/app_crashrecord
S 1
R /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/Android/Updater.ini
echo "done"
