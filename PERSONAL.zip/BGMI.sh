clear
DD="/data/data"
DMAD="/data/media/0/Android/data"
FU="files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
DM0="/data/media/0"
PKG="com.pubg.imobile"
echo
sleep 1
su -c iptables --flush
rm -f /data/cache/magisk.log &> /dev/null
rm -f /data/cache/magisk.log.bak &> /dev/null
su -c chmod -R 777 $DMAD/$PKG $DD/$PKG &> /dev/null
su -c chmod -R 777 /legacy $DM0/.mcs $DM0/.tbs $DM0/tbs $DM0/MT2 $DM0/.backups $DM0/QTAudioEngine $DM0/MidasOversea $DM0/tencent $DM0/osmini $DM0/.zzz $DM0/.m $DM0/.tbs $DM0/.turing.dat $DM0/.turingdebug $DM0/baidu $DM0/.profig.os  > /dev/null 2>&1
su -c rm -rf $DM0/legacy $DM0/.mcs $DM0/.tbs $DM0/tbs $DM0/MT2 $DM0/.backups $DM0/QTAudioEngine $DM0/MidasOversea $DM0/tencent $DM0/osmini $DM0/.zzz $DM0/.m $DM0/.tbs $DM0/.turing.dat $DM0/.turingdebug $DM0/baidu $DM0/.profig.os  > /dev/null 2>&1
clear

ver(){
chmod 2775 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks &> /dev/null


}


su -c iptables --flush

su -c rm -rf /data/data/libtersafe &> /dev/null
su -c rm -rf /data/data/libtersafe.so &> /dev/null
su -c rm -rf /data/media/lib &> /dev/null
su -c rm -rf /data/media/lib.gz &> /dev/null
su -c rm -rf /data/data/libtersafe.zip &> /dev/null
su -c rm -rf /data/data/libtersafe.gz &> /dev/null

XRED='\e[31m\e'
XGREEN='\e[32m\e'
XYELLOW='\e[33m\e'
XBLUE='\e[34m\e'
XYCYAN='\e[36m\e'
    OG="[91m"
    MG="\e[95m"
    CY="\e[96m"
    NORMAL=`echo "[m"`
    MENU=`echo "[36m"`
    NUMBER=`echo "[93m"` 
    FGRED=`echo "[35m"`
    RED_TEXT=`echo "[92m"`
    ENTER_LINE=`echo "[93m"`

su -c iptables --flush
PKG="com.pubg.imobile"
LOGO="/data/data/com.pubg.imobile/files/ano_tmp"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
echo wait
rm -rf /data/data/com.pubg.imobile/files/ano_tmp
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
while [ ! -d $LOGO ]; do sleep 0.01; done
BGMI="/data/data/com.pubg.imobile/app_crashrecord"
bugly="/data/data/com.pubg.imobile/app_bugly"
database="/data/data/com.pubg.imobile/databases"
files="/data/data/com.pubg.imobile/files"
rm -rf $files
rm -rf $bugly
rm -rf $BGMI
rm -rf $database
touch $files
touch $bugly
touch $BGMI
touch $database
chmod 000 $files
chmod 000 $BGMI
chmod 000 $bugly
chmod 000 $database
mv $lib/{libtersafe.so,1}
mv $lib/{libUE4.so,2}
mv $lib/{libtprt.so,3}
mv $lib/{libTDataMaster.so,4}
mv $lib/{libgcloud.so,5}
mkdir $lib/libtersafe.so
mkdir $lib/libTDataMaster.so
echo done