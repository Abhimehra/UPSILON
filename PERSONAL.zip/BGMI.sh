DD="/data/data"
DMAD="/data/media/0/Android/data"
FU="files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
DM0="/data/media/0"
PKG="com.pubg.imobile"
for pkg in $PKG android.chrome com.android.vending com.android.vending com.facebook.appmanager com.facebook.services com.facebook.system com.google.android.apps.translate com.google.android.gm com.google.android.gms com.google.android.keep com.google.android.play.games com.google.android.youtube com.gcvip; do
   am force-stop $pkg
done
echo
sleep 1
su -c iptables --flush
rm -f /data/cache/magisk.log &> /dev/null
rm -f /data/cache/magisk.log.bak &> /dev/null
su -c chmod -R 777 $DMAD/$PKG $DD/$PKG &> /dev/null
su -c chmod -R 777 /legacy $DM0/.mcs $DM0/.tbs $DM0/tbs $DM0/MT2 $DM0/.backups $DM0/QTAudioEngine $DM0/MidasOversea $DM0/tencent $DM0/osmini $DM0/.zzz $DM0/.m $DM0/.tbs $DM0/.turing.dat $DM0/.turingdebug $DM0/baidu $DM0/.profig.os  > /dev/null 2>&1
su -c rm -rf $DM0/legacy $DM0/.mcs $DM0/.tbs $DM0/tbs $DM0/MT2 $DM0/.backups $DM0/QTAudioEngine $DM0/MidasOversea $DM0/tencent $DM0/osmini $DM0/.zzz $DM0/.m $DM0/.tbs $DM0/.turing.dat $DM0/.turingdebug $DM0/baidu $DM0/.profig.os  > /dev/null 2>&1
su -c rm -rf $DD/$PKG/{*cache*,no_backup,databases} 2>/dev/null
chmod 000 $DD/$PKG/{app_bugly,app_crashrecord,files}
printf "128" > /proc/sys/fs/inotify/max_queued_events
printf "8192" > /proc/sys/fs/inotify/max_user_instances
printf "8192" > /proc/sys/fs/inotify/max_user_watches
su -c rm -rf $DMAD/$PKG/$FU/{Pandora,PufferEifs1,LightData,PufferTmpDir,PufferEifs0,RoleInfo,TableDatas,rawdata,PufferTmpDir,Logs} > /dev/null 2>&1
sleep 1
export PKG="com.pubg.imobile"
export LIB="/data/data/$PKG/lib/"
export SD="/sdcard"
export SAVE="/data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
rm -rf mkdir $SD/BB
mkdir $SD/BB
sleep .5
mv $SAVE/Paks/game_patch_* $SD/BB
mv $SAVE/Paks/core_patch_* $SD/BB
rm -rf $SAVE/SrcVersion.ini
rm -rf $SAVE/Android/Updater.ini
echo '[version]
appversion=1.7.0.15710
srcversion=1.7.0.27779' >> $SAVE/SrcVersion.ini
rm -rf $SAVE/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 555 $SAVE/SrcVersion.ini
chmod 555 $SAVE/Paks
rm -rf $SAVE/LightData
mkdir $SAVE/LightData
echo "
kkk3o" >> $SAVE/LightData3036393187.ltz
cp $SAVE/LightData3036393187.ltz $SAVE/LightData
rm -rf $SAVE/LightData3036393187.ltz
echo '[/Script/Client.GDolphinUpdater]
Disable=true
' >> $SAVE/Android/Updater.ini
PKG=com.pubg.imobile
data=/data/data/$PKG
lib=$data/lib
Saved=/storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
cp $lib/libtprt.so $lib/libtprt.so.bak
cp $lib/libUE4.so $lib/libUE4.so.bak
cp $lib/libtersafe.so $lib/libtersafe.so.bak
rm -rf $lib/{libtgpa.so,libBugly.so}
chmod 755 $lib/*
rm -rf $data/files
pm disable $PKG/com.tencent.midas.oversea.newnetwork.service.APNetDetectService
touch $data/files
chmod 0 $data/files
am start -n $PKG/com.epicgames.ue4.SplashActivity
sleep 4
rm -rf $lib/{libUE4.so,libtprt.so,libtersafe.so}
mv $lib/libtprt.so.bak $lib/libtprt.so
mv $lib/libUE4.so.bak $lib/libUE4.so
mv $lib/libtersafe.so.bak $lib/libtersafe.so
chmod 755 $lib/*
sleep 3
chmod 775 /data/media/0/Android/data/com.pakage.upsilon/files/UPSILON
exec  /data/media/0/Android/data/com.pakage.upsilon/files/UPSILON logo
