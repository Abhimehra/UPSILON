su -c iptables --flush
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null

iptables -I INPUT -s ns-1972.awsdns-54.co.uk -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-1972.awsdns-54.co.uk -j REJECT &>/dev/null

iptables -I INPUT -s ns-1219.awsdns-24.org -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-1219.awsdns-24.org -j REJECT &>/dev/null

iptables -I INPUT -s ns-376.awsdns-47.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-376.awsdns-47.com -j REJECT &>/dev/null

iptables -I INPUT -s ns-616.awsdns-13.net -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-616.awsdns-13.net -j REJECT &>/dev/null

iptables -I INPUT -s dns4.p08.nsone.net -j REJECT &>/dev/null
iptables -I OUTPUT -s dns4.p08.nsone.net -j REJECT &>/dev/null

iptables -I INPUT -s dns3.p08.nsone.net -j REJECT &>/dev/null
iptables -I OUTPUT -s dns3.p08.nsone.net -j REJECT &>/dev/null

iptables -I INPUT -s dns2.p08.nsone.net -j REJECT &>/dev/null
iptables -I OUTPUT -s dns2.p08.nsone.net -j REJECT &>/dev/null

iptables -I INPUT -s dns1.p08.nsone.net -j REJECT &>/dev/null
iptables -I OUTPUT -s dns1.p08.nsone.net -j REJECT &>/dev/null

iptables -I INPUT -s ns-823.awsdns-38.net -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-823.awsdns-38.net -j REJECT &>/dev/null

iptables -I INPUT -s ns-172.awsdns-21.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-172.awsdns-21.com -j  &>/dev/null

iptables -I INPUT -s ns-1693.awsdns-19.co.uk -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-1693.awsdns-19.co.uk -j REJECT &>/dev/null

iptables -I INPUT -s ns-1285.awsdns-32.org -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-1285.awsdns-32.org -j REJECT &>/dev/null

iptables -I INPUT -s ns4.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns4.qq.com -j REJECT &>/dev/null

iptables -I INPUT -s ns3.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns3.qq.com -j REJECT &>/dev/null

iptables -I INPUT -s ns2.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns2.qq.com -j REJECT &>/dev/null

iptables -I INPUT -s ns1.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns1.qq.com -j REJECT &>/dev/null

iptables -I INPUT -s ns-open3.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-open3.qq.com -j REJECT &>/dev/null

iptables -I INPUT -s ns-open2.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-open2.qq.com -j REJECT &>/dev/null

iptables -I INPUT -s ns-open1.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns-open1.qq.com -j REJECT &>/dev/null

iptables -I INPUT -s ns4.dnsv5.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns4.dnsv5.com -j REJECT &>/dev/null

iptables -I INPUT -s ns3.dnsv5.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ns3.dnsv5.com -j REJECT &>/dev/null

iptables -I INPUT -s f1g1ns1.dnspod.net -j REJECT &>/dev/null
iptables -I OUTPUT -s f1g1ns1.dnspod.net -j REJECT &>/dev/null

iptables -I INPUT -s f1g1ns2.dnspod.net -j REJECT &>/dev/null
iptables -I OUTPUT -s f1g1ns2.dnspod.net -j REJECT &>/dev/null

iptables -I INPUT -s 216.58.212.106 -j REJECT &>/dev/null
iptables -I OUTPUT -s 216.58.212.106 -j REJECT &>/dev/null

iptables -I INPUT -s 182.254.116.117 -j REJECT &>/dev/null
iptables -I OUTPUT -s 182.254.116.117 -j REJECT &>/dev/null

iptables -I INPUT -s min-pay.globh.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.globh.com -j REJECT &>/dev/null

iptables -I INPUT -s 20.40.43.235 -j REJECT &>/dev/null
iptables -I OUTPUT -s 20.40.43.235 -j REJECT &>/dev/null

iptables -I INPUT -s sandbox.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.api.unipay.qq.com -j REJECT &>/dev/null

iptables -I INPUT -s 183.61.41.148 -j REJECT &>/dev/null
iptables -I OUTPUT -s 183.61.41.148 -j REJECT &>/dev/null

iptables -I INPUT -s dev.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s dev.api.unipay.qq.com -j REJECT &>/dev/null

iptables -I INPUT -s szmg.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s szmg.qq.com -j REJECT &>/dev/null

iptables -I INPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.pgtom.com -j REJECT &>/dev/null

iptables -I INPUT -s pay.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s pay.igamecj.com -j REJECT &>/dev/null

iptables -I INPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.pgtom.com -j REJECT &>/dev/null

iptables -I INPUT -s 129.226.3.30 -j REJECT &>/dev/null
iptables -I OUTPUT -s 129.226.3.30 -j REJECT &>/dev/null

iptables -I INPUT -ssandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.centauriglobal.com -j REJECT &>/dev/null

iptables -I INPUT -s 101.32.133.41 -j REJECT &>/dev/null
iptables -I OUTPUT -s 101.32.133.41 -j REJECT &>/dev/null

iptables -I INPUT -ssandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.centauriglobal.com -j REJECT &>/dev/null

iptables -I INPUT -s 49.51.42.152 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.42.152 -j REJECT &>/dev/null

iptables -I INPUT -idcconfig.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s idcconfig.gcloudsdk.com -j REJECT &>/dev/null

iptables -I INPUT -s tglog.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s tglog.gcloudsdk.com -j REJECT &>/dev/null

iptables -I INPUT -p udp --dport 20371 -j REJECT
iptables -I OUTPUT -p udp --dport 20371 -j REJECT

iptables -I INPUT -p udp --dport 15692 -j REJECT
iptables -I OUTPUT -p udp --dport 15692 -j REJECT

iptables -I INPUT -p tcp --dport 20371 -j REJECT
iptables -I OUTPUT -p tcp --dport 20371 -j REJECT

iptables -I INPUT -p tcp --dport 15692 -j REJECT
iptables -I OUTPUT -p tcp --dport 15692 -j REJECT

iptables -I INPUT -p udp --dport 8013 -j REJECT
iptables -I OUTPUT -p udp --dport 8013 -j REJECT

iptables -I INPUT -p udp --dport 18081 -j REJECT
iptables -I OUTPUT -p udp --dport 18081 -j REJECT

iptables -I INPUT -p tcp --dport 8013 -j REJECT
iptables -I OUTPUT -p tcp --dport 8013 -j REJECT

iptables -I INPUT -p tcp --dport 18081 -j REJECT
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT

iptables -I INPUT -p tcp --dport 10012 -j REJECT
iptables -I OUTPUT -p tcp --dport 10012 -j REJECT

iptables -I INPUT -p udp --dport 10012 -j REJECT
iptables -I OUTPUT -p udp --dport 10012 -j REJECT

iptables -I INPUT -p tcp --dport 10591 -j REJECT
iptables -I OUTPUT -p tcp --dport 10591 -j REJECT

iptables -I INPUT -p udp --dport 10591 -j REJECT
iptables -I OUTPUT -p udp --dport 10591 -j REJECT

iptables -I INPUT -p udp --dport 10225 -j REJECT
iptables -I OUTPUT -p udp --dport 10225 -j REJECT

iptables -I INPUT -p tcp --dport 10225 -j REJECT
iptables -I OUTPUT -p tcp --dport 10225 -j REJECT
iptables -I OUTPUT -p udp --dport 10225 -j REJECT

iptables -I INPUT -p tcp --dport 17000 -j REJECT
iptables -I OUTPUT -p tcp --dport 1700 -j REJECT

iptables -I INPUT -p udp --dport 17000 -j REJECT
iptables -I OUTPUT -p udp --dport 1700 -j REJECT
iptables -A INPUT -p icmp -j REJECT
iptables -A OUTPUT -p icmp -j REJECT
iptables -I INPUT -p tcp --dport 43 -j DROP
iptables -I OUTPUT -p tcp --dport 43 -j DROP
iptables -I INPUT -p tcp --dport 80 -j DROP
iptables -I INPUT -p tcp --dport 8080 -j DROP
iptables -I INPUT -p tcp --dport 18081 -j DROP
iptables -I INPUT -p tcp --dport 3013 -j DROP
iptables -I INPUT -p tcp --dport 1112 -j DROP
iptables -I INPUT -p tcp --dport 11443 -j DROP
iptables -I INPUT -p tcp --dport 53 -j DROP
iptables -I OUTPUT -p tcp --dport 53 -j DROP
iptables -I OUTPUT -p tcp --dport 80 -j DROP
iptables -I OUTPUT -p tcp --dport 8080 -j DROP
iptables -I OUTPUT -p tcp --dport 18081 -j DROP
iptables -I OUTPUT -p tcp --dport 3013 -j DROP
iptables -I OUTPUT -p tcp --dport 1112 -j DROP
iptables -I OUTPUT -p tcp --dport 11443 -j DROP
iptables -I OUTPUT -p udp --dport 81 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 111 -j DROP
iptables -I OUTPUT -p udp --dport 11038 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 20001 -j DROP
iptables -I INPUT -p tcp --dport 80 -j REJECT
iptables -I INPUT -p tcp --dport 8080 -j REJECT
iptables -I INPUT -p tcp --dport 8085 -j REJECT
iptables -I INPUT -p tcp --dport 8086 -j REJECT
iptables -I INPUT -p tcp --dport 8088 -j REJECT
iptables -I INPUT -p tcp --dport 18081 -j REJECT
iptables -I INPUT -p tcp --dport 3013 -j REJECT
iptables -I INPUT -p tcp --dport 1112 -j REJECT
iptables -I INPUT -p tcp --dport 11443 -j REJECT
iptables -I INPUT -p tcp --dport 53 -j REJECT
iptables -I OUTPUT -p tcp --dport 53 -j REJECT
iptables -I OUTPUT -p tcp --dport 80 -j REJECT
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT
iptables -I OUTPUT -p tcp --dport 8085 -j REJECT
iptables -I OUTPUT -p tcp --dport 8086 -j REJECT
iptables -I OUTPUT -p tcp --dport 8088 -j REJECT
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
iptables -I OUTPUT -p tcp --dport 3013 -j REJECT
iptables -I OUTPUT -p tcp --dport 1112 -j REJECT
iptables -I OUTPUT -p tcp --dport 11443 -j REJECT
iptables -I OUTPUT -p tcp --dport 43 -j REJECT
iptables -I INPUT -p tcp --dport 43 -j REJECT
i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   15692  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   53  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   20371  - j   D R O P 
 i p t a b l e s   - I   I N P U T   - p   t c p   - - d p o r t   3013  - j   D R O P 
