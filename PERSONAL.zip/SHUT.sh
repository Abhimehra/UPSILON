su -c iptables --flush

