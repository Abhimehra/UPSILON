su -c fuser -k 17500/tcp
su -c fuser -k 1143/tcp
su -c fuser -k 9031/tcp
su -c fuser -k 49870/tcp
su -c fuser -k 8013/tcp
su -c fuser -k 80/tcp
su -c iptables -A INPUT -p tcp -j REJECT
