
iptables INPUT -p tcp -m tcp --dport 17500 -j REJECT --reject-with icmp-port-unreachable
iptables INPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables INPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables INPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables INPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables INPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables INPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables INPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables INPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables INPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables INPUT -p tcp -m tcp --dport 17500 -j DROP
iptables INPUT -p tcp -m tcp --dport 11443 -j DROP
iptables INPUT -p tcp -m tcp --dport 1112 -j DROP
iptables INPUT -p tcp -m tcp --dport 3013 -j DROP
iptables INPUT -p tcp -m tcp --dport 18081 -j DROP
iptables INPUT -p tcp -m tcp --dport 8080 -j DROP
iptables INPUT -p tcp -m tcp --dport 80 -j DROP
iptables OUTPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables OUTPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables OUTPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables OUTPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables OUTPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables OUTPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables OUTPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables OUTPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables OUTPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables OUTPUT -p tcp -m tcp --dport 17500 -j REJECT --reject-with icmp-port-unreachable
iptables OUTPUT -p udp -m udp --dport 20001 -j DROP
iptables OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables OUTPUT -p udp -m udp --dport 11038 -j DROP
iptables OUTPUT -p udp -m udp --dport 111 -j DROP
iptables OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables OUTPUT -p udp -m udp --dport 81 -j DROP
iptables OUTPUT -p tcp -m tcp --dport 11443 -j DROP
iptables OUTPUT -p tcp -m tcp --dport 1112 -j DROP
iptables OUTPUT -p tcp -m tcp --dport 3013 -j DROP
iptables OUTPUT -p tcp -m tcp --dport 18081 -j DROP
iptables OUTPUT -p tcp -m tcp --dport 8080 -j DROP
iptables OUTPUT -p tcp -m tcp --dport 80 -j DROP
iptables OUTPUT -p tcp -m tcp --dport 17500 -j DROP