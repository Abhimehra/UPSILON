 pkill com.pubg.krmobile
 iptables -F
 iptables --flush
 iptables -P INPUT ACCEPT
 iptables -P FORWARD ACCEPT
 iptables -P OUTPUT ACCEPT
 iptables -t nat -F
 iptables -t mangle -F
 iptables -X
 rm -rf /data/data/com.pubg.krmobile/app_crashrecord
 touch /data/data/com.pubg.krmobile/app_crashrecord
 rm -rf /data/data/com.pubg.krmobile/databases
 rm -rf /data/data/com.pubg.krmobile/files/ano_tmp/*
 chmod -R 000 /data/data/com.pubg.krmobile/files/ano_tmp
 rm -rf /data/cache/magisk.log
 rm -rf /data/cache/magisk.log.bak
 rm -rf /data/data/com.pubg.krmobile/*cache*
 rm -rf /data/data/com.pubg.krmobile/app*
 rm -rf /data/media/0/.backups
 rm -rf /data/media/0/MidasOversea
 rm -rf /data/data/com.pubg.krmobile/*app*
 rm -rf /data/data/com.pubg.krmobile/cache
 rm -rf /data/data/com.pubg.krmobile/code_cache
 rm -rf /data/data/com.pubg.krmobile/files
 rm -rf /data/data/com.pubg.krmobile/no_backup
 touch /data/data/com.pubg.krmobile/app_appcache
 touch /data/data/com.pubg.krmobile/app_bugly
 touch /data/data/com.pubg.krmobile/app_crashrecord
 touch /data/data/com.pubg.krmobile/app_databases
 touch /data/data/com.pubg.krmobile/app_geolocation
 touch /data/data/com.pubg.krmobile/app_lib,app_textures,cache
 touch /data/data/com.pubg.krmobile/code_cache
 touch /data/data/com.pubg.krmobile/no_backup
 chmod -R 0000 /data/data/com.pubg.krmobile/app_appcache
 chmod -R 0000 /data/data/com.pubg.krmobile/app_bugly
 chmod -R 0000 /data/data/com.pubg.krmobile/app_crashrecord
 chmod -R 0000 /data/data/com.pubg.krmobile/app_databases
 chmod -R 0000 /data/data/com.pubg.krmobile/app_geolocation
 chmod -R 0000 /data/data/com.pubg.krmobile/app_lib
 chmod -R 0000 /data/data/com.pubg.krmobile/app_textures
 chmod -R 0000 /data/data/com.pubg.krmobile/cache
 chmod -R 0000 /data/data/com.pubg.krmobile/code_cache
 chmod -R 0000 /data/data/com.pubg.krmobile/no_backup
 rm -rf /data/data/com.pubg.krmobile/databases/*
 touch /data/data/com.pubg.krmobile/databases/__hs__db_issues
 touch /data/data/com.pubg.krmobile/databases/__hs__db_issues-shm
 touch /data/data/com.pubg.krmobile/databases/__hs__db_issues-wal
 touch /data/data/com.pubg.krmobile/databases/__hs__db_key_values
 touch /data/data/com.pubg.krmobile/databases/__hs__db_key_values-shm
 touch /data/data/com.pubg.krmobile/databases/__hs__db_key_values-wal
 touch /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values
 touch /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values-shm
 touch /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values-wal
 touch /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values
 touch /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values-shm
 touch /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values-wal
 touch /data/data/com.pubg.krmobile/databases/__hs_log_store
 touch /data/data/com.pubg.krmobile/databases/__hs_log_store-shm
 touch /data/data/com.pubg.krmobile/databases/__hs_log_store-wal
 touch /data/data/com.pubg.krmobile/databases/bugly_db_
 touch /data/data/com.pubg.krmobile/databases/bugly_db_-shm
 touch /data/data/com.pubg.krmobile/databases/bugly_db_-wal
 touch /data/data/com.pubg.krmobile/databases/config.db
 touch /data/data/com.pubg.krmobile/databases/google_app_measurement_local.db
 touch /data/data/com.pubg.krmobile/databases/iMSDK.db
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_issues
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_issues-shm
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_issues-wal
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_key_values
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_key_values-shm
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_key_values-wal
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values-shm
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values-wal
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values-shm
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs__db_support_key_values-wal
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs_log_store
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs_log_store-shm
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/__hs_log_store-wal
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/bugly_db_-shm
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/bugly_db_-wal
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/config.db
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/google_app_measurement_local.db
 chmod -R 0000 /data/data/com.pubg.krmobile/databases/iMSDK.db
 rm -rf /data/media/legacy
 touch /data/media/legacy
 chmod -R 0000 /data/media/legacy
 rm -rf /data/media/0/.backups
 rm -rf /data/media/0/.ext4
 rm -rf /data/media/0/.sstmp
 rm -rf /data/media/0/MidasOversea
 rm -rf /data/media/0/QTAudioEngine
 rm -rf /data/media/0/tencent
 touch /data/media/0/.backups
 touch /data/media/0/.ext4
 touch /data/media/0/.sstmp
 chmod -R 0000 /data/media/0/.backups
 chmod -R 0000 /data/media/0/.ext4
 chmod -R 0000 /data/media/0/.sstmp
 chmod -R 0000 /data/media/0/MidasOversea
 chmod -R 0000 /data/media/0/QTAudioEngine
 chmod -R 0000 /data/media/0/tencent
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/cache
 touch /data/media/0/Android/data/com.pubg.krmobile/cache
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/cache
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/TGPA
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/ca-bundle.pem
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/cacheFile.txt
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/hawk_data
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
 touch /data/media/0/Android/data/com.pubg.krmobile/files/TGPA
 touch /data/media/0/Android/data/com.pubg.krmobile/files/ca-bundle.pem
 touch /data/media/0/Android/data/com.pubg.krmobile/files/cacheFile.txt
 touch /data/media/0/Android/data/com.pubg.krmobile/files/hawk_data
 touch /data/media/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/TGPA
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/ca-bundle.pem
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/cacheFile.txt
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/hawk_data
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Engine
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Epic Games
 touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Engine
 touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Epic Games
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Engine
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Epic Games
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
 touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
 rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
 touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
 touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
 touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
 touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
 touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
 touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
 chmod -R 0000 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
  rm -rf /data/data/com.pubg.krmobile/lib/libapp.so
 rm -rf /data/data/com.pubg.krmobile/lib/libBugly.so
 rm -rf /data/data/com.pubg.krmobile/lib/libc++_shared.so
 rm -rf /data/data/com.pubg.krmobile/lib/libflutter.so
 rm -rf /data/data/com.pubg.krmobile/lib/libgamemaster.so
 rm -rf /data/data/com.pubg.krmobile/lib/libgcloudarch.so
 rm -rf /data/data/com.pubg.krmobile/lib/libhelpshiftlistener.so
 rm -rf /data/data/com.pubg.krmobile/lib/libigshare.so
 rm -rf /data/data/com.pubg.krmobile/lib/libImSDK.so
 rm -rf /data/data/com.pubg.krmobile/lib/libkk-image.so
 rm -rf /data/data/com.pubg.krmobile/lib/liblbs.so
 rm -rf /data/data/com.pubg.krmobile/lib/libnpps-jni.so
 rm -rf /data/data/com.pubg.krmobile/lib/libsentry.so
 rm -rf /data/data/com.pubg.krmobile/lib/libsentry-android.so
 rm -rf /data/data/com.pubg.krmobile/lib/libsoundtouch.so
 rm -rf /data/data/com.pubg.krmobile/lib/libst-engine.so
 rm -rf /data/data/com.pubg.krmobile/lib/libtgpa.so
 rm -rf /data/data/com.pubg.krmobile/lib/libzip.so
 chmod -R 0000 /data/data/com.pubg.krmobile/lib/*
 sleep 1
 am start -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity
 chmod -R 755 /data/data/com.pubg.krmobile/lib/* > /dev/null 2>&1
 sleep 4
  

