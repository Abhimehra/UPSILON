pkill com.tencent.ig
 am force-stop com.tencent.ig
 kill com.tencent.ig
 am kill-all com.tencent.ig
 pm block com.tencent.ig
 pm hide  com.tencent.ig
 pm disable-user --user 0 com.tencent.ig
 pm unblock com.tencent.ig
 pm unhide com.tencent.ig
 pm enable com.tencent.ig
 chmod -R 755 /data/data/com.tencent.ig/files/ano_tmp
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.6.0.15531.pak
 chmod -R 755 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.inil
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/TGPA
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/ca-bundle.pem
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/cacheFile.txt
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/hawk_data
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/login-identifier.txt
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Epic
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Games
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Engine
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
 rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
 rm -rf /data/data/com.tencent.ig/lib/*
 rm -rf /data/data/com.tencent.ig/databases
 pm install -r /data/app/com.tencent.ig*/base.apk
 rm -rf /storage/emulated/0/com.tencent.ig
 rm -rf /storage/emulated/0/Se2
 rm -rf /data/media/0/com.tencent.ig
 rm -rf /data/cache/magisk.log
 rm -rf /data/cache/magisk.log.bak
 rm -rf /data/app/com.tencent.ig*/oat
 rm -rf /data/data/com.tencent.ig/app_webview/Default/*