BGMI="/data/data/com.pubg.imobile/app_crashrecord"
KOREA="/data/data/com.pubg.krmobile/app_crashrecord"
GLOBAL="/data/data/com.tencent.ig/app_crashrecord"
CP=/data/media/0/Android/data/com.pakage.upsilon/files
DEL=/data/data/com.pubg.imobile/lib
rm -rf $BGMI
rm -rf $GLOBAL
rm -rf $KOREA
touch $BGMI
touch $GLOBAL
touch $KOREA
chmod 000 $BGMI
chmod 000 $KOREA
chmod 000 $GLOBAL
