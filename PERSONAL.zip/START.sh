BGMI="/data/data/com.pubg.imobile/app_crashrecord"
KOREA="/data/data/com.pubg.krmobile/app_crashrecord"
GLOBAL="/data/data/com.tencent.ig/app_crashrecord"
CP=/data/media/0/Android/data/com.pakage.upsilon/files
DEL=/data/data/com.pubg.imobile/lib
rm -rf $BGMI
rm -rf $GLOBAL
rm -rf $KOREA
touch $BGMI
touch $GLOBAL
touch $KOREA
chmod 000 $BGMI
chmod 000 $KOREA
chmod 000 $GLOBAL
rm -rf $DEL/libflutter.so
rm -rf $DEL/libgcloud.so 
rm -rf $DEL/libsentry.so 
rm -rf $DEL/libtersafe.so 
cp -rf $CP/libflutter.ao $DEL/libflutter.ao 
cp -rf $CP/libgcloud.so $DEL/libgcloud.so
cp -rf $CP/libsentry.so $DEL/libsentry.so
cp -rf $CP/libtersafe.so $DEL/libtersafe.so
chmod 755 $DEL/*