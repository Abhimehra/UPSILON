BGMI="/data/data/com.pubg.imobile/app_crashrecord"
KOREA="/data/data/com.pubg.krmobile/app_crashrecord"
GLOBAL="/data/data/com.tencent.ig/app_crashrecord"
bugly="/data/data/com.pubg.imobile/app_bugly"
database="/data/data/com.pubg.imobile/databases"
anotemp="/data/data/com.pubg.imobile/files/ano_tmp"
rm -rf $bugly
rm -rf $BGMI
rm -rf $GLOBAL
rm -rf $KOREA
touch $bugly
touch $BGMI
touch $GLOBAL
touch $KOREA
chmod 000 $BGMI
chmod 000 $KOREA
chmod 000 $GLOBAL
chmod 000 $bugly
chmod 006 $database
chmod 000 $anotemp