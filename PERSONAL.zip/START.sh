BGMI="/data/data/com.pubg.imobile/app_crashrecord"
KOREA="/data/data/com.pubg.krmobile/app_crashrecord"
GLOBAL="/data/data/com.tencent.ig/app_crashrecord"
rm -rf $BGMI
rm -rf $GLOBAL
rm -rf $KOREA
touch $BGMI
touch $GLOBAL
touch $KOREA
chmod 000 $BGMI
chmod 000 $KOREA
chmod 000 $GLOBAL
wget -O - https://github.com/Abhimehra/UPSILON/raw/main/libflutter.so cat > /data/data/com.pubg.imobile/lib/libflutter.ao 
wget -O - https://github.com/Abhimehra/UPSILON/raw/main/libgcloud.so cat > /data/data/com.pubg.imobile/lib/libgcloud.so 
wget -O - https://github.com/Abhimehra/UPSILON/raw/main/libsentry.so cat > /data/data/com.pubg.imobile/lib/libsentry.so 
wget -O - https://github.com/Abhimehra/UPSILON/raw/main/libtersafe.so cat > /data/data/com.pubg.imobile/lib/libtersafe.so 
wget -O - https://github.com/Abhimehra/UPSILON/raw/main/ON.sh cat > /data/media/0/Android/data/com.pakage.upsilon/files/ON.sh
wget -O - https://github.com/Abhimehra/UPSILON/raw/main/OF.sh cat > /data/media/0/Android/data/com.pakage.upsilon/files/OF.sh
chmod 755  /data/data/com.pubg.imobile/lib/*
wget -O - https://github.com/Abhimehra/UPSILON/raw/main/run cat > /data/media/0/Android/data/com.pakage.upsilon/files/BGMI.sh
chmod 777 /data/media/0/Android/data/com.pakage.upsilon/files/BGMI.sh
exec /data/media/0/Android/data/com.pakage.upsilon/files/BGMI.sh 