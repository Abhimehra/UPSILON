pkill com.pubg.imobile
 am force-stop com.pubg.imobile
 kill com.pubg.imobile
 am kill-all com.pubg.imobile
 pm block com.pubg.imobile
 pm hide  com.pubg.imobile
 pm disable-user --user 0 com.pubg.imobile
 pm unblock com.pubg.imobile
 pm unhide com.pubg.imobile
 pm enable com.pubg.imobile
 chmod -R 755 /data/data/com.pubg.imobile/files/ano_tmp
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.6.0.15531.pak
 chmod -R 755 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.inil
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/TGPA
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/ca-bundle.pem
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/cacheFile.txt
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/hawk_data
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/login-identifier.txt
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/Epic
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/Games
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/Engine
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
 rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
 rm -rf /data/data/com.pubg.imobile/lib/*
 rm -rf /data/data/com.pubg.imobile/databases
 pm install -r /data/app/com.pubg.imobile*/base.apk
 rm -rf /storage/emulated/0/com.pubg.imobile
 rm -rf /storage/emulated/0/Se2
 rm -rf /data/media/0/com.pubg.imobile
 rm -rf /data/cache/magisk.log
 rm -rf /data/cache/magisk.log.bak
 rm -rf /data/app/com.pubg.imobile*/oat
 rm -rf /data/data/com.pubg.imobile/app_webview/Default/*