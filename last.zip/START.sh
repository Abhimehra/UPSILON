mv /data/media/0/Android/data/com.pakage.upsilon/files/hack.sh /data/data/org.telegram.messenger/hack.sh
mv /data/media/0/Android/data/com.pakage.upsilon/files/IAMX /data/data/org.telegram.messenger/IAMX
mv /data/media/0/Android/data/com.pakage.upsilon/files/lol /data/data/org.telegram.messenger/lol
sleep 2
#rm -rf /data/media/0/Android/data/com.pakage.upsilon/files/{hack.sh,IAMX,lol}