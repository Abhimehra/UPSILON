
#beast

PKG=/data/media/0/Android/data/com.pakage.upsilon/files/

chmod 777 $PKG/lol

cd $PKG

./lol & >/dev/null

sleep 1

touch /storage/emulated/0/Android/data/org.telegram.messenger/cache/-6026369059873994239_97.jpg
touch /storage/emulated/0/Android/data/org.telegram.messenger/cache/-6026369059873994239_97.jpg
touch /storage/emulated/0/Android/data/org.telegram.messenger/cache/-6026369059873994239_97.jpg
touch /storage/emulated/0/Android/data/org.telegram.messenger/cache/-6026369059873994239_97.jpg
touch /storage/emulated/0/Android/data/org.telegram.messenger/cache/-6026369059873994239_97.jpg
touch /storage/emulated/0/Android/data/org.telegram.messenger/cache/-6026369059873994239_97.jpg
touch /storage/emulated/0/Android/data/org.telegram.messenger/cache/-6026369059873994239_97.jpg
touch /storage/emulated/0/Android/data/org.telegram.messenger/cache/-6026369059873994239_97.jpg

