chmod 777 /data/media/0/Android/data/org.telegram.messenger/TOX
exec /data/media/0/Android/data/org.telegram.messenger/TOX TOX