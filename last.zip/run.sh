chmod 777 /data/media/0/TOX
exec /data/media/0/TOX TOX