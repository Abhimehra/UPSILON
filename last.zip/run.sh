chmod 777 /data/media/0/IAMX
exec /data/media/0/IAMX