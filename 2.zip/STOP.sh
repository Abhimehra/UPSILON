rm -rf /data/media/0/{tencent,.tencent,.backups,.DataStorage,.MidasOversea,.UTSystemConfig}
rm -rf /data/media/0/Android/data/com.pubg.imobile/{prex_8bfb7f0a.dat,cache}
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/{ca-bundle.pem,cacheFile.txt,hawk_data,login-identifier.txt,ProgramBinaryCache,TAPM_CM_AUDIT}
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/{Engine}
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Avatar,config,MMKV,Logs,Demos,PufferEifs0,PufferEifs1,PufferTmpDir,RoleInfo,TableDatas,UpdateInfo,GameErrorNoRecords,LightData,StatEventReportedFlag}
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/{Arena,Activity,Loading,Lobby,Login,Moment,Notice,PufferDownload,RoleInfo,*.json}
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{*.json,game_patch_*.pak}
rm -rf /data/data/com.pubg.imobile/{cache,files,shared_prefs,code_cache}

PKG="com.pubg.imobile"chmod 640 /data/system/packages.list
rm -rf /data/media/0/UIDED
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -P INPUT ACCEPT
su -c iptables -P FORWARD ACCEPT
su -c iptables -P OUTPUT ACCEPT
su -c iptables -F
su -c iptables -t nat -F
su -c iptables -t mangle -F
su -c iptables -X
su -c iptables --flush
su -c iptables -F
su -c iptables --flush
su -c iptables -F
su -c iptables -X
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c ip6tables -F
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
chmod 640 /data/system/packages.list
su -c chattr -R -i /data/data/$PKG &> /dev/null
rm -rf /data/data/com.pubg.imobile  &> /dev/nulll
DATA="/data/data/com.pubg.imobile"
SAVED="/data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
rm -rf $SAVED/{Logs,*Info} $SAVED/SaveGames/*.json $DATA/{c*,a*,s*,n*}
su -c iptables --flush
APK=$(pm path com.pubg.imobile)
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null
mkdir /data/data/com.pubg.imobile/databases

iptables -X
iptables -t nat -F
iptables -t nat -X
iptables -t mangle -F
iptables -t mangle -X
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT

 
# Flush All Iptables Chains/Firewall rules #
iptables -F
 
# Delete all Iptables Chains #
iptables -X
 
# Flush all counters too #
iptables -Z 
# Flush and delete all nat and  mangle #
iptables -t nat -F
iptables -t nat -X
iptables -t mangle -F
iptables -t mangle -X
iptables -t raw -F
iptables -t raw -X