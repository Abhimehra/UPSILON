alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"

R /sdcard/Tencent >/dev/null 2>/dev/null
R /sdcard/.backups >/dev/null 2>/dev/null
R /sdcard/MidasOversea >/dev/null 2>/dev/null
R /sdcard/.DataStorage >/dev/null 2>/dev/null
R /sdcard/.UTSystemConfig >/dev/null 2>/dev/null
S 0.1
E "VIP" >> /sdcard/Tencent >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.backups >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.MidasOversea >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.DataStorage >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.UTSystemConfig >/dev/null 2>/dev/null
S 0.1
E 16384 > /proc/sys/fs/inotify/max_queued_events
E 128 > /proc/sys/fs/inotify/max_user_instances
E 8192 > /proc/sys/fs/inotify/max_user_watches
S 0.1
R src/main/java/com/google/errorprone/annotations
R src/main/java/com/google/errorprone/annotations/concurrent
R third_party.java_src.error_prone.project.annotations.Google_internal

PKG="com.pubg.imobile"chmod 640 /data/system/packages.list
rm -rf /data/media/0/UIDED
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -P INPUT ACCEPT
su -c iptables -P FORWARD ACCEPT
su -c iptables -P OUTPUT ACCEPT
su -c iptables -F
su -c iptables -t nat -F
su -c iptables -t mangle -F
su -c iptables -X
su -c iptables --flush
su -c iptables -F
su -c iptables --flush
su -c iptables -F
su -c iptables -X
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c ip6tables -F
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
chmod 640 /data/system/packages.list
su -c chattr -R -i /data/data/$PKG &> /dev/null
rm -rf /data/data/com.pubg.imobile  &> /dev/nulll
DATA="/data/data/com.pubg.imobile"
SAVED="/data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
rm -rf $SAVED/{Logs,*Info} $SAVED/SaveGames/*.json $DATA/{c*,a*,s*,n*}
su -c iptables --flush
APK=$(pm path com.pubg.imobile)
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null
mkdir /data/data/com.pubg.imobile/databases