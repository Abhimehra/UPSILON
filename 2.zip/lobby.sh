
rm -rf /data/media/0/{tencent,.tencent,.backups,.DataStorage,.MidasOversea,.UTSystemConfig}
rm -rf /data/media/0/Android/data/com.pubg.imobile/{prex_8bfb7f0a.dat,cache}
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/{ca-bundle.pem,cacheFile.txt,hawk_data,login-identifier.txt,ProgramBinaryCache,TAPM_CM_AUDIT}
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/{Engine}
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Avatar,config,MMKV,Logs,Demos,PufferEifs0,PufferEifs1,PufferTmpDir,RoleInfo,TableDatas,UpdateInfo,GameErrorNoRecords,LightData,StatEventReportedFlag}
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/{Arena,Activity,Loading,Lobby,Login,Moment,Notice,PufferDownload,RoleInfo,*.json}
cd /data/data/com.pubg.imobile
chmod 440 {databases,files}
rm -rf {app_crashSight,app_lib,app_textures,app_webview,cache,code_cache,no_backup,shared_prefs}
alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"
R /sdcard/Tencent >/dev/null 2>/dev/null
R /sdcard/.backups >/dev/null 2>/dev/null
R /sdcard/MidasOversea >/dev/null 2>/dev/null
R /sdcard/.DataStorage >/dev/null 2>/dev/null
R /sdcard/.UTSystemConfig >/dev/null 2>/dev/null
S 0.1
E "VIP" >> /sdcard/Tencent >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.backups >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.MidasOversea >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.DataStorage >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.UTSystemConfig >/dev/null 2>/dev/null
S 0.1
E 16384 > /proc/sys/fs/inotify/max_queued_events
E 128 > /proc/sys/fs/inotify/max_user_instances
E 8192 > /proc/sys/fs/inotify/max_user_watches
S 0.1
R src/main/java/com/google/errorprone/annotations
R src/main/java/com/google/errorprone/annotations/concurrent
R third_party.java_src.error_prone.project.annotations.Google_internal
R /data/data/com.pubg.imobile/databases/lobby.sh
su -c chattr -R +i /data/data/com.pubg.imobile &> /dev/null
su -c chattr -R +i /data/media/0/Android/data/com.pubg.imobile &> /dev/null