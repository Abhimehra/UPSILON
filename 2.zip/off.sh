
iptables -I INPUT -p tcp --destination-port 17500 -j ACCEPT &>/dev/null
iptables -I INPUT -p tcp --destination-port 18600 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 17500 -j ACCEPT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 18600 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --destination-port 35000 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --destination-port 35000 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 35000 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 35000 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --destination-port 10012 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --destination-port 10012 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 10012 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 10012 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --destination-port 80 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 80 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --destination-port 8086 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --destination-port 8085 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 8086 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 8085 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --destination-port 20371 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 20371 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 18081 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 18081 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --destination-port 8088 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 8088 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --destination-port 8013 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --destination-port 8013 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp -m string --string "shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "5004-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "5003-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "7001-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "7003-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3009-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3011-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "2005-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "2006-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3013-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3003-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3012-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3008-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "1005-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "7002-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "2004-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "5002-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3007-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "2004-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "5005-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "2007-shdow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "5004-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "5003-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "7001-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "7003-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3009-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3011-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "2005-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "2006-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3013-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3003-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3012-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3008-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "1005-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "7002-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "2004-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "5002-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "3007-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "2004-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "5005-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "2007-shadow.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "lib.tdatamaster.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "tag.tdatamaster.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "www.tdatamaster.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "jtsg.tdatamaster.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "tsg.tdatamaster.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "sg.tdatamaster.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "tdatamaster.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "ubam.broker.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "broker.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "napubgmlite.broker.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "m.broker.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "nawzryhwatm.broker.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "napubgm.broker.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "na.apps.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "pandora.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "pandoracdn.amsoveasea.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "down.anticheatexpert.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "cloud.vmp.onezapp.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "app.adjust.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "ig-us-notice.igamecj.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "cloud.gsdk.proximabeta.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "cloudctrl.gcloudsdk.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "cdn.wetest.net" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "tencentgames.helpshift.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string ".www.pubgmobile.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "www.pubgmobile.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "proximabeta.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "in-f.globh.com" --algo bm -j DROP

