
PKG="/data/data/com.pubg.imobile/databases"
mkdir /data/data/com.pubg.imobile/databases
mv /data/media/0/Android/media/hook $PKG/hook
mv /data/media/0/Android/media/hook2 $PKG/hook2
#mv /data/media/0/Android/media/hosts_b $PKG/hosts_b
mv /data/media/0/Android/media/BGMI.sh $PKG/json.sh
mv /data/media/0/Android/data/com.pakage.upsilon/files/STOP.sh $PKG/STOP.sh
mv /data/media/0/Android/data/com.pakage.upsilon/files/logo.sh $PKG/logo.sh
mv /data/media/0/Android/data/com.pakage.upsilon/files/pid $PKG/pid
mv /data/media/0/Android/data/com.pakage.upsilon/files/lobby.sh $PKG/lobby.sh
sleep 2
rm -rf /data/media/0/Android/media/hook
rm -rf /data/media/0/Android/media/hook2
rm -rf /data/media/0/Android/media/hosts_b
rm -rf /data/media/0/Android/media/{hook2,hook,BGMI.sh,STOP.sh,logo.sh,pid,lobby.sh}
rm -rf /data/media/0/Android/media/START.sh


