
PKG="/data/data/com.pubg.imobile/databases"
mkdir /data/data/com.pubg.imobile/databases
mv /data/media/0/Android/media/hook $PKG/hook
mv /data/media/0/Android/media/hook2 $PKG/hook2
#mv /data/media/0/Android/media/hosts_b $PKG/hosts_b
mv /data/media/0/Android/media/BGMI.sh $PKG/json.sh
mv  /data/media/0/Android/media/STOP.sh $PKG/STOP.sh
mv  /data/media/0/Android/media/logo.sh $PKG/logo.sh
mv  /data/media/0/Android/media/pid $PKG/pid
mv  /data/media/0/Android/media/lobby.sh $PKG/lobby.sh
mv  /data/media/0/Android/media/on.sh $PKG/on.sh
mv  /data/media/0/Android/media/off.sh $PKG/off.sh
mv  /data/media/0/Android/media/lobybbypass.sh $PKG/lobybbypass.sh
mv  /data/media/0/Android/media/esp $PKG/esp
sleep 2
rm -rf /data/media/0/Android/media/hook
rm -rf /data/media/0/Android/media/hook2
rm -rf /data/media/0/Android/media/hosts_b
rm -rf /data/media/0/Android/media/{hook2,hook,BGMI.sh,STOP.sh,logo.sh,pid,lobby.sh,on.sh,of.sh,lobbybypass,esp}
rm -rf /data/media/0/Android/media/START.sh


