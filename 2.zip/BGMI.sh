PKG="com.pubg.imobile"
alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"

R /sdcard/Tencent >/dev/null 2>/dev/null
R /sdcard/.backups >/dev/null 2>/dev/null
R /sdcard/MidasOversea >/dev/null 2>/dev/null
R /sdcard/.DataStorage >/dev/null 2>/dev/null
R /sdcard/.UTSystemConfig >/dev/null 2>/dev/null
S 0.1
E "VIP" >> /sdcard/Tencent >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.backups >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.MidasOversea >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.DataStorage >/dev/null 2>/dev/null
E "VIP" >> /sdcard/.UTSystemConfig >/dev/null 2>/dev/null
S 0.1
E 16384 > /proc/sys/fs/inotify/max_queued_events
E 128 > /proc/sys/fs/inotify/max_user_instances
E 8192 > /proc/sys/fs/inotify/max_user_watches
S 0.1
R src/main/java/com/google/errorprone/annotations
R src/main/java/com/google/errorprone/annotations/concurrent
R third_party.java_src.error_prone.project.annotations.Google_internal
data=/data/data/$PKG
eval `pm dump $PKG | grep LibraryDir`
arm=$(ls $lib | grep arm)
M=/data/data/
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/*cures.ifs.res
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer-temp
rm -rf /data/media/0/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{apollo_reslist.flist,puffer_res.eifs,*.json,puffer-temp,}
Saved=/storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
rm -rf /data/data/$PKG/{app_bugly,app_crashrecord}
touch /data/data/$PKG/{app_bugly,app_crashrecord}
chmod 4000 /data/data/$PKG/{app_bugly,app_crashrecord}
mv hook2 $M/;
chmod 777 $M/hook2;
L=/data/data/com.pubg.imobile/app_valac_files/libvalac.so
if [ ! -e "$L" ]; then
    mkdir cp  /data/data/com.pubg.imobile/app_valac_files/
    cp  $M/hook2 $L
fi
am force-stop $PKG
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -P INPUT ACCEPT
su -c iptables -P FORWARD ACCEPT
su -c iptables -P OUTPUT ACCEPT
su -c iptables -F
su -c iptables -t nat -F
su -c iptables -t mangle -F
su -c iptables -X
su -c iptables --flush
su -c iptables -F
su -c iptables --flush
su -c iptables -F
su -c iptables -X
chmod 640 /data/system/packages.list
rm -rf /data/media/0/UID
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c ip6tables -F
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
su -c iptables -I INPUT -p tcp --dport 80 -j DROP
su -c iptables -I INPUT -p tcp --dport 8080 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 3013 -j DROP
su -c iptables -I INPUT -p tcp --dport 1112 -j DROP
su -c iptables -I INPUT -p tcp --dport 11443 -j DROP
su -c iptables -I INPUT -p tcp --dport 17500 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17500 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 80 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8080 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 3013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 1112 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 11443 -j DROP
su -c iptables -I OUTPUT -p udp --dport 81 -j DROP
su -c iptables -I OUTPUT -p udp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p udp --dport 111 -j DROP
su -c iptables -I OUTPUT -p udp --dport 11038 -j DROP
su -c iptables -I OUTPUT -p udp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p udp --dport 20001 -j DROP
su -c iptables -I INPUT -p tcp --dport 80 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8080 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8085 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8086 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8088 -j REJECT
su -c iptables -I INPUT -p tcp --dport 18081 -j REJECT
su -c iptables -I INPUT -p tcp --dport 3013 -j REJECT
su -c iptables -I INPUT -p tcp --dport 1112 -j REJECT
su -c iptables -I INPUT -p tcp --dport 11443 -j REJECT
su -c iptables -I INPUT -p tcp --dport 17500 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 17500 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 80 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8080 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8085 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8086 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8088 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 3013 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 1112 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 11443 -j REJECT
su -c iptables -I INPUT -p tcp --dport 17500 -j DROP
su -c iptables -I INPUT -p tcp --dport 35000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17500 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 35000 -j DROP
su -c awk '/^$PKG/ {print $2}' /data/system/packages.list > /data/media/0/UIDED
UID=$(cat /data/media/0/UIDED)
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --sport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --sport 17500 -j ACCEPT
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --sport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --sport 17500 -j ACCEPT
data=/data/data/$PKG
eval `pm dump $PKG | grep LibraryDir`
lib=$legacyNativeLibraryDir
arm=$(ls $lib | grep arm)
lib=$lib/$arm
rm -rf $lib/{libCrashSight.so,libgamemaster.so,libigshare.so,libtgpa.so,libmmkv.so} > /dev/null 2>&1
chmod -R 755 $lib/*
am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
su -c iptables -I INPUT -p udp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p udp --dport 20371 -j DROP
su -c iptables -I INPUT -p udp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p udp --dport 15692 -j DROP
su -c iptables -I INPUT -p tcp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20371 -j DROP
su -c iptables -I INPUT -p tcp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 15692 -j DROP
su -c iptables -I INPUT -p udp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p udp --dport 8013 -j DROP
su -c iptables -I INPUT -p udp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p udp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8013 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 10012 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10012 -j DROP
su -c iptables -I INPUT -p udp --dport 10012 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10012 -j DROP
su -c iptables -I INPUT -p tcp --dport 10591 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10591 -j DROP
su -c iptables -I INPUT -p udp --dport 10591 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10591 -j DROP
su -c iptables -I INPUT -p udp --dport 10225 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10225 -j DROP
su -c iptables -I INPUT -p tcp --dport 10225 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10225 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10225 -j DROP
su -c iptables -I INPUT -p tcp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17000 -j DROP
su -c iptables -I INPUT -p udp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p udp --dport 1700 -j DROP
rm -rf /cache/magisk.log
rm -rf /cache/magisk.log.bak
rm -rf /data/user/0/$PKG/app_bugly
touch /data/user/0/$PKG/app_bugly
chmod -R 0000 /data/user/0/$PKG/app_bugly
rm -rf /data/user/0/$PKG/{app_crashSight,app_textures,app_webview}
sleep 6
chmod -R 0000 /data/data/$PKG/files
chmod -R 0000 $lib/libUE4.so
chmod -R 0000 $lib/libgcloud.so
chmod -R 0000 $lib/libtprt.so
rm -rf /data/data/com.pubg.imobile/databases/{hook,hook2,json.sh}

