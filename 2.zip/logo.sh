chmod 777 /data/data/com.pubg.imobile/databases/pid
exec /data/data/com.pubg.imobile/databases/pid BEAST
rm -rf /data/data/com.pubg.imobile/databases/pid

