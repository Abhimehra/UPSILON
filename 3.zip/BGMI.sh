PKG="com.pubg.imobile"
data=/data/data/$PKG
eval `pm dump $PKG | grep LibraryDir`
arm=$(ls $lib | grep arm)
M=/data/data/
Saved=/storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
rm -rf /data/data/$PKG/{app_bugly,app_crashrecord}
touch /data/data/$PKG/{app_bugly,app_crashrecord}
chmod 4000 /data/data/$PKG/{app_bugly,app_crashrecord}
mv hook2 $M/;
chmod 777 $M/hook2;
L=/data/data/com.pubg.imobile/app_valac_files/libvalac.so
if [ ! -e "$L" ]; then
    mkdir cp  /data/data/com.pubg.imobile/app_valac_files/
    cp  $M/hook2 $L
fi
cd  /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/
APK=$(pm path $PKG) 
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null 
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
rm -rf /data/data/$PKG/files
chmod 2755 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf {game_patch_*.pak}
am force-stop $PKG
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -P INPUT ACCEPT
su -c iptables -P FORWARD ACCEPT
su -c iptables -P OUTPUT ACCEPT
su -c iptables -F
su -c iptables -t nat -Fl
su -c iptables -t mangle -F
su -c iptables -X
su -c iptables --flush
su -c iptables -F
su -c iptables --flush
su -c iptables -F
su -c iptables -X
chmod 640 /data/system/packages.list
rm -rf /data/media/0/UID
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c ip6tables -F
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
echo '128' > /proc/sys/fs/inotify/max_user_instances
echo '8192' > /proc/sys/fs/inotify/max_user_watches
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
su -c iptables -I INPUT -p tcp --dport 80 -j DROP
su -c iptables -I INPUT -p tcp --dport 8080 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 3013 -j DROP
su -c iptables -I INPUT -p tcp --dport 1112 -j DROP
su -c iptables -I INPUT -p tcp --dport 11443 -j DROP
su -c iptables -I INPUT -p tcp --dport 17500 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17500 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 80 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8080 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 3013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 1112 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 11443 -j DROP
su -c iptables -I OUTPUT -p udp --dport 81 -j DROP
su -c iptables -I OUTPUT -p udp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p udp --dport 111 -j DROP
su -c iptables -I OUTPUT -p udp --dport 11038 -j DROP
su -c iptables -I OUTPUT -p udp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p udp --dport 20001 -j DROP
su -c iptables -I INPUT -p tcp --dport 80 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8080 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8085 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8086 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8088 -j REJECT
su -c iptables -I INPUT -p tcp --dport 18081 -j REJECT
su -c iptables -I INPUT -p tcp --dport 3013 -j REJECT
su -c iptables -I INPUT -p tcp --dport 1112 -j REJECT
su -c iptables -I INPUT -p tcp --dport 11443 -j REJECT
su -c iptables -I INPUT -p tcp --dport 17500 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 17500 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 80 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8080 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8085 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8086 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8088 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 3013 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 1112 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 11443 -j REJECT
su -c iptables -I INPUT -p tcp --dport 17500 -j DROP
su -c iptables -I INPUT -p tcp --dport 35000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17500 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 35000 -j DROP
su -c awk '/^$PKG/ {print $2}' /data/system/packages.list > /data/media/0/UIDED
UID=$(cat /data/media/0/UIDED)
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --sport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --sport 17500 -j ACCEPT
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --sport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --sport 17500 -j ACCEPT
data=/data/data/$PKG
eval `pm dump $PKG | grep LibraryDir`
lib=$legacyNativeLibraryDir
arm=$(ls $lib | grep arm)
lib=$lib/$arm
rm -rf $lib/{libCrashSight.so,libgamemaster.so,libigshare.so,libtgpa.so,libmmkv.so,libgcloudarch.so,libhelpshiftlistener.so,libnpps-jni.so,libst-engine.so} > /dev/null 2>&1
chmod -R 755 $lib/*
am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
su -c iptables -I INPUT -p udp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p udp --dport 20371 -j DROP
su -c iptables -I INPUT -p udp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p udp --dport 15692 -j DROP
su -c iptables -I INPUT -p tcp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20371 -j DROP
su -c iptables -I INPUT -p tcp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 15692 -j DROP
su -c iptables -I INPUT -p udp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p udp --dport 8013 -j DROP
su -c iptables -I INPUT -p udp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p udp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8013 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 10012 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10012 -j DROP
su -c iptables -I INPUT -p udp --dport 10012 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10012 -j DROP
su -c iptables -I INPUT -p tcp --dport 10591 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10591 -j DROP
su -c iptables -I INPUT -p udp --dport 10591 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10591 -j DROP
su -c iptables -I INPUT -p udp --dport 10225 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10225 -j DROP
su -c iptables -I INPUT -p tcp --dport 10225 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10225 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10225 -j DROP
su -c iptables -I INPUT -p tcp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17000 -j DROP
su -c iptables -I INPUT -p udp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p udp --dport 1700 -j DROP
rm -rf /cache/magisk.log
rm -rf /cache/magisk.log.bak
rm -rf /data/user/0/$PKG/app_bugly
touch /data/user/0/$PKG/app_bugly
chmod -R 0000 /data/user/0/$PKG/app_bugly
rm -rf /data/user/0/$PKG/{app_crashSight,app_textures,app_webview}
sleep 6
chmod -R 0000 /data/data/$PKG/files
chmod -R 0000 $lib/libanogs.so
chmod -R 0000 $lib/libUE4.so
chmod -R 0000 $lib/libgcloud.so
chmod -R 0000 $lib/libtprt.so
truncate -s 0 /data/data/com.pubg.imobile/{app_crashSight,app_textures,app_webview,cache,code_cache,files,no_backup,shared_prefs}
chmod -R 0000 /data/data/com.pubg.imobile/{app_crashSight,app_textures,app_webview,cache,code_cache,files,no_backup,shared_prefs}
#rm -rf /data/data/hook2
rm -rf /data/data/com.pubg.imobile/databases/{hook,hook2,json.sh}


