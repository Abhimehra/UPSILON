D="/data/data/com.pubg.imobile/databases/"
chmod 777 $D/esp
exec $D/esp
