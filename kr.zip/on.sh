su -c iptables -F
iptables -F
su -c iptables --flush
iptables --flush
iptables -F
iptables -X
ip6tables --flush
ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
uptime
iptables -I INPUT -p tcp --dport 80 -j REJECT
iptables -I INPUT -p tcp --dport 8080 -j REJECT
iptables -I INPUT -p tcp --dport 18081 -j REJECT
iptables -I INPUT -p tcp --dport 3013 -j REJECT
iptables -I INPUT -p tcp --dport 1112 -j REJECT
iptables -I INPUT -p tcp --dport 11443 -j REJECT
iptables -I INPUT -p tcp --dport 17500 -j REJECT
iptables -I OUTPUT -p tcp --dport 17500 -j REJECT
iptables -I OUTPUT -p tcp --dport 80 -j REJECT
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
iptables -I OUTPUT -p tcp --dport 3013 -j REJECT
iptables -I OUTPUT -p tcp --dport 1112 -j REJECT
iptables -I OUTPUT -p tcp --dport 11443 -j REJECT
iptables -I OUTPUT -p udp --dport 81 -j REJECT
iptables -I OUTPUT -p udp --dport 8011 -j REJECT
iptables -I OUTPUT -p udp --dport 111 -j REJECT
iptables -I OUTPUT -p udp --dport 11038 -j REJECT
iptables -I OUTPUT -p udp --dport 8011 -j REJECT
iptables -I OUTPUT -p udp --dport 20001 -j REJECT
iptables -I INPUT -p tcp --dport 80 -j REJECT
iptables -I INPUT -p tcp --dport 8080 -j REJECT
iptables -I INPUT -p tcp --dport 8085 -j REJECT
iptables -I INPUT -p tcp --dport 8086 -j REJECT
iptables -I INPUT -p tcp --dport 8088 -j REJECT
iptables -I INPUT -p tcp --dport 18081 -j REJECT
iptables -I INPUT -p tcp --dport 3013 -j REJECT
iptables -I INPUT -p tcp --dport 1112 -j REJECT
iptables -I INPUT -p tcp --dport 11443 -j REJECT
iptables -I INPUT -p tcp --dport 17500 -j REJECT
iptables -I OUTPUT -p tcp --dport 17500 -j REJECT
iptables -I OUTPUT -p tcp --dport 80 -j REJECT
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT
iptables -I OUTPUT -p tcp --dport 8085 -j REJECT
iptables -I OUTPUT -p tcp --dport 8086 -j REJECT
iptables -I OUTPUT -p tcp --dport 8088 -j REJECT
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
iptables -I OUTPUT -p tcp --dport 3013 -j REJECT
iptables -I OUTPUT -p tcp --dport 1112 -j REJECT
iptables -I OUTPUT -p tcp --dport 11443 -j REJECT
iptables -I INPUT -s firebaseremoteconfig.googleapis.com -j REJECT &>/dev/null
iptables -I OUTPUT -s firebaseremoteconfig.googleapis.com -j REJECT &>/dev/null
iptables -I INPUT -s 216.58.212.106 -j REJECT &>/dev/null
iptables -I OUTPUT -s 216.58.212.106 -j REJECT &>/dev/null
iptables -I INPUT -s 182.254.116.117 -j REJECT &>/dev/null
iptables -I OUTPUT -s 182.254.116.117 -j REJECT &>/dev/null
iptables -I INPUT -s min-pay.globh.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.globh.com -j REJECT &>/dev/null
iptables -I INPUT -s 20.40.43.235 -j REJECT &>/dev/null
iptables -I OUTPUT -s 20.40.43.235 -j REJECT &>/dev/null
iptables -I INPUT -s sandbox.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s 183.61.41.148 -j REJECT &>/dev/null
iptables -I OUTPUT -s 183.61.41.148 -j REJECT &>/dev/null
iptables -I INPUT -s dev.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s dev.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s szmg.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s szmg.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I INPUT -s pay.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s pay.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I INPUT -s 129.226.3.30 -j REJECT &>/dev/null
iptables -I OUTPUT -s 129.226.3.30 -j REJECT &>/dev/null
iptables -I INPUT -ssandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I INPUT -s 101.32.133.41 -j REJECT &>/dev/null
iptables -I OUTPUT -s 101.32.133.41 -j REJECT &>/dev/null
iptables -I INPUT -ssandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.42.152 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.42.152 -j REJECT &>/dev/null
iptables -I INPUT -s qos.hk.gcloudcs.com -j REJECT &>/dev/null
iptables -I OUTPUT -s qos.hk.gcloudcs.com -j REJECT &>/dev/null
iptables -I INPUT -s hwconfig.gcloudcs.com -j REJECT &>/dev/null
iptables -I OUTPUT -s hwconfig.gcloudcs.com -j REJECT &>/dev/null
iptables -I INPUT -s harmony-hw.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s harmony-hw.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s harmony-hw.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s harmony-hw.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s hk.api.translator.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s hk.api.translator.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s hk.voice.gcloudcs.com -j REJECT &>/dev/null
iptables -I OUTPUT -s hk.voice.gcloudcs.com -j REJECT &>/dev/null
iptables -I INPUT -s idcconfig.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s idcconfig.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s idcconfig.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s idcconfig.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.0.0 -j REJECT &>/dev/null 
iptables -I OUTPUT -s 49.51.0.0 -j REJECT &>/dev/null 
iptables -I INPUT -s 49.51.235.24 -j REJECT &>/dev/null 
iptables -I OUTPUT -s 49.51.235.24 -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.255.255 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.255.255 -j REJECT &>/dev/null
iptables -I INPUT -s down.anticheatexpert.com -j REJECT &>/dev/null 
iptables -I OUTPUT -s down.anticheatexpert.com -j REJECT &>/dev/null 
iptables -I INPUT -s down.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s down.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.0.0 -j REJECT &>/dev/null 
iptables -I OUTPUT -s 49.51.0.0 -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.235.24 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.235.24 -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.255.255 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.255.255 -j REJECT &>/dev/null
iptables -I INPUT -s down.anticheatexpert.com -j REJECT &>/dev/null
iptables -I OUTPUT -s down.anticheatexpert.com -j REJECT &>/dev/null 
iptables -I INPUT -s down.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s down.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s cdn.wetest.net -j REJECT &>/dev/null
iptables -I OUTPUT -s cdn.wetest.net -j REJECT &>/dev/null
iptables -I INPUT -s bugly.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s bugly.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s 119.29.29.29 -j REJECT &>/dev/null
iptables -I OUTPUT -s 119.29.29.29 -j REJECT &>/dev/null
iptables -I INPUT -s 120.198.203.182 -j REJECT &>/dev/null
iptables -I OUTPUT -s 120.198.203.182 -j REJECT &>/dev/null
iptables -I INPUT -s 182.254.116.117 -j REJECT &>/dev/null
iptables -I OUTPUT -s 182.254.116.117 -j REJECT &>/dev/null
iptables -I INPUT -s acs.amazonaws.com -j REJECT &>/dev/null
iptables -I OUTPUT -s acs.amazonaws.com -j REJECT &>/dev/null
iptables -I INPUT -s android.bugly.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s android.bugly.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s astat.bugly.cros.wr.pvp.net -j REJECT &>/dev/null
iptables -I OUTPUT -s astat.bugly.cros.wr.pvp.net -j REJECT &>/dev/null
iptables -I INPUT -s astat.bugly.qcloud.com -j REJECT &>/dev/null
iptables -I OUTPUT -s astat.bugly.qcloud.com -j REJECT &>/dev/null
iptables -I INPUT -s cloud.gsdk.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s cloud.gsdk.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s dashif.org -j REJECT &>/dev/null
iptables -I OUTPUT -s dashif.org -j REJECT &>/dev/null
iptables -I INPUT -s hdebugtbs.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s hdebugtbs.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s debugx5.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s debugx5.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s astat.bugly.qcloud.com -j REJECT &>/dev/null
iptables -I OUTPUT -s astat.bugly.qcloud.com -j REJECT &>/dev/null
iptables -I INPUT -s docs.itop.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s docs.itop.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s itop.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s itop.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s gsdk.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gsdk.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s imgcache.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s imgcache.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s mdc.html5.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s mdc.html5.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s p.mb.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s p.mb.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s pic.xunyou.mobi -j REJECT &>/dev/null
iptables -I OUTPUT -s pic.xunyou.mobi -j REJECT &>/dev/null
iptables -I INPUT -s pingma.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s pingma.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s res.imtt.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s res.imtt.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s mqqad.html5.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s mqqad.html5.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s rqd.uu.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s rqd.uu.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s s3.amazonaws.com -j REJECT &>/dev/null
iptables -I OUTPUT -s s3.amazonaws.com -j REJECT &>/dev/null
iptables -I INPUT -s api.club.gpubgm.com -j REJECT &>/dev/null
iptables -I OUTPUT -s api.club.gpubgm.com -j REJECT &>/dev/null
iptables -I INPUT -s api.vk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s api.vk.com -j REJECT &>/dev/null
iptables -I INPUT -s app.adjust.com -j REJECT &>/dev/null
iptables -I OUTPUT -s app.adjust.com -j REJECT &>/dev/null
iptables -I INPUT -s app.adjust.world -j REJECT &>/dev/null
iptables -I OUTPUT -s app.adjust.world -j REJECT &>/dev/null
iptables -I INPUT -s app.tr.adjust.com -j REJECT &>/dev/null
iptables -I OUTPUT -s app.tr.adjust.com -j REJECT &>/dev/null
iptables -I INPUT -s app.eu.adjust.com -j REJECT &>/dev/null
iptables -I OUTPUT -s app.eu.adjust.com -j REJECT &>/dev/null
iptables -I INPUT -s cdn.wetest.net -j REJECT &>/dev/null
iptables -I OUTPUT -s cdn.wetest.net -j REJECT &>/dev/null
iptables -I INPUT -s cdn.wetest.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s cdn.wetest.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s cgi.connect.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s cgi.connect.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s cgi.qplus.com -j REJECT &>/dev/null
iptables -I OUTPUT -s cgi.qplus.com -j REJECT &>/dev/null
iptables -I INPUT -s cgi.qplus.com -j REJECT &>/dev/null
iptables -I OUTPUT -s cgi.qplus.com -j REJECT &>/dev/null
iptables -I INPUT -s clientrz2.itop.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s clientrz2.itop.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s h.trace.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s h.trace.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s huatuocode.huatuo.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s huatuocode.huatuo.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s h5.vlinkapi.com -j REJECT &>/dev/null
iptables -I OUTPUT -s h5.vlinkapi.com -j REJECT &>/dev/null
iptables -I INPUT -s imasdk.googleapis.com -j REJECT &>/dev/null
iptables -I OUTPUT -s imasdk.googleapis.com -j REJECT &>/dev/null
iptables -I INPUT -s long.open.weixin.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s long.open.weixin.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s oauth.vk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s oauth.vk.com -j REJECT &>/dev/null
iptables -I INPUT -s openmobile.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s openmobile.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s papi.club.gpubgm.com -j REJECT &>/dev/null
iptables -I OUTPUT -s papi.club.gpubgm.com -j REJECT &>/dev/null
iptables -I INPUT -s sdk.vlinkapi.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sdk.vlinkapi.com -j REJECT &>/dev/null
iptables -I INPUT -s tapi.club.gpubgm.com -j REJECT &>/dev/null
iptables -I OUTPUT -s tapi.club.gpubgm.com -j REJECT &>/dev/null
iptables -I INPUT -s test-api-inter.gbot.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s test-api-inter.gbot.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s testcloud.vmp.onezapp.com -j REJECT &>/dev/null
iptables -I OUTPUT -s testcloud.vmp.onezapp.com -j REJECT &>/dev/null
iptables -I INPUT -s vodreport.qcloud.com -j REJECT &>/dev/null
iptables -I OUTPUT -s vodreport.qcloud.com -j REJECT &>/dev/null
iptables -I INPUT -s app-measurement.com -j REJECT &>/dev/null
iptables -I OUTPUT -s app-measurement.com -j REJECT &>/dev/null
iptables -I INPUT -s xml.apache.org -j REJECT &>/dev/null
iptables -I OUTPUT -s xml.apache.org -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "szmg" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "szmg" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "idcconfig" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "idcconfig" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "report" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "report" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "cheat" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "cheat" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "gcloudsdk" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "gcloudsdk" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "gcloudsdk" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "gcloudsdk" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "globh" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "globh" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "pgtom" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "pgtom" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "ssandbox" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "ssandbox" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "tglog" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "tglog" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "log" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "log" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "logs" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "logs" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "euspeed" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "euspeed" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "tdatamaster" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "tdatamaster" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "anticheatexpert" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "anticheatexpert" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "amsoveasea" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "amsoveasea" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "firebase" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "firebase" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "bugly" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "bugly" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "pandora" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "pandora" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "config2" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "config2" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "config3" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "config3" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "dyncures" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "dyncures" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "mbgame" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "mbgame" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "csoversea" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "csoversea" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "tss" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "tss" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "tmp" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "tmp" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "xml" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "xml" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "txt" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "txt" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "zip" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "zip" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "ini" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "ini" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "json" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "json" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "shadow" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "shadow" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "graph" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "graph" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "googleads" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "googleads" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "localhost" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "localhost" -j REJECT &>/dev/null
iptables -I INPUT -s 129.226.2.165 -j REJECT &>/dev/null
iptables -I OUTPUT -s 129.226.2.165 -j REJECT &>/dev/null
iptables -I INPUT -s 101.91.63.139 -j REJECT &>/dev/null
iptables -I OUTPUT -s 101.91.63.139 -j REJECT &>/dev/null
iptables -A OUTPUT -d 127.0.0.1/24 -j REJECT
iptables -A OUTPUT -d 224.0.0.0/24 -j REJECT
iptables -A OUTPUT -d 169.254.0.0/24 -j REJECT
iptables -A OUTPUT -d 172.16.0.0/24 -j REJECT
iptables -A OUTPUT -d 192.0.2.0/24 -j REJECT
iptables -A OUTPUT -d 192.168.0.0/24 -j REJECT
iptables -A OUTPUT -d 10.0.0.0/24 -j REJECT
iptables -A OUTPUT -d 0.0.0.0/24 -j REJECT
iptables -A OUTPUT -d 240.0.0.0/24 -j REJECT
iptables -A OUTPUT -d 127.0.0.0/24 -j REJECT
iptables -A OUTPUT -d 192.168.8.1/24 -j REJECT
iptables -I INPUT -p udp --dport 10013 -j REJECT
iptables -I OUTPUT -p udp --dport 10013 -j REJECT
iptables -I INPUT -p tcp --dport 10013 -j REJECT
iptables -I OUTPUT -p tcp --dport 10013 -j REJECT
iptables -I INPUT -p udp --dport 18301 -j REJECT
iptables -I OUTPUT -p udp --dport 18301 -j REJECT
iptables -I INPUT -p tcp --dport 18301 -j REJECT
iptables -I OUTPUT -p tcp --dport 18301 -j REJECT
iptables -I INPUT -p udp --dport 8011 -j REJECT
iptables -I OUTPUT -p udp --dport 8011 -j REJECT
iptables -I INPUT -p tcp --dport 8011 -j REJECT
iptables -I OUTPUT -p tcp --dport 8011 -j REJECT
iptables -I INPUT -p tcp --dport 18081 -j REJECT
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
iptables -I INPUT -p udp --dport 18081 -j REJECT
iptables -I OUTPUT -p udp --dport 18081 -j REJECT
iptables -I INPUT -p tcp --dport 8013 -j REJECT
iptables -I OUTPUT -p tcp --dport 8013 -j REJECT
iptables -I INPUT -p udp --dport 8013 -j REJECT
iptables -I OUTPUT -p udp --dport 8013 -j REJECT
iptables -I INPUT -p udp --dport 53 -j REJECT
iptables -I OUTPUT -p udp --dport 53 -j REJECT
iptables -I INPUT -p tcp --dport 53 -j REJECT
iptables -I OUTPUT -p tcp --dport 53 -j REJECT
iptables -I INPUT -p udp --dport 8180 -j REJECT
iptables -I OUTPUT -p udp --dport 8180 -j REJECT
iptables -I INPUT -p tcp --dport 8180 -j REJECT
iptables -I OUTPUT -p tcp --dport 8180 -j REJECT
iptables -I INPUT -p udp --dport 60000 -j REJECT
iptables -I OUTPUT -p udp --dport 60000 -j REJECT
iptables -I INPUT -p tcp --dport 60000 -j REJECT
iptables -I OUTPUT -p tcp --dport 60000 -j REJECT
iptables -A INPUT -p tcp --dport 17500 -s mgl.lobby.igamecj.com -j REJECT
iptables -A INPUT -p icmp -j REJECT
iptables -A OUTPUT -p icmp -j REJECT 
iptables -I INPUT -p tcp -m string --string "in-cloudctrl.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "in-cloudctrl.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "pubgmobile.helpshift.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "pubgmobile.helpshift.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "app.adjust.net.in" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "app.adjust.net.in" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "tdm.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "tdm.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "gcloud.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "gcloud.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "in-gcloud.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "in-gcloud.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "3002-shadow.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "3002-shadow.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "3001-shadow.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "3001-shadow.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "in-csoversea.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "in-csoversea.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "in-bugly-android.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "in-bugly-android.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "shadow.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "shadow.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "in-tdm.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "in-tdm.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "in-bugly-android.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "in-bugly-android.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "abs.twimg.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "abs.twimg.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "pbs.twimg.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "pbs.twimg.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "lh3.googleusercontent.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "lh3.googleusercontent.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "asping.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "asping.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "in3-f.globh.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "in3-f.globh.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "ubam.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "ubam.broker.amsoveasea.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "broker.amsoveasea.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "broker.amsoveasea.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "m.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "m.broker.amsoveasea.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "nawzryhwatm.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "nawzryhwatm.broker.amsoveasea.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "napubgm.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "napubgm.broker.amsoveasea.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "na.apps.amsoveasea.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "na.apps.amsoveasea.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "pandora.amsoveasea.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "pandora.amsoveasea.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "amsoveasea.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "amsoveasea.com" --algo kmp -j REJECT
iptables -I INPUT -p tcp -m string --string "pandoracdn.amsoveasea.com" --algo bm -j REJECT
iptables -I INPUT -p udp -m string --string "pandoracdn.amsoveasea.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "in-cloudctrl.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "in-cloudctrl.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "pubgmobile.helpshift.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "pubgmobile.helpshift.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "app.adjust.net.in" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "app.adjust.net.in" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "tdm.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "tdm.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "gcloud.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "gcloud.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "in-gcloud.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "in-gcloud.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3002-shadow.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "3002-shadow.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3001-shadow.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "3001-shadow.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "in-csoversea.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "in-csoversea.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "in-bugly-android.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "in-bugly-android.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "shadow.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "shadow.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "in-tdm.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "in-tdm.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "in-bugly-android.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "in-bugly-android.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "abs.twimg.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "abs.twimg.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "pbs.twimg.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "pbs.twimg.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "lh3.googleusercontent.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "lh3.googleusercontent.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "asping.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "asping.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "in3-f.globh.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "in3-f.globh.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "ubam.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "ubam.broker.amsoveasea.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "broker.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "broker.amsoveasea.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "m.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "m.broker.amsoveasea.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "nawzryhwatm.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "nawzryhwatm.broker.amsoveasea.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "napubgm.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "napubgm.broker.amsoveasea.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "na.apps.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "na.apps.amsoveasea.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "pandora.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "pandora.amsoveasea.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "amsoveasea.com" --algo kmp -j REJECT
iptables -I OUTPUT -p tcp -m string --string "pandoracdn.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p udp -m string --string "pandoracdn.amsoveasea.com" --algo kmp -j REJECT
iptables -I OUTPUT -p all -m string --string "amazonaws.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "amazonaws.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "pubgmobile.helpshift.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "pubgm.helpshift.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "euspeed.igamecj.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "euspeed.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "cloud.gsdk.proximabeta.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "cloud.gsdk.proximabeta.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "platform-lookaside.fbsbx.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "platform-lookaside.fbsbx.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "sg.tdatamaster.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "sg.tdatamaster.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "cloudctrl.gcloudsdk.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "cloudctrl.gcloudsdk.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "googleads.g.doubleclick.net" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "googleads.g.doubleclick.net" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "ig-us-sdkapi.igamecj.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "ig-us-sdkapi.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "graph.facebook.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "graph.facebook.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "cdn.wetest.qq.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "cdn.wetest.qq.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "astat.bugly.qcloud.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "astat.bugly.qcloud.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "cloud.vmp.onezapp.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "cloud.vmp.onezapp.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "ig-us-notice.igamecj.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "ig-us-notice.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "na-east.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "na-east.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "na-mx.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "na-mx.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "na-centra.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "na-centra.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "5005-shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "5005-shadow.igamecj.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "5004-shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "5004-shadow.igamecj.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "me-du.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "me-du.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null
iptables -I INPUT -p all -m string --string "1006-shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "1006-shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "eu-fra.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "eu-fra.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "2006-shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "2006-shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "2005-shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "2005-shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "2007-shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "2007-shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "eu-mo.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "eu-mo.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "kj-se.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "kj-se.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "3022-shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "3022-shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "as-sg-m.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "as-sg-m.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "as-in.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "as-in.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "as-mb.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "as-mb.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "as-hk.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "as-hk.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "as-sg.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "as-sg.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "3021-shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "3021-shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "sa-sap.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "sa-sap.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "sa-scl.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "sa-scl.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "4006-shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "4006-shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "kj-tk.shadow.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "kj-tk.shadow.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "pay.igamecj.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "pay.igamecj.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "www.pubgmobile.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "www.pubgmobile.com" --algo bm -j REJECT &>/dev/null 
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j REJECT &>/dev/null
iptables -I OUTPUT -p all -m string --string hc.tdm.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string c.tdm.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string d.tdm.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string le.proxyacc.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string d.tdm.qq --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string c.tdm.qq --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string sqlobby.pg.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string 17500.aioks.cn --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string idcconfig.gcloudsdk.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string gcloud.tencent.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string intl.console.gcloud.tencent.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string wecard.tenpay.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string sdk.gcloud.tencent.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string dl.gcloud.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string consolev2.gcloud.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string web.gcloud.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string speedm-team.tga.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string web.gcloud.tencent.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string app.tga.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string mspeed-op.tga.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string op.tga.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string intl.gcloud.tencent.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string gcloud.tencent --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string hpjy-op.tga.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string qos.gcloud.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string qosidc.gcloud.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string qosidc.gcloudsdk.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string wx.qlogo.cn --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string thirdwx.qlogo.cn --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string cwx.qlogo.cn --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string cn.voice.gcloudcs.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string master.solar.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string capi.voice.gcloud.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string jsonatm.broker.tplay.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string cjm.broker.tplay.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string control.mna.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string control.mocmna.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string tools.tmga.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string access1.tpns.sh.tencent.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string apm.wetest.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string test.mhzx.qq.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string down.anticheatexpert.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string he8nvbq7.dayugslb.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string stat.tpns.sh.tencent.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string log.tpns.sh.tencent.com --algo bm -j REJECT
iptables -I OUTPUT -p all -m string --string guid.tpns.sh.tencent.com --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "5004-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "5003-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "7001-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "7003-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3009-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3011-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "2005-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "2006-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3013-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3003-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3012-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3008-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "1005-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "7002-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "2004-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "5002-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3007-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "2004-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "5005-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "2007-shdow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "5004-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "5003-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "7001-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "7003-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3009-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3011-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "2005-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "2006-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3013-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3003-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3012-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3008-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "1005-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "7002-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "2004-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "5002-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "3007-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "2004-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "5005-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "2007-shadow.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "lib.tdatamaster.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "tag.tdatamaster.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "www.tdatamaster.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "jtsg.tdatamaster.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "tsg.tdatamaster.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "sg.tdatamaster.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "tdatamaster.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "ubam.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "broker.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "napubgmlite.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "m.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "nawzryhwatm.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "napubgm.broker.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "na.apps.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "pandora.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "pandoracdn.amsoveasea.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "down.anticheatexpert.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "cloud.vmp.onezapp.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "app.adjust.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "ig-us-notice.igamecj.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "cloud.gsdk.proximabeta.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "cloudctrl.gcloudsdk.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "cdn.wetest.net" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "tencentgames.helpshift.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string ".www.pubgmobile.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "www.pubgmobile.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "proximabeta.com" --algo bm -j REJECT
iptables -I OUTPUT -p tcp -m string --string "in-f.globh.com" --algo bm -j REJECT
