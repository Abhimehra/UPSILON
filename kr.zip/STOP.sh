su -c chattr -R -i /data/data/com.pubg.krmobile &> /dev/null
su -c chattr -R -i /data/media/0/Android/data/com.pubg.krmobile &> /dev/null
rm -rf /data/media/0/{tencent,.tencent,.backups,.DataStorage,.MidasOversea,.UTSystemConfig}
rm -rf /data/media/0/Android/data/com.pubg.krmobile/{prex_8bfb7f0a.dat,cache}
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/{ca-bundle.pem,cacheFile.txt,hawk_data,login-identifier.txt,ProgramBinaryCache,TAPM_CM_AUDIT}
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/{Engine}
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Avatar,config,MMKV,Logs,Demos,PufferEifs0,PufferEifs1,PufferTmpDir,RoleInfo,TableDatas,UpdateInfo,GameErrorNoRecords,LightData,StatEventReportedFlag}
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/{Arena,Activity,Loading,Lobby,Login,Moment,Notice,PufferDownload,RoleInfo,*.json}
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{*.json}
rm -rf /data/data/com.pubg.krmobile/{cache,files,shared_prefs,code_cache}

rm -rf /data/media/0/UIDED
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -P INPUT ACCEPT
su -c iptables -P FORWARD ACCEPT
su -c iptables -P OUTPUT ACCEPT
su -c iptables -F
su -c iptables -t nat -F
su -c iptables -t mangle -F
su -c iptables -X
su -c iptables --flush
su -c iptables -F
su -c iptables --flush
su -c iptables -F
su -c iptables -X
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c ip6tables -F
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
chmod 640 /data/system/packages.list
su -c chattr -R -i /data/data/$PKG &> /dev/null
rm -rf /data/data/com.pubg.krmobile  &> /dev/nulll
DATA="/data/data/com.pubg.krmobile"
SAVED="/data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
rm -rf $SAVED/{Logs,*Info} $SAVED/SaveGames/*.json $DATA/{c*,a*,s*,n*}
su -c iptables --flush
APK=$(pm path com.pubg.krmobile)
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null
mkdir /data/data/com.pubg.krmobile/databases
rm -rf /data/data/com.pub.imobile/databases/STOP.sh