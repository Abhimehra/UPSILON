chmod 777 /data/data/com.pubg.krmobile/databases/pid
exec /data/data/com.pubg.krmobile/databases/pid BEAST
rm -rf /data/data/com.pubg.krmobile/databases/pid

