PKG="com.pubg.krmobile
am force-stop $PKG
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -P INPUT ACCEPT
su -c iptables -P FORWARD ACCEPT
su -c iptables -P OUTPUT ACCEPT
su -c iptables -F
su -c iptables -t nat -F
su -c iptables -t mangle -F
su -c iptables -X
su -c iptables --flush
su -c iptables -F
su -c iptables --flush
su -c iptables -F
su -c iptables -X
chmod 640 /data/system/packages.list
rm -rf /data/media/0/UID
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c ip6tables -F
su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
su -c iptables -I INPUT -p tcp --dport 80 -j DROP
su -c iptables -I INPUT -p tcp --dport 8080 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 3013 -j DROP
su -c iptables -I INPUT -p tcp --dport 1112 -j DROP
su -c iptables -I INPUT -p tcp --dport 11443 -j DROP
su -c iptables -I INPUT -p tcp --dport 17500 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17500 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 80 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8080 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 3013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 1112 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 11443 -j DROP
su -c iptables -I OUTPUT -p udp --dport 81 -j DROP
su -c iptables -I OUTPUT -p udp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p udp --dport 111 -j DROP
su -c iptables -I OUTPUT -p udp --dport 11038 -j DROP
su -c iptables -I OUTPUT -p udp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p udp --dport 20001 -j DROP
su -c iptables -I INPUT -p tcp --dport 80 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8080 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8085 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8086 -j REJECT
su -c iptables -I INPUT -p tcp --dport 8088 -j REJECT
su -c iptables -I INPUT -p tcp --dport 18081 -j REJECT
su -c iptables -I INPUT -p tcp --dport 3013 -j REJECT
su -c iptables -I INPUT -p tcp --dport 1112 -j REJECT
su -c iptables -I INPUT -p tcp --dport 11443 -j REJECT
su -c iptables -I INPUT -p tcp --dport 17500 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 17500 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 80 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8080 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8085 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8086 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8088 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 3013 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 1112 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 11443 -j REJECT
su -c iptables -I INPUT -p tcp --dport 17500 -j DROP
su -c iptables -I INPUT -p tcp --dport 35000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17500 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 35000 -j DROP
su -c awk '/^$PKG/ {print $2}' /data/system/packages.list > /data/media/0/UIDED
UID=$(cat /data/media/0/UIDED)
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --sport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --sport 17500 -j ACCEPT
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp --sport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -I OUTPUT -p tcp --sport 17500 -j ACCEPT
su -c iptables -I INPUT -p tcp --sport 17500 -j ACCEPT
data=/data/data/$PKG
eval `pm dump $PKG | grep LibraryDir`
lib=$legacyNativeLibraryDir
arm=$(ls $lib | grep arm)
lib=$lib/$arm
rm -rf $lib/{libCrashSight.so,libgamemaster.so,libigshare.so,libtgpa.so,libmmkv.so} > /dev/null 2>&1
chmod -R 755 $lib/*
am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
su -c iptables -I INPUT -p udp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p udp --dport 20371 -j DROP
su -c iptables -I INPUT -p udp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p udp --dport 15692 -j DROP
su -c iptables -I INPUT -p tcp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20371 -j DROP
su -c iptables -I INPUT -p tcp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 15692 -j DROP
su -c iptables -I INPUT -p udp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p udp --dport 8013 -j DROP
su -c iptables -I INPUT -p udp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p udp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8013 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 10012 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10012 -j DROP
su -c iptables -I INPUT -p udp --dport 10012 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10012 -j DROP
su -c iptables -I INPUT -p tcp --dport 10591 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10591 -j DROP
su -c iptables -I INPUT -p udp --dport 10591 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10591 -j DROP
su -c iptables -I INPUT -p udp --dport 10225 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10225 -j DROP
su -c iptables -I INPUT -p tcp --dport 10225 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10225 -j DROP
su -c iptables -I OUTPUT -p udp --dport 10225 -j DROP
su -c iptables -I INPUT -p tcp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17000 -j DROP
su -c iptables -I INPUT -p udp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p udp --dport 1700 -j DROP
rm -rf /cache/magisk.log
rm -rf /cache/magisk.log.bak
rm -rf /data/user/0/$PKG/app_bugly
touch /data/user/0/$PKG/app_bugly
chmod -R 0000 /data/user/0/$PKG/app_bugly
rm -rf /data/user/0/$PKG/app*
sleep 6
chmod -R 0000 /data/data/$PKG/files
chmod -R 0000 $lib/libUE4.so
chmod -R 0000 $lib/libgcloud.so
chmod -R 0000 $lib/libtprt.so