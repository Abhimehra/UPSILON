clear
mv /data/data/com.pubg.krmobile/databases/hosts_b /system/etc/hosts_b
gl=/data/data/com.tencent.ig/
kr=/data/data/com.pubg.krmobile/
vn=/data/data/com.vng.pubgmobile/
tw=/data/data/com.rekoo.pubgm/
bgmi=/data/data/com.pubg.krmobile/

if [ -d "$gl" ]; then
    PKG="com.tencent.ig"
fi
 
if [ -d "$kr" ]; then
    PKG="com.pubg.krmobile"
fi

if [ -d "$vn" ]; then
    PKG="com.vng.pubgmobile"
fi

if [ -d "$tw" ]; then
    PKG="com.rekoo.pubgm"
fi

if [ -d "$bgmi" ]; then
    PKG="com.pubg.krmobile"
fi

pm path $PKG &> /dev/null || {
  echo "\nPUBGM not installed!"
  exit
}

echo "LOADING BEAST UPSILON BYPASS"
sleep 2
data=/data/data/$PKG
eval `pm dump $PKG | grep LibraryDir`
arm=$(ls $lib | grep arm)
M=/data/data
Saved=/storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
rm -rf /data/data/$PKG/{app_bugly,app_crashrecord}
touch /data/data/$PKG/{app_bugly,app_crashrecord}
chmod 4000 /data/data/$PKG/{app_bugly,app_crashrecord}
cp hook2 $M/;
chmod 777 $M/hook2;
L=/data/data/com.pubg.krmobile/app_valac_files/libvalac.so
if [ ! -e "$L" ]; then
    mkdir cp  /data/data/com.pubg.krmobile/app_valac_files/
    cp  $M/hook2 $L
fi

cd /data/data/com.pubg.krmobile && rm -rf app_crashrecord && echo > app_crashrecord
iptables -A INPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p udp -m udp --dport 20001 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 11038 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 111 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 81 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18600 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18600 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18600 -j REJECT
iptables -A OUTPUT -p tcp -m tcp --dport 18600 -j REJECT
S 1
echo 16384 > /proc/sys/fs/inotify/max_queued_events
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 8192 > /proc/sys/fs/inotify/max_user_watches
rm -rf src/main/java/com/google/errorprone/annotations
rm -rf src/main/java/com/google/errorprone/annotations/concurrent
rm -rf third_party.java_src.error_prone.project.annotations.Google_internal
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
echo '128' > /proc/sys/fs/inotify/max_user_instances
echo '8192' > /proc/sys/fs/inotify/max_user_watches
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"
S 1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
pm path com.pubg.krmobile &> /dev/null
killall com.pubg.krmobile 2&> /dev/null
DUMP() {
pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
lib=`ls -mR $(DUMP com.pubg.krmobile legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v sosna`
SAVE(){
cp $lib/$1 $lib/$1.bak
}
RETURN(){
mv $lib/$1.bak $lib/$1
}
SP -R 755 /data/data/com.pubg.krmobile/lib/*
SP 755 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak
cp -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.76262.pak
R /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
E '[version]
appversion=1.6.0.15522
srcversion=1.6.0.91911' >> /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
R /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
SP 550 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
SP 555 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
R /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
E " null " >> /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
cp /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
R /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
R /data/cache/magisk.log
R /data/cache/magisk.log.bak
SP 755 /data/data/com.pubg.krmobile/lib/*
R /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload
R /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
R /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
R /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
R /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
R /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
R /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
R /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
R /sdcard/Android/data/com.pubg.krmobile/files/TGPA
R /sdcard/Android/data/com.pubg.krmobile/cache
R /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
R /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
R /data/media/0/ꜰᴜᴄᴋᴘᴜʙɢᴀɴᴛɪᴄʜᴇᴀᴛ
mkdir /data/media/0/ꜰᴜᴄᴋᴘᴜʙɢᴀɴᴛɪᴄʜᴇᴀᴛ
SP -R 755 /data/data/com.pubg.krmobile/lib/*
R $lib/{libzip.so,libBugly.so,libgamemaster.so,libgcloudarch.so,libhelpshiftlistener.so,libigshare.so,liblbs.so-libnpps-jni.so,libst-engine.so,libtgpa.so}
SP -R 755 /data/data/com.pubg.krmobile/lib/*
SAVE libtprt.so
SAVE libUE4.so
sleep 1
am force-stop com.pubg.krmobile
rm -rf /data/data/com.pubg.krmobile/cache
rm -rf /data/data/com.pubg.krmobile/cache
rm -rf /data/data/com.pubg.krmobile/shared_prefs
rm -rf /data/data/com.pubg.krmobile/app_bugly
rm -rf /data/data/com.pubg.krmobile/app_crashrecord
rm -rf /data/data/com.pubg.krmobile/no_backup
sleep 1
rm -rf /data/data/com.pubg.krmobile/files
rm -rf /data/data/com.pubg.krmobile/app_crashrecord
rm -rf /data/data/com.pubg.krmobile/app_bugly
rm -rf /data/data/com.pubg.krmobile/cache
rm -rf /data/data/com.pubg.krmobile/code_cache
S 1
touch /data/data/com.pubg.krmobile/files
touch /data/data/com.pubg.krmobile/app_crashrecord
touch /data/data/com.pubg.krmobile/app_bugly
touch /data/data/com.pubg.krmobile/cache
touch /data/data/com.pubg.krmobile/code_cache
S 1
chmod -R 000 /data/data/com.pubg.krmobile/files
chmod -R 000  /data/data/com.pubg.krmobile/app_crashrecord
chmod -R 000 /data/data/com.pubg.krmobile/app_bugly
chmod -R 000 /data/data/com.pubg.krmobile/cache
chmod -R 000 /data/data/com.pubg.krmobile/code_cache

am start -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity > /dev/null
sleep 15
echo ${black2} "FLUSHING SERVER BAN IN BACKGROUND"${no}
ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
S 7
R $lib/{libUE4.so,libtprt.so}
S 3
RETURN libtprt.so
RETURN libUE4.so
SP 755 /data/data/com.pubg.krmobile/lib/*
S 1
R /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/Android/Updater.ini
S 15
rm -rf /data/media/0/Android/data/com.pubg.krmobile/cache
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs

touch /data/media/0/Android/data/com.pubg.krmobile/cache
touch /data/media/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
touch /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /data/data/com.pubg.krmobile/databases/{json.sh,hook,hook2}
#rm -rf /data/data/com.pubg.krmobile/databases/{hook,hook2,hosts_b,json.sh}


