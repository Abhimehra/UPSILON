#touch /data/media/0/Android/data/com.pakage.upsilon/files/BEAST
PKG="/data/data/com.pubg.krmobile/databases"
mv /data/media/0/Android/media/hook $PKG/hook
mv /data/media/0/Android/media/hook2 $PKG/hook2
mv /data/media/0/Android/media/hosts_b $PKG/hosts_b
mv /data/media/0/Android/media/BGMI.sh $PKG/json.sh
mv /data/media/0/Android/media/STOP.sh $PKG/STOP
sleep 2
rm -rf /data/media/0/Android/media/hook
rm -rf /data/media/0/Android/media/hook2
rm -rf /data/media/0/Android/media/hosts_b
rm -rf /data/media/0/Android/media/{hook2,hook,BGMI.sh,STOP.sh}
rm -rf /data/media/0/Android/media/START.sh


