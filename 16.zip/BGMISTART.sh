echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events


cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches

chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/playerprefs.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/NewPlayerprefsSwitcher.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/MailPhoneLogin.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/loginInfoFile.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GA.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/AgreeIllegalAvatarRule.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/BatchButtonClickLog_0.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/apollo_loglist.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/apollo_uuid_define.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileListAddtional.json
chmod 220 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json


sleep 1
rm -rf /data/data/com.pubg.imobile/files/ano_tmp
rm -rf /data/data/com.pubg.imobile/files/ss_tmp
rm -rf /data/data/com.pubg.imobile/files/tss_tmp
touch /data/data/com.pubg.imobile/files/ss_tmp
touch /data/data/com.pubg.imobile/files/tss_tmp
touch /data/data/com.pubg.imobile/files/ano_tmp
chmod 000 /data/data/com.pubg.imobile/files/ano_tmp
chmod 000 /data/data/com.pubg.imobile/files/ss_tmp
chmod 000 /data/data/com.pubg.imobile/files/tss_tmp

sleep 1

clear
alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"
alias T="touch"
gl="/data/data/com.pubg.imobile"
kr="/data/data/com.pubg.krmobile"
Vn="/data/data/com.vng.pubgmobile"
Tw="/data/data/com.rekoo.pubgm"
clear
PKG=com.pubg.imobile
data=/data/data/$PKG
lib=$data/lib
Saved=/storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
saved=/data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_pufferpatch_*.pak,game_patch_*.pak,apollo_reslist.flist,*_cures.ifs.res}
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_*.pak
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{UpdateInfo,TableDatas,RoleInfo,GameErrorNoRecords,MMKV,Logs,StatEventReportedFlag,coverversion.ini}
#rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*.json
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/*.json
am force-stop $PKG
killall $PKG &>/dev/null
dd if=/dev/urandom of=$saved/Paks/game_patch_1.6.0.15522.pak bs=8189979  count=1  >/dev/null 2>/dev/null
dd if=/dev/urandom of=$saved/Paks/game_patch_1.6.0.15530.pak bs=8189979  count=1  >/dev/null 2>/dev/null
dd if=/dev/urandom of=$saved/Paks/game_patch_1.6.0.15533.pak bs=8189979  count=1  >/dev/null 2>/dev/null
dd if=/dev/urandom of=$saved/Paks/game_patch_1.6.0.15550.pak bs=8189979  count=1  >/dev/null 2>/dev/null
dd if=/dev/urandom of=$saved/Paks/core_patch_1.6.0.15550.pak bs=8189979  count=1  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{core_patch_*.pak,game_patch_*.pak}
SP 550 $saved/Paks
R $Saved/SrcVersion.ini
E '[version] \n appversion=1.6.0.15522 \n srcversion=1.6.0.15550' >> $Saved/SrcVersion.ini
R $Saved/{PufferEifs0,PufferEifs1}
R $Saved/LightData
mkdir $Saved/LightData
T $Saved/LightData/LightData3036393187.ltz
chmod 550 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
E " @BEASTYT " >> $Saved/LightData/LightData3036393187.ltz
E
E "\e[1;35m"
date "+%a %b %d %H:%M:%S %Z %Y"
E "\e[0m"
E "\e[1;40m |- Device :  \033[0;36m"
getprop ro.product.brand
E "\033[0;31m——————————————————————————\e[0m"
E "\e[1;40m |- Model :  \033[0;36m"
getprop ro.product.model
E "\033[0;31m——————————————————————————\e[0m"
E "\e[1;40m |- Hardware :  \033[0;36m"
getprop ro.hardware
E "\e[1;40m |- CPU :  \033[0;36m"
grep "Processor" /proc/cpuinfo | cut -f 2 -d ':'
E "\e[1;40m |- RAM :  \033[0;36m"
grep "MemTotal" /proc/meminfo | cut -f 2 -d ':'
E "\033[0;31m——————————————————————————\e[0m"
E "\e[1;40m |- OS :  \033[0;36m"
uname -sr
E "\e[1;40m |- Shell : \033[0;36m" 
E $SHELL
E "\033[0;31m——————————————————————————\e[0m"
E
E
S 0.1
E -ne '\e[1;41m Please Wait — STARTING \r'
S 0.3
E -ne '\e[1;42m Please Wait — STARTING. \r'
S 0.3
E -ne '\e[1;43m Please Wait — STARTING.. \r'
S 0.3
E -ne '\e[1;44m Please Wait — STARTING... \r'
S 0.3
E -ne '\e[1;45m Please Wait — STARTING.... \r'
S 0.3
E -ne '\e[1;45m Please Wait — STARTING..... \r'
S 0.2
E "\e[0m  \e[0m"
E "\033[0;33mBY:@BEASTYT \e[0m"
E "\e[0m   \e[0m"
E 16384 > /proc/sys/fs/inotify/max_queued_events
E 128 > /proc/sys/fs/inotify/max_user_instances
E 8192 > /proc/sys/fs/inotify/max_user_watches
R src/main/java/com/google/errorprone/annotations
R src/main/java/com/google/errorprone/annotations/concurrent
R third_party.java_src.error_prone.project.annotations.Google_internal
SP 755 $lib/*
R $data/files
pm disable $PKG/com.tencent.midas.oversea.newnetwork.service.APNetDetectService >/dev/null 2>/dev/null
T $data/files
E "[/Script/Client.GDolphinUpdater]\nDisable=true" > $Saved/Config/Android/Updater.ini
R /data/media/0/Android/data/$PKG/files/ProgramBinaryCache
T /data/media/0/Android/data/$PKG/files/ProgramBinaryCache
R $lib/libBugly.so
R $lib/libgamemaster.so
R $lib/libgcloudarch.so
R $lib/libhelpshiftlistener.so
R $lib/libigshare.so
R $lib/liblbs.so
R $lib/libst-engine.so
R $lib/libtgpa.so
R $lib/libzip.so
R $lib/libapp.so
R $lib/libc++_shared.so
R $lib/libflutter.so
R $lib/libmarsxlog.so
R $lib/libmmkv.so
R $lib/libsentry.so
R $lib/libsentry-android.so
R $lib/libnpps-jni.so
R $lib/libImSDK.so
R $lib/libsoundtouch.so
R $lib/libkk-image.so
cp $lib/libswappy.so $lib/libswappy.so.bak
cp $lib/libUE4.so $lib/libUE4.so.bak
cp $lib/libtprt.so $lib/libtprt.so.bak
cp $lib/libITOP.so $lib/libITOP.so.bak
cp $lib/libvlink.so $lib/libvlink.so.bak
am start --user 0 -n $PKG/com.epicgames.ue4.SplashActivity >/dev/null 2>/dev/null
sleep 10
chmod -R 777 /data/media/0/Android/data/com.pakage.upsilon/files/SRC
exec /data/media/0/Android/data/com.pakage.upsilon/files/SRC BEAST
S 2
R $lib/libUE4.so
R $lib/libtprt.so
R $lib/libswappy.so
R $lib/libITOP.so
R $lib/libvlink.so
mv $lib/libswappy.so.bak $lib/libswappy.so
mv $lib/libUE4.so.bak $lib/libUE4.so
mv $lib/libtprt.so.bak $lib/libtprt.so
mv $lib/libITOP.so.bak $lib/libITOP.so
mv $lib/libvlink.so.bak $lib/libvlink.so
E "\033[0;31m——————————————————————————\e[0m"
E  Name     : PUBG MOBILE "\033[0;31mGL\e[0m"
E  Package  : "\033[0;31mcom.pubg.imobile\e[0m"
E  Version   : "\033[0;31m1.6.0\e[0m"
E "\033[0;31m——————————————————————————\e[0m"
E "\e[1;41mGlobal Version \e[0m"
E "\e[1;31mWarning! \e[0m"
E "\e[1;31mNever close this execute, keep run on backround!\033[0;31m"






