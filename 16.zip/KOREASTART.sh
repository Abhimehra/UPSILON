echo ""
date
getprop ro.product.brand
getprop ro.product.model
sleep 1
echo ""
echo "[5;34m------------------- Ⓜ️|HACK| -------------------"
echo "[5;34m Creator and developer in telegram: @Gxghost"
echo "[5;34m------------------- Ⓜ️|HACK| -------------------"
sleep 1
echo ""
echo ""
echo ""
echo "[5;33m DISABLE PUBGM ANTICHEAT SYSTEM"
echo "[5;33m............................"
sleep 1
rm -rf /sdcard/@Gxghost
mkdir /sdcard/@Gxghost
GL=com.pubg.krmobile
data=/data/data/$GL
lib=$data/lib
DIR=/storage/emulated/0/Android/data/$GL/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
MAIN=/storage/emulated/0/Android/data/$GL
am force-stop $GL
pkill $GL
cp $lib/libtprt.so $lib/libtprt.so.bak
cp $lib/libUE4.so $lib/libUE4.so.bak
cp $lib/libtersafe.so $lib/libtersafe.so.bak
rm -rf $lib/{libtgpa.so,libBugly.so}
chmod 755 $lib/*
rm -rf $data/files
touch $data/files
chmod 0 $data/files
echo "[/Script/Client.GDolphinUpdater]\nDisable=true" > $DIR/Config/Android/Updater.ini
dd if=/dev/urandom of=$DIR/Paks/core_patch_1.6.0.15566.pak bs=900 count=900 &> /dev/null;
rm -rf $DIR/Paks/{game_patch_1.6.0.15532.pak,game_patch_1.6.0.15533.pak,game_patch_1.6.0.15535.pak,res_pufferpatch_1.6.0.15528.pak,res_pufferpatch_1.6.0.15533.pak,*res,puffer_temp}
rm -rf $DIR/{Pandora,PufferEifs1,PufferEifs0,Logs,RoleInfo,TableDatas,PufferTmpDir,ImageDownload,UpdateInfo,*json,*log,MMKV}
touch $DIR/{Pandora,PufferEifs1,PufferEifs0,Logs,RoleInfo,TableDatas,PufferTmpDir,ImageDownload,UpdateInfo,MMKV}
rm -rf $DIR/{GameErrorNoRecords,StatEventReportedFlag}
mkdir $DIR/{GameErrorNoRecords,StatEventReportedFlag}
rm -rf $MAIN/cache
touch $MAIN/cache
rm -rf $MAIN/files/{cacheFile.txt,login-identifier.txt,ca-bundle.pem,TGPA,ProgramBinaryCache}
mkdir $MAIN/files/{cacheFile.txt,login-identifier.txt,ca-bundle.pem}
touch $MAIN/files/{TGPA,ProgramBinaryCache}
echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
rm -rf $DIR/LightData/LightData3036393187.ltz
touch $DIR/LightData/LightData3036393187.ltz
echo "  

srcMOSTAFA" > $DIR/LightData/LightData3036393187.ltz
echo '[version]
appversion=1.6.0.15522
srcversion=1.6.0.15566' > $DIR/SrcVersion.ini
ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables
#==========MOSTAFA===========#
echo 'Server is processing...✅';
iptables -I INPUT -s down.anticheatexpert.com -j DROP
iptables -I OUTPUT -s down.anticheatexpert.com -j DROP
iptables -I INPUT -s down.anticheatexpert.com -j REJECT
iptables -I OUTPUT -s down.anticheatexpert.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s asia.csoversea.mbgame.anticheatexpert.com -j DROP
iptables -I OUTPUT -s asia.csoversea.mbgame.anticheatexpert.com -j DROP
iptables -I INPUT -s asia.csoversea.mbgame.anticheatexpert.com -j REJECT
iptables -I OUTPUT -s asia.csoversea.mbgame.anticheatexpert.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s napubgm.broker.amsoveasea.com -j DROP
iptables -I OUTPUT -s napubgm.broker.amsoveasea.com -j DROP
iptables -I INPUT -s napubgm.broker.amsoveasea.com -j REJECT
iptables -I OUTPUT -s napubgm.broker.amsoveasea.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s tsg.tdatamaster.com -j DROP
iptables -I OUTPUT -s tsg.tdatamaster.com -j DROP
iptables -I INPUT -s tsg.tdatamaster.com -j REJECT
iptables -I OUTPUT -s tsg.tdatamaster.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s cloud.gsdk.proximabeta.com -j DROP
iptables -I OUTPUT -s cloud.gsdk.proximabeta.com -j DROP
iptables -I INPUT -s cloud.gsdk.proximabeta.com -j REJECT
iptables -I OUTPUT -s cloud.gsdk.proximabeta.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s nawzryhwatm.broker.amsoveasea.com -j DROP
iptables -I OUTPUT -s nawzryhwatm.broker.amsoveasea.com -j DROP
iptables -I INPUT -s nawzryhwatm.broker.amsoveasea.com -j REJECT
iptables -I OUTPUT -s nawzryhwatm.broker.amsoveasea.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s naspeed.igamecj.com -j DROP
iptables -I OUTPUT -s naspeed.igamecj.com -j DROP
iptables -I INPUT -s naspeed.igamecj.com -j REJECT
iptables -I OUTPUT -s naspeed.igamecj.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s usa.csoversea.mbgame.anticheatexpert.com -j DROP
iptables -I OUTPUT -s usa.csoversea.mbgame.anticheatexpert.com -j DROP
iptables -I INPUT -s usa.csoversea.mbgame.anticheatexpert.com -j REJECT
iptables -I OUTPUT -s usa.csoversea.mbgame.anticheatexpert.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s qos.hk.gcloudcs.com -j DROP
iptables -I OUTPUT -s qos.hk.gcloudcs.com -j DROP
iptables -I INPUT -s qos.hk.gcloudcs.com -j REJECT
iptables -I OUTPUT -s qos.hk.gcloudcs.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s astat.bugly.qcloud.com -j DROP
iptables -I OUTPUT -s astat.bugly.qcloud.com -j DROP
iptables -I INPUT -s astat.bugly.qcloud.com -j REJECT
iptables -I OUTPUT -s astat.bugly.qcloud.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s vmp.qq.com -j DROP
iptables -I OUTPUT -s vmp.qq.com -j DROP
iptables -I INPUT -s vmp.qq.com -j REJECT
iptables -I OUTPUT -s vmp.qq.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s app.adjust.com -j DROP
iptables -I OUTPUT -s app.adjust.com -j DROP
iptables -I INPUT -s app.adjust.com -j REJECT
iptables -I OUTPUT -s app.adjust.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s tencentgames.helpshift.com -j DROP
iptables -I OUTPUT -s tencentgames.helpshift.com -j DROP
iptables -I INPUT -s tencentgames.helpshift.com -j REJECT
iptables -I OUTPUT -s tencentgames.helpshift.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s euspeed.igamecj.com -j DROP
iptables -I INPUT -s euspeed.igamecj.com -j DROP
iptables -I INPUT -s euspeed.igamecj.com -j REJECT
iptables -I INPUT -s euspeed.igamecj.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s file.igamecj.com -j DROP
iptables -I OUTPUT -s file.igamecj.com -j DROP
iptables -I INPUT -s file.igamecj.com -j REJECT
iptables -I OUTPUT -s file.igamecj.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s cdn.wetest.qq.com -j DROP
iptables -I OUTPUT -s cdn.wetest.qq.com -j DROP
iptables -I INPUT -s cdn.wetest.qq.com -j REJECT
iptables -I OUTPUT -s cdn.wetest.qq.com -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s app.adjust.world -j DROP
iptables -I OUTPUT -s app.adjust.world -j DROP
iptables -I INPUT -s app.adjust.world -j REJECT
iptables -I OUTPUT -s app.adjust.world -j REJECT
echo 'Server is processing...✅';
iptables -I INPUT -s sg.tdatamaster.com -j DROP
iptables -I OUTPUT -s sg.tdatamaster.com -j DROP
iptables -I INPUT -s sg.tdatamaster.com -j REJECT
iptables -I OUTPUT -s sg.tdatamaster.com -j REJECT
#==========MOSTAFA===========#
echo ""
echo ""
echo "[5;32m PUBGM HACKED SUCCESSFULLY 🔐"
echo "[5;32m.................."
echo ""
sleep 1
am start -n $GL/com.epicgames.ue4.SplashActivity
sleep 4
rm -rf $lib/{libUE4.so,libtprt.so,libtersafe.so}
mv $lib/libtprt.so.bak $lib/libtprt.so
mv $lib/libUE4.so.bak $lib/libUE4.so
mv $lib/libtersafe.so.bak $lib/libtersafe.so
chmod 755 $lib/*
echo "@Gxghost"