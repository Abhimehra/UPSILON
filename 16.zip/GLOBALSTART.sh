echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
PKG=com.tencent.ig
data=/data/data/$PKG
lib=$data/lib
Saved=/storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
am force-stop $PKG
killall $PKG &>/dev/null
cp /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{game_patch_1.5.0.15337.pak,game_patch_1.5.0.15338.pak,game_patch_1.5.0.15339.pak,game_patch_1.5.0.15340.pak} $Saved
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15337.pak
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15339.pak
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15340.pak
cp $Saved/paks/game_patch_1.5.0.15340.pak $Saved/paks/game_patch_1.5.0.15553.pak
R $Saved/SrcVersion.ini
E '[version]
appversion=1.5.0.15331
srcversion=1.5.0.15553' >> $Saved/SrcVersion.ini
R $Saved/{PufferEifs0,PufferEifs1}
R $Saved/LightData
mkdir $Saved/LightData
E " @QQpubg " >> $Saved/LightData/LightData3036393187.ltz
E "[/Script/Client.GDolphinUpdater]
Disable=true" > $Saved/Config/Android/Updater.ini
E "\033[0;33mBY:@QQpubg \e[0m\n\n\n"
E 16384 > /proc/sys/fs/inotify/max_queued_events
E 128 > /proc/sys/fs/inotify/max_user_instances
E 8192 > /proc/sys/fs/inotify/max_user_watches
R src/main/java/com/google/errorprone/annotations
R src/main/java/com/google/errorprone/annotations/concurrent
R third_party.java_src.error_prone.project.annotations.Google_internal
R $lib/{libtgpa.so,libBugly.so,libgamemaster.so,libgcloudarch.so,libhelpshiftlistener.so,libigshare.so,liblbs.so,libst-engine.so,libtgpa.so,libzip.so,libapp.so,libc++_shared.so,libflutter.so,libmarsxlog.so,libmmkv.so,libsentry.so,libsentry-android.so,libnpps-jni.so,libImSDK.so}
SP 755 $lib/*
R $data/files
pm disable $PKG/com.tencent.midas.oversea.newnetwork.service.APNetDetectService >/dev/null 2>/dev/null
T $data/files
SP 0 $data/files
E "[/Script/Client.GDolphinUpdater]\nDisable=true" > $Saved/Config/Android/Updater.ini
R /data/media/0/Android/data/$PKG/files/ProgramBinaryCache
T /data/media/0/Android/data/$PKG/files/ProgramBinaryCache
cp $lib/libswappy.so $lib/libswappy.so.bak
cp $lib/libUE4.so $lib/libUE4.so.bak
cp $lib/libtprt.so $lib/libtprt.so.bak
cp $lib/libITOP.so $lib/libITOP.so.bak
cp $lib/libvlink.so $lib/libvlink.so.bak
am start --user 0 -n $PKG/com.epicgames.ue4.SplashActivity >/dev/null 2>/dev/null
S 12
R $lib/libUE4.so
R $lib/libtprt.so
R $lib/libswappy.so
R $lib/libITOP.so
R $lib/libvlink.so
mv $lib/libswappy.so.bak $lib/libswappy.so
mv $lib/libUE4.so.bak $lib/libUE4.so
mv $lib/libtprt.so.bak $lib/libtprt.so
mv $lib/libITOP.so.bak $lib/libITOP.so
mv $lib/libvlink.so.bak $lib/libvlink.so
cleanlog()
{
E "\e[1;40m\n\a\t  Cleaning Shit ♦  \e[0m\n"
R /sdcard/Android/data/$PKG/files/tbslog &> /dev/null
R /sdcard/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved//SaveGames/{Logs,Season,RoleInfo,PersonSpace,Match,LobbyBubble,GEM,Loading,CharacterActivity} &> /dev/null
R /data/data/$PKG/{app_bugly,app_crashrecord,app_databases,app_geolocation,app_lib,app_tbs,app_webview,app_textures,app_webview_imsdk_inner_webview,cache,no_backup,app_appcache،} &> /dev/null
R /data/data/$PKG/databases/{tdm.db,bugly_db_,beacon_db,config.db,iMSDK.db,__hs_log_store-journal,bugly_db_-journal,__hs__db_sessions-journal,__hs__db_support_key_values-journal,__hs__db_key_values-journal,__hs__db_issues-journal,pri_tencent_analysis.db,xg_message.db-journal,tencent_analysis.db-journal,google_app_measurement_local.db,pri_tencent_analysis.db-journal,google_app_measurement_local.db-journal} &> /dev/null
R /sdcard/MidasOversea/GUID &> /dev/null
R /sdcard/Android/data/$PKG/files/ca-bundle.pem &> /dev/null
R /sdcard/Android/data/$PKG/files/cacheFile.txt &> /dev/null
R /sdcard/Android/data/$PKG/files/login-identifier.txt &> /dev/null
R /sdcard/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs &> /dev/null
R $Saved/Paks/{puffer_temp,*.res,*.flist,*.json,*.cures,*.flistnewlist,*.filelist}
R /sdcard/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag &> /dev/null
R /sdcard/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir &> /dev/null
R /sdcard/.backups &> /dev/null
R /sdcard/Tencent &> /dev/null
S 15
}
PACKAGE=$PKG
while [ $(pidof $PACKAGE) ]
do
cleanlog
if [ ! $(pidof $PACKAGE) ]; then
break
fi
done
E "Game Closed Restore Initiated"
E "Reinstalling App to restore libs"
R /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{game_patch_1.5.0.15337.pak,game_patch_1.5.0.15338.pak,game_patch_1.5.0.15339.pak,game_patch_1.5.0.15340.pak,game_patch_1.5.0.15553}
R $Saved/{LightData,SrcVersion.ini}
mv $Saved/{game_patch_1.5.0.15337.pak,game_patch_1.5.0.15338.pak,game_patch_1.5.0.15339.pak,game_patch_1.5.0.15340.pak} /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
pm install /data/app/$PKG*/base.apk >/dev/null 2>/dev/null