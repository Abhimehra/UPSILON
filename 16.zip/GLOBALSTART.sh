#gloabl
chmod 660 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 220 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/playerprefs.json
chmod 220 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/NewPlayerprefsSwitcher.json
chmod 220 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/MailPhoneLogin.json
chmod 220 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/loginInfoFile.json
chmod 220 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GA.json
chmod 220 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/AgreeIllegalAvatarRule.json
chmod 220 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/BatchButtonClickLog_0.json
chmod 220 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
chmod 220 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/apollo_loglist.json
chmod 220 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/apollo_uuid_define.json


sleep 1
chmod 770 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
touch /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15337.pak
cp -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15337.pak /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.25523.pak
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
echo '[version]
appversion=1.5.0.15523
srcversion=1.5.0.25523' >> /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 550 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 555 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
echo "
kkk3o" >> /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
cp /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
chmod 550 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

sleep 1

echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
date
export PKG="com.tencent.ig"
export lib="/data/data/$PKG/lib"
killall $PKG >/dev/null 2>/dev/null
clear
date
sleep 1
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
rm -rf /storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 755 $lib/*
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo "[/Script/Client.GDolphinUpdater]
Disable=true" > /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
rm -rf $lib/libBugly.so 
rm -rf $lib/libgamemaster.so 
rm -rf $lib/libgcloudarch.so 
rm -rf $lib/libhelpshiftlistener.so 
rm -rf $lib/libigshare.so 
rm -rf $lib/liblbs.so 
rm -rf $lib/libst-engine.so 
rm -rf $lib/libtgpa.so 
rm -rf $lib/libzip.so 
rm -rf $lib/libapp.so 
rm -rf $lib/libc++_shared.so 
rm -rf $lib/libflutter.so 
rm -rf $lib/libmarsxlog.so 
rm -rf $lib/libmmkv.so 
rm -rf $lib/libsentry.so 
rm -rf $lib/libsentry-android.so 
rm -rf $lib/libnpps-jni.so 
rm -rf $lib/libImSDK.so 
chmod -R 755 $lib/*
rm -rf /data/data/$PKG/files
touch /data/data/$PKG/files
echo "@BEEASTYT"
cp $lib/libtersafe.so $lib/libtersafe.so.bak
cp $lib/libswappy.so $lib/libswappy.so.bak
cp $lib/libUE4.so $lib/libUE4.so.bak
cp $lib/libtprt.so $lib/libtprt.so.bak
cp $lib/libITOP.so $lib/libITOP.so.bak
cp $lib/libvlink.so $lib/libvlink.so.bak
am start --user 0 -n $PKG/com.epicgames.ue4.SplashActivity >/dev/null 2>/dev/null
sleep 8.5
rm -rf $lib/libtersafe.so
rm -rf $lib/libUE4.so
rm -rf $lib/libtprt.so
rm -rf $lib/libswappy.so
rm -rf $lib/libITOP.so
rm -rf $lib/libvlink.so
mv $lib/libtersafe.so.bak $lib/libtersafe.so
mv $lib/libswappy.so.bak $lib/libswappy.so
mv $lib/libUE4.so.bak $lib/libUE4.so
mv $lib/libtprt.so.bak $lib/libtprt.so
mv $lib/libITOP.so.bak $lib/libITOP.so
mv $lib/libvlink.so.bak $lib/libvlink.so
svc data enable && svc wifi enable
am force-stop com.tencent.ig:imsdk_inner_webview &> /dev/null && am force-stop com.tencent.ig:networkDetector &> /dev/null && am force-stop com.tencent.ig:playcore_missing_splits_activity &> /dev/null && am force-stop com.tencent.ig:plugin &> /dev/null  && am force-stop com.tencent.ig:remoteWeb &> /dev/null && am force-stop com.tencent.ig:vlink &> /dev/null
sleep 3
am force-stop com.tencent.ig:imsdk_inner_webview &> /dev/null && am force-stop com.tencent.ig:networkDetector &> /dev/null && am force-stop com.tencent.ig:playcore_missing_splits_activity &> /dev/null && am force-stop com.tencent.ig:plugin &> /dev/null && am force-stop com.tencent.ig:remoteWeb &> /dev/null && am force-stop com.tencent.ig:vlink &> /dev/null
sleep 3
am force-stop com.tencent.ig:imsdk_inner_webview &> /dev/null && am force-stop com.tencent.ig:networkDetector &> /dev/null && am force-stop com.tencent.ig:playcore_missing_splits_activity &> /dev/null && am force-stop com.tencent.ig:plugin &> /dev/null  && am force-stop com.tencent.ig:remoteWeb &> /dev/null && am force-stop com.tencent.ig:vlink &> /dev/null
sleep 3
am force-stop com.tencent.ig:imsdk_inner_webview &> /dev/null && am force-stop com.tencent.ig:networkDetector &> /dev/null && am force-stop com.tencent.ig:playcore_missing_splits_activity &> /dev/null && am force-stop com.tencent.ig:plugin  &> /dev/null && am force-stop com.tencent.ig:remoteWeb &> /dev/null && am force-stop com.tencent.ig:vlink &> /dev/null