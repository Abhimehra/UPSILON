if [ $(pidof com.tencent.ig) ]; then
iptables -A INPUT -p tcp -m tcp --dport 17500 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 17500 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 17500 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p udp -m udp --dport 20001 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 11038 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 111 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 81 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 17500 -j DROP
rm -rf /data/data/com.tencent.ig/code_cache &>/dev/null
touch /data/data/com.tencent.ig/code_cache &>/dev/null
chmod 555 /data/data/com.tencent.ig/code_cache &>/dev/null
rm -rf /data/data/com.tencent.ig/cache/* &>/dev/null
chmod 555 /data/data/com.tencent.ig/cache &>/dev/null
rm -rf /Storage/emulated/0/Tencent/Midas/Log &>/dev/null
rm -rf /Storage/emulated/0/.backups &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/tbslog &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache &>/dev/null
rm -rf /Storage/emulated/0/.backups/com.tencent.ig/helpshift/databases &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/cache &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/tbslog &>/dev/null
rm -rf /data/data/com.tencent.ig/databases/tdm.db &>/dev/null
rm -rf /data/data/com.tencent.ig/databases/beacon_db &>/dev/null
rm -rf /data/data/com.tencent.ig/databases/bugly_db_ &>/dev/null
rm -rf /data/data/com.tencent.ig/databases/config.db &>/dev/null
rm -rf /data/data/com.tencent.ig/databases/iMSDK.db &>/dev/null
rm -rf /Storage/emulated/0/.backups/com.tencent.ig/helpshift/databases/__hs__backup_dao_storage &>/dev/null
rm -rf /Storage/emulated/0/Tencent/beacon/meta.dat &>/dev/null
rm -rf /Storage/emulated/0/MidasOversea/GUID &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/cache &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/tbslog &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs &>/dev/null
touch /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir &>/dev/null
touch /storage/emulated/0/Android/Data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp &>/dev/null
elif [ $(pidof com.pubg.krmobile) ]; then
iptables -I INPUT -p tcp --dport 17000 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 17500 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 443 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 443 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 80 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 80 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 8080 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 8080 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 18081 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 18081 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 17000 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 17500 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 443 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 443 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 80 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 80 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8080 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 18081 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 18600 -j REJECT &>/dev/null
su -c iptables -I INPUT -s www.anticheatexpert.com -j DROP &>/dev/null
su -c iptables -I OUTPUT -s www.anticheatexpert.com -j DROP &>/dev/null
rm -rf /data/data/com.pubg.krmobile/code_cache &>/dev/null
touch /data/data/com.pubg.krmobile/code_cache &>/dev/null
chmod 555 /data/data/com.pubg.krmobile/code_cache &>/dev/null
rm -rf /data/data/com.pubg.krmobile/cache/* &>/dev/null
chmod 555 /data/data/com.pubg.krmobile/cache &>/dev/null
rm -rf /Storage/emulated/0/Tencent/Midas/Log &>/dev/null
rm -rf /Storage/emulated/0/.backups &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache &>/dev/null
rm -rf /Storage/emulated/0/.backups/com.pubg.krmobile/helpshift/databases &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/cache &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog &>/dev/null
rm -rf /data/data/com.pubg.krmobile/databases/tdm.db &>/dev/null
rm -rf /data/data/com.pubg.krmobile/databases/beacon_db &>/dev/null
rm -rf /data/data/com.pubg.krmobile/databases/bugly_db_ &>/dev/null
rm -rf /data/data/com.pubg.krmobile/databases/config.db &>/dev/null
rm -rf /data/data/com.pubg.krmobile/databases/iMSDK.db &>/dev/null
rm -rf /Storage/emulated/0/.backups/com.pubg.krmobile/helpshift/databases/__hs__backup_dao_storage &>/dev/null
rm -rf /Storage/emulated/0/Tencent/beacon/meta.dat &>/dev/null
rm -rf /Storage/emulated/0/MidasOversea/GUID &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/ca-bundle.pem &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/cache &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs &>/dev/null
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir &>/dev/null
touch /storage/emulated/0/Android/Data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp &>/dev/null
rm -rf /data/data/com.rekoo.pubgm/code_cache &>/dev/null
touch /data/data/com.rekoo.pubgm/code_cache &>/dev/null
chmod 555 /data/data/com.rekoo.pubgm/code_cache &>/dev/null
rm -rf /data/data/com.rekoo.pubgm/cache/* &>/dev/null
chmod 555 /data/data/com.rekoo.pubgm/cache &>/dev/null
rm -rf /Storage/emulated/0/Tencent/Midas/Log &>/dev/null
rm -rf /Storage/emulated/0/.backups &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.rekoo.pubgm/files/tbslog &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.rekoo.pubgm/files/ProgramBinaryCache &>/dev/null
rm -rf /Storage/emulated/0/.backups/com.rekoo.pubgm/helpshift/databases &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.rekoo.pubgm/cache &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.rekoo.pubgm/files/tbslog &>/dev/null
rm -rf /data/data/com.rekoo.pubgm/databases/tdm.db &>/dev/null
rm -rf /data/data/com.rekoo.pubgm/databases/beacon_db &>/dev/null
rm -rf /data/data/com.rekoo.pubgm/databases/bugly_db_ &>/dev/null
rm -rf /data/data/com.rekoo.pubgm/databases/config.db &>/dev/null
rm -rf /data/data/com.rekoo.pubgm/databases/iMSDK.db &>/dev/null
rm -rf /Storage/emulated/0/.backups/com.rekoo.pubgm/helpshift/databases/__hs__backup_dao_storage &>/dev/null
rm -rf /Storage/emulated/0/Tencent/beacon/meta.dat &>/dev/null
rm -rf /Storage/emulated/0/MidasOversea/GUID &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.rekoo.pubgm/files/ca-bundle.pem &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.rekoo.pubgm/files/cacheFile.txt &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.rekoo.pubgm/files/login-identifier.txt &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.rekoo.pubgm/cache &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.rekoo.pubgm/files/tbslog &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs &>/dev/null
touch /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir &>/dev/null
touch /storage/emulated/0/Android/Data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp &>/dev/null
elif [ $(pidof com.pubg.imobile) ]; then
iptables -I INPUT -p tcp --dport 17000 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 17500 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 443 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 443 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 80 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 80 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 8080 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 8080 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 18081 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 18081 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 17000 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 17500 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 443 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 443 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 80 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 80 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8080 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 18081 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 18600 -j REJECT &>/dev/null
su -c iptables -I INPUT -s www.anticheatexpert.com -j DROP &>/dev/null
su -c iptables -I OUTPUT -s www.anticheatexpert.com -j DROP &>/dev/null
else
echo "No Process Running"
fi








