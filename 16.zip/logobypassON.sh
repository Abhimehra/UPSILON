

if [ $(pidof com.tencent.ig) ]; then
chmod 444 /data/data/com.tencent.ig/lib/libBugly.so
chmod 444 /data/data/com.tencent.ig/lib/libcubehawk.so
chmod 444 /data/data/com.tencent.ig/lib/libgcloud.so
chmod 444 /data/data/com.tencent.ig/lib/libIMSDK.so
chmod 444 /data/data/com.tencent.ig/lib/libTDataMaster.so
chmod 444 /data/data/com.tencent.ig/lib/libtersafe.so
elif [ $(pidof com.pubg.krmobile) ]; then
chmod 444 /data/data/com.pubg.krmobile/lib/libBugly.so
chmod 444 /data/data/com.pubg.krmobile/lib/libcubehawk.so
chmod 444 /data/data/com.pubg.krmobile/lib/libgcloud.so
chmod 444 /data/data/com.pubg.krmobile/lib/libIMSDK.so
chmod 444 /data/data/com.pubg.krmobile/lib/libTDataMaster.so
chmod 444 /data/data/com.pubg.krmobile/lib/libtersafe.so
elif [ $(pidof com.pubg.imobile) ]; then
chmod 444 /data/data/com.pubg.imobile/lib/libBugly.so
chmod 444 /data/data/com.pubg.imobile/lib/libcubehawk.so
chmod 444 /data/data/com.pubg.imobile/lib/libgcloud.so
chmod 444 /data/data/com.pubg.imobile/lib/libIMSDK.so
chmod 444 /data/data/com.pubg.imobile/lib/libTDataMaster.so
chmod 444 /data/data/com.pubg.imobile/lib/libtersafe.so
else
echo "No Process Running"
fi








