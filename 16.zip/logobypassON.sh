

if [ $(pidof com.tencent.ig) ]; then
rm -rf /data/data/com.tencent.ig/lib/libBugly
rm -rf /data/data/com.tencent.ig/lib/libcubehawk.so
rm -rf /data/data/com.tencent.ig/lib/libgcloud.so
rm -rf /data/data/com.tencent.ig/lib/libIMSDK.so
rm -rf /data/data/com.tencent.ig/lib/libTDataMaster.so
rm -rf /data/data/com.tencent.ig/lib/libtersafe.so
rm -rf /data/data/com.tencent.ig/lib/libUE4.so

cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/h.so /data/data/com.tencent.ig/lib/libBugly.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/i.so /data/data/com.tencent.ig/lib/libcubehawk.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/j.so /data/data/com.tencent.ig/lib/libgcloud.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/k.so /data/data/com.tencent.ig/lib/libIMSDK.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/l.so /data/data/com.tencent.ig/lib/libTDataMaster.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/m.so /data/data/com.tencent.ig/lib/libtersafe.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/n.so /data/data/com.tencent.ig/lib/libUE4.so

chmod 755 /data/data/com.tencent.ig/lib/*
chmod 755 /data/data/com.tencent.ig/lib*/

elif [ $(pidof com.pubg.krmobile) ]; then
rm -rf /data/data/com.pubg.krmobile/lib/libBugly
rm -rf /data/data/com.pubg.krmobile/lib/libcubehawk.so
rm -rf /data/data/com.pubg.krmobile/lib/libgcloud.so
rm -rf /data/data/com.pubg.krmobile/lib/libIMSDK.so
rm -rf /data/data/com.pubg.krmobile/lib/libTDataMaster.so
rm -rf /data/data/com.pubg.krmobile/lib/libtersafe.so
rm -rf /data/data/com.pubg.krmobile/lib/libUE4.so

cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/a.so /data/data/com.pubg.krmobile/lib/libBugly.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/b.so /data/data/com.pubg.krmobile/lib/libcubehawk.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/c.so /data/data/com.pubg.krmobile/lib/libgcloud.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/d.so /data/data/com.pubg.krmobile/lib/libIMSDK.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/e.so /data/data/com.pubg.krmobile/lib/libTDataMaster.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/f.so /data/data/com.pubg.krmobile/lib/libtersafe.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/g.so /data/data/com.pubg.krmobile/lib/libUE4.so

chmod 755 /data/data/com.pubg.krmobile/lib/*
chmod 755 /data/data/com.pubg.krmobile/lib*/

elif [ $(pidof com.pubg.imobile) ]; then
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.vdex /data/app/com.pubg.imobile*/
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.odex /data/app/com.pubg.imobile*/
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.vdex /data/app/com.pubg.imobile*/oat/arm/
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.odex /data/app/com.pubg.imobile*/oat/arm/
sleep 1
chmod 000 /data/app/com.pubg.imobile*/lib
chmod 000 /data/app/com.pubg.imobile*/base.apk
else
echo "No Process Running"
fi








