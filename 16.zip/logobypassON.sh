

if [ $(pidof com.tencent.ig) ]; then
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.vdex /data/app/com.tencent.ig*/
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.odex /data/app/com.tencent.ig*/
sleep 1
rm -rf /data/app/com.tencent.ig*/oat/arm/base.odex
rm -rf /data/app/com.tencent.ig*/oat/arm/base.vdex
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.vdex /data/app/com.tencent.ig*/oat/arm/
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.odex /data/app/com.tencent.ig*/oat/arm/
sleep 1
chmod 000 /data/app/com.tencent.ig*/lib
chmod 000 /data/app/com.tencent.ig*/base.apk

elif [ $(pidof com.pubg.krmobile) ]; then
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.vdex /data/app/com.pubg.krmobile*/
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.odex /data/app/com.pubg.krmobile*/
sleep 1
rm -rf /data/app/com.pubg.krmobile*/oat/arm/base.odex
rm -rf /data/app/com.pubg.krmobile*/oat/arm/base.vdex
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.vdex /data/app/com.pubg.krmobile*/oat/arm/
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.odex /data/app/com.pubg.krmobile*/oat/arm/
sleep 1
chmod 000 /data/app/com.pubg.krmobile*/lib
chmod 000 /data/app/com.pubg.krmobile*/base.apk

elif [ $(pidof com.pubg.imobile) ]; then
chmod -R 777 /data/media/0/Android/data/com.pakage.upsilon/files/TAP
exec /data/media/0/Android/data/com.pakage.upsilon/files/TAP BEAST
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.vdex /data/app/com.pubg.imobile*/
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.odex /data/app/com.pubg.imobile*/
sleep 1
rm -rf /data/app/com.pubg.imobile*/oat/arm/base.odex
rm -rf /data/app/com.pubg.imobile*/oat/arm/base.vdex
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.vdex /data/app/com.pubg.imobile*/oat/arm/
cp -rf /storage/emulated/0/Android/data/com.pakage.upsilon/files/base.odex /data/app/com.pubg.imobile*/oat/arm/
sleep 1
chmod 000 /data/app/com.pubg.imobile*/lib
chmod 000 /data/app/com.pubg.imobile*/base.apk
chmod 000 /data/app/com.pubg.imobile*
else
echo "No Process Running"
fi








