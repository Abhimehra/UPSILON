#GlOBAL
rm -rf /data/data/com.tencent.ig/files
rm -rf /data/data/com.tencent.ig/app_crashrecord
rm -rf /data/data/com.tencent.ig/app_bugly
rm -rf /data/data/com.tencent.ig/cache
rm -rf /data/data/com.tencent.ig/code_cache

touch /data/data/com.tencent.ig/files
touch /data/data/com.tencent.ig/app_crashrecord
touch /data/data/com.tencent.ig/app_bugly
touch /data/data/com.tencent.ig/cache
touch /data/data/com.tencent.ig/code_cache

chmod -R 000 /data/data/com.tencent.ig/files
chmod -R 000  /data/data/com.tencent.ig/app_crashrecord
chmod -R 000 /data/data/com.tencent.ig/app_bugly
chmod -R 000 /data/data/com.tencent.ig/cache
chmod -R 000 /data/data/com.tencent.ig/code_cache

#KOREA

rm -rf /data/data/com.pubg.krmobile/files
rm -rf /data/data/com.pubg.krmobile/app_crashrecord
rm -rf /data/data/com.pubg.krmobile/app_bugly
rm -rf /data/data/com.pubg.krmobile/cache
rm -rf /data/data/com.pubg.krmobile/code_cache

touch /data/data/com.pubg.krmobile/files
touch /data/data/com.pubg.krmobile/app_crashrecord
touch /data/data/com.pubg.krmobile/app_bugly
touch /data/data/com.pubg.krmobile/cache
touch /data/data/com.pubg.krmobile/code_cache

chmod -R 000 /data/data/com.pubg.krmobile/files
chmod -R 000  /data/data/com.pubg.krmobile/app_crashrecord
chmod -R 000 /data/data/com.pubg.krmobile/app_bugly
chmod -R 000 /data/data/com.pubg.krmobile/cache
chmod -R 000 /data/data/com.pubg.krmobile/code_cache

#PUBGINDIA

rm -rf /data/data/com.pubg.imobile/files
rm -rf /data/data/com.pubg.imobile/app_crashrecord
rm -rf /data/data/com.pubg.imobile/app_bugly
rm -rf /data/data/com.pubg.imobile/cache
rm -rf /data/data/com.pubg.imobile/code_cache

touch /data/data/com.pubg.imobile/files
touch /data/data/com.pubg.imobile/app_crashrecord
touch /data/data/com.pubg.imobile/app_bugly
touch /data/data/com.pubg.imobile/cache
touch /data/data/com.pubg.imobile/code_cache

chmod -R 000 /data/data/com.pubg.imobile/files
chmod -R 000  /data/data/com.pubg.imobile/app_crashrecord
chmod -R 000 /data/data/com.pubg.imobile/app_bugly
chmod -R 000 /data/data/com.pubg.imobile/cache
chmod -R 000 /data/data/com.pubg.imobile/code_cache

echo "FIX CRASH DONE BY BEAST"


chmod 777 /system/etc/hosts
sleep 1
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/hosts /system/etc/
chmod 777 /system/etc/hosts

rm -rf /data/app/com.pubg.imobile*/oat/arm/base.art
rm -rf /data/app/com.pubg.krmobile*/oat/arm/base.art
rm -rf /data/app/com.tencent.ig*/oat/arm/base.art




