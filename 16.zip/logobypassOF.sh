
chmod 755 /data/data/com.tencent.ig/lib/libBugly.so
chmod 755 /data/data/com.tencent.ig/lib/libcubehawk.so
chmod 755 /data/data/com.tencent.ig/lib/libgcloud.so
chmod 755 /data/data/com.tencent.ig/lib/libIMSDK.so
chmod 755 /data/data/com.tencent.ig/lib/libTDataMaster.so
chmod 755 /data/data/com.tencent.ig/lib/libtersafe.so
sleep 1
chmod 755 /data/data/com.pubg.krmobile/lib/libBugly.so
chmod 755 /data/data/com.pubg.krmobile/lib/libcubehawk.so
chmod 755 /data/data/com.pubg.krmobile/lib/libgcloud.so
chmod 755 /data/data/com.pubg.krmobile/lib/libIMSDK.so
chmod 755 /data/data/com.pubg.krmobile/lib/libTDataMaster.so
chmod 755 /data/data/com.pubg.krmobile/lib/libtersafe.so
sleep 1
chmod 755 /data/data/com.pubg.imobile/lib/libBugly.so
chmod 755 /data/data/com.pubg.imobile/lib/libcubehawk.so
chmod 755 /data/data/com.pubg.imobile/lib/libgcloud.so
chmod 755 /data/data/com.pubg.imobile/lib/libIMSDK.so
chmod 755 /data/data/com.pubg.imobile/lib/libTDataMaster.so
chmod 755 /data/data/com.pubg.imobile/lib/libtersafe.so









