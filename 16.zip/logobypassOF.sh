#global
pm install -r /data/app/com.tencent.ig*/base.apk
#korea
pm install -r /data/app/com.pubg.krmobile*/base.apk
#India
pm install -r /data/app/com.pubg.imobile*/base.apk