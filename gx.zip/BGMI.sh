PKG="com.pubg.imobile"
data=/data/data/$PKG
eval `pm dump $PKG | grep LibraryDir`
arm=$(ls $lib | grep arm)
M=/data/data/
Saved=/storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
rm -rf /data/data/$PKG/{app_bugly,app_crashrecord}
touch /data/data/$PKG/{app_bugly,app_crashrecord}
chmod 4000 /data/data/$PKG/{app_bugly,app_crashrecord}
mv hook2 $M/;
chmod 777 $M/hook2;
L=/data/data/com.pubg.imobile/app_valac_files/libvalac.so
if [ ! -e "$L" ]; then
    mkdir cp  /data/data/com.pubg.imobile/app_valac_files/
    cp  $M/hook2 $L
fi
cd  /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/
rm -rf {*_cures.ifs.res,*.json}
rm -rf /data/media/0/{tencent,.tencent,.backups,.DataStorage,.MidasOversea,.UTSystemConfig}
rm -rf /data/media/0/Android/data/com.pubg.imobile/{prex_8bfb7f0a.dat,cache}
data=/data/data/$PKG
eval `pm dump $PKG | grep LibraryDir`
lib=$legacyNativeLibraryDir
arm=$(ls $lib | grep arm)
lib=$lib/$arm
rm -rf $lib/{libCrashSight.so,libgamemaster.so,libigshare.so,libtgpa.so,libmmkv.so,libgcloudarch.so,libhelpshiftlistener.so,libnpps-jni.so,libst-engine.so} > /dev/null 2>&1
chmod -R 755 $lib/*
am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
rm -rf /cache/magisk.log
rm -rf /cache/magisk.log.bak
rm -rf /data/user/0/$PKG/app_bugly
touch /data/user/0/$PKG/app_bugly
chmod -R 0000 /data/user/0/$PKG/app_bugly
rm -rf /data/user/0/$PKG/{app_crashSight,app_textures,app_webview}
sleep 6
chmod -R 0000 /data/data/$PKG/files
chmod -R 0000 $lib/libUE4.so
chmod -R 0000 $lib/libgcloud.so
chmod -R 0000 $lib/libtprt.so
#rm -rf /data/data/hook2
rm -rf /data/data/com.pubg.imobile/databases/{hook,hook2,json.sh}

