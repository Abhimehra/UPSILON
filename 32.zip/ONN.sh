


if [ $(pidof com.tencent.ig) ]; then

awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list > /data/media/0/UID;
UID=$(cat /data/media/0/UID);
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c ip6tables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c ip6tables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
ip6tables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
ip6tables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;


elif [ $(pidof com.pubg.krmobile) ]; then

awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list > /data/media/0/UID;
UID=$(cat /data/media/0/UID);
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c ip6tables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c ip6tables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
ip6tables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
ip6tables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;


elif [ $(pidof com.pubg.imobile) ]; then

awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list > /data/media/0/UID;
UID=$(cat /data/media/0/UID);
su -c iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c ip6tables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
su -c ip6tables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
iptables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
iptables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
ip6tables -I INPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;
ip6tables -I OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &>/dev/null;

else
echo "No Process Running"
fi








