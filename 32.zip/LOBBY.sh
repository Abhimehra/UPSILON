
if [ $(pidof com.tencent.ig) ]; then
clear

dp="/data/data/com.tencent.ig*/lib"
rm -rf $dp/{libUE4.so,libtprt.so,libTDataMaster.so,libgcloud.so,libapp.so,libflutter.so,libBugly.so,libImSDK.so,libmmkv.so,libtgpa.so,libijkffmpeg.so,libst-engine.so,libITOP.so,libhelpshiftlistener.so,1,3,4,5,6,7,8,9,10,11,12,13,14,15}
clear



ver(){

chmod 777 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks &> /dev/null
}
clear
PKG="com.tencent.ig"
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
rm -rf /data/data/$PKG/{d*,a*,c*}
chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null
mv $lib/{2,libUE4.so}
exec /data/media/0/Android/data/com.pakage.upsilon/files/BEAST LOGO
rm -rf $dp/libUE4.so
echo "done"

elif [ $(pidof com.pubg.krmobile) ]; then
clear

dp="/data/data/com.pubg.krmobile*/lib"
rm -rf $dp/{libUE4.so,libtprt.so,libTDataMaster.so,libgcloud.so,libapp.so,libflutter.so,libBugly.so,libImSDK.so,libmmkv.so,libtgpa.so,libijkffmpeg.so,libst-engine.so,libITOP.so,libhelpshiftlistener.so,1,3,4,5,6,7,8,9,10,11,12,13,14,15}
clear

ver(){

chmod 777 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks &> /dev/null
}
clear
PKG="com.pubg.krmobile"
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
rm -rf /data/data/$PKG/{d*,a*,c*}
chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null
mv $lib/{2,libUE4.so}
exec /data/media/0/Android/data/com.pakage.upsilon/files/BEAST LOGO
rm -rf $dp/libUE4.so
echo "done"

elif [ $(pidof com.pubg.imobile) ]; then
clear

dp="/data/data/com.pubg.imobile*/lib"
rm -rf $dp/{libUE4.so,libtprt.so,libTDataMaster.so,libgcloud.so,libapp.so,libflutter.so,libBugly.so,libImSDK.so,libmmkv.so,libtgpa.so,libijkffmpeg.so,libst-engine.so,libITOP.so,libhelpshiftlistener.so,1,3,4,5,6,7,8,9,10,11,12,13,14,15}
clear

ver(){

chmod 777 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks &> /dev/null
}
clear
PKG="com.pubg.imobile"
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
rm -rf /data/data/$PKG/{d*,a*,c*}
chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null
mv $lib/{2,libUE4.so}
exec /data/media/0/Android/data/com.pakage.upsilon/files/BEAST LOGO
rm -rf $dp/libUE4.so
echo "done"

else
echo "No Process Running"
fi








