
if [ $(pidof com.tencent.ig) ]; then

PKG=/data/data/com.tencent.ig
dp="/data/data/com.tencent.ig*/lib"
rm -rf /data/data/$PKG/{d*,a*,c*}
rm -rf $dp/{libtersafe.so,libUE4.so,libtprt.so,libTDataMaster.so,libgcloud.so,libapp.so,libflutter.so,libBugly.so,libImSDK.so,libmmkv.so,libtgpa.so,libijkffmpeg.so,libst-engine.so,libITOP.so,libhelpshiftlistener.so,1,3,4,5,6,7,8,9,10,11,12,13,14,15}

mv /data/data/com.tencent.ig/lib/2 /data/data/com.tencent.ig/lib/libUE4.so

chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null

elif [ $(pidof com.pubg.krmobile) ]; then

PKG=/data/data/com.pubg.krmobile
dp="/data/data/com.pubg.krmobile/lib"
rm -rf /data/data/$PKG/{d*,a*,c*}
rm -rf $dp/{libtersafe.so,libUE4.so,libtprt.so,libTDataMaster.so,libgcloud.so,libapp.so,libflutter.so,libBugly.so,libImSDK.so,libmmkv.so,libtgpa.so,libijkffmpeg.so,libst-engine.so,libITOP.so,libhelpshiftlistener.so,1,3,4,5,6,7,8,9,10,11,12,13,14,15}

mv /data/data/com.pubg.krmobile/lib/2 /data/data/com.pubg.krmobile/lib/libUE4.so

chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null

elif [ $(pidof com.pubg.imobile) ]; then
clear

PKG=/data/data/com.pubg.imobile
dp="/data/data/com.pubg.imobile/lib"
rm -rf /data/data/$PKG/{d*,a*,c*}
rm -rf $dp/{libtersafe.so,libUE4.so,libtprt.so,libTDataMaster.so,libgcloud.so,libapp.so,libflutter.so,libBugly.so,libImSDK.so,libmmkv.so,libtgpa.so,libijkffmpeg.so,libst-engine.so,libITOP.so,libhelpshiftlistener.so,1,3,4,5,6,7,8,9,10,11,12,13,14,15}

mv /data/data/com.pubg.imobile/lib/2 /data/data/com.pubg.imobile/lib/libUE4.so

chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null
echo "done"

else
echo "No Process Running"
fi








