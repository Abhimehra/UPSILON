
if [ $(pidof com.tencent.ig) ]; then

PKG="com.tencent.ig"
lib="/data/data/com.tencent.ig/lib"
rm -rf /data/data/$PKG/{d*,a*,c*}
rm -rf $lib/libtersafe.so
rm -rf $lib/libTDataMaster.so
mv $lib/{1,libtersafe.so}
mv $lib/{2,libUE4.so}
mv $lib/{3,libtprt.so}
mv $lib/{4,libTDataMaster.so}
mv $lib/{5,libgcloud.so}
chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null

elif [ $(pidof com.pubg.krmobile) ]; then

PKG="com.pubg.krmobile"
lib="/data/data/com.pubg.krmobile/lib"
rm -rf /data/data/$PKG/{d*,a*,c*}
rm -rf $lib/libtersafe.so
rm -rf $lib/libTDataMaster.so
mv $lib/{1,libtersafe.so}
mv $lib/{2,libUE4.so}
mv $lib/{3,libtprt.so}
mv $lib/{4,libTDataMaster.so}
mv $lib/{5,libgcloud.so}
chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null

elif [ $(pidof com.pubg.imobile) ]; then

PKG="com.pubg.imobile"
lib="/data/data/com.pubg.imobile/lib"
rm -rf /data/data/$PKG/{d*,a*,c*}
rm -rf $lib/libtersafe.so
rm -rf $lib/libTDataMaster.so
mv $lib/{1,libtersafe.so}
mv $lib/{2,libUE4.so}
mv $lib/{3,libtprt.so}
mv $lib/{4,libTDataMaster.so}
mv $lib/{5,libgcloud.so}
chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null

else
echo "No Process Running"
fi








