PKG="com.pubg.imobile"

ver(){

rm -rf  /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{core_patch_1.7.1.15737.pak,game_patch_1.7.0.15730.pak}

chmod 555 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks &> /dev/null
}
clear
PKG="com.pubg.imobile"
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
echo -e "$XYELLOW DEMOLISHING CLIENTSIDE ANTICHEAT"
echo
rm -rf /data/data/$PKG/{f*,a*,c*}
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
while [ ! -f $LOGO ]; do sleep 0.01; done
sleep 5
mv $lib/{libtersafe.so,1}
mv $lib/{libUE4.so,2}
mv $lib/{libtprt.so,3}
mv $lib/{libTDataMaster.so,4}
mv $lib/{libgcloud.so,5}
mv $lib/{libapp.so,6}
mv $lib/{libflutter.so,7}
mv $lib/{libBugly.so,8}
mv $lib/{libImSDK.so,9}
mv $lib/{libmmkv.so,10}
mv $lib/{libtgpa.so,11}
mv $lib/{libijkffmpeg.so,12}
mv $lib/{libst-engine.so,13}
mv $lib/{libITOP.so,14}
mv $lib/{libhelpshiftlistener.so,15}


mkdir $lib/libtersafe.so
mkdir $lib/libUE4.so
mkdir $lib/libtprt.so
mkdir $lib/libTDataMaster.so
mkdir $lib/libgcloud.so
mkdir $lib/libapp.so
mkdir $lib/libflutter.so
mkdir $lib/libBugly.so
mkdir $lib/libImSDK.so
mkdir $lib/libmmkv.so
mkdir $lib/libtgpa.so
mkdir $lib/libijkffmpeg.so
mkdir $lib/libst-engine.so
mkdir $lib/libITOP.so
mkdir $lib/libhelpshiftlistener.so

echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events


cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches

su -c iptables --flush
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/nullnull

echo -e "$XRED DONE "