iptables --flush
iptables -F
