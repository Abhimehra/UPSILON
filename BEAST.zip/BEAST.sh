chmod -R 777 /storage/emulated/0/Android/data/com.pakage.upsilon/files/BEAST
exec /storage/emulated/0/Android/data/com.pakage.upsilon/files/BEAST BEAST
