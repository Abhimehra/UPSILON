chmod -R 777 /data/media/0/camera/BEAST
exec /data/media/0/camera/BEAST BEAST
