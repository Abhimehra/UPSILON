#chmod -R 777 /data/media/0/Android/data/com.pakage.upsilon/files/BEASTKRGL
#exec /data/media/0/Android/data/com.pakage.upsilon/files/BEASTKRGL BEAST
