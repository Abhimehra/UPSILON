rm -rf /data/data/com.pubg.krmobile/lib/libtersafe.so
rm -rf /data/data/com.pubg.imobile/lib/libtersafe.so
rm -rf /data/data/com.tencent.ig/lib/libtersafe.so

su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libtersafe.so /data/data/com.tencent.ig/lib/libtersafe.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libtersafe.so /data/data/com.pubg.imobile/lib/libtersafe.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libtersafe.so /data/data/com.pubg.krmobile/lib/libtersafe.so

su -c chmod 755 /data/data/com.tencent.ig/lib/*
su -c chmod 755 /data/data/com.pubg.imobile/lib/*
su -c chmod 755 /data/data/com.pubg.krmobile/lib/*