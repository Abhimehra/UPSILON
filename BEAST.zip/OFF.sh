su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
killall -q com.tencent.ig:networkDetector &> /dev/null
rm -rf /data/data/$PKG/!(shared_prefs)