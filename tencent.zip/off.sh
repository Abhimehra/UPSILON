su -c iptables --flush
pm install /data/app/com.tencent.ig*/base.apk
