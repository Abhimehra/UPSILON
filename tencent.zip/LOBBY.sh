
lib="/data/data/com.tencent.ig/lib"
PKG="/data/data/com.tencent.ig/"
rm -rf /data/data/$PKG/{d*,a*,c*}
rm -rf $lib/libtersafe.so
rm -rf $lib/libTDataMaster.so
mv $lib/1 $lib/libtersafe.so
mv $lib/2 $lib/libUE4.so
mv $lib/3 $lib/libtprt.so
mv $lib/4 $lib/libTDataMaster.so
mv $lib/5 $lib/libgcloud.so
chmod 777 $PKG/lib*/
chmod 600 /data/data/$PKG/files/ano_tmp &> /dev/null
exec /data/media/0/Android/data/com.pakage.upsilon/files/BEAST LOGO &> /dev/null