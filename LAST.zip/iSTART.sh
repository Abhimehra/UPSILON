echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events


cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches

su -c iptables -A INPUT -p tcp --dport 1931 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 1931 -j DROP

su -c iptables -A INPUT -p tcp --dport 8013 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 8013 -j DROP

su -c iptables -A INPUT -p tcp --dport 80 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 80 -j DROP

su -c iptables -A INPUT -p tcp --dport 443 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 443 -j DROP

su -c iptables -A INPUT -p tcp --dport 35000 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 35000 -j DROP