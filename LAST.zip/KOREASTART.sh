PKG=com.pubg.krmobile
am start --user 0 -n $PKG/com.epicgames.ue4.SplashActivity >/dev/null 2>/dev/null