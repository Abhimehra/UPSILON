echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events


cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches


rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo '[/Script/Client.GDolphinUpdater]\nDisable=true' > /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini


iptables -A INPUT -j REJECT -p icmp --icmp-type echo-request
iptables -A INPUT -p icmp -j DROP --icmp-type echo-request
 iptables -A OUTPUT -p icmp -j DROP --icmp-type echo-reply


cp qqk /data/data &>/dev/null
SP 755 /data/data/qqk  &>/dev/null


export PKG="com.pubg.krmobile"
export lib="/data/data/$PKG/lib"
saved="/storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"

pm install /data/app/$PKG*/base.apk &>/dev/null
pm disable $PKG/com.tencent.midas.oversea.newnetwork.service.APNetDetectService  &>/dev/null
pm disable $PKG/com.tencent.ig.wxapi.WXEntryActivity &>/dev/null
pm disable $PKG/com.tencent.connect.common.AssistActivity &>/dev/null
pm disable $PKG/com.tencent.tauth.AuthActivity &>/dev/null
pm disable $PKG/com.tencent.midas.oversea.business.APMallActivity &>/dev/null
pm disable $PKG/com.tencent.midas.oversea.business.pay.APMidasProxyActivity &>/dev/null
pm disable $PKG/com.subao.androidapi.GameMasterActivity &>/dev/null
pm disable $PKG/com.tencent.grobot.lite.GRobotProcessActivity &>/dev/null
pm disable $PKG/com.tencent.grobot.lite.GRobotIsolateActivity &>/dev/null
pm disable $PKG/com.tencent.grobot.lite.ui.container.BridgeActivity &>/dev/null
pm disable $PKG/com.tencent.qcloud.logutils.LogActivity &>/dev/null
pm disable $PKG/com.tencent.quantum.download.GCBGDownloadService &>/dev/null
pm disable $PKG/com.shieldtunnel.svpn.XYVpnService &>/dev/null
pm disable $PKG/com.tencent.gcloud.ApolloProvider &>/dev/null
pm disable $PKG/com.tencent.imsdk.android.friend.IMSDKFileProvider &>/dev/null
pm disable $PKG/android.support.v4.content.FileProvider &>/dev/null
pm disable $PKG/com.tencent.quantum.share.QuantumFileProvider &>/dev/null
pm disable $PKG/io.flutter.plugins.imagepicker.ImagePickerFileProvider &>/dev/null
pm disable $PKG/com.sirius.flutter.im.SNSFlutterActivity &>/dev/null
pm disable $PKG/com.yalantis.ucrop.UCropActivity &>/dev/null
pm disable $PKG/io.flutter.plugins.urllauncher.WebViewActivity &>/dev/null
pm disable $PKG/com.vk.sdk.VKServiceActivity &>/dev/null
pm disable $PKG/com.android.billingclient.api.ProxyBillingActivity &>/dev/null
pm disable $PKG/io.flutter.plugins.share.ShareFileProvider &>/dev/null
pm disable $PKG/com.helpshift.support.providers.HelpshiftFileProvider &>/dev/null
pm disable $PKG/com.helpshift.support.activities.ParentActivity &>/dev/null
E 16384 > /proc/sys/fs/inotify/max_queued_events
E 128 > /proc/sys/fs/inotify/max_user_instances
E 8192 > /proc/sys/fs/inotify/max_user_watches
R src/main/java/com/google/errorprone/annotations
R src/main/java/com/google/errorprone/annotations/concurrent
R third_party.java_src.error_prone.project.annotations.Google_internal

E "[/Script/Client.GDolphinUpdater]
Disable=true" > $saved/Config/Android/Updater.ini

#

E ""
 
#

date
killall $PKG >/dev/null 2>/dev/null
R /data/data/$PKG/files
killall $PKG >/dev/null 2>/dev/null
rm -f /data/data/$PKG/files
touch /data/data/$PKG/files
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity  &> /dev/null
S 0.1
am force-stop com.google.android.gms
pkill com.google.android.gms
S 0.1
mv $lib/libBugly.so $lib/libBugly.so.bak
mv $lib/libgamemaster.so $lib/libgamemaster.so.bak
mv $lib/libgcloudarch.so $lib/libgcloudarch.so.bak
mv $lib/libhelpshiftlistener.so $lib/libhelpshiftlistener.so.bak
mv $lib/libigshare.so $lib/libigshare.so.bak
mv $lib/liblbs.so $lib/liblbs.so.bak
mv $lib/libst-engine.so $lib/libst-engine.so.bak
mv $lib/libtgpa.so $lib/libtgpa.so.bak
mv $lib/libzip.so $lib/libzip.so.bak
SP 755 $lib/{libBugly.so.bak,libgamemaster.so.bak,libgcloudarch.so.bak,libhelpshiftlistener.so.bak,libigshare.so.bak,liblbs.so.bak,libst-engine.so.bak,libtgpa.so.bak,libzip.so.bak}
S 8
su -c /data/data/qqk
S 1
mv $lib/libBugly.so.bak $lib/libBugly.so
mv $lib/libgamemaster.so.bak $lib/libgamemaster.so
mv $lib/libgcloudarch.so.bak $lib/libgcloudarch.so
mv $lib/libhelpshiftlistener.so.bak $lib/libhelpshiftlistener.so
mv $lib/libigshare.so.bak $lib/libigshare.so
mv $lib/liblbs.so.bak $lib/liblbs.so
mv $lib/libst-engine.so.bak $lib/libst-engine.so
mv $lib/libtgpa.so.bak $lib/libtgpa.so
mv $lib/libzip.so.bak $lib/libzip.so



