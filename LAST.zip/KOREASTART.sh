chmod 777 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.25337.pak
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
echo '[version]
appversion=1.5.0.15331
srcversion=1.5.0.25337' >> /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 550 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 555 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
echo "

kkk3o" >> /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
cp /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz



echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events


cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches


rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo '[/Script/Client.GDolphinUpdater]\nDisable=true' > /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini


su -c iptables -A INPUT -p tcp --dport 8086 -j DROP
su -c iptables -A INPUT -p tcp --dport 8085 -j DROP
su -c iptables -A INPUT -p tcp --dport 90 -j DROP
su -c iptables -A INPUT -p tcp --dport 554 -j DROP
su -c iptables -A INPUT -p tcp --dport 80 -j DROP
#su -c iptables -A INPUT -p tcp --dport 443 -j DROP
su -c iptables -A INPUT -p tcp --dport 8013 -j DROP
su -c iptables -A INPUT -p tcp --dport 15692 -j DROP
su -c iptables -A INPUT -p UDP --dport 9031 -j DROP
su -c iptables -A INPUT -p tcp --dport 10080 -j DROP
su -c iptables -A INPUT -p tcp --dport 20001 -j DROP
su -c iptables -A INPUT -p tcp --dport 20000 -j DROP
su -c iptables -A INPUT -p tcp --dport 8011 -j DROP
su -c iptables -A INPUT -p tcp --dport 18081 -j DROP
su -c iptables -A INPUT -p tcp --dport 20002 -j DROP
su -c iptables -A INPUT -p tcp --dport 17000 -j DROP
su -c iptables -A INPUT -p UDP --dport 8700 -j DROP
su -c iptables -A INPUT -p tcp --dport 20371 -j DROP
su -c iptables -A INPUT -p UDP --dport 9030 -j DROP
su -c iptables -A INPUT -p UDP --dport 9031 -j DROP
su -c iptables -A INPUT -p tcp --dport 18600 -j DROP
su -c iptables -A INPUT -p UDP --dport 10013 -j DROP
su -c iptables -A INPUT -p UDP --dport 10012 -j DROP
su -c iptables -A INPUT -p UDP --dport 10019 -j DROP

su -c iptables -A OUTPUT -p tcp --dport 8086 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 8085 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 90 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 554 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 80 -j DROP
#su -c iptables -A OUTPUT -p tcp --dport 443 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 8013 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 15692 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 9031 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 10080 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 20001 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 20000 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 8011 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 20002 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 17000 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 8700 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 20371 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 9030 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 9031 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 18600 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10013 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10012 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10019 -j DROP

su -c iptables -A INPUT -p UDP --dport 8086 -j DROP
su -c iptables -A INPUT -p UDP --dport 8085 -j DROP
su -c iptables -A INPUT -p UDP --dport 90 -j DROP
su -c iptables -A INPUT -p UDP --dport 554 -j DROP
su -c iptables -A INPUT -p UDP --dport 80 -j DROP
#su -c iptables -A INPUT -p UDP --dport 443 -j DROP
su -c iptables -A INPUT -p UDP --dport 8013 -j DROP
su -c iptables -A INPUT -p UDP --dport 15692 -j DROP
su -c iptables -A INPUT -p UDP --dport 9031 -j DROP
su -c iptables -A INPUT -p UDP --dport 10080 -j DROP
su -c iptables -A INPUT -p UDP --dport 20001 -j DROP
su -c iptables -A INPUT -p UDP --dport 20000 -j DROP
su -c iptables -A INPUT -p UDP --dport 8011 -j DROP
su -c iptables -A INPUT -p UDP --dport 18081 -j DROP
su -c iptables -A INPUT -p UDP --dport 20002 -j DROP
su -c iptables -A INPUT -p UDP --dport 17000 -j DROP
su -c iptables -A INPUT -p UDP --dport 8700 -j DROP
su -c iptables -A INPUT -p UDP --dport 20371 -j DROP
su -c iptables -A INPUT -p UDP --dport 9030 -j DROP
su -c iptables -A INPUT -p UDP --dport 9031 -j DROP
su -c iptables -A INPUT -p UDP --dport 18600 -j DROP
su -c iptables -A INPUT -p UDP --dport 10013 -j DROP
su -c iptables -A INPUT -p UDP --dport 10012 -j DROP
su -c iptables -A INPUT -p UDP --dport 10019 -j DROP

su -c iptables -A OUTPUT -p UDP --dport 8086 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 8085 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 90 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 554 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 80 -j DROP
#su -c iptables -A OUTPUT -p UDP --dport 443 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 8013 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 15692 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 9031 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10080 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 20001 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 20000 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 8011 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 18081 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 20002 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 17000 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 8700 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 20371 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 9030 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 9031 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 18600 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10013 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10012 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10019 -j DROP



am start -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity > /dev/null


sleep 5
clear
while true
do
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.krmobile/cache
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
