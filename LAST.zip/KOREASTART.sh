iptables -A INPUT -j REJECT -p icmp --icmp-type echo-request
iptables -A INPUT -p icmp -j DROP --icmp-type echo-request
 iptables -A OUTPUT -p icmp -j DROP --icmp-type echo-reply

am start -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity > /dev/null



