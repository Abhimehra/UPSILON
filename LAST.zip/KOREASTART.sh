echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
date
export PKG="com.pubg.krmobile"
export lib="/data/data/$PKG/lib"
killall $PKG >/dev/null 2>/dev/null
clear
date
sleep 1
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15337.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15339.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15340.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_1.5.0.15350.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_1.5.0.15351.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_1.5.0.15352.pak  >/dev/null 2>/dev/null
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
rm -rf /storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 755 $lib/*
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo "[/Script/Client.GDolphinUpdater]
Disable=true" > /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
rm -rf $lib/libBugly.so 
rm -rf $lib/libgamemaster.so 
rm -rf $lib/libgcloudarch.so 
rm -rf $lib/libhelpshiftlistener.so 
rm -rf $lib/libigshare.so 
rm -rf $lib/liblbs.so 
rm -rf $lib/libst-engine.so 
rm -rf $lib/libtgpa.so 
rm -rf $lib/libzip.so 
rm -rf $lib/libapp.so 
rm -rf $lib/libc++_shared.so 
rm -rf $lib/libflutter.so 
rm -rf $lib/libmarsxlog.so 
rm -rf $lib/libmmkv.so 
rm -rf $lib/libsentry.so 
rm -rf $lib/libsentry-android.so 
rm -rf $lib/libnpps-jni.so 
rm -rf $lib/libImSDK.so 
chmod -R 755 $lib/*
rm -rf /data/data/$PKG/files
touch /data/data/$PKG/files
echo "@BEEASTYT"
cp $lib/libtersafe.so $lib/libtersafe.so.bak
cp $lib/libswappy.so $lib/libswappy.so.bak
cp $lib/libUE4.so $lib/libUE4.so.bak
cp $lib/libtprt.so $lib/libtprt.so.bak
cp $lib/libITOP.so $lib/libITOP.so.bak
cp $lib/libvlink.so $lib/libvlink.so.bak
am start --user 0 -n $PKG/com.epicgames.ue4.SplashActivity >/dev/null 2>/dev/null
sleep 8.5
rm -rf $lib/libtersafe.so
rm -rf $lib/libUE4.so
rm -rf $lib/libtprt.so
rm -rf $lib/libswappy.so
rm -rf $lib/libITOP.so
rm -rf $lib/libvlink.so
mv $lib/libtersafe.so.bak $lib/libtersafe.so
mv $lib/libswappy.so.bak $lib/libswappy.so
mv $lib/libUE4.so.bak $lib/libUE4.so
mv $lib/libtprt.so.bak $lib/libtprt.so
mv $lib/libITOP.so.bak $lib/libITOP.so
mv $lib/libvlink.so.bak $lib/libvlink.so
svc data enable && svc wifi enable
am force-stop com.pubg.krmobile:imsdk_inner_webview &> /dev/null && am force-stop com.pubg.krmobile:networkDetector &> /dev/null && am force-stop com.pubg.krmobile:playcore_missing_splits_activity &> /dev/null && am force-stop com.pubg.krmobile:plugin &> /dev/null  && am force-stop com.pubg.krmobile:remoteWeb &> /dev/null && am force-stop com.pubg.krmobile:vlink &> /dev/null
sleep 3
am force-stop com.pubg.krmobile:imsdk_inner_webview &> /dev/null && am force-stop com.pubg.krmobile:networkDetector &> /dev/null && am force-stop com.pubg.krmobile:playcore_missing_splits_activity &> /dev/null && am force-stop com.pubg.krmobile:plugin &> /dev/null && am force-stop com.pubg.krmobile:remoteWeb &> /dev/null && am force-stop com.pubg.krmobile:vlink &> /dev/null
sleep 3
am force-stop com.pubg.krmobile:imsdk_inner_webview &> /dev/null && am force-stop com.pubg.krmobile:networkDetector &> /dev/null && am force-stop com.pubg.krmobile:playcore_missing_splits_activity &> /dev/null && am force-stop com.pubg.krmobile:plugin &> /dev/null  && am force-stop com.pubg.krmobile:remoteWeb &> /dev/null && am force-stop com.pubg.krmobile:vlink &> /dev/null
sleep 3
am force-stop com.pubg.krmobile:imsdk_inner_webview &> /dev/null && am force-stop com.pubg.krmobile:networkDetector &> /dev/null && am force-stop com.pubg.krmobile:playcore_missing_splits_activity &> /dev/null && am force-stop com.pubg.krmobile:plugin  &> /dev/null && am force-stop com.pubg.krmobile:remoteWeb &> /dev/null && am force-stop com.pubg.krmobile:vlink &> /dev/null