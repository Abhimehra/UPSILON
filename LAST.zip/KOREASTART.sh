echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches

svc data disable && svc wifi disable
echo '8192' > /proc/sys/fs/inotify/max_user_instances && echo '8192' > /proc/sys/fs/inotify/max_user_watches && echo '8192' > /proc/sys/fs/inotify/max_queued_events
iptables -F && iptables -X && iptables --flush
am force-stop com.pubg.krmobile
DMPKG="/data/media/0/Android/data/com.pubg.krmobile"
DDPKG="/data/data/com.pubg.krmobile"
FUS="files/UE4Game/ShadowTrackerExtra"
mv $DDPKG/shared_prefs/device_id.xml1.bak
rm -rf /data/media/0/com.pubg.krmobile
rm -rf /data/cache/magisk.lo*
rm -rf /data/data/*/*cache*
rm -rf /data/media/0/Android/*/*/cache
rm -rf $DDPKG/app_*
rm -rf $DDPKG/databases
rm -rf $DDPKG/files/*
rm -rf $DDPKG/no_backup
rm -rf $DDPKG/shared_prefs/*
rm -rf $DMPKG/cache
rm -rf $DMPKG/files/TGPA
rm -rf $DMPKG/files/ca-bundle.pem
rm -rf $DMPKG/files/cacheFile.txt
rm -rf $DMPKG/files/login-identifier.txt
rm -rf $DMPKG/files/hawk_data
rm -rf $DMPKG/$FUS/Engine
rm -rf $DMPKG/$FUS/'Epic Games'
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Content
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Intermediate
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/Config
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/ImageDownload
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/LightData
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/Logs
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/MMKV
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/Pandora
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/Puffer*
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/rawdata
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/RoleInfo
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/TableDatas
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/coverversion.ini
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/SrcVersion.ini
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/GameErrorNoRecords
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/SaveGames/*.json
rm -rf $DMPKG/$FUS/ShadowTrackerExtra/Saved/SaveGames/*/*.json
rmdir $DMPKG/$FUS/ShadowTrackerExtra/Saved/SaveGames/* &> /dev/null
rm -rf $DDPKG/lib/libapp.so
rm -rf $DDPKG/lib/libBugly.so
rm -rf $DDPKG/lib/libc++_shared.so
rm -rf $DDPKG/lib/libflutter.so
rm -rf $DDPKG/lib/libgamemaster.so
rm -rf $DDPKG/lib/libgcloudarch.so
rm -rf $DDPKG/lib/libhelpshiftlistener.so
rm -rf $DDPKG/lib/libigshare.so
rm -rf $DDPKG/lib/liblbs.so
rm -rf $DDPKG/lib/libmarsxlog.so
rm -rf $DDPKG/lib/libmmkv.so
rm -rf $DDPKG/lib/libnpps-jni.so
rm -rf $DDPKG/lib/libsentry.so
rm -rf $DDPKG/lib/libsenrty-android.so
rm -rf $DDPKG/lib/libst-engine.so
rm -rf $DDPKG/lib/libtgpa.so
rm -rf $DDPKG/lib/libzip.so
mkdir $DDPKG/files &> /dev/null
mkdir $DDPKG/shared_prefs &> /dev/null
mv 1.bak $DDPKG/shared_prefs/device_id.xml
touch $DDPKG/app_crashrecord
touch $DDPKG/files/ano_tmp
touch $DMPKG/$FUS/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15336.pak
chmod -R 755 $DDPKG
chmod -R 755 $DMPKG
#am start --user 0 -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity > /dev/null
sleep 11.5
chmod 000 $DDPKG/files/ano_tmp
chmod 550 $DDPKG/files
chmod 404 $DDPKG/lib/*
svc data enable && svc wifi enable
am force-stop com.pubg.krmobile:imsdk_inner_webview &> /dev/null && am force-stop com.pubg.krmobile:networkDetector &> /dev/null && am force-stop com.pubg.krmobile:playcore_missing_splits_activity &> /dev/null && am force-stop com.pubg.krmobile:plugin &> /dev/null  && am force-stop com.pubg.krmobile:remoteWeb &> /dev/null && am force-stop com.pubg.krmobile:vlink &> /dev/null
sleep 3
am force-stop com.pubg.krmobile:imsdk_inner_webview &> /dev/null && am force-stop com.pubg.krmobile:networkDetector &> /dev/null && am force-stop com.pubg.krmobile:playcore_missing_splits_activity &> /dev/null && am force-stop com.pubg.krmobile:plugin &> /dev/null && am force-stop com.pubg.krmobile:remoteWeb &> /dev/null && am force-stop com.pubg.krmobile:vlink &> /dev/null
sleep 3
am force-stop com.pubg.krmobile:imsdk_inner_webview &> /dev/null && am force-stop com.pubg.krmobile:networkDetector &> /dev/null && am force-stop com.pubg.krmobile:playcore_missing_splits_activity &> /dev/null && am force-stop com.pubg.krmobile:plugin &> /dev/null  && am force-stop com.pubg.krmobile:remoteWeb &> /dev/null && am force-stop com.pubg.krmobile:vlink &> /dev/null
sleep 3
am force-stop com.pubg.krmobile:imsdk_inner_webview &> /dev/null && am force-stop com.pubg.krmobile:networkDetector &> /dev/null && am force-stop com.pubg.krmobile:playcore_missing_splits_activity &> /dev/null && am force-stop com.pubg.krmobile:plugin  &> /dev/null && am force-stop com.pubg.krmobile:remoteWeb &> /dev/null && am force-stop com.pubg.krmobile:vlink &> /dev/null


export PKG="com.pubg.krmobile"
export lib="/data/data/$PKG/lib"
killall $PKG >/dev/null 2>/dev/null

sleep 1
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15337.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15339.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15340.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_1.5.0.15350.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_1.5.0.15351.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_1.5.0.15352.pak  >/dev/null 2>/dev/null
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
rm -rf /storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 755 $lib/*
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo "[/Script/Client.GDolphinUpdater]
Disable=true" > /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
rm -rf $lib/libBugly.so 
rm -rf $lib/libgamemaster.so 
rm -rf $lib/libgcloudarch.so 
rm -rf $lib/libhelpshiftlistener.so 
rm -rf $lib/libigshare.so 
rm -rf $lib/liblbs.so 
rm -rf $lib/libst-engine.so 
rm -rf $lib/libtgpa.so 
rm -rf $lib/libzip.so 
rm -rf $lib/libapp.so 
rm -rf $lib/libc++_shared.so 
rm -rf $lib/libflutter.so 
rm -rf $lib/libmarsxlog.so 
rm -rf $lib/libmmkv.so 
rm -rf $lib/libsentry.so 
rm -rf $lib/libsentry-android.so 
rm -rf $lib/libnpps-jni.so 
rm -rf $lib/libImSDK.so 
chmod -R 755 $lib/*
rm -rf /data/data/$PKG/files
touch /data/data/$PKG/files
echo "@BEEASTYT"
cp $lib/libtersafe.so $lib/libtersafe.so.bak
cp $lib/libswappy.so $lib/libswappy.so.bak
cp $lib/libUE4.so $lib/libUE4.so.bak
cp $lib/libtprt.so $lib/libtprt.so.bak
cp $lib/libITOP.so $lib/libITOP.so.bak
cp $lib/libvlink.so $lib/libvlink.so.bak
am start --user 0 -n $PKG/com.epicgames.ue4.SplashActivity >/dev/null 2>/dev/null
sleep 8.5
rm -rf $lib/libtersafe.so
rm -rf $lib/libUE4.so
rm -rf $lib/libtprt.so
rm -rf $lib/libswappy.so
rm -rf $lib/libITOP.so
rm -rf $lib/libvlink.so
mv $lib/libtersafe.so.bak $lib/libtersafe.so
mv $lib/libswappy.so.bak $lib/libswappy.so
mv $lib/libUE4.so.bak $lib/libUE4.so
mv $lib/libtprt.so.bak $lib/libtprt.so
mv $lib/libITOP.so.bak $lib/libITOP.so
mv $lib/libvlink.so.bak $lib/libvlink.so