su -c chmod -R 777 /data/media/0/Android/data/com.pakage.upsilon/files/CARFLYOFF
su -c exec /data/media/0/Android/data/com.pakage.upsilon/files/CARFLYOFF BEAST