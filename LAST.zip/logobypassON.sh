chmod 775 /data/media/0/Android/data/com.pakage.upsilon/files/fixban

su -c /data/media/0/Android/data/com.pakage.upsilon/files/fixban

#korean
rm -rf /data/data/com.pubg.krmobile/lib/libBugly.so
rm -rf /data/data/com.pubg.krmobile/lib/libcubehawk.so
rm -rf /data/data/com.pubg.krmobile/lib/libgcloud.so
rm -rf /data/data/com.pubg.krmobile/lib/libIMSDK.so
rm -rf /data/data/com.pubg.krmobile/lib/libTDataMaster.so
rm -rf /data/data/com.pubg.krmobile/lib/libtersafe.so
rm -rf /data/data/com.pubg.krmobile/lib/libtprt.so
rm -rf /data/data/com.pubg.krmobile/lib/libUE4.so

#krmover

cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/a.so /data/data/com.pubg.krmobile/lib/libBugly.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/b.so /data/data/com.pubg.krmobile/lib/libcubehawk.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/c.so /data/data/com.pubg.krmobile/lib/libgcloud.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/d.so /data/data/com.pubg.krmobile/lib/libIMSDK.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/e.so /data/data/com.pubg.krmobile/lib/libTDataMaster.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/f.so /data/data/com.pubg.krmobile/lib/libtersafe.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/g.so /data/data/com.pubg.krmobile/lib/libtprt.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/h.so /data/data/com.pubg.krmobile/lib/libUE4.so


#Global

rm -rf /data/data/com.tencent.ig/lib/libBugly
rm -rf /data/data/com.tencent.ig/lib/libcubehawk.so
rm -rf /data/data/com.tencent.ig/lib/libgcloud.so
rm -rf /data/data/com.tencent.ig/lib/libIMSDK.so
rm -rf /data/data/com.tencent.ig/lib/libTDataMaster.so
rm -rf /data/data/com.tencent.ig/lib/libtersafe.so
rm -rf /data/data/com.tencent.ig/lib/libtprt.so
rm -rf /data/data/com.tencent.ig/lib/libUE4.so

cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/i.so /data/data/com.tencent.ig/lib/libBugly.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/j.so /data/data/com.tencent.ig/lib/libcubehawk.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/k.so /data/data/com.tencent.ig/lib/libgcloud.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/l.so /data/data/com.tencent.ig/lib/libIMSDK.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/m.so /data/data/com.tencent.ig/lib/libTDataMaster.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/n.so /data/data/com.tencent.ig/lib/libtersafe.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/o.so /data/data/com.tencent.ig/lib/libtprt.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/p.so /data/data/com.tencent.ig/lib/libUE4.so

chmod 755 /data/data/com.pubg.krmobile/lib/*
chmod 755 /data/data/com.pubg.krmobile/lib*/
chmod 755 /data/data/com.tencent.ig/lib/*
chmod 755 /data/data/com.tencent.ig/lib*/





