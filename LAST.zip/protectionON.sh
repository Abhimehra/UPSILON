su -c iptables -A INPUT -p tcp --dport 17500 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 17500 -j DROP

su -c iptables -A INPUT -p tcp --dport 18600 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 18600 -j DROP