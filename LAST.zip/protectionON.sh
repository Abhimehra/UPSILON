iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 0000 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 17500 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 15292 -j DROP
ptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 443 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 20371 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 18081 -j DROP

iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 0000 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 17500 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 15292 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 443 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 20371 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 18081 -j DROP

iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 0000 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 17500 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 15292 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 443 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 20371 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 18081 -j DROP

