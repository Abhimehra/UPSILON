su -c iptables -I INPUT -p tcp --dport 17500 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17500 -j DROP