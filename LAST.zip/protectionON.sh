NOW=`date '+%y%m%d'`
EXPIRY=210505 # set expiry date here
if (( $NOW > $EXPIRY )); then
  echo -e '\e[32m\e ❌ EXPIRED ❌'
  killall bin.mt.plus.canary
  killall bin.mt.plus
  killall com.termux
else
echo -e '\e[32m\e 🆗Opening'
fi
iptables --flush &> /dev/null
if [ $(pidof com.tencent.ig) ]; then
awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list > /data/media/0/uidinf
UID=$(cat /data/media/0/uidinf)
iptables -A OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &> /dev/null
echo "Successful"
elif [ $(pidof com.pubg.krmobile) ]; then
awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list > /data/media/0/uidinf
UID=$(cat /data/media/0/uidinf)
iptables -A OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &> /dev/null
echo "Successful"
elif [ $(pidof com.pubg.imobile) ]; then
awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list > /data/media/0/uidinf
UID=$(cat /data/media/0/uidinf)
iptables -A OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &> /dev/null
echo "Successful"
else
echo "No Process Running"
fi