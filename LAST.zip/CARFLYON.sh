su -c chmod -R 777 /data/media/0/Android/data/com.pakage.upsilon/files/CARFLYON
su -c exec /data/media/0/Android/data/com.pakage.upsilon/files/CARFLYON BEAST