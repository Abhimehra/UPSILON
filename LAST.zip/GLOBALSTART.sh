iptables -I INPUT -s krlobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s krlobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 0euping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 0euping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 14meping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 14meping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 1dd2hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 1dd2hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 127.1hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 127.1hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 1krping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 1krping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 1pay.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 1pay.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 3rdparty.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 4lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s config.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s config.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s gilobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gilobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 4lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 4lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s headshot.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s headshot.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s vn.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s vn.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s tw.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s tw.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s gl.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gl.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s guest.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s guest.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s gl.public.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gl.public.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s pubgm.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s pubgm.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s tencent.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s tencent.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s report.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s report.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s reverse.comsaping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s reverse.comsaping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s free.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s free.igamecj.com -j REJECT &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/TGPA &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs0 /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs1 &>/dev/null
chmod 770 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

iptables -A FORWARD -m string --algo bm --string "AntiCheatOpenID" -j DROP
iptables -A FORWARD -m string --algo bm --string "COREREPORT" -j DROP
iptables -A FORWARD -m string --algo bm --string "N6TssSDK11ReportQueue" -j DROP
iptables -A FORWARD -m string --algo bm --string "N6TssSDK15FileCrcReporter" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDK.ReportQosByGame" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKDelReportData" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKGetReportData" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKOnRecvData" -j DROP
iptables -A FORWARD -m string --algo bm --string "WB_GetReportStr" -j DROP
iptables -A FORWARD -m string --algo bm --string "_ZN6TssSdk16sdt_report_errorEv" -j DROP
iptables -A FORWARD -m string --algo bm --string "amazonaws.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "asia.csoversea.mbgame.anticheatexpert.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "cs.mbgame.gamesafe.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "dlied1.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "down.anticheatexpert.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "down.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "intldlgs.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "report_apk" -j DROP
iptables -A FORWARD -m string --algo bm --string "res_max_report_missed_cnt" -j DROP
iptables -A FORWARD -m string --algo bm --string "sc_report" -j DROP
iptables -A FORWARD -m string --algo bm --string "tdm_report" -j DROP
iptables -A FORWARD -m string --algo bm --string "tdm_report_sdk_update_config_finish" -j DROP
iptables -A FORWARD -m string --algo bm --string "tencentgames.helpshift.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "tp2_free_anti_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_del_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_enable_get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_sdk_rcv_anti_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "vmp.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "AntiCheatOpenID" -j DROP
iptables -A INPUT -m string --algo bm --string "COREREPORT" -j DROP
iptables -A INPUT -m string --algo bm --string "N6TssSDK11ReportQueue" -j DROP
iptables -A INPUT -m string --algo bm --string "N6TssSDK15FileCrcReporter" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDK.ReportQosByGame" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKDelReportData" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKGetReportData" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKOnRecvData" -j DROP
iptables -A INPUT -m string --algo bm --string "WB_GetReportStr" -j DROP
iptables -A INPUT -m string --algo bm --string "_ZN6TssSdk16sdt_report_errorEv" -j DROP
iptables -A INPUT -m string --algo bm --string "amazonaws.com" -j DROP
iptables -A INPUT -m string --algo bm --string "asia.csoversea.mbgame.anticheatexpert.com" -j DROP
iptables -A INPUT -m string --algo bm --string "cs.mbgame.gamesafe.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "dlied1.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "down.anticheatexpert.com" -j DROP
iptables -A INPUT -m string --algo bm --string "down.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "intldlgs.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "report_apk" -j DROP
iptables -A INPUT -m string --algo bm --string "res_max_report_missed_cnt" -j DROP
iptables -A INPUT -m string --algo bm --string "sc_report" -j DROP
iptables -A INPUT -m string --algo bm --string "tdm_report" -j DROP
iptables -A INPUT -m string --algo bm --string "tdm_report_sdk_update_config_finish" -j DROP
iptables -A INPUT -m string --algo bm --string "tencentgames.helpshift.com" -j DROP
iptables -A INPUT -m string --algo bm --string "tp2_free_anti_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_del_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_enable_get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_sdk_rcv_anti_data" -j DROP
iptables -A INPUT -m string --algo bm --string "vmp.qq.com" -j DROP
iptables -A INPUT -p tcp --dport 10000:10024 -j DROP
iptables -A INPUT -p tcp --dport 22:443 -j DROP
iptables -A INPUT -p tcp --dport 38824 -j DROP
iptables -A INPUT -p tcp --dport 39752 -j DROP
iptables -A INPUT -p tcp --dport 39888 -j DROP
iptables -A INPUT -p tcp --dport 40984 -j DROP
iptables -A INPUT -p tcp --dport 42856 -j DROP
iptables -A INPUT -p tcp --dport 42856:43000 -j DROP
iptables -A INPUT -p tcp --dport 43314 -j DROP
iptables -A INPUT -p tcp --dport 43322 -j DROP
iptables -A INPUT -p tcp --dport 43388 -j DROP
iptables -A INPUT -p tcp --dport 43476 -j DROP
iptables -A INPUT -p tcp --dport 43732 -j DROP
iptables -A INPUT -p tcp --dport 44808 -j DROP
iptables -A INPUT -p tcp --dport 44978:45000 -j DROP
iptables -A INPUT -p tcp --dport 45198 -j DROP
iptables -A INPUT -p tcp --dport 46726 -j DROP
iptables -A INPUT -p tcp --dport 46924 -j DROP
iptables -A INPUT -p tcp --dport 48774 -j DROP
iptables -A INPUT -p tcp --dport 48919 -j DROP
iptables -A INPUT -p tcp --dport 8080:8099 -j DROP
#iptables -A INPUT -p tcp -m multiport ! --dports 17500 -j DROP
iptables -A OUTPUT -m string --algo bm --string "AntiCheatOpenID" -j DROP
iptables -A OUTPUT -m string --algo bm --string "COREREPORT" -j DROP
iptables -A OUTPUT -m string --algo bm --string "N6TssSDK11ReportQueue" -j DROP
iptables -A OUTPUT -m string --algo bm --string "N6TssSDK15FileCrcReporter" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDK.ReportQosByGame" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDKDelReportData" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDKGetReportData" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDKOnRecvData" -j DROP
iptables -A OUTPUT -m string --algo bm --string "WB_GetReportStr" -j DROP
iptables -A OUTPUT -m string --algo bm --string "_ZN6TssSdk16sdt_report_errorEv" -j DROP
iptables -A OUTPUT -m string --algo bm --string "amazonaws.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "asia.csoversea.mbgame.anticheatexpert.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "cs.mbgame.gamesafe.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "dlied1.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "down.anticheatexpert.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "down.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "get_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "intldlgs.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "report_apk" -j DROP
iptables -A OUTPUT -m string --algo bm --string "res_max_report_missed_cnt" -j DROP
iptables -A OUTPUT -m string --algo bm --string "sc_report" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tdm_report" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tdm_report_sdk_update_config_finish" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tencentgames.helpshift.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tp2_free_anti_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_del_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_enable_get_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_get_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_sdk_rcv_anti_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "vmp.qq.com" -j DROP
iptables -I INPUT -p all -m string --string "app.adjust.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cloudconfig.googleapis.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cloudctrl.gcloudsdk.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "compute.amazonaws.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "d.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dl.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "f.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "ig-us-sdkapi.igamecj.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "k.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "mtp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "onezapp.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "proximabeta.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "qcloud.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "report.syzs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "sy.guanjia.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "tencentgames.helpshift.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "tsg.tdatamaster.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "twimg.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '150.109.27.214' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '157.240.16.16' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '192.168.0.103' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '224.0.0.251' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'abs.twimg.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'af-za.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'api.amplitude.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-hk.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-in.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-mb.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-sg.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-th.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'astat.bugly.qcloud.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cdn.wetest.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cdn.wetest.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cloud.gsdk.proximabeta.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cloudsv.ieg.onezapp.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'csi.gstatic.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'eu-fra.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'eu-mo.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'euping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'file.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'filecdn.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'hk.api.unipay.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'hkping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'hkspeed.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'idcconfig.gcloudsdk.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'ig-us-notice.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'in.voice.gcloudcs.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'intldlgs.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'kj-se.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'kj-tk.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'krping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'lh3.googleusercontent.com' --algo kmp -j DROP &>/dev/null
#iptables -I INPUT -p all -m string --string 'lobby.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'me-du.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'meping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'midas.gtimg.cn' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-centra.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-east.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-mx.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-west.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'naping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'napubgm.broker.amsoveasea.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'nawzryhwatm.broker.amsoveasea.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'pandora.game.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'platform-lookaside.fbsbx.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'pubgmobile.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'qos.hk.gcloudcs.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'safebrowsing.googleapis.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'saping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'tpc.googlesyndication.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'usa.csoversea.mbgame.anticheatexpert.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'video.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'youtubei.googleapis.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 1112 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 11443 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 18081 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 3013 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 80 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8080 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8085 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8086 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8088 -j DROP &>/dev/null
#iptables -I INPUT -s krlobby.igamecj.com -j DROP &>/dev/null
#iptables -I INPUT -s lobby.igamecj.com -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d 150.109.248.116 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d 199.59.242.154 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d 58.250.137.36 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -s 150.109.248.116 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -s 199.59.242.154 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -s 58.250.137.36 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d 150.109.248.116 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d 199.59.242.154 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d 58.250.137.36 -j DROP &>/dev/null
#iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -s 150.109.248.116 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -s 199.59.242.154 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -s 58.250.137.36 -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "app.adjust.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cloudconfig.googleapis.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cloudctrl.gcloudsdk.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "compute.amazonaws.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "d.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dl.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "f.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "ig-us-sdkapi.igamecj.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "k.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "mtp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "onezapp.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "proximabeta.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "qcloud.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "report.syzs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "sy.guanjia.qq.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "tencentgames.helpshift.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "tsg.tdatamaster.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "twimg.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'abs.twimg.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'af-za.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'api.amplitude.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-hk.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-in.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-mb.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-sg.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-th.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'astat.bugly.qcloud.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cdn.wetest.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cdn.wetest.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cloud.gsdk.proximabeta.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cloudsv.ieg.onezapp.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'csi.gstatic.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'eu-fra.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'eu-mo.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'euping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'file.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'filecdn.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'hk.api.unipay.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'hkping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'hkspeed.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'idcconfig.gcloudsdk.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'ig-us-notice.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'in.voice.gcloudcs.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'intldlgs.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'kj-se.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'kj-tk.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'krping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'lh3.googleusercontent.com' --algo bm -j DROP &>/dev/null
#iptables -I OUTPUT -p all -m string --string 'lobby.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'me-du.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'meping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'midas.gtimg.cn' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-centra.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-east.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-mx.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-west.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'naping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'napubgm.broker.amsoveasea.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'nawzryhwatm.broker.amsoveasea.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'pandora.game.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'platform-lookaside.fbsbx.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'pubgmobile.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'qos.hk.gcloudcs.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'safebrowsing.googleapis.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'saping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'tpc.googlesyndication.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'usa.csoversea.mbgame.anticheatexpert.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'video.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'youtubei.googleapis.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 1112 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 11443 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 18081 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 3013 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 80 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8080 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8085 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8086 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8088 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 11038 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 111 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 20001 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 8011 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 81 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 11038 -j DROP
iptables -I OUTPUT -p udp --dport 111 -j DROP
iptables -I OUTPUT -p udp --dport 20001 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 81 -j DROP
#iptables -I OUTPUT -s krlobby.igamecj.com -j DROP &>/dev/nul

iptables -I OUTPUT -p all -m string --string --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string 1539yyy.869lt.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string 4114.net --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string 599ds.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string agcpqoeprn.asiacdn.gfcdn.xyz --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string aklobekz.asiacdn.gfcdn.xyz --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string api.unipay.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string apiunipay.msf.tencent-cloud.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string astat-bugly-tgw4l.mig.tencent-cloud.net --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string astat.bugly.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string c.isdspeed.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string c.sayhi.360.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string coding.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string cs.mainconn.gamesafe.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string cs.mbgame.anticheatexpert.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string cs.mbgame.gamesafe.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string cschannel.anticheatexpert.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string daswh.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string dev.itop.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string dev.msdkpass.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string download.1.10218.tc.gcloudgbs.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string dun.030idc.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string ebjvu.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string ez4q2.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string game.eve.mdt.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string gchat.qpic.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string gogoru.ert345.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string hc2.tdm.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string huatuocode.huatuo.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string i.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string ip103.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string ipv6.mainconn.gamesafe.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string itop.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string komori.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string lmc.599ds.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string lobby1-live.cn.codm.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string logic.content.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string macgn.cc --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string mmsns.qpic.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string msdktest.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string nj.cschannel.anticheatexpert.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string oth.eve.mdt.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string puffer.2.10218.tc.gcloudgbs.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string qvvvvv.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string ruantv.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string shmmsns.qpic.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string szmmsns.qpic.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string txt.293rr.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string wchat-live.cn.codm.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.030idc.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.1889c.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.4114.net --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.678de.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.cdn67.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.daishuawang.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.ip103.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.kuhu168.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.lgoukm.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.macgn.cc --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.mxssacg.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.nangua11.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.putaoqq.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.qxfaka.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.ruantv.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.shukw.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.sk19919.cc --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.tkkkkk.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.xingkong3.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.yayafaka.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www.zixiaowl.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string www7788.adc.ectr.cn --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string wxsnsdy.tc.qq.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string yayafaka.com --algo bm -j DROP
iptables -I OUTPUT -p all -m string --string zixiaowl.com --algo bm -j DROP
iptables -I INPUT -s -j DROP
iptables -I INPUT -s 111.30.144.154 -j DROP
iptables -I INPUT -s 111.30.164.57 -j DROP
iptables -I INPUT -s 111.30.169.109 -j DROP
iptables -I INPUT -s 111.30.169.84 -j DROP
iptables -I INPUT -s 111.30.171.226 -j DROP
iptables -I INPUT -s 111.30.171.239 -j DROP
iptables -I INPUT -s 111.6.160.81 -j DROP
iptables -I INPUT -s 112.53.26.203 -j DROP
iptables -I INPUT -s 117.184.248.217 -j DROP
iptables -I INPUT -s 117.184.248.218 -j DROP
iptables -I INPUT -s 117.184.248.54 -j DROP
iptables -I INPUT -s 117.184.248.56 -j DROP
iptables -I INPUT -s 117.184.248.73 -j DROP
iptables -I INPUT -s 120.204.207.182 -j DROP
iptables -I INPUT -s 120.204.21.115 -j DROP
iptables -I INPUT -s 120.204.21.117 -j DROP
iptables -I INPUT -s 120.204.21.53 -j DROP
iptables -I INPUT -s 120.221.240.28 -j DROP
iptables -I INPUT -s 120.221.241.233 -j DROP
iptables -I INPUT -s 120.241.190.163 -j DROP
iptables -I INPUT -s 182.254.116.117 -j DROP
iptables -I INPUT -s 183.192.171.214 -j DROP
iptables -I INPUT -s 183.192.172.96 -j DROP
iptables -I INPUT -s 183.194.189.196 -j DROP
iptables -I INPUT -s 183.194.234.48 -j DROP
iptables -I INPUT -s 183.194.235.157 -j DROP
iptables -I INPUT -s 183.204.14.17 -j DROP
iptables -I INPUT -s 183.204.14.41 -j DROP
iptables -I INPUT -s 183.247.242.42 -j DROP
iptables -I INPUT -s 221.130.199.239 -j DROP
iptables -I INPUT -s 221.181.81.253 -j DROP
iptables -I INPUT -s 36.155.245.152 -j DROP
iptables -I INPUT -s 36.155.245.57 -j DROP
iptables -I INPUT -s 58.251.116.12 -j DROP
iptables -I INPUT -s 65.52.187.14 -j DROP
iptables -I INPUT -s 81.69.188.27 -j DROP
iptables -I INPUT -s [2409:8c04:1005:4004:37::] -j DROP
iptables -I INPUT -s [2409:8c54:1050:10::8e] -j DROP
iptables -I OUTPUT -d -j DROP
iptables -I OUTPUT -d 111.30.144.154 -j DROP
iptables -I OUTPUT -d 111.30.164.57 -j DROP
iptables -I OUTPUT -d 111.30.169.109 -j DROP
iptables -I OUTPUT -d 111.30.169.84 -j DROP
iptables -I OUTPUT -d 111.30.171.226 -j DROP
iptables -I OUTPUT -d 111.30.171.239 -j DROP
iptables -I OUTPUT -d 111.6.160.81 -j DROP
iptables -I OUTPUT -d 112.53.26.203 -j DROP
iptables -I OUTPUT -d 117.184.248.217 -j DROP
iptables -I OUTPUT -d 117.184.248.218 -j DROP
iptables -I OUTPUT -d 117.184.248.54 -j DROP
iptables -I OUTPUT -d 117.184.248.56 -j DROP
iptables -I OUTPUT -d 117.184.248.73 -j DROP
iptables -I OUTPUT -d 120.204.207.182 -j DROP
iptables -I OUTPUT -d 120.204.21.115 -j DROP
iptables -I OUTPUT -d 120.204.21.117 -j DROP
iptables -I OUTPUT -d 120.204.21.53 -j DROP
iptables -I OUTPUT -d 120.221.240.28 -j DROP
iptables -I OUTPUT -d 120.221.241.233 -j DROP
iptables -I OUTPUT -d 120.241.190.163 -j DROP
iptables -I OUTPUT -d 182.254.116.117 -j DROP
iptables -I OUTPUT -d 183.192.171.214 -j DROP
iptables -I OUTPUT -d 183.192.172.96 -j DROP
iptables -I OUTPUT -d 183.194.189.196 -j DROP
iptables -I OUTPUT -d 183.194.234.48 -j DROP
iptables -I OUTPUT -d 183.194.235.157 -j DROP
iptables -I OUTPUT -d 183.204.14.17 -j DROP
iptables -I OUTPUT -d 183.204.14.41 -j DROP
iptables -I OUTPUT -d 183.247.242.42 -j DROP
iptables -I OUTPUT -d 221.130.199.239 -j DROP
iptables -I OUTPUT -d 221.181.81.253 -j DROP
iptables -I OUTPUT -d 36.155.245.152 -j DROP
iptables -I OUTPUT -d 36.155.245.57 -j DROP
iptables -I OUTPUT -d 58.251.116.12 -j DROP
iptables -I OUTPUT -d 65.52.187.14 -j DROP
iptables -I OUTPUT -d 81.69.188.27 -j DROP
iptables -I OUTPUT -d [2409:8c04:1005:4004:37::] -j DROP
iptables -I OUTPUT -d [2409:8c54:1050:10::8e] -j DROP
iptables -I INPUT -s -j DROP
iptables -I INPUT -s 1.198.11.81 -j DROP
iptables -I INPUT -s 1.198.11.82 -j DROP
iptables -I INPUT -s 1.198.5.111 -j DROP
iptables -I INPUT -s 1.198.5.151 -j DROP
iptables -I INPUT -s 1.198.5.168 -j DROP
iptables -I INPUT -s 1.198.5.212 -j DROP
iptables -I INPUT -s 1.198.5.249 -j DROP
iptables -I INPUT -s 1.31.109.158 -j DROP
iptables -I INPUT -s 1.31.130.147 -j DROP
iptables -I INPUT -s 1.31.130.148 -j DROP
iptables -I INPUT -s 1.31.130.149 -j DROP
iptables -I INPUT -s 1.31.130.157 -j DROP
iptables -I INPUT -s 1.31.130.158 -j DROP
iptables -I INPUT -s 1.31.173.36 -j DROP
iptables -I INPUT -s 101.226.233.173 -j DROP
iptables -I INPUT -s 101.226.90.186 -j DROP
iptables -I INPUT -s 101.227.216.161 -j DROP
iptables -I INPUT -s 101.69.121.30 -j DROP
iptables -I INPUT -s 101.89.15.189 -j DROP
iptables -I INPUT -s 101.89.39.11 -j DROP
iptables -I INPUT -s 101.91.42.213 -j DROP
iptables -I INPUT -s 103.18.208.142 -j DROP
iptables -I INPUT -s 103.18.208.155 -j DROP
iptables -I INPUT -s 103.18.208.160 -j DROP
iptables -I INPUT -s 103.18.208.171 -j DROP
iptables -I INPUT -s 103.18.208.172 -j DROP
iptables -I INPUT -s 103.18.208.239 -j DROP
iptables -I INPUT -s 103.18.209.11 -j DROP
iptables -I INPUT -s 103.18.209.117 -j DROP
iptables -I INPUT -s 103.18.209.12 -j DROP
iptables -I INPUT -s 103.18.209.13 -j DROP
iptables -I INPUT -s 103.18.209.14 -j DROP
iptables -I INPUT -s 103.18.209.15 -j DROP
iptables -I INPUT -s 103.18.209.16 -j DROP
iptables -I INPUT -s 103.18.209.52 -j DROP
iptables -I INPUT -s 103.7.28.109 -j DROP
iptables -I INPUT -s 103.7.28.15 -j DROP
iptables -I INPUT -s 103.7.29.189 -j DROP
iptables -I INPUT -s 103.7.30.122 -j DROP
iptables -I INPUT -s 103.7.30.50 -j DROP
iptables -I INPUT -s 106.117.248.153 -j DROP
iptables -I INPUT -s 106.117.248.166 -j DROP
iptables -I INPUT -s 106.117.248.167 -j DROP
iptables -I INPUT -s 106.38.181.155 -j DROP
iptables -I INPUT -s 106.38.181.156 -j DROP
iptables -I INPUT -s 106.42.24.31 -j DROP
iptables -I INPUT -s 107.155.58.98 -j DROP
iptables -I INPUT -s 107.155.58.99 -j DROP
iptables -I INPUT -s 110.185.115.171 -j DROP
iptables -I INPUT -s 110.185.115.226 -j DROP
iptables -I INPUT -s 110.185.115.234 -j DROP
iptables -I INPUT -s 110.185.115.237 -j DROP
iptables -I INPUT -s 110.53.246.36 -j DROP
iptables -I INPUT -s 110.81.153.187 -j DROP
iptables -I INPUT -s 110.81.153.248 -j DROP
iptables -I INPUT -s 111.1.57.12 -j DROP
iptables -I INPUT -s 111.1.57.80 -j DROP
iptables -I INPUT -s 111.12.66.11 -j DROP
iptables -I INPUT -s 111.12.66.17 -j DROP
iptables -I INPUT -s 111.12.66.20 -j DROP
iptables -I INPUT -s 111.12.66.84 -j DROP
iptables -I INPUT -s 111.123.50.142 -j DROP
iptables -I INPUT -s 111.123.50.144 -j DROP
iptables -I INPUT -s 111.123.50.197 -j DROP
iptables -I INPUT -s 111.123.50.223 -j DROP
iptables -I INPUT -s 111.13.137.13 -j DROP
iptables -I INPUT -s 111.13.137.57 -j DROP
iptables -I INPUT -s 111.13.137.59 -j DROP
iptables -I INPUT -s 111.13.3.36 -j DROP
iptables -I INPUT -s 111.13.3.37 -j DROP
iptables -I INPUT -s 111.161.64.118 -j DROP
iptables -I INPUT -s 111.177.1.12 -j DROP
iptables -I INPUT -s 111.177.1.14 -j DROP
iptables -I INPUT -s 111.19.244.114 -j DROP
iptables -I INPUT -s 111.19.244.90 -j DROP
iptables -I INPUT -s 111.19.248.193 -j DROP
iptables -I INPUT -s 111.19.248.253 -j DROP
iptables -I INPUT -s 111.202.99.166 -j DROP
iptables -I INPUT -s 111.202.99.18 -j DROP
iptables -I INPUT -s 111.202.99.19 -j DROP
iptables -I INPUT -s 111.206.15.101 -j DROP
iptables -I INPUT -s 111.206.15.13 -j DROP
iptables -I INPUT -s 111.23.8.25 -j DROP
iptables -I INPUT -s 111.30.131.121 -j DROP
iptables -I INPUT -s 111.30.137.123 -j DROP
iptables -I INPUT -s 111.30.144.154 -j DROP
iptables -I INPUT -s 111.30.159.141 -j DROP
iptables -I INPUT -s 111.30.159.171 -j DROP
iptables -I INPUT -s 111.30.159.202 -j DROP
iptables -I INPUT -s 111.30.164.162 -j DROP
iptables -I INPUT -s 111.30.164.163 -j DROP
iptables -I INPUT -s 111.30.164.174 -j DROP
iptables -I INPUT -s 111.30.171.210 -j DROP
iptables -I INPUT -s 111.4.118.148 -j DROP
iptables -I INPUT -s 111.40.174.42 -j DROP
iptables -I INPUT -s 111.41.56.236 -j DROP
iptables -I INPUT -s 111.43.181.105 -j DROP
iptables -I INPUT -s 111.43.181.107 -j DROP
iptables -I INPUT -s 111.43.181.111 -j DROP
iptables -I INPUT -s 111.43.181.123 -j DROP
iptables -I INPUT -s 111.43.181.124 -j DROP
iptables -I INPUT -s 111.43.181.14 -j DROP
iptables -I INPUT -s 111.43.181.149 -j DROP
iptables -I INPUT -s 111.43.181.150 -j DROP
iptables -I INPUT -s 111.43.181.154 -j DROP
iptables -I INPUT -s 111.43.181.164 -j DROP
iptables -I INPUT -s 111.43.181.169 -j DROP
iptables -I INPUT -s 111.43.181.177 -j DROP
iptables -I INPUT -s 111.43.181.181 -j DROP
iptables -I INPUT -s 111.43.181.183 -j DROP
iptables -I INPUT -s 111.43.181.201 -j DROP
iptables -I INPUT -s 111.43.181.219 -j DROP
iptables -I INPUT -s 111.43.181.226 -j DROP
iptables -I INPUT -s 111.43.182.111 -j DROP
iptables -I INPUT -s 111.43.182.165 -j DROP
iptables -I INPUT -s 111.43.182.169 -j DROP
iptables -I INPUT -s 111.43.182.208 -j DROP
iptables -I INPUT -s 111.43.182.227 -j DROP
iptables -I INPUT -s 111.43.182.233 -j DROP
iptables -I INPUT -s 111.43.182.234 -j DROP
iptables -I INPUT -s 111.43.182.38 -j DROP
iptables -I INPUT -s 111.43.182.41 -j DROP
iptables -I INPUT -s 111.43.182.45 -j DROP
iptables -I INPUT -s 111.43.182.46 -j DROP
iptables -I INPUT -s 111.43.182.88 -j DROP
iptables -I INPUT -s 111.43.182.96 -j DROP
iptables -I INPUT -s 111.44.253.249 -j DROP
iptables -I INPUT -s 111.45.68.30 -j DROP
iptables -I INPUT -s 111.47.223.142 -j DROP
iptables -I INPUT -s 111.47.223.161 -j DROP
iptables -I INPUT -s 111.47.223.164 -j DROP
iptables -I INPUT -s 111.47.223.174 -j DROP
iptables -I INPUT -s 111.47.224.152 -j DROP
iptables -I INPUT -s 111.47.224.159 -j DROP
iptables -I INPUT -s 111.47.224.201 -j DROP
iptables -I INPUT -s 111.47.224.237 -j DROP
iptables -I INPUT -s 111.47.224.250 -j DROP
iptables -I INPUT -s 111.47.225.155 -j DROP
iptables -I INPUT -s 111.47.225.157 -j DROP
iptables -I INPUT -s 111.47.225.158 -j DROP
iptables -I INPUT -s 111.47.225.160 -j DROP
iptables -I INPUT -s 111.47.225.166 -j DROP
iptables -I INPUT -s 111.47.225.167 -j DROP
iptables -I INPUT -s 111.47.225.168 -j DROP
iptables -I INPUT -s 111.47.225.169 -j DROP
iptables -I INPUT -s 111.47.244.21 -j DROP
iptables -I INPUT -s 111.47.248.156 -j DROP
iptables -I INPUT -s 111.47.248.179 -j DROP
iptables -I INPUT -s 111.6.186.144 -j DROP
iptables -I INPUT -s 111.6.186.146 -j DROP
iptables -I INPUT -s 111.6.186.156 -j DROP
iptables -I INPUT -s 111.6.186.199 -j DROP
iptables -I INPUT -s 111.6.186.213 -j DROP
iptables -I INPUT -s 111.6.189.141 -j DROP
iptables -I INPUT -s 111.6.189.143 -j DROP
iptables -I INPUT -s 111.6.189.144 -j DROP
iptables -I INPUT -s 111.6.189.195 -j DROP
iptables -I INPUT -s 111.6.189.252 -j DROP
iptables -I INPUT -s 111.62.242.11 -j DROP
iptables -I INPUT -s 111.62.242.12 -j DROP
iptables -I INPUT -s 111.62.242.13 -j DROP
iptables -I INPUT -s 111.62.242.14 -j DROP
iptables -I INPUT -s 111.62.242.15 -j DROP
iptables -I INPUT -s 111.62.242.16 -j DROP
iptables -I INPUT -s 111.62.242.59 -j DROP
iptables -I INPUT -s 111.62.242.78 -j DROP
iptables -I INPUT -s 111.62.249.109 -j DROP
iptables -I INPUT -s 111.62.249.126 -j DROP
iptables -I INPUT -s 111.62.249.26 -j DROP
iptables -I INPUT -s 111.62.249.28 -j DROP
iptables -I INPUT -s 111.62.249.29 -j DROP
iptables -I INPUT -s 111.62.249.30 -j DROP
iptables -I INPUT -s 111.62.249.34 -j DROP
iptables -I INPUT -s 111.62.249.37 -j DROP
iptables -I INPUT -s 111.62.249.38 -j DROP
iptables -I INPUT -s 111.62.249.94 -j DROP
iptables -I INPUT -s 111.7.189.248 -j DROP
iptables -I INPUT -s 111.8.6.145 -j DROP
iptables -I INPUT -s 112.117.221.16 -j DROP
iptables -I INPUT -s 112.17.5.31 -j DROP
iptables -I INPUT -s 112.25.104.182 -j DROP
iptables -I INPUT -s 112.25.105.143 -j DROP
iptables -I INPUT -s 112.25.45.212 -j DROP
iptables -I INPUT -s 112.25.45.251 -j DROP
iptables -I INPUT -s 112.25.52.159 -j DROP
iptables -I INPUT -s 112.25.52.179 -j DROP
iptables -I INPUT -s 112.25.58.141 -j DROP
iptables -I INPUT -s 112.25.58.155 -j DROP
iptables -I INPUT -s 112.25.58.156 -j DROP
iptables -I INPUT -s 112.25.58.157 -j DROP
iptables -I INPUT -s 112.25.58.158 -j DROP
iptables -I INPUT -s 112.25.58.162 -j DROP
iptables -I INPUT -s 112.25.58.163 -j DROP
iptables -I INPUT -s 112.25.58.164 -j DROP
iptables -I INPUT -s 112.25.58.165 -j DROP
iptables -I INPUT -s 112.25.58.191 -j DROP
iptables -I INPUT -s 112.25.58.232 -j DROP
iptables -I INPUT -s 112.29.151.154 -j DROP
iptables -I INPUT -s 112.29.151.155 -j DROP
iptables -I INPUT -s 112.29.151.156 -j DROP
iptables -I INPUT -s 112.29.151.157 -j DROP
iptables -I INPUT -s 112.29.151.195 -j DROP
iptables -I INPUT -s 112.29.151.196 -j DROP
iptables -I INPUT -s 112.29.152.39 -j DROP
iptables -I INPUT -s 112.29.152.62 -j DROP
iptables -I INPUT -s 112.29.196.148 -j DROP
iptables -I INPUT -s 112.29.196.166 -j DROP
iptables -I INPUT -s 112.29.197.60 -j DROP
iptables -I INPUT -s 112.29.199.27 -j DROP
iptables -I INPUT -s 112.29.199.36 -j DROP
iptables -I INPUT -s 112.29.199.61 -j DROP
iptables -I INPUT -s 112.29.207.210 -j DROP
iptables -I INPUT -s 112.29.208.101 -j DROP
iptables -I INPUT -s 112.29.208.11 -j DROP
iptables -I INPUT -s 112.29.208.12 -j DROP
iptables -I INPUT -s 112.29.208.13 -j DROP
iptables -I INPUT -s 112.29.208.14 -j DROP
iptables -I INPUT -s 112.29.208.31 -j DROP
iptables -I INPUT -s 112.29.212.205 -j DROP
iptables -I INPUT -s 112.47.23.216 -j DROP
iptables -I INPUT -s 112.47.23.222 -j DROP
iptables -I INPUT -s 112.47.4.141 -j DROP
iptables -I INPUT -s 112.47.4.202 -j DROP
iptables -I INPUT -s 112.47.4.204 -j DROP
iptables -I INPUT -s 112.47.9.12 -j DROP
iptables -I INPUT -s 112.47.9.126 -j DROP
iptables -I INPUT -s 112.47.9.24 -j DROP
iptables -I INPUT -s 112.47.9.25 -j DROP
iptables -I INPUT -s 112.47.9.30 -j DROP
iptables -I INPUT -s 112.47.9.40 -j DROP
iptables -I INPUT -s 112.53.25.178 -j DROP
iptables -I INPUT -s 112.53.26.102 -j DROP
iptables -I INPUT -s 112.53.26.203 -j DROP
iptables -I INPUT -s 112.53.26.81 -j DROP
iptables -I INPUT -s 112.60.0.231 -j DROP
iptables -I INPUT -s 112.60.0.234 -j DROP
iptables -I INPUT -s 112.60.8.109 -j DROP
iptables -I INPUT -s 112.65.212.43 -j DROP
iptables -I INPUT -s 112.90.149.80 -j DROP
iptables -I INPUT -s 112.90.149.85 -j DROP
iptables -I INPUT -s 112.90.149.87 -j DROP
iptables -I INPUT -s 112.90.83.46 -j DROP
iptables -I INPUT -s 113.105.141.220 -j DROP
iptables -I INPUT -s 113.105.73.144 -j DROP
iptables -I INPUT -s 113.105.73.145 -j DROP
iptables -I INPUT -s 113.107.216.36 -j DROP
iptables -I INPUT -s 113.107.238.24 -j DROP
iptables -I INPUT -s 113.107.238.25 -j DROP
iptables -I INPUT -s 113.137.62.89 -j DROP
iptables -I INPUT -s 113.142.52.139 -j DROP
iptables -I INPUT -s 113.142.52.145 -j DROP
iptables -I INPUT -s 113.142.52.173 -j DROP
iptables -I INPUT -s 113.200.17.153 -j DROP
iptables -I INPUT -s 113.200.90.146 -j DROP
iptables -I INPUT -s 113.200.90.151 -j DROP
iptables -I INPUT -s 113.96.156.141 -j DROP
iptables -I INPUT -s 113.96.156.142 -j DROP
iptables -I INPUT -s 113.96.156.143 -j DROP
iptables -I INPUT -s 113.96.156.144 -j DROP
iptables -I INPUT -s 113.96.156.226 -j DROP
iptables -I INPUT -s 113.96.208.233 -j DROP
iptables -I INPUT -s 113.96.232.76 -j DROP
iptables -I INPUT -s 113.96.232.92 -j DROP
iptables -I INPUT -s 114.106.160.91 -j DROP
iptables -I INPUT -s 115.231.37.204 -j DROP
iptables -I INPUT -s 116.1.237.164 -j DROP
iptables -I INPUT -s 116.128.163.23 -j DROP
iptables -I INPUT -s 116.128.164.37 -j DROP
iptables -I INPUT -s 116.153.4.59 -j DROP
iptables -I INPUT -s 116.211.104.82 -j DROP
iptables -I INPUT -s 116.211.104.83 -j DROP
iptables -I INPUT -s 116.211.185.158 -j DROP
iptables -I INPUT -s 116.211.185.159 -j DROP
iptables -I INPUT -s 116.211.185.195 -j DROP
iptables -I INPUT -s 116.211.185.244 -j DROP
iptables -I INPUT -s 116.211.185.35 -j DROP
iptables -I INPUT -s 116.211.73.32 -j DROP
iptables -I INPUT -s 116.211.73.33 -j DROP
iptables -I INPUT -s 116.55.250.25 -j DROP
iptables -I INPUT -s 117.131.201.35 -j DROP
iptables -I INPUT -s 117.131.201.36 -j DROP
iptables -I INPUT -s 117.144.243.186 -j DROP
iptables -I INPUT -s 117.156.18.17 -j DROP
iptables -I INPUT -s 117.156.18.19 -j DROP
iptables -I INPUT -s 117.156.18.20 -j DROP
iptables -I INPUT -s 117.156.18.22 -j DROP
iptables -I INPUT -s 117.156.18.25 -j DROP
iptables -I INPUT -s 117.156.18.29 -j DROP
iptables -I INPUT -s 117.156.18.32 -j DROP
iptables -I INPUT -s 117.156.18.35 -j DROP
iptables -I INPUT -s 117.156.18.37 -j DROP
iptables -I INPUT -s 117.156.18.50 -j DROP
iptables -I INPUT -s 117.156.18.51 -j DROP
iptables -I INPUT -s 117.156.18.52 -j DROP
iptables -I INPUT -s 117.156.18.53 -j DROP
iptables -I INPUT -s 117.156.18.54 -j DROP
iptables -I INPUT -s 117.156.18.55 -j DROP
iptables -I INPUT -s 117.156.18.57 -j DROP
iptables -I INPUT -s 117.156.18.58 -j DROP
iptables -I INPUT -s 117.156.18.95 -j DROP
iptables -I INPUT -s 117.156.18.96 -j DROP
iptables -I INPUT -s 117.156.18.98 -j DROP
iptables -I INPUT -s 117.169.101.58 -j DROP
iptables -I INPUT -s 117.169.16.26 -j DROP
iptables -I INPUT -s 117.169.71.168 -j DROP
iptables -I INPUT -s 117.169.71.170 -j DROP
iptables -I INPUT -s 117.169.71.230 -j DROP
iptables -I INPUT -s 117.169.97.219 -j DROP
iptables -I INPUT -s 117.169.98.113 -j DROP
iptables -I INPUT -s 117.169.98.114 -j DROP
iptables -I INPUT -s 117.169.98.115 -j DROP
iptables -I INPUT -s 117.169.98.75 -j DROP
iptables -I INPUT -s 117.172.5.20 -j DROP
iptables -I INPUT -s 117.177.223.155 -j DROP
iptables -I INPUT -s 117.177.223.169 -j DROP
iptables -I INPUT -s 117.177.223.212 -j DROP
iptables -I INPUT -s 117.177.223.229 -j DROP
iptables -I INPUT -s 117.184.242.222 -j DROP
iptables -I INPUT -s 117.21.180.23 -j DROP
iptables -I INPUT -s 117.21.180.92 -j DROP
iptables -I INPUT -s 117.41.241.144 -j DROP
iptables -I INPUT -s 117.41.241.167 -j DROP
iptables -I INPUT -s 117.41.241.170 -j DROP
iptables -I INPUT -s 117.41.241.238 -j DROP
iptables -I INPUT -s 117.41.243.19 -j DROP
iptables -I INPUT -s 117.41.243.24 -j DROP
iptables -I INPUT -s 117.41.243.27 -j DROP
iptables -I INPUT -s 117.41.243.29 -j DROP
iptables -I INPUT -s 117.41.243.32 -j DROP
iptables -I INPUT -s 117.41.243.33 -j DROP
iptables -I INPUT -s 117.41.243.36 -j DROP
iptables -I INPUT -s 117.41.243.38 -j DROP
iptables -I INPUT -s 117.41.243.39 -j DROP
iptables -I INPUT -s 117.41.243.45 -j DROP
iptables -I INPUT -s 117.41.243.46 -j DROP
iptables -I INPUT -s 117.41.243.47 -j DROP
iptables -I INPUT -s 118.112.11.100 -j DROP
iptables -I INPUT -s 118.112.11.13 -j DROP
iptables -I INPUT -s 118.112.11.139 -j DROP
iptables -I INPUT -s 118.112.11.14 -j DROP
iptables -I INPUT -s 118.112.11.142 -j DROP
iptables -I INPUT -s 118.112.11.145 -j DROP
iptables -I INPUT -s 118.112.11.158 -j DROP
iptables -I INPUT -s 118.112.11.163 -j DROP
iptables -I INPUT -s 118.112.11.173 -j DROP
iptables -I INPUT -s 118.112.11.18 -j DROP
iptables -I INPUT -s 118.112.22.141 -j DROP
iptables -I INPUT -s 118.112.22.142 -j DROP
iptables -I INPUT -s 118.112.22.143 -j DROP
iptables -I INPUT -s 118.112.22.144 -j DROP
iptables -I INPUT -s 118.112.22.145 -j DROP
iptables -I INPUT -s 118.112.22.202 -j DROP
iptables -I INPUT -s 118.112.22.251 -j DROP
iptables -I INPUT -s 118.112.23.11 -j DROP
iptables -I INPUT -s 118.112.23.16 -j DROP
iptables -I INPUT -s 118.112.23.17 -j DROP
iptables -I INPUT -s 118.112.23.18 -j DROP
iptables -I INPUT -s 118.112.23.95 -j DROP
iptables -I INPUT -s 118.112.24.79 -j DROP
iptables -I INPUT -s 118.112.25.126 -j DROP
iptables -I INPUT -s 118.112.26.209 -j DROP
iptables -I INPUT -s 118.180.26.39 -j DROP
iptables -I INPUT -s 118.180.30.158 -j DROP
iptables -I INPUT -s 118.180.30.159 -j DROP
iptables -I INPUT -s 118.180.30.160 -j DROP
iptables -I INPUT -s 118.180.30.230 -j DROP
iptables -I INPUT -s 118.180.31.100 -j DROP
iptables -I INPUT -s 118.180.31.145 -j DROP
iptables -I INPUT -s 118.180.31.151 -j DROP
iptables -I INPUT -s 118.180.31.152 -j DROP
iptables -I INPUT -s 118.180.31.157 -j DROP
iptables -I INPUT -s 118.180.31.159 -j DROP
iptables -I INPUT -s 118.180.31.165 -j DROP
iptables -I INPUT -s 118.212.137.11 -j DROP
iptables -I INPUT -s 118.212.137.19 -j DROP
iptables -I INPUT -s 118.212.145.162 -j DROP
iptables -I INPUT -s 118.212.226.24 -j DROP
iptables -I INPUT -s 118.212.226.25 -j DROP
iptables -I INPUT -s 118.212.226.27 -j DROP
iptables -I INPUT -s 118.212.226.53 -j DROP
iptables -I INPUT -s 119.147.227.100 -j DROP
iptables -I INPUT -s 119.147.227.103 -j DROP
iptables -I INPUT -s 119.147.227.11 -j DROP
iptables -I INPUT -s 119.147.227.113 -j DROP
iptables -I INPUT -s 119.147.227.12 -j DROP
iptables -I INPUT -s 119.147.227.13 -j DROP
iptables -I INPUT -s 119.147.227.14 -j DROP
iptables -I INPUT -s 119.147.227.15 -j DROP
iptables -I INPUT -s 119.147.227.16 -j DROP
iptables -I INPUT -s 119.147.227.27 -j DROP
iptables -I INPUT -s 119.147.227.35 -j DROP
iptables -I INPUT -s 119.147.33.11 -j DROP
iptables -I INPUT -s 119.147.33.123 -j DROP
iptables -I INPUT -s 119.147.33.25 -j DROP
iptables -I INPUT -s 119.147.33.26 -j DROP
iptables -I INPUT -s 119.147.33.36 -j DROP
iptables -I INPUT -s 119.147.33.38 -j DROP
iptables -I INPUT -s 119.147.33.39 -j DROP
iptables -I INPUT -s 119.147.33.49 -j DROP
iptables -I INPUT -s 119.147.33.87 -j DROP
iptables -I INPUT -s 119.147.33.90 -j DROP
iptables -I INPUT -s 119.147.83.11 -j DROP
iptables -I INPUT -s 119.147.83.73 -j DROP
iptables -I INPUT -s 119.167.134.109 -j DROP
iptables -I INPUT -s 119.167.134.123 -j DROP
iptables -I INPUT -s 119.167.141.100 -j DROP
iptables -I INPUT -s 119.167.216.174 -j DROP
iptables -I INPUT -s 119.167.217.123 -j DROP
iptables -I INPUT -s 119.167.217.57 -j DROP
iptables -I INPUT -s 119.167.217.80 -j DROP
iptables -I INPUT -s 119.188.206.20 -j DROP
iptables -I INPUT -s 119.188.47.164 -j DROP
iptables -I INPUT -s 119.249.49.11 -j DROP
iptables -I INPUT -s 119.249.49.12 -j DROP
iptables -I INPUT -s 119.249.49.13 -j DROP
iptables -I INPUT -s 119.249.49.14 -j DROP
iptables -I INPUT -s 119.249.49.15 -j DROP
iptables -I INPUT -s 119.28.164.141 -j DROP
iptables -I INPUT -s 119.28.164.202 -j DROP
iptables -I INPUT -s 119.28.164.203 -j DROP
iptables -I INPUT -s 119.28.164.219 -j DROP
iptables -I INPUT -s 119.28.164.220 -j DROP
iptables -I INPUT -s 119.28.164.222 -j DROP
iptables -I INPUT -s 119.28.164.223 -j DROP
iptables -I INPUT -s 119.36.226.212 -j DROP
iptables -I INPUT -s 119.36.226.238 -j DROP
iptables -I INPUT -s 119.39.120.11 -j DROP
iptables -I INPUT -s 119.39.120.12 -j DROP
iptables -I INPUT -s 119.39.120.125 -j DROP
iptables -I INPUT -s 119.39.120.15 -j DROP
iptables -I INPUT -s 119.84.106.17 -j DROP
iptables -I INPUT -s 119.84.68.160 -j DROP
iptables -I INPUT -s 119.84.99.178 -j DROP
iptables -I INPUT -s 120.192.69.161 -j DROP
iptables -I INPUT -s 120.192.69.222 -j DROP
iptables -I INPUT -s 120.198.199.176 -j DROP
iptables -I INPUT -s 120.198.199.212 -j DROP
iptables -I INPUT -s 120.198.199.213 -j DROP
iptables -I INPUT -s 120.198.235.248 -j DROP
iptables -I INPUT -s 120.204.205.142 -j DROP
iptables -I INPUT -s 120.204.205.154 -j DROP
iptables -I INPUT -s 120.204.205.155 -j DROP
iptables -I INPUT -s 120.204.205.188 -j DROP
iptables -I INPUT -s 120.204.205.200 -j DROP
iptables -I INPUT -s 120.204.205.210 -j DROP
iptables -I INPUT -s 120.209.135.150 -j DROP
iptables -I INPUT -s 120.209.135.194 -j DROP
iptables -I INPUT -s 120.210.222.14 -j DROP
iptables -I INPUT -s 120.210.222.150 -j DROP
iptables -I INPUT -s 120.210.222.20 -j DROP
iptables -I INPUT -s 120.220.188.141 -j DROP
iptables -I INPUT -s 120.220.188.16 -j DROP
iptables -I INPUT -s 120.220.188.160 -j DROP
iptables -I INPUT -s 120.220.188.80 -j DROP
iptables -I INPUT -s 120.221.14.36 -j DROP
iptables -I INPUT -s 120.221.14.47 -j DROP
iptables -I INPUT -s 120.221.143.104 -j DROP
iptables -I INPUT -s 120.221.143.61 -j DROP
iptables -I INPUT -s 120.221.143.80 -j DROP
iptables -I INPUT -s 120.221.143.90 -j DROP
iptables -I INPUT -s 120.221.218.144 -j DROP
iptables -I INPUT -s 120.221.218.145 -j DROP
iptables -I INPUT -s 120.221.218.164 -j DROP
iptables -I INPUT -s 120.221.218.233 -j DROP
iptables -I INPUT -s 120.221.218.241 -j DROP
iptables -I INPUT -s 120.221.227.193 -j DROP
iptables -I INPUT -s 120.221.227.235 -j DROP
iptables -I INPUT -s 120.221.31.36 -j DROP
iptables -I INPUT -s 120.221.97.123 -j DROP
iptables -I INPUT -s 120.221.97.188 -j DROP
iptables -I INPUT -s 120.221.97.204 -j DROP
iptables -I INPUT -s 120.221.97.240 -j DROP
iptables -I INPUT -s 120.221.97.253 -j DROP
iptables -I INPUT -s 120.221.97.78 -j DROP
iptables -I INPUT -s 120.232.196.221 -j DROP
iptables -I INPUT -s 120.233.38.109 -j DROP
iptables -I INPUT -s 120.233.38.11 -j DROP
iptables -I INPUT -s 120.233.38.42 -j DROP
iptables -I INPUT -s 120.233.38.43 -j DROP
iptables -I INPUT -s 120.233.38.44 -j DROP
iptables -I INPUT -s 120.233.38.76 -j DROP
iptables -I INPUT -s 120.241.139.207 -j DROP
iptables -I INPUT -s 120.241.186.33 -j DROP
iptables -I INPUT -s 120.241.186.36 -j DROP
iptables -I INPUT -s 120.241.186.38 -j DROP
iptables -I INPUT -s 120.241.186.40 -j DROP
iptables -I INPUT -s 120.241.186.52 -j DROP
iptables -I INPUT -s 120.241.186.99 -j DROP
iptables -I INPUT -s 120.241.190.163 -j DROP
iptables -I INPUT -s 120.241.30.143 -j DROP
iptables -I INPUT -s 120.241.30.144 -j DROP
iptables -I INPUT -s 120.241.30.145 -j DROP
iptables -I INPUT -s 120.241.30.148 -j DROP
iptables -I INPUT -s 120.241.30.174 -j DROP
iptables -I INPUT -s 120.241.30.188 -j DROP
iptables -I INPUT -s 120.241.30.195 -j DROP
iptables -I INPUT -s 120.241.30.219 -j DROP
iptables -I INPUT -s 120.33.50.100 -j DROP
iptables -I INPUT -s 120.33.50.50 -j DROP
iptables -I INPUT -s 120.33.50.51 -j DROP
iptables -I INPUT -s 120.33.50.52 -j DROP
iptables -I INPUT -s 120.37.140.74 -j DROP
iptables -I INPUT -s 120.41.44.152 -j DROP
iptables -I INPUT -s 120.41.44.170 -j DROP
iptables -I INPUT -s 120.41.44.31 -j DROP
iptables -I INPUT -s 120.41.44.32 -j DROP
iptables -I INPUT -s 120.41.44.33 -j DROP
iptables -I INPUT -s 120.41.44.34 -j DROP
iptables -I INPUT -s 120.41.44.35 -j DROP
iptables -I INPUT -s 121.14.88.11 -j DROP
iptables -I INPUT -s 121.14.88.12 -j DROP
iptables -I INPUT -s 121.14.88.13 -j DROP
iptables -I INPUT -s 121.14.88.14 -j DROP
iptables -I INPUT -s 121.14.88.15 -j DROP
iptables -I INPUT -s 121.14.88.16 -j DROP
iptables -I INPUT -s 121.14.88.17 -j DROP
iptables -I INPUT -s 121.14.88.18 -j DROP
iptables -I INPUT -s 121.14.88.20 -j DROP
iptables -I INPUT -s 121.14.88.21 -j DROP
iptables -I INPUT -s 121.14.88.22 -j DROP
iptables -I INPUT -s 121.14.88.23 -j DROP
iptables -I INPUT -s 121.14.88.24 -j DROP
iptables -I INPUT -s 121.14.88.25 -j DROP
iptables -I INPUT -s 121.14.88.26 -j DROP
iptables -I INPUT -s 121.14.88.27 -j DROP
iptables -I INPUT -s 121.14.88.28 -j DROP
iptables -I INPUT -s 121.14.88.29 -j DROP
iptables -I INPUT -s 121.14.88.30 -j DROP
iptables -I INPUT -s 121.14.88.31 -j DROP
iptables -I INPUT -s 121.14.88.32 -j DROP
iptables -I INPUT -s 121.14.88.33 -j DROP
iptables -I INPUT -s 121.14.88.34 -j DROP
iptables -I INPUT -s 121.14.88.35 -j DROP
iptables -I INPUT -s 121.14.88.36 -j DROP
iptables -I INPUT -s 121.14.88.37 -j DROP
iptables -I INPUT -s 121.14.88.38 -j DROP
iptables -I INPUT -s 121.14.88.39 -j DROP
iptables -I INPUT -s 121.14.88.40 -j DROP
iptables -I INPUT -s 121.14.88.41 -j DROP
iptables -I INPUT -s 121.14.88.42 -j DROP
iptables -I INPUT -s 121.14.88.43 -j DROP
iptables -I INPUT -s 121.14.88.44 -j DROP
iptables -I INPUT -s 121.14.88.45 -j DROP
iptables -I INPUT -s 121.14.88.46 -j DROP
iptables -I INPUT -s 121.14.88.47 -j DROP
iptables -I INPUT -s 121.14.88.48 -j DROP
iptables -I INPUT -s 121.14.88.49 -j DROP
iptables -I INPUT -s 121.14.88.50 -j DROP
iptables -I INPUT -s 121.14.88.51 -j DROP
iptables -I INPUT -s 121.14.88.52 -j DROP
iptables -I INPUT -s 121.14.88.53 -j DROP
iptables -I INPUT -s 121.14.88.54 -j DROP
iptables -I INPUT -s 121.14.88.55 -j DROP
iptables -I INPUT -s 121.14.88.56 -j DROP
iptables -I INPUT -s 121.14.88.57 -j DROP
iptables -I INPUT -s 121.29.54.152 -j DROP
iptables -I INPUT -s 121.29.54.156 -j DROP
iptables -I INPUT -s 121.29.54.171 -j DROP
iptables -I INPUT -s 121.29.54.222 -j DROP
iptables -I INPUT -s 121.31.22.152 -j DROP
iptables -I INPUT -s 121.51.118.37 -j DROP
iptables -I INPUT -s 121.51.131.211 -j DROP
iptables -I INPUT -s 121.51.141.78 -j DROP
iptables -I INPUT -s 121.51.142.189 -j DROP
iptables -I INPUT -s 121.51.142.27 -j DROP
iptables -I INPUT -s 121.51.175.100 -j DROP
iptables -I INPUT -s 121.51.175.118 -j DROP
iptables -I INPUT -s 121.51.175.56 -j DROP
iptables -I INPUT -s 121.51.175.70 -j DROP
iptables -I INPUT -s 121.51.175.81 -j DROP
iptables -I INPUT -s 121.51.18.62 -j DROP
iptables -I INPUT -s 121.51.23.243 -j DROP
iptables -I INPUT -s 121.51.40.100 -j DROP
iptables -I INPUT -s 121.51.93.19 -j DROP
iptables -I INPUT -s 122.225.36.51 -j DROP
iptables -I INPUT -s 122.228.0.139 -j DROP
iptables -I INPUT -s 122.228.0.141 -j DROP
iptables -I INPUT -s 122.228.56.150 -j DROP
iptables -I INPUT -s 122.228.56.151 -j DROP
iptables -I INPUT -s 122.228.56.153 -j DROP
iptables -I INPUT -s 122.228.72.155 -j DROP
iptables -I INPUT -s 122.228.72.183 -j DROP
iptables -I INPUT -s 123.125.110.142 -j DROP
iptables -I INPUT -s 123.125.110.146 -j DROP
iptables -I INPUT -s 123.125.110.15 -j DROP
iptables -I INPUT -s 123.125.110.16 -j DROP
iptables -I INPUT -s 123.125.110.17 -j DROP
iptables -I INPUT -s 123.125.110.18 -j DROP
iptables -I INPUT -s 123.125.110.249 -j DROP
iptables -I INPUT -s 123.125.110.27 -j DROP
iptables -I INPUT -s 123.125.46.166 -j DROP
iptables -I INPUT -s 123.125.46.36 -j DROP
iptables -I INPUT -s 123.125.9.11 -j DROP
iptables -I INPUT -s 123.125.9.12 -j DROP
iptables -I INPUT -s 123.125.9.13 -j DROP
iptables -I INPUT -s 123.125.9.15 -j DROP
iptables -I INPUT -s 123.125.9.79 -j DROP
iptables -I INPUT -s 123.125.9.91 -j DROP
iptables -I INPUT -s 123.125.9.94 -j DROP
iptables -I INPUT -s 123.126.121.160 -j DROP
iptables -I INPUT -s 123.129.203.155 -j DROP
iptables -I INPUT -s 123.129.203.156 -j DROP
iptables -I INPUT -s 123.138.162.112 -j DROP
iptables -I INPUT -s 123.138.162.119 -j DROP
iptables -I INPUT -s 123.138.162.120 -j DROP
iptables -I INPUT -s 123.138.58.12 -j DROP
iptables -I INPUT -s 123.138.58.13 -j DROP
iptables -I INPUT -s 123.138.58.60 -j DROP
iptables -I INPUT -s 123.150.174.156 -j DROP
iptables -I INPUT -s 123.150.174.165 -j DROP
iptables -I INPUT -s 123.150.174.225 -j DROP
iptables -I INPUT -s 123.150.174.227 -j DROP
iptables -I INPUT -s 123.150.76.208 -j DROP
iptables -I INPUT -s 123.151.137.122 -j DROP
iptables -I INPUT -s 123.151.139.116 -j DROP
iptables -I INPUT -s 123.151.139.117 -j DROP
iptables -I INPUT -s 123.151.15.197 -j DROP
iptables -I INPUT -s 123.151.152.51 -j DROP
iptables -I INPUT -s 123.151.152.66 -j DROP
iptables -I INPUT -s 123.151.179.175 -j DROP
iptables -I INPUT -s 123.151.190.175 -j DROP
iptables -I INPUT -s 123.151.190.176 -j DROP
iptables -I INPUT -s 123.151.190.177 -j DROP
iptables -I INPUT -s 123.151.190.178 -j DROP
iptables -I INPUT -s 123.151.190.217 -j DROP
iptables -I INPUT -s 123.151.72.63 -j DROP
iptables -I INPUT -s 123.151.72.85 -j DROP
iptables -I INPUT -s 123.155.153.148 -j DROP
iptables -I INPUT -s 123.161.59.60 -j DROP
iptables -I INPUT -s 123.246.132.25 -j DROP
iptables -I INPUT -s 123.246.132.64 -j DROP
iptables -I INPUT -s 123.6.0.12 -j DROP
iptables -I INPUT -s 123.6.0.13 -j DROP
iptables -I INPUT -s 123.6.0.14 -j DROP
iptables -I INPUT -s 123.6.0.15 -j DROP
iptables -I INPUT -s 123.6.0.60 -j DROP
iptables -I INPUT -s 123.6.1.107 -j DROP
iptables -I INPUT -s 123.6.1.13 -j DROP
iptables -I INPUT -s 123.6.1.22 -j DROP
iptables -I INPUT -s 123.6.1.26 -j DROP
iptables -I INPUT -s 123.6.1.27 -j DROP
iptables -I INPUT -s 123.6.1.28 -j DROP
iptables -I INPUT -s 123.6.1.29 -j DROP
iptables -I INPUT -s 123.6.1.30 -j DROP
iptables -I INPUT -s 123.6.1.31 -j DROP
iptables -I INPUT -s 123.6.1.36 -j DROP
iptables -I INPUT -s 123.6.1.37 -j DROP
iptables -I INPUT -s 123.6.1.38 -j DROP
iptables -I INPUT -s 123.6.1.39 -j DROP
iptables -I INPUT -s 123.6.1.40 -j DROP
iptables -I INPUT -s 123.6.1.41 -j DROP
iptables -I INPUT -s 123.6.1.42 -j DROP
iptables -I INPUT -s 123.6.1.43 -j DROP
iptables -I INPUT -s 123.6.1.59 -j DROP
iptables -I INPUT -s 123.6.1.62 -j DROP
iptables -I INPUT -s 123.6.1.66 -j DROP
iptables -I INPUT -s 123.6.1.86 -j DROP
iptables -I INPUT -s 123.6.1.91 -j DROP
iptables -I INPUT -s 123.6.2.170 -j DROP
iptables -I INPUT -s 123.6.2.45 -j DROP
iptables -I INPUT -s 123.6.4.101 -j DROP
iptables -I INPUT -s 123.6.4.11 -j DROP
iptables -I INPUT -s 123.6.4.12 -j DROP
iptables -I INPUT -s 123.6.4.123 -j DROP
iptables -I INPUT -s 123.6.4.13 -j DROP
iptables -I INPUT -s 123.6.4.14 -j DROP
iptables -I INPUT -s 123.6.4.15 -j DROP
iptables -I INPUT -s 123.6.4.16 -j DROP
iptables -I INPUT -s 123.6.4.235 -j DROP
iptables -I INPUT -s 123.6.4.73 -j DROP
iptables -I INPUT -s 123.6.4.88 -j DROP
iptables -I INPUT -s 123.6.6.119 -j DROP
iptables -I INPUT -s 123.6.6.19 -j DROP
iptables -I INPUT -s 123.6.6.20 -j DROP
iptables -I INPUT -s 123.6.6.22 -j DROP
iptables -I INPUT -s 123.6.6.42 -j DROP
iptables -I INPUT -s 124.14.21.20 -j DROP
iptables -I INPUT -s 124.225.105.103 -j DROP
iptables -I INPUT -s 124.225.105.120 -j DROP
iptables -I INPUT -s 124.225.105.13 -j DROP
iptables -I INPUT -s 124.225.105.14 -j DROP
iptables -I INPUT -s 124.225.105.32 -j DROP
iptables -I INPUT -s 124.225.105.72 -j DROP
iptables -I INPUT -s 124.225.105.95 -j DROP
iptables -I INPUT -s 124.226.64.23 -j DROP
iptables -I INPUT -s 124.226.64.24 -j DROP
iptables -I INPUT -s 124.226.64.27 -j DROP
iptables -I INPUT -s 124.227.184.145 -j DROP
iptables -I INPUT -s 124.227.184.159 -j DROP
iptables -I INPUT -s 124.227.184.37 -j DROP
iptables -I INPUT -s 124.227.184.69 -j DROP
iptables -I INPUT -s 124.227.184.71 -j DROP
iptables -I INPUT -s 124.236.32.104 -j DROP
iptables -I INPUT -s 124.236.35.108 -j DROP
iptables -I INPUT -s 124.236.35.11 -j DROP
iptables -I INPUT -s 124.236.35.15 -j DROP
iptables -I INPUT -s 124.95.173.114 -j DROP
iptables -I INPUT -s 124.95.173.180 -j DROP
iptables -I INPUT -s 125.211.204.22 -j DROP
iptables -I INPUT -s 125.211.204.23 -j DROP
iptables -I INPUT -s 125.39.171.12 -j DROP
iptables -I INPUT -s 125.39.171.14 -j DROP
iptables -I INPUT -s 125.39.171.15 -j DROP
iptables -I INPUT -s 125.39.171.16 -j DROP
iptables -I INPUT -s 125.39.171.19 -j DROP
iptables -I INPUT -s 125.39.171.21 -j DROP
iptables -I INPUT -s 125.39.171.25 -j DROP
iptables -I INPUT -s 125.39.171.26 -j DROP
iptables -I INPUT -s 125.39.171.30 -j DROP
iptables -I INPUT -s 125.39.171.33 -j DROP
iptables -I INPUT -s 125.39.171.35 -j DROP
iptables -I INPUT -s 125.39.171.37 -j DROP
iptables -I INPUT -s 125.39.171.38 -j DROP
iptables -I INPUT -s 125.39.171.41 -j DROP
iptables -I INPUT -s 125.39.171.42 -j DROP
iptables -I INPUT -s 125.39.171.43 -j DROP
iptables -I INPUT -s 125.39.213.25 -j DROP
iptables -I INPUT -s 125.39.213.30 -j DROP
iptables -I INPUT -s 125.39.213.63 -j DROP
iptables -I INPUT -s 125.39.247.214 -j DROP
iptables -I INPUT -s 125.39.6.16 -j DROP
iptables -I INPUT -s 125.39.6.17 -j DROP
iptables -I INPUT -s 125.39.6.234 -j DROP
iptables -I INPUT -s 125.74.5.218 -j DROP
iptables -I INPUT -s 125.74.5.232 -j DROP
iptables -I INPUT -s 125.78.246.86 -j DROP
iptables -I INPUT -s 125.78.246.87 -j DROP
iptables -I INPUT -s 125.78.246.89 -j DROP
iptables -I INPUT -s 125.78.246.90 -j DROP
iptables -I INPUT -s 125.78.252.143 -j DROP
iptables -I INPUT -s 125.78.252.144 -j DROP
iptables -I INPUT -s 125.78.252.145 -j DROP
iptables -I INPUT -s 125.78.252.147 -j DROP
iptables -I INPUT -s 125.78.252.149 -j DROP
iptables -I INPUT -s 125.78.252.150 -j DROP
iptables -I INPUT -s 125.78.252.151 -j DROP
iptables -I INPUT -s 125.78.252.152 -j DROP
iptables -I INPUT -s 125.78.252.153 -j DROP
iptables -I INPUT -s 125.78.252.154 -j DROP
iptables -I INPUT -s 125.78.252.155 -j DROP
iptables -I INPUT -s 125.78.252.156 -j DROP
iptables -I INPUT -s 125.78.252.157 -j DROP
iptables -I INPUT -s 125.78.252.158 -j DROP
iptables -I INPUT -s 125.78.252.159 -j DROP
iptables -I INPUT -s 125.78.252.160 -j DROP
iptables -I INPUT -s 125.78.252.162 -j DROP
iptables -I INPUT -s 125.78.252.163 -j DROP
iptables -I INPUT -s 125.78.252.164 -j DROP
iptables -I INPUT -s 125.78.252.165 -j DROP
iptables -I INPUT -s 125.78.252.166 -j DROP
iptables -I INPUT -s 125.78.252.167 -j DROP
iptables -I INPUT -s 125.78.252.168 -j DROP
iptables -I INPUT -s 125.78.252.169 -j DROP
iptables -I INPUT -s 125.78.252.172 -j DROP
iptables -I INPUT -s 125.78.252.181 -j DROP
iptables -I INPUT -s 125.78.252.37 -j DROP
iptables -I INPUT -s 125.94.49.123 -j DROP
iptables -I INPUT -s 125.94.49.21 -j DROP
iptables -I INPUT -s 125.94.49.68 -j DROP
iptables -I INPUT -s 128.1.102.21 -j DROP
iptables -I INPUT -s 139.215.137.11 -j DROP
iptables -I INPUT -s 139.215.137.12 -j DROP
iptables -I INPUT -s 139.215.137.13 -j DROP
iptables -I INPUT -s 139.215.137.14 -j DROP
iptables -I INPUT -s 139.215.137.15 -j DROP
iptables -I INPUT -s 139.215.137.16 -j DROP
iptables -I INPUT -s 139.215.137.17 -j DROP
iptables -I INPUT -s 139.215.137.30 -j DROP
iptables -I INPUT -s 139.215.137.48 -j DROP
iptables -I INPUT -s 139.215.137.49 -j DROP
iptables -I INPUT -s 139.215.137.50 -j DROP
iptables -I INPUT -s 139.215.137.51 -j DROP
iptables -I INPUT -s 139.215.137.52 -j DROP
iptables -I INPUT -s 139.215.137.53 -j DROP
iptables -I INPUT -s 139.215.137.54 -j DROP
iptables -I INPUT -s 139.215.137.55 -j DROP
iptables -I INPUT -s 139.215.137.57 -j DROP
iptables -I INPUT -s 139.215.137.58 -j DROP
iptables -I INPUT -s 139.215.203.166 -j DROP
iptables -I INPUT -s 14.17.32.165 -j DROP
iptables -I INPUT -s 14.17.32.188 -j DROP
iptables -I INPUT -s 14.17.41.190 -j DROP
iptables -I INPUT -s 14.17.41.191 -j DROP
iptables -I INPUT -s 14.17.41.192 -j DROP
iptables -I INPUT -s 14.17.41.193 -j DROP
iptables -I INPUT -s 14.17.41.194 -j DROP
iptables -I INPUT -s 14.17.41.195 -j DROP
iptables -I INPUT -s 14.17.43.48 -j DROP
iptables -I INPUT -s 14.17.43.49 -j DROP
iptables -I INPUT -s 14.18.175.103 -j DROP
iptables -I INPUT -s 14.18.175.107 -j DROP
iptables -I INPUT -s 14.18.175.119 -j DROP
iptables -I INPUT -s 14.18.175.125 -j DROP
iptables -I INPUT -s 14.18.175.205 -j DROP
iptables -I INPUT -s 14.18.175.208 -j DROP
iptables -I INPUT -s 14.18.175.213 -j DROP
iptables -I INPUT -s 14.18.175.215 -j DROP
iptables -I INPUT -s 14.18.175.218 -j DROP
iptables -I INPUT -s 14.18.175.219 -j DROP
iptables -I INPUT -s 14.18.175.220 -j DROP
iptables -I INPUT -s 14.18.175.221 -j DROP
iptables -I INPUT -s 14.18.175.42 -j DROP
iptables -I INPUT -s 14.18.245.161 -j DROP
iptables -I INPUT -s 14.18.245.252 -j DROP
iptables -I INPUT -s 14.215.166.152 -j DROP
iptables -I INPUT -s 14.215.166.161 -j DROP
iptables -I INPUT -s 14.215.166.243 -j DROP
iptables -I INPUT -s 14.215.8.11 -j DROP
iptables -I INPUT -s 14.215.8.19 -j DROP
iptables -I INPUT -s 14.215.85.124 -j DROP
iptables -I INPUT -s 14.215.85.59 -j DROP
iptables -I INPUT -s 14.215.85.70 -j DROP
iptables -I INPUT -s 14.22.33.35 -j DROP
iptables -I INPUT -s 14.22.5.209 -j DROP
iptables -I INPUT -s 14.22.5.226 -j DROP
iptables -I INPUT -s 14.22.5.242 -j DROP
iptables -I INPUT -s 14.22.6.114 -j DROP
iptables -I INPUT -s 14.22.7.151 -j DROP
iptables -I INPUT -s 14.22.7.156 -j DROP
iptables -I INPUT -s 14.22.7.227 -j DROP
iptables -I INPUT -s 14.29.104.36 -j DROP
iptables -I INPUT -s 140.206.161.92 -j DROP
iptables -I INPUT -s 140.207.123.187 -j DROP
iptables -I INPUT -s 140.207.234.19 -j DROP
iptables -I INPUT -s 140.207.234.20 -j DROP
iptables -I INPUT -s 140.207.234.21 -j DROP
iptables -I INPUT -s 140.207.234.23 -j DROP
iptables -I INPUT -s 140.207.234.25 -j DROP
iptables -I INPUT -s 140.207.234.26 -j DROP
iptables -I INPUT -s 140.207.234.35 -j DROP
iptables -I INPUT -s 140.207.234.36 -j DROP
iptables -I INPUT -s 140.207.234.38 -j DROP
iptables -I INPUT -s 140.207.234.39 -j DROP
iptables -I INPUT -s 140.207.234.40 -j DROP
iptables -I INPUT -s 140.207.234.41 -j DROP
iptables -I INPUT -s 140.207.234.46 -j DROP
iptables -I INPUT -s 140.207.234.47 -j DROP
iptables -I INPUT -s 140.249.243.144 -j DROP
iptables -I INPUT -s 140.249.243.218 -j DROP
iptables -I INPUT -s 140.249.243.221 -j DROP
iptables -I INPUT -s 140.249.247.232 -j DROP
iptables -I INPUT -s 140.249.247.238 -j DROP
iptables -I INPUT -s 153.3.167.18 -j DROP
iptables -I INPUT -s 153.3.222.101 -j DROP
iptables -I INPUT -s 153.3.222.119 -j DROP
iptables -I INPUT -s 153.37.238.242 -j DROP
iptables -I INPUT -s 157.0.149.11 -j DROP
iptables -I INPUT -s 157.0.149.12 -j DROP
iptables -I INPUT -s 157.0.149.13 -j DROP
iptables -I INPUT -s 157.0.149.16 -j DROP
iptables -I INPUT -s 157.255.173.228 -j DROP
iptables -I INPUT -s 157.255.245.22 -j DROP
iptables -I INPUT -s 157.255.245.247 -j DROP
iptables -I INPUT -s 157.255.245.27 -j DROP
iptables -I INPUT -s 157.255.245.29 -j DROP
iptables -I INPUT -s 163.177.71.192 -j DROP
iptables -I INPUT -s 163.177.89.173 -j DROP
iptables -I INPUT -s 163.177.90.103 -j DROP
iptables -I INPUT -s 175.6.13.146 -j DROP
iptables -I INPUT -s 175.6.13.148 -j DROP
iptables -I INPUT -s 175.6.13.149 -j DROP
iptables -I INPUT -s 175.6.13.151 -j DROP
iptables -I INPUT -s 175.6.13.157 -j DROP
iptables -I INPUT -s 175.6.13.166 -j DROP
iptables -I INPUT -s 175.6.13.168 -j DROP
iptables -I INPUT -s 175.6.13.169 -j DROP
iptables -I INPUT -s 175.6.13.171 -j DROP
iptables -I INPUT -s 175.6.13.174 -j DROP
iptables -I INPUT -s 175.6.13.176 -j DROP
iptables -I INPUT -s 175.6.13.177 -j DROP
iptables -I INPUT -s 175.6.13.180 -j DROP
iptables -I INPUT -s 175.6.13.187 -j DROP
iptables -I INPUT -s 175.6.232.218 -j DROP
iptables -I INPUT -s 175.6.26.166 -j DROP
iptables -I INPUT -s 175.6.93.118 -j DROP
iptables -I INPUT -s 175.6.93.151 -j DROP
iptables -I INPUT -s 175.6.93.153 -j DROP
iptables -I INPUT -s 175.6.93.165 -j DROP
iptables -I INPUT -s 175.6.93.169 -j DROP
iptables -I INPUT -s 175.6.93.175 -j DROP
iptables -I INPUT -s 175.6.93.31 -j DROP
iptables -I INPUT -s 175.6.93.39 -j DROP
iptables -I INPUT -s 175.6.93.41 -j DROP
iptables -I INPUT -s 175.6.93.42 -j DROP
iptables -I INPUT -s 175.6.93.46 -j DROP
iptables -I INPUT -s 175.6.93.48 -j DROP
iptables -I INPUT -s 175.6.93.49 -j DROP
iptables -I INPUT -s 175.6.93.51 -j DROP
iptables -I INPUT -s 175.6.93.81 -j DROP
iptables -I INPUT -s 175.6.93.85 -j DROP
iptables -I INPUT -s 175.6.93.89 -j DROP
iptables -I INPUT -s 175.6.93.90 -j DROP
iptables -I INPUT -s 175.6.93.92 -j DROP
iptables -I INPUT -s 175.6.93.95 -j DROP
iptables -I INPUT -s 180.101.153.103 -j DROP
iptables -I INPUT -s 180.101.153.109 -j DROP
iptables -I INPUT -s 180.101.153.12 -j DROP
iptables -I INPUT -s 180.101.153.124 -j DROP
iptables -I INPUT -s 180.101.153.13 -j DROP
iptables -I INPUT -s 180.101.153.33 -j DROP
iptables -I INPUT -s 180.101.217.147 -j DROP
iptables -I INPUT -s 180.101.217.148 -j DROP
iptables -I INPUT -s 180.101.217.158 -j DROP
iptables -I INPUT -s 180.101.217.159 -j DROP
iptables -I INPUT -s 180.101.217.166 -j DROP
iptables -I INPUT -s 180.101.217.168 -j DROP
iptables -I INPUT -s 180.101.217.20 -j DROP
iptables -I INPUT -s 180.153.105.147 -j DROP
iptables -I INPUT -s 180.153.105.152 -j DROP
iptables -I INPUT -s 180.153.105.153 -j DROP
iptables -I INPUT -s 180.153.105.154 -j DROP
iptables -I INPUT -s 180.153.105.155 -j DROP
iptables -I INPUT -s 180.153.105.156 -j DROP
iptables -I INPUT -s 180.153.105.157 -j DROP
iptables -I INPUT -s 180.153.105.159 -j DROP
iptables -I INPUT -s 180.153.105.161 -j DROP
iptables -I INPUT -s 180.153.105.162 -j DROP
iptables -I INPUT -s 180.153.105.168 -j DROP
iptables -I INPUT -s 180.153.105.173 -j DROP
iptables -I INPUT -s 180.153.105.185 -j DROP
iptables -I INPUT -s 180.153.105.194 -j DROP
iptables -I INPUT -s 180.153.105.195 -j DROP
iptables -I INPUT -s 180.153.105.213 -j DROP
iptables -I INPUT -s 180.153.105.227 -j DROP
iptables -I INPUT -s 180.153.105.248 -j DROP
iptables -I INPUT -s 180.153.93.106 -j DROP
iptables -I INPUT -s 180.153.93.22 -j DROP
iptables -I INPUT -s 180.153.93.29 -j DROP
iptables -I INPUT -s 180.153.93.30 -j DROP
iptables -I INPUT -s 180.153.93.33 -j DROP
iptables -I INPUT -s 180.153.93.36 -j DROP
iptables -I INPUT -s 180.163.21.41 -j DROP
iptables -I INPUT -s 180.163.25.182 -j DROP
iptables -I INPUT -s 180.96.0.13 -j DROP
iptables -I INPUT -s 180.96.30.15 -j DROP
iptables -I INPUT -s 180.96.30.18 -j DROP
iptables -I INPUT -s 180.97.10.109 -j DROP
iptables -I INPUT -s 180.97.10.110 -j DROP
iptables -I INPUT -s 180.97.10.111 -j DROP
iptables -I INPUT -s 180.97.10.112 -j DROP
iptables -I INPUT -s 180.97.10.119 -j DROP
iptables -I INPUT -s 180.97.10.120 -j DROP
iptables -I INPUT -s 180.97.10.121 -j DROP
iptables -I INPUT -s 180.97.10.14 -j DROP
iptables -I INPUT -s 180.97.146.141 -j DROP
iptables -I INPUT -s 180.97.146.142 -j DROP
iptables -I INPUT -s 180.97.146.143 -j DROP
iptables -I INPUT -s 180.97.146.144 -j DROP
iptables -I INPUT -s 180.97.146.145 -j DROP
iptables -I INPUT -s 180.97.146.237 -j DROP
iptables -I INPUT -s 182.107.81.19 -j DROP
iptables -I INPUT -s 182.107.81.20 -j DROP
iptables -I INPUT -s 182.107.81.22 -j DROP
iptables -I INPUT -s 182.107.81.23 -j DROP
iptables -I INPUT -s 182.107.81.24 -j DROP
iptables -I INPUT -s 182.107.81.25 -j DROP
iptables -I INPUT -s 182.107.81.26 -j DROP
iptables -I INPUT -s 182.107.81.27 -j DROP
iptables -I INPUT -s 182.107.81.29 -j DROP
iptables -I INPUT -s 182.107.81.30 -j DROP
iptables -I INPUT -s 182.107.81.71 -j DROP
iptables -I INPUT -s 182.118.124.168 -j DROP
iptables -I INPUT -s 182.118.124.204 -j DROP
iptables -I INPUT -s 182.118.124.205 -j DROP
iptables -I INPUT -s 182.118.63.179 -j DROP
iptables -I INPUT -s 182.131.30.23 -j DROP
iptables -I INPUT -s 182.140.167.16 -j DROP
iptables -I INPUT -s 182.140.174.174 -j DROP
iptables -I INPUT -s 182.140.174.175 -j DROP
iptables -I INPUT -s 182.140.185.140 -j DROP
iptables -I INPUT -s 182.140.185.185 -j DROP
iptables -I INPUT -s 182.140.217.36 -j DROP
iptables -I INPUT -s 182.150.10.154 -j DROP
iptables -I INPUT -s 182.150.10.157 -j DROP
iptables -I INPUT -s 182.150.10.158 -j DROP
iptables -I INPUT -s 182.150.10.159 -j DROP
iptables -I INPUT -s 182.150.10.160 -j DROP
iptables -I INPUT -s 182.150.10.165 -j DROP
iptables -I INPUT -s 182.150.10.166 -j DROP
iptables -I INPUT -s 182.150.10.167 -j DROP
iptables -I INPUT -s 182.150.10.168 -j DROP
iptables -I INPUT -s 182.150.10.169 -j DROP
iptables -I INPUT -s 182.150.10.170 -j DROP
iptables -I INPUT -s 182.150.10.171 -j DROP
iptables -I INPUT -s 182.150.10.172 -j DROP
iptables -I INPUT -s 182.150.10.182 -j DROP
iptables -I INPUT -s 182.150.10.184 -j DROP
iptables -I INPUT -s 182.150.10.189 -j DROP
iptables -I INPUT -s 182.150.10.207 -j DROP
iptables -I INPUT -s 182.150.10.41 -j DROP
iptables -I INPUT -s 182.150.10.44 -j DROP
iptables -I INPUT -s 182.150.10.46 -j DROP
iptables -I INPUT -s 182.150.10.47 -j DROP
iptables -I INPUT -s 182.150.10.51 -j DROP
iptables -I INPUT -s 182.150.10.53 -j DROP
iptables -I INPUT -s 182.150.10.54 -j DROP
iptables -I INPUT -s 182.150.10.55 -j DROP
iptables -I INPUT -s 182.150.11.163 -j DROP
iptables -I INPUT -s 182.254.10.86 -j DROP
iptables -I INPUT -s 182.254.11.165 -j DROP
iptables -I INPUT -s 182.254.34.45 -j DROP
iptables -I INPUT -s 182.254.34.86 -j DROP
iptables -I INPUT -s 182.254.48.12 -j DROP
iptables -I INPUT -s 182.254.48.215 -j DROP
iptables -I INPUT -s 182.254.48.221 -j DROP
iptables -I INPUT -s 182.254.48.232 -j DROP
iptables -I INPUT -s 182.254.48.233 -j DROP
iptables -I INPUT -s 182.254.48.74 -j DROP
iptables -I INPUT -s 182.254.48.95 -j DROP
iptables -I INPUT -s 182.254.49.111 -j DROP
iptables -I INPUT -s 182.254.51.114 -j DROP
iptables -I INPUT -s 182.254.52.100 -j DROP
iptables -I INPUT -s 182.254.52.101 -j DROP
iptables -I INPUT -s 182.254.52.102 -j DROP
iptables -I INPUT -s 182.254.52.186 -j DROP
iptables -I INPUT -s 182.254.52.196 -j DROP
iptables -I INPUT -s 182.254.52.230 -j DROP
iptables -I INPUT -s 182.254.56.61 -j DROP
iptables -I INPUT -s 182.254.57.52 -j DROP
iptables -I INPUT -s 182.254.58.154 -j DROP
iptables -I INPUT -s 182.254.59.152 -j DROP
iptables -I INPUT -s 182.254.60.52 -j DROP
iptables -I INPUT -s 182.254.74.243 -j DROP
iptables -I INPUT -s 182.254.76.104 -j DROP
iptables -I INPUT -s 182.254.76.116 -j DROP
iptables -I INPUT -s 182.254.76.118 -j DROP
iptables -I INPUT -s 182.254.86.178 -j DROP
iptables -I INPUT -s 182.254.90.189 -j DROP
iptables -I INPUT -s 182.254.93.101 -j DROP
iptables -I INPUT -s 183.131.53.27 -j DROP
iptables -I INPUT -s 183.131.53.72 -j DROP
iptables -I INPUT -s 183.134.22.11 -j DROP
iptables -I INPUT -s 183.192.163.33 -j DROP
iptables -I INPUT -s 183.192.163.34 -j DROP
iptables -I INPUT -s 183.192.163.36 -j DROP
iptables -I INPUT -s 183.192.163.37 -j DROP
iptables -I INPUT -s 183.192.196.188 -j DROP
iptables -I INPUT -s 183.192.196.36 -j DROP
iptables -I INPUT -s 183.192.202.176 -j DROP
iptables -I INPUT -s 183.194.184.101 -j DROP
iptables -I INPUT -s 183.194.234.48 -j DROP
iptables -I INPUT -s 183.2.192.11 -j DROP
iptables -I INPUT -s 183.2.192.12 -j DROP
iptables -I INPUT -s 183.2.192.15 -j DROP
iptables -I INPUT -s 183.2.192.166 -j DROP
iptables -I INPUT -s 183.2.192.25 -j DROP
iptables -I INPUT -s 183.2.192.41 -j DROP
iptables -I INPUT -s 183.2.192.85 -j DROP
iptables -I INPUT -s 183.2.196.141 -j DROP
iptables -I INPUT -s 183.2.196.142 -j DROP
iptables -I INPUT -s 183.2.196.143 -j DROP
iptables -I INPUT -s 183.2.196.144 -j DROP
iptables -I INPUT -s 183.2.196.145 -j DROP
iptables -I INPUT -s 183.2.196.152 -j DROP
iptables -I INPUT -s 183.2.196.154 -j DROP
iptables -I INPUT -s 183.2.196.155 -j DROP
iptables -I INPUT -s 183.2.196.159 -j DROP
iptables -I INPUT -s 183.2.196.160 -j DROP
iptables -I INPUT -s 183.2.196.163 -j DROP
iptables -I INPUT -s 183.2.196.164 -j DROP
iptables -I INPUT -s 183.2.196.167 -j DROP
iptables -I INPUT -s 183.2.196.168 -j DROP
iptables -I INPUT -s 183.2.196.169 -j DROP
iptables -I INPUT -s 183.2.196.170 -j DROP
iptables -I INPUT -s 183.2.196.171 -j DROP
iptables -I INPUT -s 183.201.224.11 -j DROP
iptables -I INPUT -s 183.201.224.13 -j DROP
iptables -I INPUT -s 183.201.224.14 -j DROP
iptables -I INPUT -s 183.201.224.69 -j DROP
iptables -I INPUT -s 183.201.224.75 -j DROP
iptables -I INPUT -s 183.201.241.68 -j DROP
iptables -I INPUT -s 183.201.241.69 -j DROP
iptables -I INPUT -s 183.203.17.71 -j DROP
iptables -I INPUT -s 183.214.128.166 -j DROP
iptables -I INPUT -s 183.214.42.143 -j DROP
iptables -I INPUT -s 183.214.42.144 -j DROP
iptables -I INPUT -s 183.214.42.252 -j DROP
iptables -I INPUT -s 183.216.179.11 -j DROP
iptables -I INPUT -s 183.216.179.112 -j DROP
iptables -I INPUT -s 183.216.179.14 -j DROP
iptables -I INPUT -s 183.216.179.15 -j DROP
iptables -I INPUT -s 183.216.179.97 -j DROP
iptables -I INPUT -s 183.230.74.44 -j DROP
iptables -I INPUT -s 183.232.119.180 -j DROP
iptables -I INPUT -s 183.232.119.187 -j DROP
iptables -I INPUT -s 183.232.119.190 -j DROP
iptables -I INPUT -s 183.232.119.195 -j DROP
iptables -I INPUT -s 183.232.125.212 -j DROP
iptables -I INPUT -s 183.232.171.210 -j DROP
iptables -I INPUT -s 183.232.171.212 -j DROP
iptables -I INPUT -s 183.232.171.55 -j DROP
iptables -I INPUT -s 183.232.173.179 -j DROP
iptables -I INPUT -s 183.232.173.180 -j DROP
iptables -I INPUT -s 183.232.173.181 -j DROP
iptables -I INPUT -s 183.232.173.182 -j DROP
iptables -I INPUT -s 183.232.173.183 -j DROP
iptables -I INPUT -s 183.232.173.184 -j DROP
iptables -I INPUT -s 183.232.173.185 -j DROP
iptables -I INPUT -s 183.232.173.186 -j DROP
iptables -I INPUT -s 183.232.173.187 -j DROP
iptables -I INPUT -s 183.232.173.188 -j DROP
iptables -I INPUT -s 183.232.175.140 -j DROP
iptables -I INPUT -s 183.232.175.142 -j DROP
iptables -I INPUT -s 183.232.175.156 -j DROP
iptables -I INPUT -s 183.232.175.157 -j DROP
iptables -I INPUT -s 183.232.175.162 -j DROP
iptables -I INPUT -s 183.232.175.166 -j DROP
iptables -I INPUT -s 183.232.175.167 -j DROP
iptables -I INPUT -s 183.232.175.168 -j DROP
iptables -I INPUT -s 183.232.175.173 -j DROP
iptables -I INPUT -s 183.232.175.180 -j DROP
iptables -I INPUT -s 183.232.175.187 -j DROP
iptables -I INPUT -s 183.232.175.188 -j DROP
iptables -I INPUT -s 183.232.224.11 -j DROP
iptables -I INPUT -s 183.232.30.18 -j DROP
iptables -I INPUT -s 183.232.93.182 -j DROP
iptables -I INPUT -s 183.232.93.208 -j DROP
iptables -I INPUT -s 183.232.95.160 -j DROP
iptables -I INPUT -s 183.232.95.173 -j DROP
iptables -I INPUT -s 183.232.95.183 -j DROP
iptables -I INPUT -s 183.232.95.189 -j DROP
iptables -I INPUT -s 183.232.95.195 -j DROP
iptables -I INPUT -s 183.232.95.197 -j DROP
iptables -I INPUT -s 183.232.95.79 -j DROP
iptables -I INPUT -s 183.232.95.99 -j DROP
iptables -I INPUT -s 183.240.118.181 -j DROP
iptables -I INPUT -s 183.240.118.241 -j DROP
iptables -I INPUT -s 183.240.119.165 -j DROP
iptables -I INPUT -s 183.240.119.166 -j DROP
iptables -I INPUT -s 183.240.119.168 -j DROP
iptables -I INPUT -s 183.240.119.169 -j DROP
iptables -I INPUT -s 183.240.59.20 -j DROP
iptables -I INPUT -s 183.252.54.144 -j DROP
iptables -I INPUT -s 183.252.54.176 -j DROP
iptables -I INPUT -s 183.3.225.22 -j DROP
iptables -I INPUT -s 183.3.226.41 -j DROP
iptables -I INPUT -s 183.3.235.218 -j DROP
iptables -I INPUT -s 183.3.235.81 -j DROP
iptables -I INPUT -s 183.56.150.153 -j DROP
iptables -I INPUT -s 183.56.150.154 -j DROP
iptables -I INPUT -s 183.56.150.160 -j DROP
iptables -I INPUT -s 183.56.150.161 -j DROP
iptables -I INPUT -s 183.56.150.162 -j DROP
iptables -I INPUT -s 183.56.150.163 -j DROP
iptables -I INPUT -s 183.56.150.164 -j DROP
iptables -I INPUT -s 183.56.150.165 -j DROP
iptables -I INPUT -s 183.56.150.242 -j DROP
iptables -I INPUT -s 183.60.137.148 -j DROP
iptables -I INPUT -s 183.60.137.150 -j DROP
iptables -I INPUT -s 183.60.15.168 -j DROP
iptables -I INPUT -s 183.60.185.101 -j DROP
iptables -I INPUT -s 183.60.217.79 -j DROP
iptables -I INPUT -s 183.60.23.31 -j DROP
iptables -I INPUT -s 183.61.239.14 -j DROP
iptables -I INPUT -s 183.61.239.15 -j DROP
iptables -I INPUT -s 183.61.239.28 -j DROP
iptables -I INPUT -s 183.61.239.32 -j DROP
iptables -I INPUT -s 183.61.51.43 -j DROP
iptables -I INPUT -s 183.66.103.142 -j DROP
iptables -I INPUT -s 183.66.103.161 -j DROP
iptables -I INPUT -s 183.66.103.167 -j DROP
iptables -I INPUT -s 183.66.103.206 -j DROP
iptables -I INPUT -s 183.66.105.231 -j DROP
iptables -I INPUT -s 202.102.178.11 -j DROP
iptables -I INPUT -s 202.102.178.12 -j DROP
iptables -I INPUT -s 202.102.178.121 -j DROP
iptables -I INPUT -s 202.102.178.13 -j DROP
iptables -I INPUT -s 202.102.178.14 -j DROP
iptables -I INPUT -s 202.102.178.15 -j DROP
iptables -I INPUT -s 202.102.178.16 -j DROP
iptables -I INPUT -s 203.205.128.173 -j DROP
iptables -I INPUT -s 203.205.136.105 -j DROP
iptables -I INPUT -s 203.205.136.169 -j DROP
iptables -I INPUT -s 203.205.136.77 -j DROP
iptables -I INPUT -s 203.205.137.232 -j DROP
iptables -I INPUT -s 203.205.137.234 -j DROP
iptables -I INPUT -s 203.205.137.237 -j DROP
iptables -I INPUT -s 203.205.137.238 -j DROP
iptables -I INPUT -s 203.205.137.242 -j DROP
iptables -I INPUT -s 203.205.137.29 -j DROP
iptables -I INPUT -s 203.205.137.76 -j DROP
iptables -I INPUT -s 203.205.137.78 -j DROP
iptables -I INPUT -s 203.205.138.231 -j DROP
iptables -I INPUT -s 203.205.138.73 -j DROP
iptables -I INPUT -s 203.205.138.74 -j DROP
iptables -I INPUT -s 203.205.140.107 -j DROP
iptables -I INPUT -s 203.205.140.109 -j DROP
iptables -I INPUT -s 203.205.144.15 -j DROP
iptables -I INPUT -s 203.205.144.19 -j DROP
iptables -I INPUT -s 203.205.144.22 -j DROP
iptables -I INPUT -s 203.205.146.49 -j DROP
iptables -I INPUT -s 203.205.147.218 -j DROP
iptables -I INPUT -s 203.205.149.240 -j DROP
iptables -I INPUT -s 203.205.149.244 -j DROP
iptables -I INPUT -s 203.205.150.108 -j DROP
iptables -I INPUT -s 203.205.150.110 -j DROP
iptables -I INPUT -s 203.205.151.46 -j DROP
iptables -I INPUT -s 203.205.158.50 -j DROP
iptables -I INPUT -s 203.205.158.52 -j DROP
iptables -I INPUT -s 203.205.158.60 -j DROP
iptables -I INPUT -s 203.205.158.61 -j DROP
iptables -I INPUT -s 203.205.158.62 -j DROP
iptables -I INPUT -s 203.205.158.63 -j DROP
iptables -I INPUT -s 203.205.158.65 -j DROP
iptables -I INPUT -s 203.205.219.229 -j DROP
iptables -I INPUT -s 203.205.235.2 -j DROP
iptables -I INPUT -s 203.205.235.243 -j DROP
iptables -I INPUT -s 203.205.239.141 -j DROP
iptables -I INPUT -s 203.205.239.144 -j DROP
iptables -I INPUT -s 203.205.239.162 -j DROP
iptables -I INPUT -s 203.205.239.166 -j DROP
iptables -I INPUT -s 203.205.253.184 -j DROP
iptables -I INPUT -s 203.205.254.62 -j DROP
iptables -I INPUT -s 210.22.248.141 -j DROP
iptables -I INPUT -s 210.22.248.149 -j DROP
iptables -I INPUT -s 210.22.248.155 -j DROP
iptables -I INPUT -s 210.22.248.164 -j DROP
iptables -I INPUT -s 210.22.248.170 -j DROP
iptables -I INPUT -s 210.22.248.217 -j DROP
iptables -I INPUT -s 210.22.248.232 -j DROP
iptables -I INPUT -s 210.22.249.95 -j DROP
iptables -I INPUT -s 218.11.11.190 -j DROP
iptables -I INPUT -s 218.30.98.17 -j DROP
iptables -I INPUT -s 218.30.98.18 -j DROP
iptables -I INPUT -s 218.30.98.19 -j DROP
iptables -I INPUT -s 218.60.33.148 -j DROP
iptables -I INPUT -s 218.75.176.157 -j DROP
iptables -I INPUT -s 218.75.176.158 -j DROP
iptables -I INPUT -s 218.75.176.167 -j DROP
iptables -I INPUT -s 218.75.176.169 -j DROP
iptables -I INPUT -s 218.75.176.170 -j DROP
iptables -I INPUT -s 218.75.176.171 -j DROP
iptables -I INPUT -s 218.75.176.172 -j DROP
iptables -I INPUT -s 218.75.177.20 -j DROP
iptables -I INPUT -s 218.75.177.22 -j DROP
iptables -I INPUT -s 219.133.60.213 -j DROP
iptables -I INPUT -s 219.133.60.217 -j DROP
iptables -I INPUT -s 219.133.60.218 -j DROP
iptables -I INPUT -s 219.133.60.219 -j DROP
iptables -I INPUT -s 219.133.60.222 -j DROP
iptables -I INPUT -s 219.144.82.209 -j DROP
iptables -I INPUT -s 219.146.241.141 -j DROP
iptables -I INPUT -s 219.146.241.145 -j DROP
iptables -I INPUT -s 219.146.241.146 -j DROP
iptables -I INPUT -s 219.146.241.147 -j DROP
iptables -I INPUT -s 219.146.241.148 -j DROP
iptables -I INPUT -s 219.146.241.149 -j DROP
iptables -I INPUT -s 219.146.241.150 -j DROP
iptables -I INPUT -s 219.146.241.151 -j DROP
iptables -I INPUT -s 219.146.241.152 -j DROP
iptables -I INPUT -s 219.146.241.153 -j DROP
iptables -I INPUT -s 219.146.241.154 -j DROP
iptables -I INPUT -s 219.146.241.155 -j DROP
iptables -I INPUT -s 219.146.241.157 -j DROP
iptables -I INPUT -s 219.146.241.158 -j DROP
iptables -I INPUT -s 219.146.241.159 -j DROP
iptables -I INPUT -s 219.146.241.160 -j DROP
iptables -I INPUT -s 219.146.241.161 -j DROP
iptables -I INPUT -s 219.146.241.162 -j DROP
iptables -I INPUT -s 219.146.241.163 -j DROP
iptables -I INPUT -s 219.146.241.164 -j DROP
iptables -I INPUT -s 219.146.241.172 -j DROP
iptables -I INPUT -s 219.146.241.173 -j DROP
iptables -I INPUT -s 219.146.241.174 -j DROP
iptables -I INPUT -s 219.146.241.175 -j DROP
iptables -I INPUT -s 219.151.14.28 -j DROP
iptables -I INPUT -s 219.151.17.124 -j DROP
iptables -I INPUT -s 219.151.17.15 -j DROP
iptables -I INPUT -s 219.151.17.21 -j DROP
iptables -I INPUT -s 219.151.17.44 -j DROP
iptables -I INPUT -s 220.181.91.148 -j DROP
iptables -I INPUT -s 220.181.91.149 -j DROP
iptables -I INPUT -s 220.194.111.229 -j DROP
iptables -I INPUT -s 220.194.223.11 -j DROP
iptables -I INPUT -s 220.194.223.125 -j DROP
iptables -I INPUT -s 220.194.223.14 -j DROP
iptables -I INPUT -s 220.194.223.15 -j DROP
iptables -I INPUT -s 220.194.223.16 -j DROP
iptables -I INPUT -s 220.194.223.32 -j DROP
iptables -I INPUT -s 220.194.223.35 -j DROP
iptables -I INPUT -s 220.194.223.36 -j DROP
iptables -I INPUT -s 220.194.223.44 -j DROP
iptables -I INPUT -s 220.194.223.60 -j DROP
iptables -I INPUT -s 220.194.223.79 -j DROP
iptables -I INPUT -s 220.194.224.141 -j DROP
iptables -I INPUT -s 220.194.224.142 -j DROP
iptables -I INPUT -s 220.194.224.145 -j DROP
iptables -I INPUT -s 220.194.224.146 -j DROP
iptables -I INPUT -s 220.194.224.147 -j DROP
iptables -I INPUT -s 220.194.224.148 -j DROP
iptables -I INPUT -s 220.194.224.15 -j DROP
iptables -I INPUT -s 220.194.224.17 -j DROP
iptables -I INPUT -s 220.194.224.177 -j DROP
iptables -I INPUT -s 220.194.224.179 -j DROP
iptables -I INPUT -s 220.194.224.18 -j DROP
iptables -I INPUT -s 220.194.224.182 -j DROP
iptables -I INPUT -s 220.194.224.185 -j DROP
iptables -I INPUT -s 220.194.224.19 -j DROP
iptables -I INPUT -s 220.194.79.36 -j DROP
iptables -I INPUT -s 220.194.87.100 -j DROP
iptables -I INPUT -s 220.194.87.11 -j DROP
iptables -I INPUT -s 220.194.87.12 -j DROP
iptables -I INPUT -s 220.194.87.13 -j DROP
iptables -I INPUT -s 220.194.87.14 -j DROP
iptables -I INPUT -s 220.194.87.15 -j DROP
iptables -I INPUT -s 220.194.87.43 -j DROP
iptables -I INPUT -s 220.194.87.52 -j DROP
iptables -I INPUT -s 220.194.91.125 -j DROP
iptables -I INPUT -s 220.194.91.184 -j DROP
iptables -I INPUT -s 220.194.91.190 -j DROP
iptables -I INPUT -s 220.194.91.69 -j DROP
iptables -I INPUT -s 220.194.91.93 -j DROP
iptables -I INPUT -s 220.194.95.218 -j DROP
iptables -I INPUT -s 220.194.95.221 -j DROP
iptables -I INPUT -s 220.195.17.35 -j DROP
iptables -I INPUT -s 220.195.19.22 -j DROP
iptables -I INPUT -s 220.195.19.23 -j DROP
iptables -I INPUT -s 220.195.19.24 -j DROP
iptables -I INPUT -s 220.195.19.25 -j DROP
iptables -I INPUT -s 220.195.19.26 -j DROP
iptables -I INPUT -s 220.195.19.27 -j DROP
iptables -I INPUT -s 220.249.243.177 -j DROP
iptables -I INPUT -s 220.249.243.18 -j DROP
iptables -I INPUT -s 220.249.243.19 -j DROP
iptables -I INPUT -s 220.249.243.43 -j DROP
iptables -I INPUT -s 221.180.147.22 -j DROP
iptables -I INPUT -s 221.180.213.27 -j DROP
iptables -I INPUT -s 221.180.213.37 -j DROP
iptables -I INPUT -s 221.181.81.253 -j DROP
iptables -I INPUT -s 221.204.165.121 -j DROP
iptables -I INPUT -s 221.204.183.93 -j DROP
iptables -I INPUT -s 221.204.57.11 -j DROP
iptables -I INPUT -s 221.204.57.13 -j DROP
iptables -I INPUT -s 221.204.57.14 -j DROP
iptables -I INPUT -s 221.204.57.15 -j DROP
iptables -I INPUT -s 221.228.218.166 -j DROP
iptables -I INPUT -s 221.228.219.112 -j DROP
iptables -I INPUT -s 221.228.67.141 -j DROP
iptables -I INPUT -s 221.228.67.145 -j DROP
iptables -I INPUT -s 221.228.67.151 -j DROP
iptables -I INPUT -s 221.228.67.153 -j DROP
iptables -I INPUT -s 221.228.67.154 -j DROP
iptables -I INPUT -s 221.228.67.155 -j DROP
iptables -I INPUT -s 221.228.67.161 -j DROP
iptables -I INPUT -s 221.228.67.162 -j DROP
iptables -I INPUT -s 221.228.67.163 -j DROP
iptables -I INPUT -s 221.228.67.164 -j DROP
iptables -I INPUT -s 221.228.67.172 -j DROP
iptables -I INPUT -s 221.228.67.186 -j DROP
iptables -I INPUT -s 221.228.67.230 -j DROP
iptables -I INPUT -s 221.233.41.16 -j DROP
iptables -I INPUT -s 221.233.41.17 -j DROP
iptables -I INPUT -s 221.233.41.26 -j DROP
iptables -I INPUT -s 221.235.252.170 -j DROP
iptables -I INPUT -s 221.8.78.15 -j DROP
iptables -I INPUT -s 221.8.78.16 -j DROP
iptables -I INPUT -s 221.8.78.17 -j DROP
iptables -I INPUT -s 221.8.78.18 -j DROP
iptables -I INPUT -s 221.8.78.19 -j DROP
iptables -I INPUT -s 222.186.49.108 -j DROP
iptables -I INPUT -s 222.186.49.11 -j DROP
iptables -I INPUT -s 222.186.49.114 -j DROP
iptables -I INPUT -s 222.186.49.12 -j DROP
iptables -I INPUT -s 222.186.49.124 -j DROP
iptables -I INPUT -s 222.186.49.13 -j DROP
iptables -I INPUT -s 222.186.49.14 -j DROP
iptables -I INPUT -s 222.186.49.15 -j DROP
iptables -I INPUT -s 222.186.49.34 -j DROP
iptables -I INPUT -s 222.186.49.85 -j DROP
iptables -I INPUT -s 222.218.81.11 -j DROP
iptables -I INPUT -s 222.218.81.12 -j DROP
iptables -I INPUT -s 222.218.81.13 -j DROP
iptables -I INPUT -s 222.218.81.52 -j DROP
iptables -I INPUT -s 222.218.81.97 -j DROP
iptables -I INPUT -s 222.73.133.121 -j DROP
iptables -I INPUT -s 223.111.108.141 -j DROP
iptables -I INPUT -s 223.111.108.142 -j DROP
iptables -I INPUT -s 223.111.108.143 -j DROP
iptables -I INPUT -s 223.111.108.144 -j DROP
iptables -I INPUT -s 223.111.108.145 -j DROP
iptables -I INPUT -s 223.111.108.167 -j DROP
iptables -I INPUT -s 223.111.108.168 -j DROP
iptables -I INPUT -s 223.111.108.169 -j DROP
iptables -I INPUT -s 223.111.108.170 -j DROP
iptables -I INPUT -s 223.111.108.196 -j DROP
iptables -I INPUT -s 223.111.153.139 -j DROP
iptables -I INPUT -s 223.111.153.143 -j DROP
iptables -I INPUT -s 223.111.153.147 -j DROP
iptables -I INPUT -s 223.111.153.160 -j DROP
iptables -I INPUT -s 223.111.153.162 -j DROP
iptables -I INPUT -s 223.111.153.165 -j DROP
iptables -I INPUT -s 223.111.153.167 -j DROP
iptables -I INPUT -s 223.111.153.168 -j DROP
iptables -I INPUT -s 223.111.153.169 -j DROP
iptables -I INPUT -s 223.111.153.205 -j DROP
iptables -I INPUT -s 223.111.154.103 -j DROP
iptables -I INPUT -s 223.111.154.104 -j DROP
iptables -I INPUT -s 223.111.154.108 -j DROP
iptables -I INPUT -s 223.111.154.15 -j DROP
iptables -I INPUT -s 223.111.154.17 -j DROP
iptables -I INPUT -s 223.111.154.20 -j DROP
iptables -I INPUT -s 223.111.154.21 -j DROP
iptables -I INPUT -s 223.111.154.22 -j DROP
iptables -I INPUT -s 223.111.154.24 -j DROP
iptables -I INPUT -s 223.111.154.29 -j DROP
iptables -I INPUT -s 223.111.154.33 -j DROP
iptables -I INPUT -s 223.111.154.40 -j DROP
iptables -I INPUT -s 223.111.154.43 -j DROP
iptables -I INPUT -s 223.111.158.11 -j DROP
iptables -I INPUT -s 223.111.158.115 -j DROP
iptables -I INPUT -s 223.111.158.12 -j DROP
iptables -I INPUT -s 223.111.158.13 -j DROP
iptables -I INPUT -s 223.111.158.14 -j DROP
iptables -I INPUT -s 223.111.158.15 -j DROP
iptables -I INPUT -s 223.111.158.16 -j DROP
iptables -I INPUT -s 223.111.158.20 -j DROP
iptables -I INPUT -s 223.111.158.40 -j DROP
iptables -I INPUT -s 223.111.158.41 -j DROP
iptables -I INPUT -s 223.111.158.79 -j DROP
iptables -I INPUT -s 223.111.158.90 -j DROP
iptables -I INPUT -s 223.111.187.141 -j DROP
iptables -I INPUT -s 223.111.187.142 -j DROP
iptables -I INPUT -s 223.111.187.144 -j DROP
iptables -I INPUT -s 223.111.187.145 -j DROP
iptables -I INPUT -s 223.111.187.146 -j DROP
iptables -I INPUT -s 223.111.187.147 -j DROP
iptables -I INPUT -s 223.111.187.167 -j DROP
iptables -I INPUT -s 223.111.187.168 -j DROP
iptables -I INPUT -s 223.111.187.208 -j DROP
iptables -I INPUT -s 223.111.187.233 -j DROP
iptables -I INPUT -s 223.111.187.237 -j DROP
iptables -I INPUT -s 223.111.194.174 -j DROP
iptables -I INPUT -s 223.111.195.78 -j DROP
iptables -I INPUT -s 223.111.243.11 -j DROP
iptables -I INPUT -s 223.111.243.12 -j DROP
iptables -I INPUT -s 223.111.243.126 -j DROP
iptables -I INPUT -s 223.111.243.13 -j DROP
iptables -I INPUT -s 223.111.243.14 -j DROP
iptables -I INPUT -s 223.111.243.15 -j DROP
iptables -I INPUT -s 223.111.243.156 -j DROP
iptables -I INPUT -s 223.111.243.16 -j DROP
iptables -I INPUT -s 223.111.243.218 -j DROP
iptables -I INPUT -s 223.111.96.68 -j DROP
iptables -I INPUT -s 223.111.97.159 -j DROP
iptables -I INPUT -s 223.111.97.172 -j DROP
iptables -I INPUT -s 223.111.97.187 -j DROP
iptables -I INPUT -s 223.166.152.196 -j DROP
iptables -I INPUT -s 223.167.86.70 -j DROP
iptables -I INPUT -s 223.82.245.24 -j DROP
iptables -I INPUT -s 223.82.245.26 -j DROP
iptables -I INPUT -s 223.82.245.27 -j DROP
iptables -I INPUT -s 223.82.245.30 -j DROP
iptables -I INPUT -s 223.82.245.31 -j DROP
iptables -I INPUT -s 223.82.245.33 -j DROP
iptables -I INPUT -s 223.82.245.86 -j DROP
iptables -I INPUT -s 223.99.231.142 -j DROP
iptables -I INPUT -s 223.99.231.145 -j DROP
iptables -I INPUT -s 223.99.231.155 -j DROP
iptables -I INPUT -s 223.99.231.166 -j DROP
iptables -I INPUT -s 223.99.231.171 -j DROP
iptables -I INPUT -s 223.99.231.172 -j DROP
iptables -I INPUT -s 223.99.231.186 -j DROP
iptables -I INPUT -s 223.99.231.238 -j DROP
iptables -I INPUT -s 223.99.245.42 -j DROP
iptables -I INPUT -s 223.99.245.49 -j DROP
iptables -I INPUT -s 27.148.185.86 -j DROP
iptables -I INPUT -s 27.152.185.166 -j DROP
iptables -I INPUT -s 27.221.15.140 -j DROP
iptables -I INPUT -s 27.221.15.186 -j DROP
iptables -I INPUT -s 27.221.28.166 -j DROP
iptables -I INPUT -s 27.221.81.102 -j DROP
iptables -I INPUT -s 27.221.81.104 -j DROP
iptables -I INPUT -s 27.221.81.23 -j DROP
iptables -I INPUT -s 27.221.81.24 -j DROP
iptables -I INPUT -s 27.221.81.25 -j DROP
iptables -I INPUT -s 27.221.81.27 -j DROP
iptables -I INPUT -s 27.221.81.36 -j DROP
iptables -I INPUT -s 27.221.81.38 -j DROP
iptables -I INPUT -s 27.221.81.39 -j DROP
iptables -I INPUT -s 27.221.81.43 -j DROP
iptables -I INPUT -s 27.221.81.44 -j DROP
iptables -I INPUT -s 27.221.81.63 -j DROP
iptables -I INPUT -s 27.221.81.72 -j DROP
iptables -I INPUT -s 27.45.166.11 -j DROP
iptables -I INPUT -s 27.45.166.14 -j DROP
iptables -I INPUT -s 27.45.166.143 -j DROP
iptables -I INPUT -s 27.45.166.146 -j DROP
iptables -I INPUT -s 27.45.166.16 -j DROP
iptables -I INPUT -s 27.45.166.55 -j DROP
iptables -I INPUT -s 36.101.205.15 -j DROP
iptables -I INPUT -s 36.101.205.92 -j DROP
iptables -I INPUT -s 36.152.2.101 -j DROP
iptables -I INPUT -s 36.152.2.102 -j DROP
iptables -I INPUT -s 36.152.2.110 -j DROP
iptables -I INPUT -s 36.158.210.195 -j DROP
iptables -I INPUT -s 36.158.211.17 -j DROP
iptables -I INPUT -s 36.159.126.123 -j DROP
iptables -I INPUT -s 36.159.126.70 -j DROP
iptables -I INPUT -s 36.159.126.86 -j DROP
iptables -I INPUT -s 36.248.26.166 -j DROP
iptables -I INPUT -s 36.250.8.141 -j DROP
iptables -I INPUT -s 36.250.8.142 -j DROP
iptables -I INPUT -s 36.250.8.144 -j DROP
iptables -I INPUT -s 36.250.8.145 -j DROP
iptables -I INPUT -s 36.250.8.146 -j DROP
iptables -I INPUT -s 39.130.161.21 -j DROP
iptables -I INPUT -s 39.130.161.90 -j DROP
iptables -I INPUT -s 39.130.161.98 -j DROP
iptables -I INPUT -s 42.101.76.202 -j DROP
iptables -I INPUT -s 42.202.141.23 -j DROP
iptables -I INPUT -s 42.202.154.11 -j DROP
iptables -I INPUT -s 42.202.154.18 -j DROP
iptables -I INPUT -s 42.202.154.19 -j DROP
iptables -I INPUT -s 42.202.154.42 -j DROP
iptables -I INPUT -s 42.202.154.44 -j DROP
iptables -I INPUT -s 42.202.154.56 -j DROP
iptables -I INPUT -s 42.236.125.36 -j DROP
iptables -I INPUT -s 42.236.126.166 -j DROP
iptables -I INPUT -s 42.236.126.23 -j DROP
iptables -I INPUT -s 42.236.126.25 -j DROP
iptables -I INPUT -s 42.236.126.32 -j DROP
iptables -I INPUT -s 42.236.126.33 -j DROP
iptables -I INPUT -s 42.236.126.36 -j DROP
iptables -I INPUT -s 42.236.126.39 -j DROP
iptables -I INPUT -s 42.236.95.11 -j DROP
iptables -I INPUT -s 42.236.95.23 -j DROP
iptables -I INPUT -s 42.236.95.24 -j DROP
iptables -I INPUT -s 42.236.95.25 -j DROP
iptables -I INPUT -s 42.236.95.26 -j DROP
iptables -I INPUT -s 42.236.95.27 -j DROP
iptables -I INPUT -s 42.236.95.40 -j DROP
iptables -I INPUT -s 42.236.95.41 -j DROP
iptables -I INPUT -s 42.236.95.42 -j DROP
iptables -I INPUT -s 42.236.95.43 -j DROP
iptables -I INPUT -s 42.236.95.44 -j DROP
iptables -I INPUT -s 42.48.109.16 -j DROP
iptables -I INPUT -s 42.48.109.17 -j DROP
iptables -I INPUT -s 42.56.64.30 -j DROP
iptables -I INPUT -s 42.56.65.153 -j DROP
iptables -I INPUT -s 42.56.65.155 -j DROP
iptables -I INPUT -s 42.56.65.157 -j DROP
iptables -I INPUT -s 42.56.65.21 -j DROP
iptables -I INPUT -s 42.56.65.22 -j DROP
iptables -I INPUT -s 42.56.65.23 -j DROP
iptables -I INPUT -s 42.56.65.24 -j DROP
iptables -I INPUT -s 42.56.76.36 -j DROP
iptables -I INPUT -s 42.56.79.11 -j DROP
iptables -I INPUT -s 42.56.83.119 -j DROP
iptables -I INPUT -s 42.81.85.190 -j DROP
iptables -I INPUT -s 42.81.85.191 -j DROP
iptables -I INPUT -s 42.81.85.253 -j DROP
iptables -I INPUT -s 58.144.143.11 -j DROP
iptables -I INPUT -s 58.144.143.12 -j DROP
iptables -I INPUT -s 58.144.143.13 -j DROP
iptables -I INPUT -s 58.144.143.14 -j DROP
iptables -I INPUT -s 58.144.143.16 -j DROP
iptables -I INPUT -s 58.205.214.148 -j DROP
iptables -I INPUT -s 58.211.85.13 -j DROP
iptables -I INPUT -s 58.211.85.14 -j DROP
iptables -I INPUT -s 58.211.85.15 -j DROP
iptables -I INPUT -s 58.211.85.17 -j DROP
iptables -I INPUT -s 58.211.85.19 -j DROP
iptables -I INPUT -s 58.211.85.20 -j DROP
iptables -I INPUT -s 58.211.85.36 -j DROP
iptables -I INPUT -s 58.211.85.37 -j DROP
iptables -I INPUT -s 58.211.85.38 -j DROP
iptables -I INPUT -s 58.211.85.39 -j DROP
iptables -I INPUT -s 58.211.85.41 -j DROP
iptables -I INPUT -s 58.211.85.42 -j DROP
iptables -I INPUT -s 58.211.85.43 -j DROP
iptables -I INPUT -s 58.211.85.44 -j DROP
iptables -I INPUT -s 58.215.146.159 -j DROP
iptables -I INPUT -s 58.215.146.160 -j DROP
iptables -I INPUT -s 58.216.106.166 -j DROP
iptables -I INPUT -s 58.216.6.14 -j DROP
iptables -I INPUT -s 58.216.6.163 -j DROP
iptables -I INPUT -s 58.216.6.17 -j DROP
iptables -I INPUT -s 58.216.6.18 -j DROP
iptables -I INPUT -s 58.216.6.19 -j DROP
iptables -I INPUT -s 58.216.6.27 -j DROP
iptables -I INPUT -s 58.216.6.28 -j DROP
iptables -I INPUT -s 58.216.96.11 -j DROP
iptables -I INPUT -s 58.216.96.111 -j DROP
iptables -I INPUT -s 58.216.96.12 -j DROP
iptables -I INPUT -s 58.216.96.13 -j DROP
iptables -I INPUT -s 58.216.96.14 -j DROP
iptables -I INPUT -s 58.216.96.15 -j DROP
iptables -I INPUT -s 58.216.96.21 -j DROP
iptables -I INPUT -s 58.216.96.38 -j DROP
iptables -I INPUT -s 58.216.96.63 -j DROP
iptables -I INPUT -s 58.247.206.171 -j DROP
iptables -I INPUT -s 58.247.214.113 -j DROP
iptables -I INPUT -s 58.250.137.42 -j DROP
iptables -I INPUT -s 58.251.116.47 -j DROP
iptables -I INPUT -s 58.251.149.11 -j DROP
iptables -I INPUT -s 58.251.149.12 -j DROP
iptables -I INPUT -s 58.251.149.13 -j DROP
iptables -I INPUT -s 58.251.149.14 -j DROP
iptables -I INPUT -s 58.251.149.15 -j DROP
iptables -I INPUT -s 58.251.149.16 -j DROP
iptables -I INPUT -s 58.251.149.17 -j DROP
iptables -I INPUT -s 58.251.149.18 -j DROP
iptables -I INPUT -s 58.251.149.19 -j DROP
iptables -I INPUT -s 58.251.149.20 -j DROP
iptables -I INPUT -s 58.251.149.21 -j DROP
iptables -I INPUT -s 58.251.149.22 -j DROP
iptables -I INPUT -s 58.251.149.23 -j DROP
iptables -I INPUT -s 58.251.149.24 -j DROP
iptables -I INPUT -s 58.251.149.25 -j DROP
iptables -I INPUT -s 58.251.149.26 -j DROP
iptables -I INPUT -s 58.251.149.27 -j DROP
iptables -I INPUT -s 58.251.149.28 -j DROP
iptables -I INPUT -s 58.251.149.29 -j DROP
iptables -I INPUT -s 58.251.149.30 -j DROP
iptables -I INPUT -s 58.251.149.31 -j DROP
iptables -I INPUT -s 58.251.149.32 -j DROP
iptables -I INPUT -s 58.251.149.33 -j DROP
iptables -I INPUT -s 58.251.149.34 -j DROP
iptables -I INPUT -s 58.49.137.107 -j DROP
iptables -I INPUT -s 58.49.137.125 -j DROP
iptables -I INPUT -s 58.49.137.17 -j DROP
iptables -I INPUT -s 58.49.157.141 -j DROP
iptables -I INPUT -s 58.49.224.43 -j DROP
iptables -I INPUT -s 59.36.113.27 -j DROP
iptables -I INPUT -s 59.36.113.41 -j DROP
iptables -I INPUT -s 59.36.113.60 -j DROP
iptables -I INPUT -s 59.36.113.62 -j DROP
iptables -I INPUT -s 59.37.96.149 -j DROP
iptables -I INPUT -s 59.37.96.150 -j DROP
iptables -I INPUT -s 59.37.96.151 -j DROP
iptables -I INPUT -s 59.37.96.152 -j DROP
iptables -I INPUT -s 59.37.96.202 -j DROP
iptables -I INPUT -s 59.37.96.244 -j DROP
iptables -I INPUT -s 59.37.96.25 -j DROP
iptables -I INPUT -s 59.37.96.26 -j DROP
iptables -I INPUT -s 59.37.96.36 -j DROP
iptables -I INPUT -s 59.37.96.37 -j DROP
iptables -I INPUT -s 59.49.45.40 -j DROP
iptables -I INPUT -s 59.49.91.106 -j DROP
iptables -I INPUT -s 59.49.91.13 -j DROP
iptables -I INPUT -s 59.49.91.14 -j DROP
iptables -I INPUT -s 59.49.91.15 -j DROP
iptables -I INPUT -s 59.49.91.82 -j DROP
iptables -I INPUT -s 59.57.18.146 -j DROP
iptables -I INPUT -s 59.63.235.11 -j DROP
iptables -I INPUT -s 59.63.235.113 -j DROP
iptables -I INPUT -s 59.63.235.13 -j DROP
iptables -I INPUT -s 59.63.235.14 -j DROP
iptables -I INPUT -s 59.63.235.15 -j DROP
iptables -I INPUT -s 59.63.235.78 -j DROP
iptables -I INPUT -s 59.63.237.145 -j DROP
iptables -I INPUT -s 59.63.237.146 -j DROP
iptables -I INPUT -s 59.63.237.147 -j DROP
iptables -I INPUT -s 59.63.237.148 -j DROP
iptables -I INPUT -s 59.63.237.16 -j DROP
iptables -I INPUT -s 59.63.237.22 -j DROP
iptables -I INPUT -s 59.63.237.237 -j DROP
iptables -I INPUT -s 59.63.237.243 -j DROP
iptables -I INPUT -s 59.63.237.36 -j DROP
iptables -I INPUT -s 59.83.218.121 -j DROP
iptables -I INPUT -s 59.83.218.15 -j DROP
iptables -I INPUT -s 59.83.218.252 -j DROP
iptables -I INPUT -s 59.83.218.87 -j DROP
iptables -I INPUT -s 60.167.138.26 -j DROP
iptables -I INPUT -s 60.167.138.27 -j DROP
iptables -I INPUT -s 60.174.156.21 -j DROP
iptables -I INPUT -s 60.217.249.40 -j DROP
iptables -I INPUT -s 60.217.253.100 -j DROP
iptables -I INPUT -s 61.128.150.34 -j DROP
iptables -I INPUT -s 61.129.7.18 -j DROP
iptables -I INPUT -s 61.140.13.166 -j DROP
iptables -I INPUT -s 61.142.166.141 -j DROP
iptables -I INPUT -s 61.142.166.168 -j DROP
iptables -I INPUT -s 61.142.166.209 -j DROP
iptables -I INPUT -s 61.142.166.248 -j DROP
iptables -I INPUT -s 61.151.206.42 -j DROP
iptables -I INPUT -s 61.151.206.68 -j DROP
iptables -I INPUT -s 61.151.206.90 -j DROP
iptables -I INPUT -s 61.151.234.32 -j DROP
iptables -I INPUT -s 61.151.234.36 -j DROP
iptables -I INPUT -s 61.151.234.56 -j DROP
iptables -I INPUT -s 61.151.234.57 -j DROP
iptables -I INPUT -s 61.151.234.58 -j DROP
iptables -I INPUT -s 61.151.234.59 -j DROP
iptables -I INPUT -s 61.151.234.60 -j DROP
iptables -I INPUT -s 61.155.220.204 -j DROP
iptables -I INPUT -s 61.155.220.206 -j DROP
iptables -I INPUT -s 61.156.15.27 -j DROP
iptables -I INPUT -s 61.156.15.28 -j DROP
iptables -I INPUT -s 61.156.15.29 -j DROP
iptables -I INPUT -s 61.156.15.30 -j DROP
iptables -I INPUT -s 61.156.15.35 -j DROP
iptables -I INPUT -s 61.156.15.37 -j DROP
iptables -I INPUT -s 61.156.15.38 -j DROP
iptables -I INPUT -s 61.156.15.39 -j DROP
iptables -I INPUT -s 61.156.15.40 -j DROP
iptables -I INPUT -s 61.156.15.41 -j DROP
iptables -I INPUT -s 61.156.15.42 -j DROP
iptables -I INPUT -s 61.156.15.52 -j DROP
iptables -I INPUT -s 61.156.15.71 -j DROP
iptables -I INPUT -s 61.156.15.88 -j DROP
iptables -I INPUT -s 61.182.131.60 -j DROP
iptables -I INPUT -s 61.182.131.62 -j DROP
iptables -I INPUT -s 61.182.140.149 -j DROP
iptables -I INPUT -s 61.183.164.24 -j DROP
iptables -I INPUT -s 61.183.164.25 -j DROP
iptables -I INPUT -s 61.183.164.27 -j DROP
iptables -I INPUT -s 61.183.164.28 -j DROP
iptables -I INPUT -s 61.183.164.29 -j DROP
iptables -I INPUT -s 61.183.164.30 -j DROP
iptables -I INPUT -s 61.183.164.31 -j DROP
iptables -I INPUT -s 61.183.164.34 -j DROP
iptables -I INPUT -s 61.183.164.35 -j DROP
iptables -I INPUT -s 61.183.164.36 -j DROP
iptables -I INPUT -s 61.183.164.37 -j DROP
iptables -I INPUT -s 61.183.164.38 -j DROP
iptables -I INPUT -s 61.183.164.39 -j DROP
iptables -I INPUT -s 61.183.164.41 -j DROP
iptables -I INPUT -s 61.183.164.42 -j DROP
iptables -I INPUT -s 61.183.164.44 -j DROP
iptables -I INPUT -s 61.183.164.81 -j DROP
iptables -I INPUT -s 61.184.213.244 -j DROP
iptables -I INPUT -s 61.191.60.35 -j DROP
iptables -I INPUT -s 61.240.150.33 -j DROP
iptables -I INPUT -s 61.54.253.18 -j DROP
iptables -I INPUT -s 61.54.253.29 -j DROP
iptables -I INPUT -s 61.54.253.33 -j DROP
iptables -I INPUT -s 61.54.253.42 -j DROP
iptables -I INPUT -s 61.54.253.44 -j DROP
iptables -I INPUT -s 61.54.253.92 -j DROP
iptables -I OUTPUT -d -j DROP
iptables -I OUTPUT -d 1.198.11.81 -j DROP
iptables -I OUTPUT -d 1.198.11.82 -j DROP
iptables -I OUTPUT -d 1.198.5.111 -j DROP
iptables -I OUTPUT -d 1.198.5.151 -j DROP
iptables -I OUTPUT -d 1.198.5.168 -j DROP
iptables -I OUTPUT -d 1.198.5.212 -j DROP
iptables -I OUTPUT -d 1.198.5.249 -j DROP
iptables -I OUTPUT -d 1.31.109.158 -j DROP
iptables -I OUTPUT -d 1.31.130.147 -j DROP
iptables -I OUTPUT -d 1.31.130.148 -j DROP
iptables -I OUTPUT -d 1.31.130.149 -j DROP
iptables -I OUTPUT -d 1.31.130.157 -j DROP
iptables -I OUTPUT -d 1.31.130.158 -j DROP
iptables -I OUTPUT -d 1.31.173.36 -j DROP
iptables -I OUTPUT -d 101.226.233.173 -j DROP
iptables -I OUTPUT -d 101.226.90.186 -j DROP
iptables -I OUTPUT -d 101.227.216.161 -j DROP
iptables -I OUTPUT -d 101.69.121.30 -j DROP
iptables -I OUTPUT -d 101.89.15.189 -j DROP
iptables -I OUTPUT -d 101.89.39.11 -j DROP
iptables -I OUTPUT -d 101.91.42.213 -j DROP
iptables -I OUTPUT -d 103.18.208.142 -j DROP
iptables -I OUTPUT -d 103.18.208.155 -j DROP
iptables -I OUTPUT -d 103.18.208.160 -j DROP
iptables -I OUTPUT -d 103.18.208.171 -j DROP
iptables -I OUTPUT -d 103.18.208.172 -j DROP
iptables -I OUTPUT -d 103.18.208.239 -j DROP
iptables -I OUTPUT -d 103.18.209.11 -j DROP
iptables -I OUTPUT -d 103.18.209.117 -j DROP
iptables -I OUTPUT -d 103.18.209.12 -j DROP
iptables -I OUTPUT -d 103.18.209.13 -j DROP
iptables -I OUTPUT -d 103.18.209.14 -j DROP
iptables -I OUTPUT -d 103.18.209.15 -j DROP
iptables -I OUTPUT -d 103.18.209.16 -j DROP
iptables -I OUTPUT -d 103.18.209.52 -j DROP
iptables -I OUTPUT -d 103.7.28.109 -j DROP
iptables -I OUTPUT -d 103.7.28.15 -j DROP
iptables -I OUTPUT -d 103.7.29.189 -j DROP
iptables -I OUTPUT -d 103.7.30.122 -j DROP
iptables -I OUTPUT -d 103.7.30.50 -j DROP
iptables -I OUTPUT -d 106.117.248.153 -j DROP
iptables -I OUTPUT -d 106.117.248.166 -j DROP
iptables -I OUTPUT -d 106.117.248.167 -j DROP
iptables -I OUTPUT -d 106.38.181.155 -j DROP
iptables -I OUTPUT -d 106.38.181.156 -j DROP
iptables -I OUTPUT -d 106.42.24.31 -j DROP
iptables -I OUTPUT -d 107.155.58.98 -j DROP
iptables -I OUTPUT -d 107.155.58.99 -j DROP
iptables -I OUTPUT -d 110.185.115.171 -j DROP
iptables -I OUTPUT -d 110.185.115.226 -j DROP
iptables -I OUTPUT -d 110.185.115.234 -j DROP
iptables -I OUTPUT -d 110.185.115.237 -j DROP
iptables -I OUTPUT -d 110.53.246.36 -j DROP
iptables -I OUTPUT -d 110.81.153.187 -j DROP
iptables -I OUTPUT -d 110.81.153.248 -j DROP
iptables -I OUTPUT -d 111.1.57.12 -j DROP
iptables -I OUTPUT -d 111.1.57.80 -j DROP
iptables -I OUTPUT -d 111.12.66.11 -j DROP
iptables -I OUTPUT -d 111.12.66.17 -j DROP
iptables -I OUTPUT -d 111.12.66.20 -j DROP
iptables -I OUTPUT -d 111.12.66.84 -j DROP
iptables -I OUTPUT -d 111.123.50.142 -j DROP
iptables -I OUTPUT -d 111.123.50.144 -j DROP
iptables -I OUTPUT -d 111.123.50.197 -j DROP
iptables -I OUTPUT -d 111.123.50.223 -j DROP
iptables -I OUTPUT -d 111.13.137.13 -j DROP
iptables -I OUTPUT -d 111.13.137.57 -j DROP
iptables -I OUTPUT -d 111.13.137.59 -j DROP
iptables -I OUTPUT -d 111.13.3.36 -j DROP
iptables -I OUTPUT -d 111.13.3.37 -j DROP
iptables -I OUTPUT -d 111.161.64.118 -j DROP
iptables -I OUTPUT -d 111.177.1.12 -j DROP
iptables -I OUTPUT -d 111.177.1.14 -j DROP
iptables -I OUTPUT -d 111.19.244.114 -j DROP
iptables -I OUTPUT -d 111.19.244.90 -j DROP
iptables -I OUTPUT -d 111.19.248.193 -j DROP
iptables -I OUTPUT -d 111.19.248.253 -j DROP
iptables -I OUTPUT -d 111.202.99.166 -j DROP
iptables -I OUTPUT -d 111.202.99.18 -j DROP
iptables -I OUTPUT -d 111.202.99.19 -j DROP
iptables -I OUTPUT -d 111.206.15.101 -j DROP
iptables -I OUTPUT -d 111.206.15.13 -j DROP
iptables -I OUTPUT -d 111.23.8.25 -j DROP
iptables -I OUTPUT -d 111.30.131.121 -j DROP
iptables -I OUTPUT -d 111.30.137.123 -j DROP
iptables -I OUTPUT -d 111.30.144.154 -j DROP
iptables -I OUTPUT -d 111.30.159.141 -j DROP
iptables -I OUTPUT -d 111.30.159.171 -j DROP
iptables -I OUTPUT -d 111.30.159.202 -j DROP
iptables -I OUTPUT -d 111.30.164.162 -j DROP
iptables -I OUTPUT -d 111.30.164.163 -j DROP
iptables -I OUTPUT -d 111.30.164.174 -j DROP
iptables -I OUTPUT -d 111.30.171.210 -j DROP
iptables -I OUTPUT -d 111.4.118.148 -j DROP
iptables -I OUTPUT -d 111.40.174.42 -j DROP
iptables -I OUTPUT -d 111.41.56.236 -j DROP
iptables -I OUTPUT -d 111.43.181.105 -j DROP
iptables -I OUTPUT -d 111.43.181.107 -j DROP
iptables -I OUTPUT -d 111.43.181.111 -j DROP
iptables -I OUTPUT -d 111.43.181.123 -j DROP
iptables -I OUTPUT -d 111.43.181.124 -j DROP
iptables -I OUTPUT -d 111.43.181.14 -j DROP
iptables -I OUTPUT -d 111.43.181.149 -j DROP
iptables -I OUTPUT -d 111.43.181.150 -j DROP
iptables -I OUTPUT -d 111.43.181.154 -j DROP
iptables -I OUTPUT -d 111.43.181.164 -j DROP
iptables -I OUTPUT -d 111.43.181.169 -j DROP
iptables -I OUTPUT -d 111.43.181.177 -j DROP
iptables -I OUTPUT -d 111.43.181.181 -j DROP
iptables -I OUTPUT -d 111.43.181.183 -j DROP
iptables -I OUTPUT -d 111.43.181.201 -j DROP
iptables -I OUTPUT -d 111.43.181.219 -j DROP
iptables -I OUTPUT -d 111.43.181.226 -j DROP
iptables -I OUTPUT -d 111.43.182.111 -j DROP
iptables -I OUTPUT -d 111.43.182.165 -j DROP
iptables -I OUTPUT -d 111.43.182.169 -j DROP
iptables -I OUTPUT -d 111.43.182.208 -j DROP
iptables -I OUTPUT -d 111.43.182.227 -j DROP
iptables -I OUTPUT -d 111.43.182.233 -j DROP
iptables -I OUTPUT -d 111.43.182.234 -j DROP
iptables -I OUTPUT -d 111.43.182.38 -j DROP
iptables -I OUTPUT -d 111.43.182.41 -j DROP
iptables -I OUTPUT -d 111.43.182.45 -j DROP
iptables -I OUTPUT -d 111.43.182.46 -j DROP
iptables -I OUTPUT -d 111.43.182.88 -j DROP
iptables -I OUTPUT -d 111.43.182.96 -j DROP
iptables -I OUTPUT -d 111.44.253.249 -j DROP
iptables -I OUTPUT -d 111.45.68.30 -j DROP
iptables -I OUTPUT -d 111.47.223.142 -j DROP
iptables -I OUTPUT -d 111.47.223.161 -j DROP
iptables -I OUTPUT -d 111.47.223.164 -j DROP
iptables -I OUTPUT -d 111.47.223.174 -j DROP
iptables -I OUTPUT -d 111.47.224.152 -j DROP
iptables -I OUTPUT -d 111.47.224.159 -j DROP
iptables -I OUTPUT -d 111.47.224.201 -j DROP
iptables -I OUTPUT -d 111.47.224.237 -j DROP
iptables -I OUTPUT -d 111.47.224.250 -j DROP
iptables -I OUTPUT -d 111.47.225.155 -j DROP
iptables -I OUTPUT -d 111.47.225.157 -j DROP
iptables -I OUTPUT -d 111.47.225.158 -j DROP
iptables -I OUTPUT -d 111.47.225.160 -j DROP
iptables -I OUTPUT -d 111.47.225.166 -j DROP
iptables -I OUTPUT -d 111.47.225.167 -j DROP
iptables -I OUTPUT -d 111.47.225.168 -j DROP
iptables -I OUTPUT -d 111.47.225.169 -j DROP
iptables -I OUTPUT -d 111.47.244.21 -j DROP
iptables -I OUTPUT -d 111.47.248.156 -j DROP
iptables -I OUTPUT -d 111.47.248.179 -j DROP
iptables -I OUTPUT -d 111.6.186.144 -j DROP
iptables -I OUTPUT -d 111.6.186.146 -j DROP
iptables -I OUTPUT -d 111.6.186.156 -j DROP
iptables -I OUTPUT -d 111.6.186.199 -j DROP
iptables -I OUTPUT -d 111.6.186.213 -j DROP
iptables -I OUTPUT -d 111.6.189.141 -j DROP
iptables -I OUTPUT -d 111.6.189.143 -j DROP
iptables -I OUTPUT -d 111.6.189.144 -j DROP
iptables -I OUTPUT -d 111.6.189.195 -j DROP
iptables -I OUTPUT -d 111.6.189.252 -j DROP
iptables -I OUTPUT -d 111.62.242.11 -j DROP
iptables -I OUTPUT -d 111.62.242.12 -j DROP
iptables -I OUTPUT -d 111.62.242.13 -j DROP
iptables -I OUTPUT -d 111.62.242.14 -j DROP
iptables -I OUTPUT -d 111.62.242.15 -j DROP
iptables -I OUTPUT -d 111.62.242.16 -j DROP
iptables -I OUTPUT -d 111.62.242.59 -j DROP
iptables -I OUTPUT -d 111.62.242.78 -j DROP
iptables -I OUTPUT -d 111.62.249.109 -j DROP
iptables -I OUTPUT -d 111.62.249.126 -j DROP
iptables -I OUTPUT -d 111.62.249.26 -j DROP
iptables -I OUTPUT -d 111.62.249.28 -j DROP
iptables -I OUTPUT -d 111.62.249.29 -j DROP
iptables -I OUTPUT -d 111.62.249.30 -j DROP
iptables -I OUTPUT -d 111.62.249.34 -j DROP
iptables -I OUTPUT -d 111.62.249.37 -j DROP
iptables -I OUTPUT -d 111.62.249.38 -j DROP
iptables -I OUTPUT -d 111.62.249.94 -j DROP
iptables -I OUTPUT -d 111.7.189.248 -j DROP
iptables -I OUTPUT -d 111.8.6.145 -j DROP
iptables -I OUTPUT -d 112.117.221.16 -j DROP
iptables -I OUTPUT -d 112.17.5.31 -j DROP
iptables -I OUTPUT -d 112.25.104.182 -j DROP
iptables -I OUTPUT -d 112.25.105.143 -j DROP
iptables -I OUTPUT -d 112.25.45.212 -j DROP
iptables -I OUTPUT -d 112.25.45.251 -j DROP
iptables -I OUTPUT -d 112.25.52.159 -j DROP
iptables -I OUTPUT -d 112.25.52.179 -j DROP
iptables -I OUTPUT -d 112.25.58.141 -j DROP
iptables -I OUTPUT -d 112.25.58.155 -j DROP
iptables -I OUTPUT -d 112.25.58.156 -j DROP
iptables -I OUTPUT -d 112.25.58.157 -j DROP
iptables -I OUTPUT -d 112.25.58.158 -j DROP
iptables -I OUTPUT -d 112.25.58.162 -j DROP
iptables -I OUTPUT -d 112.25.58.163 -j DROP
iptables -I OUTPUT -d 112.25.58.164 -j DROP
iptables -I OUTPUT -d 112.25.58.165 -j DROP
iptables -I OUTPUT -d 112.25.58.191 -j DROP
iptables -I OUTPUT -d 112.25.58.232 -j DROP
iptables -I OUTPUT -d 112.29.151.154 -j DROP
iptables -I OUTPUT -d 112.29.151.155 -j DROP
iptables -I OUTPUT -d 112.29.151.156 -j DROP
iptables -I OUTPUT -d 112.29.151.157 -j DROP
iptables -I OUTPUT -d 112.29.151.195 -j DROP
iptables -I OUTPUT -d 112.29.151.196 -j DROP
iptables -I OUTPUT -d 112.29.152.39 -j DROP
iptables -I OUTPUT -d 112.29.152.62 -j DROP
iptables -I OUTPUT -d 112.29.196.148 -j DROP
iptables -I OUTPUT -d 112.29.196.166 -j DROP
iptables -I OUTPUT -d 112.29.197.60 -j DROP
iptables -I OUTPUT -d 112.29.199.27 -j DROP
iptables -I OUTPUT -d 112.29.199.36 -j DROP
iptables -I OUTPUT -d 112.29.199.61 -j DROP
iptables -I OUTPUT -d 112.29.207.210 -j DROP
iptables -I OUTPUT -d 112.29.208.101 -j DROP
iptables -I OUTPUT -d 112.29.208.11 -j DROP
iptables -I OUTPUT -d 112.29.208.12 -j DROP
iptables -I OUTPUT -d 112.29.208.13 -j DROP
iptables -I OUTPUT -d 112.29.208.14 -j DROP
iptables -I OUTPUT -d 112.29.208.31 -j DROP
iptables -I OUTPUT -d 112.29.212.205 -j DROP
iptables -I OUTPUT -d 112.47.23.216 -j DROP
iptables -I OUTPUT -d 112.47.23.222 -j DROP
iptables -I OUTPUT -d 112.47.4.141 -j DROP
iptables -I OUTPUT -d 112.47.4.202 -j DROP
iptables -I OUTPUT -d 112.47.4.204 -j DROP
iptables -I OUTPUT -d 112.47.9.12 -j DROP
iptables -I OUTPUT -d 112.47.9.126 -j DROP
iptables -I OUTPUT -d 112.47.9.24 -j DROP
iptables -I OUTPUT -d 112.47.9.25 -j DROP
iptables -I OUTPUT -d 112.47.9.30 -j DROP
iptables -I OUTPUT -d 112.47.9.40 -j DROP
iptables -I OUTPUT -d 112.53.25.178 -j DROP
iptables -I OUTPUT -d 112.53.26.102 -j DROP
iptables -I OUTPUT -d 112.53.26.203 -j DROP
iptables -I OUTPUT -d 112.53.26.81 -j DROP
iptables -I OUTPUT -d 112.60.0.231 -j DROP
iptables -I OUTPUT -d 112.60.0.234 -j DROP
iptables -I OUTPUT -d 112.60.8.109 -j DROP
iptables -I OUTPUT -d 112.65.212.43 -j DROP
iptables -I OUTPUT -d 112.90.149.80 -j DROP
iptables -I OUTPUT -d 112.90.149.85 -j DROP
iptables -I OUTPUT -d 112.90.149.87 -j DROP
iptables -I OUTPUT -d 112.90.83.46 -j DROP
iptables -I OUTPUT -d 113.105.141.220 -j DROP
iptables -I OUTPUT -d 113.105.73.144 -j DROP
iptables -I OUTPUT -d 113.105.73.145 -j DROP
iptables -I OUTPUT -d 113.107.216.36 -j DROP
iptables -I OUTPUT -d 113.107.238.24 -j DROP
iptables -I OUTPUT -d 113.107.238.25 -j DROP
iptables -I OUTPUT -d 113.137.62.89 -j DROP
iptables -I OUTPUT -d 113.142.52.139 -j DROP
iptables -I OUTPUT -d 113.142.52.145 -j DROP
iptables -I OUTPUT -d 113.142.52.173 -j DROP
iptables -I OUTPUT -d 113.200.17.153 -j DROP
iptables -I OUTPUT -d 113.200.90.146 -j DROP
iptables -I OUTPUT -d 113.200.90.151 -j DROP
iptables -I OUTPUT -d 113.96.156.141 -j DROP
iptables -I OUTPUT -d 113.96.156.142 -j DROP
iptables -I OUTPUT -d 113.96.156.143 -j DROP
iptables -I OUTPUT -d 113.96.156.144 -j DROP
iptables -I OUTPUT -d 113.96.156.226 -j DROP
iptables -I OUTPUT -d 113.96.208.233 -j DROP
iptables -I OUTPUT -d 113.96.232.76 -j DROP
iptables -I OUTPUT -d 113.96.232.92 -j DROP
iptables -I OUTPUT -d 114.106.160.91 -j DROP
iptables -I OUTPUT -d 115.231.37.204 -j DROP
iptables -I OUTPUT -d 116.1.237.164 -j DROP
iptables -I OUTPUT -d 116.128.163.23 -j DROP
iptables -I OUTPUT -d 116.128.164.37 -j DROP
iptables -I OUTPUT -d 116.153.4.59 -j DROP
iptables -I OUTPUT -d 116.211.104.82 -j DROP
iptables -I OUTPUT -d 116.211.104.83 -j DROP
iptables -I OUTPUT -d 116.211.185.158 -j DROP
iptables -I OUTPUT -d 116.211.185.159 -j DROP
iptables -I OUTPUT -d 116.211.185.195 -j DROP
iptables -I OUTPUT -d 116.211.185.244 -j DROP
iptables -I OUTPUT -d 116.211.185.35 -j DROP
iptables -I OUTPUT -d 116.211.73.32 -j DROP
iptables -I OUTPUT -d 116.211.73.33 -j DROP
iptables -I OUTPUT -d 116.55.250.25 -j DROP
iptables -I OUTPUT -d 117.131.201.35 -j DROP
iptables -I OUTPUT -d 117.131.201.36 -j DROP
iptables -I OUTPUT -d 117.144.243.186 -j DROP
iptables -I OUTPUT -d 117.156.18.17 -j DROP
iptables -I OUTPUT -d 117.156.18.19 -j DROP
iptables -I OUTPUT -d 117.156.18.20 -j DROP
iptables -I OUTPUT -d 117.156.18.22 -j DROP
iptables -I OUTPUT -d 117.156.18.25 -j DROP
iptables -I OUTPUT -d 117.156.18.29 -j DROP
iptables -I OUTPUT -d 117.156.18.32 -j DROP
iptables -I OUTPUT -d 117.156.18.35 -j DROP
iptables -I OUTPUT -d 117.156.18.37 -j DROP
iptables -I OUTPUT -d 117.156.18.50 -j DROP
iptables -I OUTPUT -d 117.156.18.51 -j DROP
iptables -I OUTPUT -d 117.156.18.52 -j DROP
iptables -I OUTPUT -d 117.156.18.53 -j DROP
iptables -I OUTPUT -d 117.156.18.54 -j DROP
iptables -I OUTPUT -d 117.156.18.55 -j DROP
iptables -I OUTPUT -d 117.156.18.57 -j DROP
iptables -I OUTPUT -d 117.156.18.58 -j DROP
iptables -I OUTPUT -d 117.156.18.95 -j DROP
iptables -I OUTPUT -d 117.156.18.96 -j DROP
iptables -I OUTPUT -d 117.156.18.98 -j DROP
iptables -I OUTPUT -d 117.169.101.58 -j DROP
iptables -I OUTPUT -d 117.169.16.26 -j DROP
iptables -I OUTPUT -d 117.169.71.168 -j DROP
iptables -I OUTPUT -d 117.169.71.170 -j DROP
iptables -I OUTPUT -d 117.169.71.230 -j DROP
iptables -I OUTPUT -d 117.169.97.219 -j DROP
iptables -I OUTPUT -d 117.169.98.113 -j DROP
iptables -I OUTPUT -d 117.169.98.114 -j DROP
iptables -I OUTPUT -d 117.169.98.115 -j DROP
iptables -I OUTPUT -d 117.169.98.75 -j DROP
iptables -I OUTPUT -d 117.172.5.20 -j DROP
iptables -I OUTPUT -d 117.177.223.155 -j DROP
iptables -I OUTPUT -d 117.177.223.169 -j DROP
iptables -I OUTPUT -d 117.177.223.212 -j DROP
iptables -I OUTPUT -d 117.177.223.229 -j DROP
iptables -I OUTPUT -d 117.184.242.222 -j DROP
iptables -I OUTPUT -d 117.21.180.23 -j DROP
iptables -I OUTPUT -d 117.21.180.92 -j DROP
iptables -I OUTPUT -d 117.41.241.144 -j DROP
iptables -I OUTPUT -d 117.41.241.167 -j DROP
iptables -I OUTPUT -d 117.41.241.170 -j DROP
iptables -I OUTPUT -d 117.41.241.238 -j DROP
iptables -I OUTPUT -d 117.41.243.19 -j DROP
iptables -I OUTPUT -d 117.41.243.24 -j DROP
iptables -I OUTPUT -d 117.41.243.27 -j DROP
iptables -I OUTPUT -d 117.41.243.29 -j DROP
iptables -I OUTPUT -d 117.41.243.32 -j DROP
iptables -I OUTPUT -d 117.41.243.33 -j DROP
iptables -I OUTPUT -d 117.41.243.36 -j DROP
iptables -I OUTPUT -d 117.41.243.38 -j DROP
iptables -I OUTPUT -d 117.41.243.39 -j DROP
iptables -I OUTPUT -d 117.41.243.45 -j DROP
iptables -I OUTPUT -d 117.41.243.46 -j DROP
iptables -I OUTPUT -d 117.41.243.47 -j DROP
iptables -I OUTPUT -d 118.112.11.100 -j DROP
iptables -I OUTPUT -d 118.112.11.13 -j DROP
iptables -I OUTPUT -d 118.112.11.139 -j DROP
iptables -I OUTPUT -d 118.112.11.14 -j DROP
iptables -I OUTPUT -d 118.112.11.142 -j DROP
iptables -I OUTPUT -d 118.112.11.145 -j DROP
iptables -I OUTPUT -d 118.112.11.158 -j DROP
iptables -I OUTPUT -d 118.112.11.163 -j DROP
iptables -I OUTPUT -d 118.112.11.173 -j DROP
iptables -I OUTPUT -d 118.112.11.18 -j DROP
iptables -I OUTPUT -d 118.112.22.141 -j DROP
iptables -I OUTPUT -d 118.112.22.142 -j DROP
iptables -I OUTPUT -d 118.112.22.143 -j DROP
iptables -I OUTPUT -d 118.112.22.144 -j DROP
iptables -I OUTPUT -d 118.112.22.145 -j DROP
iptables -I OUTPUT -d 118.112.22.202 -j DROP
iptables -I OUTPUT -d 118.112.22.251 -j DROP
iptables -I OUTPUT -d 118.112.23.11 -j DROP
iptables -I OUTPUT -d 118.112.23.16 -j DROP
iptables -I OUTPUT -d 118.112.23.17 -j DROP
iptables -I OUTPUT -d 118.112.23.18 -j DROP
iptables -I OUTPUT -d 118.112.23.95 -j DROP
iptables -I OUTPUT -d 118.112.24.79 -j DROP
iptables -I OUTPUT -d 118.112.25.126 -j DROP
iptables -I OUTPUT -d 118.112.26.209 -j DROP
iptables -I OUTPUT -d 118.180.26.39 -j DROP
iptables -I OUTPUT -d 118.180.30.158 -j DROP
iptables -I OUTPUT -d 118.180.30.159 -j DROP
iptables -I OUTPUT -d 118.180.30.160 -j DROP
iptables -I OUTPUT -d 118.180.30.230 -j DROP
iptables -I OUTPUT -d 118.180.31.100 -j DROP
iptables -I OUTPUT -d 118.180.31.145 -j DROP
iptables -I OUTPUT -d 118.180.31.151 -j DROP
iptables -I OUTPUT -d 118.180.31.152 -j DROP
iptables -I OUTPUT -d 118.180.31.157 -j DROP
iptables -I OUTPUT -d 118.180.31.159 -j DROP
iptables -I OUTPUT -d 118.180.31.165 -j DROP
iptables -I OUTPUT -d 118.212.137.11 -j DROP
iptables -I OUTPUT -d 118.212.137.19 -j DROP
iptables -I OUTPUT -d 118.212.145.162 -j DROP
iptables -I OUTPUT -d 118.212.226.24 -j DROP
iptables -I OUTPUT -d 118.212.226.25 -j DROP
iptables -I OUTPUT -d 118.212.226.27 -j DROP
iptables -I OUTPUT -d 118.212.226.53 -j DROP
iptables -I OUTPUT -d 119.147.227.100 -j DROP
iptables -I OUTPUT -d 119.147.227.103 -j DROP
iptables -I OUTPUT -d 119.147.227.11 -j DROP
iptables -I OUTPUT -d 119.147.227.113 -j DROP
iptables -I OUTPUT -d 119.147.227.12 -j DROP
iptables -I OUTPUT -d 119.147.227.13 -j DROP
iptables -I OUTPUT -d 119.147.227.14 -j DROP
iptables -I OUTPUT -d 119.147.227.15 -j DROP
iptables -I OUTPUT -d 119.147.227.16 -j DROP
iptables -I OUTPUT -d 119.147.227.27 -j DROP
iptables -I OUTPUT -d 119.147.227.35 -j DROP
iptables -I OUTPUT -d 119.147.33.11 -j DROP
iptables -I OUTPUT -d 119.147.33.123 -j DROP
iptables -I OUTPUT -d 119.147.33.25 -j DROP
iptables -I OUTPUT -d 119.147.33.26 -j DROP
iptables -I OUTPUT -d 119.147.33.36 -j DROP
iptables -I OUTPUT -d 119.147.33.38 -j DROP
iptables -I OUTPUT -d 119.147.33.39 -j DROP
iptables -I OUTPUT -d 119.147.33.49 -j DROP
iptables -I OUTPUT -d 119.147.33.87 -j DROP
iptables -I OUTPUT -d 119.147.33.90 -j DROP
iptables -I OUTPUT -d 119.147.83.11 -j DROP
iptables -I OUTPUT -d 119.147.83.73 -j DROP
iptables -I OUTPUT -d 119.167.134.109 -j DROP
iptables -I OUTPUT -d 119.167.134.123 -j DROP
iptables -I OUTPUT -d 119.167.141.100 -j DROP
iptables -I OUTPUT -d 119.167.216.174 -j DROP
iptables -I OUTPUT -d 119.167.217.123 -j DROP
iptables -I OUTPUT -d 119.167.217.57 -j DROP
iptables -I OUTPUT -d 119.167.217.80 -j DROP
iptables -I OUTPUT -d 119.188.206.20 -j DROP
iptables -I OUTPUT -d 119.188.47.164 -j DROP
iptables -I OUTPUT -d 119.249.49.11 -j DROP
iptables -I OUTPUT -d 119.249.49.12 -j DROP
iptables -I OUTPUT -d 119.249.49.13 -j DROP
iptables -I OUTPUT -d 119.249.49.14 -j DROP
iptables -I OUTPUT -d 119.249.49.15 -j DROP
iptables -I OUTPUT -d 119.28.164.141 -j DROP
iptables -I OUTPUT -d 119.28.164.202 -j DROP
iptables -I OUTPUT -d 119.28.164.203 -j DROP
iptables -I OUTPUT -d 119.28.164.219 -j DROP
iptables -I OUTPUT -d 119.28.164.220 -j DROP
iptables -I OUTPUT -d 119.28.164.222 -j DROP
iptables -I OUTPUT -d 119.28.164.223 -j DROP
iptables -I OUTPUT -d 119.36.226.212 -j DROP
iptables -I OUTPUT -d 119.36.226.238 -j DROP
iptables -I OUTPUT -d 119.39.120.11 -j DROP
iptables -I OUTPUT -d 119.39.120.12 -j DROP
iptables -I OUTPUT -d 119.39.120.125 -j DROP
iptables -I OUTPUT -d 119.39.120.15 -j DROP
iptables -I OUTPUT -d 119.84.106.17 -j DROP
iptables -I OUTPUT -d 119.84.68.160 -j DROP
iptables -I OUTPUT -d 119.84.99.178 -j DROP
iptables -I OUTPUT -d 120.192.69.161 -j DROP
iptables -I OUTPUT -d 120.192.69.222 -j DROP
iptables -I OUTPUT -d 120.198.199.176 -j DROP
iptables -I OUTPUT -d 120.198.199.212 -j DROP
iptables -I OUTPUT -d 120.198.199.213 -j DROP
iptables -I OUTPUT -d 120.198.235.248 -j DROP
iptables -I OUTPUT -d 120.204.205.142 -j DROP
iptables -I OUTPUT -d 120.204.205.154 -j DROP
iptables -I OUTPUT -d 120.204.205.155 -j DROP
iptables -I OUTPUT -d 120.204.205.188 -j DROP
iptables -I OUTPUT -d 120.204.205.200 -j DROP
iptables -I OUTPUT -d 120.204.205.210 -j DROP
iptables -I OUTPUT -d 120.209.135.150 -j DROP
iptables -I OUTPUT -d 120.209.135.194 -j DROP
iptables -I OUTPUT -d 120.210.222.14 -j DROP
iptables -I OUTPUT -d 120.210.222.150 -j DROP
iptables -I OUTPUT -d 120.210.222.20 -j DROP
iptables -I OUTPUT -d 120.220.188.141 -j DROP
iptables -I OUTPUT -d 120.220.188.16 -j DROP
iptables -I OUTPUT -d 120.220.188.160 -j DROP
iptables -I OUTPUT -d 120.220.188.80 -j DROP
iptables -I OUTPUT -d 120.221.14.36 -j DROP
iptables -I OUTPUT -d 120.221.14.47 -j DROP
iptables -I OUTPUT -d 120.221.143.104 -j DROP
iptables -I OUTPUT -d 120.221.143.61 -j DROP
iptables -I OUTPUT -d 120.221.143.80 -j DROP
iptables -I OUTPUT -d 120.221.143.90 -j DROP
iptables -I OUTPUT -d 120.221.218.144 -j DROP
iptables -I OUTPUT -d 120.221.218.145 -j DROP
iptables -I OUTPUT -d 120.221.218.164 -j DROP
iptables -I OUTPUT -d 120.221.218.233 -j DROP
iptables -I OUTPUT -d 120.221.218.241 -j DROP
iptables -I OUTPUT -d 120.221.227.193 -j DROP
iptables -I OUTPUT -d 120.221.227.235 -j DROP
iptables -I OUTPUT -d 120.221.31.36 -j DROP
iptables -I OUTPUT -d 120.221.97.123 -j DROP
iptables -I OUTPUT -d 120.221.97.188 -j DROP
iptables -I OUTPUT -d 120.221.97.204 -j DROP
iptables -I OUTPUT -d 120.221.97.240 -j DROP
iptables -I OUTPUT -d 120.221.97.253 -j DROP
iptables -I OUTPUT -d 120.221.97.78 -j DROP
iptables -I OUTPUT -d 120.232.196.221 -j DROP
iptables -I OUTPUT -d 120.233.38.109 -j DROP
iptables -I OUTPUT -d 120.233.38.11 -j DROP
iptables -I OUTPUT -d 120.233.38.42 -j DROP
iptables -I OUTPUT -d 120.233.38.43 -j DROP
iptables -I OUTPUT -d 120.233.38.44 -j DROP
iptables -I OUTPUT -d 120.233.38.76 -j DROP
iptables -I OUTPUT -d 120.241.139.207 -j DROP
iptables -I OUTPUT -d 120.241.186.33 -j DROP
iptables -I OUTPUT -d 120.241.186.36 -j DROP
iptables -I OUTPUT -d 120.241.186.38 -j DROP
iptables -I OUTPUT -d 120.241.186.40 -j DROP
iptables -I OUTPUT -d 120.241.186.52 -j DROP
iptables -I OUTPUT -d 120.241.186.99 -j DROP
iptables -I OUTPUT -d 120.241.190.163 -j DROP
iptables -I OUTPUT -d 120.241.30.143 -j DROP
iptables -I OUTPUT -d 120.241.30.144 -j DROP
iptables -I OUTPUT -d 120.241.30.145 -j DROP
iptables -I OUTPUT -d 120.241.30.148 -j DROP
iptables -I OUTPUT -d 120.241.30.174 -j DROP
iptables -I OUTPUT -d 120.241.30.188 -j DROP
iptables -I OUTPUT -d 120.241.30.195 -j DROP
iptables -I OUTPUT -d 120.241.30.219 -j DROP
iptables -I OUTPUT -d 120.33.50.100 -j DROP
iptables -I OUTPUT -d 120.33.50.50 -j DROP
iptables -I OUTPUT -d 120.33.50.51 -j DROP
iptables -I OUTPUT -d 120.33.50.52 -j DROP
iptables -I OUTPUT -d 120.37.140.74 -j DROP
iptables -I OUTPUT -d 120.41.44.152 -j DROP
iptables -I OUTPUT -d 120.41.44.170 -j DROP
iptables -I OUTPUT -d 120.41.44.31 -j DROP
iptables -I OUTPUT -d 120.41.44.32 -j DROP
iptables -I OUTPUT -d 120.41.44.33 -j DROP
iptables -I OUTPUT -d 120.41.44.34 -j DROP
iptables -I OUTPUT -d 120.41.44.35 -j DROP
iptables -I OUTPUT -d 121.14.88.11 -j DROP
iptables -I OUTPUT -d 121.14.88.12 -j DROP
iptables -I OUTPUT -d 121.14.88.13 -j DROP
iptables -I OUTPUT -d 121.14.88.14 -j DROP
iptables -I OUTPUT -d 121.14.88.15 -j DROP
iptables -I OUTPUT -d 121.14.88.16 -j DROP
iptables -I OUTPUT -d 121.14.88.17 -j DROP
iptables -I OUTPUT -d 121.14.88.18 -j DROP
iptables -I OUTPUT -d 121.14.88.20 -j DROP
iptables -I OUTPUT -d 121.14.88.21 -j DROP
iptables -I OUTPUT -d 121.14.88.22 -j DROP
iptables -I OUTPUT -d 121.14.88.23 -j DROP
iptables -I OUTPUT -d 121.14.88.24 -j DROP
iptables -I OUTPUT -d 121.14.88.25 -j DROP
iptables -I OUTPUT -d 121.14.88.26 -j DROP
iptables -I OUTPUT -d 121.14.88.27 -j DROP
iptables -I OUTPUT -d 121.14.88.28 -j DROP
iptables -I OUTPUT -d 121.14.88.29 -j DROP
iptables -I OUTPUT -d 121.14.88.30 -j DROP
iptables -I OUTPUT -d 121.14.88.31 -j DROP
iptables -I OUTPUT -d 121.14.88.32 -j DROP
iptables -I OUTPUT -d 121.14.88.33 -j DROP
iptables -I OUTPUT -d 121.14.88.34 -j DROP
iptables -I OUTPUT -d 121.14.88.35 -j DROP
iptables -I OUTPUT -d 121.14.88.36 -j DROP
iptables -I OUTPUT -d 121.14.88.37 -j DROP
iptables -I OUTPUT -d 121.14.88.38 -j DROP
iptables -I OUTPUT -d 121.14.88.39 -j DROP
iptables -I OUTPUT -d 121.14.88.40 -j DROP
iptables -I OUTPUT -d 121.14.88.41 -j DROP
iptables -I OUTPUT -d 121.14.88.42 -j DROP
iptables -I OUTPUT -d 121.14.88.43 -j DROP
iptables -I OUTPUT -d 121.14.88.44 -j DROP
iptables -I OUTPUT -d 121.14.88.45 -j DROP
iptables -I OUTPUT -d 121.14.88.46 -j DROP
iptables -I OUTPUT -d 121.14.88.47 -j DROP
iptables -I OUTPUT -d 121.14.88.48 -j DROP
iptables -I OUTPUT -d 121.14.88.49 -j DROP
iptables -I OUTPUT -d 121.14.88.50 -j DROP
iptables -I OUTPUT -d 121.14.88.51 -j DROP
iptables -I OUTPUT -d 121.14.88.52 -j DROP
iptables -I OUTPUT -d 121.14.88.53 -j DROP
iptables -I OUTPUT -d 121.14.88.54 -j DROP
iptables -I OUTPUT -d 121.14.88.55 -j DROP
iptables -I OUTPUT -d 121.14.88.56 -j DROP
iptables -I OUTPUT -d 121.14.88.57 -j DROP
iptables -I OUTPUT -d 121.29.54.152 -j DROP
iptables -I OUTPUT -d 121.29.54.156 -j DROP
iptables -I OUTPUT -d 121.29.54.171 -j DROP
iptables -I OUTPUT -d 121.29.54.222 -j DROP
iptables -I OUTPUT -d 121.31.22.152 -j DROP
iptables -I OUTPUT -d 121.51.118.37 -j DROP
iptables -I OUTPUT -d 121.51.131.211 -j DROP
iptables -I OUTPUT -d 121.51.141.78 -j DROP
iptables -I OUTPUT -d 121.51.142.189 -j DROP
iptables -I OUTPUT -d 121.51.142.27 -j DROP
iptables -I OUTPUT -d 121.51.175.100 -j DROP
iptables -I OUTPUT -d 121.51.175.118 -j DROP
iptables -I OUTPUT -d 121.51.175.56 -j DROP
iptables -I OUTPUT -d 121.51.175.70 -j DROP
iptables -I OUTPUT -d 121.51.175.81 -j DROP
iptables -I OUTPUT -d 121.51.18.62 -j DROP
iptables -I OUTPUT -d 121.51.23.243 -j DROP
iptables -I OUTPUT -d 121.51.40.100 -j DROP
iptables -I OUTPUT -d 121.51.93.19 -j DROP
iptables -I OUTPUT -d 122.225.36.51 -j DROP
iptables -I OUTPUT -d 122.228.0.139 -j DROP
iptables -I OUTPUT -d 122.228.0.141 -j DROP
iptables -I OUTPUT -d 122.228.56.150 -j DROP
iptables -I OUTPUT -d 122.228.56.151 -j DROP
iptables -I OUTPUT -d 122.228.56.153 -j DROP
iptables -I OUTPUT -d 122.228.72.155 -j DROP
iptables -I OUTPUT -d 122.228.72.183 -j DROP
iptables -I OUTPUT -d 123.125.110.142 -j DROP
iptables -I OUTPUT -d 123.125.110.146 -j DROP
iptables -I OUTPUT -d 123.125.110.15 -j DROP
iptables -I OUTPUT -d 123.125.110.16 -j DROP
iptables -I OUTPUT -d 123.125.110.17 -j DROP
iptables -I OUTPUT -d 123.125.110.18 -j DROP
iptables -I OUTPUT -d 123.125.110.249 -j DROP
iptables -I OUTPUT -d 123.125.110.27 -j DROP
iptables -I OUTPUT -d 123.125.46.166 -j DROP
iptables -I OUTPUT -d 123.125.46.36 -j DROP
iptables -I OUTPUT -d 123.125.9.11 -j DROP
iptables -I OUTPUT -d 123.125.9.12 -j DROP
iptables -I OUTPUT -d 123.125.9.13 -j DROP
iptables -I OUTPUT -d 123.125.9.15 -j DROP
iptables -I OUTPUT -d 123.125.9.79 -j DROP
iptables -I OUTPUT -d 123.125.9.91 -j DROP
iptables -I OUTPUT -d 123.125.9.94 -j DROP
iptables -I OUTPUT -d 123.126.121.160 -j DROP
iptables -I OUTPUT -d 123.129.203.155 -j DROP
iptables -I OUTPUT -d 123.129.203.156 -j DROP
iptables -I OUTPUT -d 123.138.162.112 -j DROP
iptables -I OUTPUT -d 123.138.162.119 -j DROP
iptables -I OUTPUT -d 123.138.162.120 -j DROP
iptables -I OUTPUT -d 123.138.58.12 -j DROP
iptables -I OUTPUT -d 123.138.58.13 -j DROP
iptables -I OUTPUT -d 123.138.58.60 -j DROP
iptables -I OUTPUT -d 123.150.174.156 -j DROP
iptables -I OUTPUT -d 123.150.174.165 -j DROP
iptables -I OUTPUT -d 123.150.174.225 -j DROP
iptables -I OUTPUT -d 123.150.174.227 -j DROP
iptables -I OUTPUT -d 123.150.76.208 -j DROP
iptables -I OUTPUT -d 123.151.137.122 -j DROP
iptables -I OUTPUT -d 123.151.139.116 -j DROP
iptables -I OUTPUT -d 123.151.139.117 -j DROP
iptables -I OUTPUT -d 123.151.15.197 -j DROP
iptables -I OUTPUT -d 123.151.152.51 -j DROP
iptables -I OUTPUT -d 123.151.152.66 -j DROP
iptables -I OUTPUT -d 123.151.179.175 -j DROP
iptables -I OUTPUT -d 123.151.190.175 -j DROP
iptables -I OUTPUT -d 123.151.190.176 -j DROP
iptables -I OUTPUT -d 123.151.190.177 -j DROP
iptables -I OUTPUT -d 123.151.190.178 -j DROP
iptables -I OUTPUT -d 123.151.190.217 -j DROP
iptables -I OUTPUT -d 123.151.72.63 -j DROP
iptables -I OUTPUT -d 123.151.72.85 -j DROP
iptables -I OUTPUT -d 123.155.153.148 -j DROP
iptables -I OUTPUT -d 123.161.59.60 -j DROP
iptables -I OUTPUT -d 123.246.132.25 -j DROP
iptables -I OUTPUT -d 123.246.132.64 -j DROP
iptables -I OUTPUT -d 123.6.0.12 -j DROP
iptables -I OUTPUT -d 123.6.0.13 -j DROP
iptables -I OUTPUT -d 123.6.0.14 -j DROP
iptables -I OUTPUT -d 123.6.0.15 -j DROP
iptables -I OUTPUT -d 123.6.0.60 -j DROP
iptables -I OUTPUT -d 123.6.1.107 -j DROP
iptables -I OUTPUT -d 123.6.1.13 -j DROP
iptables -I OUTPUT -d 123.6.1.22 -j DROP
iptables -I OUTPUT -d 123.6.1.26 -j DROP
iptables -I OUTPUT -d 123.6.1.27 -j DROP
iptables -I OUTPUT -d 123.6.1.28 -j DROP
iptables -I OUTPUT -d 123.6.1.29 -j DROP
iptables -I OUTPUT -d 123.6.1.30 -j DROP
iptables -I OUTPUT -d 123.6.1.31 -j DROP
iptables -I OUTPUT -d 123.6.1.36 -j DROP
iptables -I OUTPUT -d 123.6.1.37 -j DROP
iptables -I OUTPUT -d 123.6.1.38 -j DROP
iptables -I OUTPUT -d 123.6.1.39 -j DROP
iptables -I OUTPUT -d 123.6.1.40 -j DROP
iptables -I OUTPUT -d 123.6.1.41 -j DROP
iptables -I OUTPUT -d 123.6.1.42 -j DROP
iptables -I OUTPUT -d 123.6.1.43 -j DROP
iptables -I OUTPUT -d 123.6.1.59 -j DROP
iptables -I OUTPUT -d 123.6.1.62 -j DROP
iptables -I OUTPUT -d 123.6.1.66 -j DROP
iptables -I OUTPUT -d 123.6.1.86 -j DROP
iptables -I OUTPUT -d 123.6.1.91 -j DROP
iptables -I OUTPUT -d 123.6.2.170 -j DROP
iptables -I OUTPUT -d 123.6.2.45 -j DROP
iptables -I OUTPUT -d 123.6.4.101 -j DROP
iptables -I OUTPUT -d 123.6.4.11 -j DROP
iptables -I OUTPUT -d 123.6.4.12 -j DROP
iptables -I OUTPUT -d 123.6.4.123 -j DROP
iptables -I OUTPUT -d 123.6.4.13 -j DROP
iptables -I OUTPUT -d 123.6.4.14 -j DROP
iptables -I OUTPUT -d 123.6.4.15 -j DROP
iptables -I OUTPUT -d 123.6.4.16 -j DROP
iptables -I OUTPUT -d 123.6.4.235 -j DROP
iptables -I OUTPUT -d 123.6.4.73 -j DROP
iptables -I OUTPUT -d 123.6.4.88 -j DROP
iptables -I OUTPUT -d 123.6.6.119 -j DROP
iptables -I OUTPUT -d 123.6.6.19 -j DROP
iptables -I OUTPUT -d 123.6.6.20 -j DROP
iptables -I OUTPUT -d 123.6.6.22 -j DROP
iptables -I OUTPUT -d 123.6.6.42 -j DROP
iptables -I OUTPUT -d 124.14.21.20 -j DROP
iptables -I OUTPUT -d 124.225.105.103 -j DROP
iptables -I OUTPUT -d 124.225.105.120 -j DROP
iptables -I OUTPUT -d 124.225.105.13 -j DROP
iptables -I OUTPUT -d 124.225.105.14 -j DROP
iptables -I OUTPUT -d 124.225.105.32 -j DROP
iptables -I OUTPUT -d 124.225.105.72 -j DROP
iptables -I OUTPUT -d 124.225.105.95 -j DROP
iptables -I OUTPUT -d 124.226.64.23 -j DROP
iptables -I OUTPUT -d 124.226.64.24 -j DROP
iptables -I OUTPUT -d 124.226.64.27 -j DROP
iptables -I OUTPUT -d 124.227.184.145 -j DROP
iptables -I OUTPUT -d 124.227.184.159 -j DROP
iptables -I OUTPUT -d 124.227.184.37 -j DROP
iptables -I OUTPUT -d 124.227.184.69 -j DROP
iptables -I OUTPUT -d 124.227.184.71 -j DROP
iptables -I OUTPUT -d 124.236.32.104 -j DROP
iptables -I OUTPUT -d 124.236.35.108 -j DROP
iptables -I OUTPUT -d 124.236.35.11 -j DROP
iptables -I OUTPUT -d 124.236.35.15 -j DROP
iptables -I OUTPUT -d 124.95.173.114 -j DROP
iptables -I OUTPUT -d 124.95.173.180 -j DROP
iptables -I OUTPUT -d 125.211.204.22 -j DROP
iptables -I OUTPUT -d 125.211.204.23 -j DROP
iptables -I OUTPUT -d 125.39.171.12 -j DROP
iptables -I OUTPUT -d 125.39.171.14 -j DROP
iptables -I OUTPUT -d 125.39.171.15 -j DROP
iptables -I OUTPUT -d 125.39.171.16 -j DROP
iptables -I OUTPUT -d 125.39.171.19 -j DROP
iptables -I OUTPUT -d 125.39.171.21 -j DROP
iptables -I OUTPUT -d 125.39.171.25 -j DROP
iptables -I OUTPUT -d 125.39.171.26 -j DROP
iptables -I OUTPUT -d 125.39.171.30 -j DROP
iptables -I OUTPUT -d 125.39.171.33 -j DROP
iptables -I OUTPUT -d 125.39.171.35 -j DROP
iptables -I OUTPUT -d 125.39.171.37 -j DROP
iptables -I OUTPUT -d 125.39.171.38 -j DROP
iptables -I OUTPUT -d 125.39.171.41 -j DROP
iptables -I OUTPUT -d 125.39.171.42 -j DROP
iptables -I OUTPUT -d 125.39.171.43 -j DROP
iptables -I OUTPUT -d 125.39.213.25 -j DROP
iptables -I OUTPUT -d 125.39.213.30 -j DROP
iptables -I OUTPUT -d 125.39.213.63 -j DROP
iptables -I OUTPUT -d 125.39.247.214 -j DROP
iptables -I OUTPUT -d 125.39.6.16 -j DROP
iptables -I OUTPUT -d 125.39.6.17 -j DROP
iptables -I OUTPUT -d 125.39.6.234 -j DROP
iptables -I OUTPUT -d 125.74.5.218 -j DROP
iptables -I OUTPUT -d 125.74.5.232 -j DROP
iptables -I OUTPUT -d 125.78.246.86 -j DROP
iptables -I OUTPUT -d 125.78.246.87 -j DROP
iptables -I OUTPUT -d 125.78.246.89 -j DROP
iptables -I OUTPUT -d 125.78.246.90 -j DROP
iptables -I OUTPUT -d 125.78.252.143 -j DROP
iptables -I OUTPUT -d 125.78.252.144 -j DROP
iptables -I OUTPUT -d 125.78.252.145 -j DROP
iptables -I OUTPUT -d 125.78.252.147 -j DROP
iptables -I OUTPUT -d 125.78.252.149 -j DROP
iptables -I OUTPUT -d 125.78.252.150 -j DROP
iptables -I OUTPUT -d 125.78.252.151 -j DROP
iptables -I OUTPUT -d 125.78.252.152 -j DROP
iptables -I OUTPUT -d 125.78.252.153 -j DROP
iptables -I OUTPUT -d 125.78.252.154 -j DROP
iptables -I OUTPUT -d 125.78.252.155 -j DROP
iptables -I OUTPUT -d 125.78.252.156 -j DROP
iptables -I OUTPUT -d 125.78.252.157 -j DROP
iptables -I OUTPUT -d 125.78.252.158 -j DROP
iptables -I OUTPUT -d 125.78.252.159 -j DROP
iptables -I OUTPUT -d 125.78.252.160 -j DROP
iptables -I OUTPUT -d 125.78.252.162 -j DROP
iptables -I OUTPUT -d 125.78.252.163 -j DROP
iptables -I OUTPUT -d 125.78.252.164 -j DROP
iptables -I OUTPUT -d 125.78.252.165 -j DROP
iptables -I OUTPUT -d 125.78.252.166 -j DROP
iptables -I OUTPUT -d 125.78.252.167 -j DROP
iptables -I OUTPUT -d 125.78.252.168 -j DROP
iptables -I OUTPUT -d 125.78.252.169 -j DROP
iptables -I OUTPUT -d 125.78.252.172 -j DROP
iptables -I OUTPUT -d 125.78.252.181 -j DROP
iptables -I OUTPUT -d 125.78.252.37 -j DROP
iptables -I OUTPUT -d 125.94.49.123 -j DROP
iptables -I OUTPUT -d 125.94.49.21 -j DROP
iptables -I OUTPUT -d 125.94.49.68 -j DROP
iptables -I OUTPUT -d 128.1.102.21 -j DROP
iptables -I OUTPUT -d 139.215.137.11 -j DROP
iptables -I OUTPUT -d 139.215.137.12 -j DROP
iptables -I OUTPUT -d 139.215.137.13 -j DROP
iptables -I OUTPUT -d 139.215.137.14 -j DROP
iptables -I OUTPUT -d 139.215.137.15 -j DROP
iptables -I OUTPUT -d 139.215.137.16 -j DROP
iptables -I OUTPUT -d 139.215.137.17 -j DROP
iptables -I OUTPUT -d 139.215.137.30 -j DROP
iptables -I OUTPUT -d 139.215.137.48 -j DROP
iptables -I OUTPUT -d 139.215.137.49 -j DROP
iptables -I OUTPUT -d 139.215.137.50 -j DROP
iptables -I OUTPUT -d 139.215.137.51 -j DROP
iptables -I OUTPUT -d 139.215.137.52 -j DROP
iptables -I OUTPUT -d 139.215.137.53 -j DROP
iptables -I OUTPUT -d 139.215.137.54 -j DROP
iptables -I OUTPUT -d 139.215.137.55 -j DROP
iptables -I OUTPUT -d 139.215.137.57 -j DROP
iptables -I OUTPUT -d 139.215.137.58 -j DROP
iptables -I OUTPUT -d 139.215.203.166 -j DROP
iptables -I OUTPUT -d 14.17.32.165 -j DROP
iptables -I OUTPUT -d 14.17.32.188 -j DROP
iptables -I OUTPUT -d 14.17.41.190 -j DROP
iptables -I OUTPUT -d 14.17.41.191 -j DROP
iptables -I OUTPUT -d 14.17.41.192 -j DROP
iptables -I OUTPUT -d 14.17.41.193 -j DROP
iptables -I OUTPUT -d 14.17.41.194 -j DROP
iptables -I OUTPUT -d 14.17.41.195 -j DROP
iptables -I OUTPUT -d 14.17.43.48 -j DROP
iptables -I OUTPUT -d 14.17.43.49 -j DROP
iptables -I OUTPUT -d 14.18.175.103 -j DROP
iptables -I OUTPUT -d 14.18.175.107 -j DROP
iptables -I OUTPUT -d 14.18.175.119 -j DROP
iptables -I OUTPUT -d 14.18.175.125 -j DROP
iptables -I OUTPUT -d 14.18.175.205 -j DROP
iptables -I OUTPUT -d 14.18.175.208 -j DROP
iptables -I OUTPUT -d 14.18.175.213 -j DROP
iptables -I OUTPUT -d 14.18.175.215 -j DROP
iptables -I OUTPUT -d 14.18.175.218 -j DROP
iptables -I OUTPUT -d 14.18.175.219 -j DROP
iptables -I OUTPUT -d 14.18.175.220 -j DROP
iptables -I OUTPUT -d 14.18.175.221 -j DROP
iptables -I OUTPUT -d 14.18.175.42 -j DROP
iptables -I OUTPUT -d 14.18.245.161 -j DROP
iptables -I OUTPUT -d 14.18.245.252 -j DROP
iptables -I OUTPUT -d 14.215.166.152 -j DROP
iptables -I OUTPUT -d 14.215.166.161 -j DROP
iptables -I OUTPUT -d 14.215.166.243 -j DROP
iptables -I OUTPUT -d 14.215.8.11 -j DROP
iptables -I OUTPUT -d 14.215.8.19 -j DROP
iptables -I OUTPUT -d 14.215.85.124 -j DROP
iptables -I OUTPUT -d 14.215.85.59 -j DROP
iptables -I OUTPUT -d 14.215.85.70 -j DROP
iptables -I OUTPUT -d 14.22.33.35 -j DROP
iptables -I OUTPUT -d 14.22.5.209 -j DROP
iptables -I OUTPUT -d 14.22.5.226 -j DROP
iptables -I OUTPUT -d 14.22.5.242 -j DROP
iptables -I OUTPUT -d 14.22.6.114 -j DROP
iptables -I OUTPUT -d 14.22.7.151 -j DROP
iptables -I OUTPUT -d 14.22.7.156 -j DROP
iptables -I OUTPUT -d 14.22.7.227 -j DROP
iptables -I OUTPUT -d 14.29.104.36 -j DROP
iptables -I OUTPUT -d 140.206.161.92 -j DROP
iptables -I OUTPUT -d 140.207.123.187 -j DROP
iptables -I OUTPUT -d 140.207.234.19 -j DROP
iptables -I OUTPUT -d 140.207.234.20 -j DROP
iptables -I OUTPUT -d 140.207.234.21 -j DROP
iptables -I OUTPUT -d 140.207.234.23 -j DROP
iptables -I OUTPUT -d 140.207.234.25 -j DROP
iptables -I OUTPUT -d 140.207.234.26 -j DROP
iptables -I OUTPUT -d 140.207.234.35 -j DROP
iptables -I OUTPUT -d 140.207.234.36 -j DROP
iptables -I OUTPUT -d 140.207.234.38 -j DROP
iptables -I OUTPUT -d 140.207.234.39 -j DROP
iptables -I OUTPUT -d 140.207.234.40 -j DROP
iptables -I OUTPUT -d 140.207.234.41 -j DROP
iptables -I OUTPUT -d 140.207.234.46 -j DROP
iptables -I OUTPUT -d 140.207.234.47 -j DROP
iptables -I OUTPUT -d 140.249.243.144 -j DROP
iptables -I OUTPUT -d 140.249.243.218 -j DROP
iptables -I OUTPUT -d 140.249.243.221 -j DROP
iptables -I OUTPUT -d 140.249.247.232 -j DROP
iptables -I OUTPUT -d 140.249.247.238 -j DROP
iptables -I OUTPUT -d 153.3.167.18 -j DROP
iptables -I OUTPUT -d 153.3.222.101 -j DROP
iptables -I OUTPUT -d 153.3.222.119 -j DROP
iptables -I OUTPUT -d 153.37.238.242 -j DROP
iptables -I OUTPUT -d 157.0.149.11 -j DROP
iptables -I OUTPUT -d 157.0.149.12 -j DROP
iptables -I OUTPUT -d 157.0.149.13 -j DROP
iptables -I OUTPUT -d 157.0.149.16 -j DROP
iptables -I OUTPUT -d 157.255.173.228 -j DROP
iptables -I OUTPUT -d 157.255.245.22 -j DROP
iptables -I OUTPUT -d 157.255.245.247 -j DROP
iptables -I OUTPUT -d 157.255.245.27 -j DROP
iptables -I OUTPUT -d 157.255.245.29 -j DROP
iptables -I OUTPUT -d 163.177.71.192 -j DROP
iptables -I OUTPUT -d 163.177.89.173 -j DROP
iptables -I OUTPUT -d 163.177.90.103 -j DROP
iptables -I OUTPUT -d 175.6.13.146 -j DROP
iptables -I OUTPUT -d 175.6.13.148 -j DROP
iptables -I OUTPUT -d 175.6.13.149 -j DROP
iptables -I OUTPUT -d 175.6.13.151 -j DROP
iptables -I OUTPUT -d 175.6.13.157 -j DROP
iptables -I OUTPUT -d 175.6.13.166 -j DROP
iptables -I OUTPUT -d 175.6.13.168 -j DROP
iptables -I OUTPUT -d 175.6.13.169 -j DROP
iptables -I OUTPUT -d 175.6.13.171 -j DROP
iptables -I OUTPUT -d 175.6.13.174 -j DROP
iptables -I OUTPUT -d 175.6.13.176 -j DROP
iptables -I OUTPUT -d 175.6.13.177 -j DROP
iptables -I OUTPUT -d 175.6.13.180 -j DROP
iptables -I OUTPUT -d 175.6.13.187 -j DROP
iptables -I OUTPUT -d 175.6.232.218 -j DROP
iptables -I OUTPUT -d 175.6.26.166 -j DROP
iptables -I OUTPUT -d 175.6.93.118 -j DROP
iptables -I OUTPUT -d 175.6.93.151 -j DROP
iptables -I OUTPUT -d 175.6.93.153 -j DROP
iptables -I OUTPUT -d 175.6.93.165 -j DROP
iptables -I OUTPUT -d 175.6.93.169 -j DROP
iptables -I OUTPUT -d 175.6.93.175 -j DROP
iptables -I OUTPUT -d 175.6.93.31 -j DROP
iptables -I OUTPUT -d 175.6.93.39 -j DROP
iptables -I OUTPUT -d 175.6.93.41 -j DROP
iptables -I OUTPUT -d 175.6.93.42 -j DROP
iptables -I OUTPUT -d 175.6.93.46 -j DROP
iptables -I OUTPUT -d 175.6.93.48 -j DROP
iptables -I OUTPUT -d 175.6.93.49 -j DROP
iptables -I OUTPUT -d 175.6.93.51 -j DROP
iptables -I OUTPUT -d 175.6.93.81 -j DROP
iptables -I OUTPUT -d 175.6.93.85 -j DROP
iptables -I OUTPUT -d 175.6.93.89 -j DROP
iptables -I OUTPUT -d 175.6.93.90 -j DROP
iptables -I OUTPUT -d 175.6.93.92 -j DROP
iptables -I OUTPUT -d 175.6.93.95 -j DROP
iptables -I OUTPUT -d 180.101.153.103 -j DROP
iptables -I OUTPUT -d 180.101.153.109 -j DROP
iptables -I OUTPUT -d 180.101.153.12 -j DROP
iptables -I OUTPUT -d 180.101.153.124 -j DROP
iptables -I OUTPUT -d 180.101.153.13 -j DROP
iptables -I OUTPUT -d 180.101.153.33 -j DROP
iptables -I OUTPUT -d 180.101.217.147 -j DROP
iptables -I OUTPUT -d 180.101.217.148 -j DROP
iptables -I OUTPUT -d 180.101.217.158 -j DROP
iptables -I OUTPUT -d 180.101.217.159 -j DROP
iptables -I OUTPUT -d 180.101.217.166 -j DROP
iptables -I OUTPUT -d 180.101.217.168 -j DROP
iptables -I OUTPUT -d 180.101.217.20 -j DROP
iptables -I OUTPUT -d 180.153.105.147 -j DROP
iptables -I OUTPUT -d 180.153.105.152 -j DROP
iptables -I OUTPUT -d 180.153.105.153 -j DROP
iptables -I OUTPUT -d 180.153.105.154 -j DROP
iptables -I OUTPUT -d 180.153.105.155 -j DROP
iptables -I OUTPUT -d 180.153.105.156 -j DROP
iptables -I OUTPUT -d 180.153.105.157 -j DROP
iptables -I OUTPUT -d 180.153.105.159 -j DROP
iptables -I OUTPUT -d 180.153.105.161 -j DROP
iptables -I OUTPUT -d 180.153.105.162 -j DROP
iptables -I OUTPUT -d 180.153.105.168 -j DROP
iptables -I OUTPUT -d 180.153.105.173 -j DROP
iptables -I OUTPUT -d 180.153.105.185 -j DROP
iptables -I OUTPUT -d 180.153.105.194 -j DROP
iptables -I OUTPUT -d 180.153.105.195 -j DROP
iptables -I OUTPUT -d 180.153.105.213 -j DROP
iptables -I OUTPUT -d 180.153.105.227 -j DROP
iptables -I OUTPUT -d 180.153.105.248 -j DROP
iptables -I OUTPUT -d 180.153.93.106 -j DROP
iptables -I OUTPUT -d 180.153.93.22 -j DROP
iptables -I OUTPUT -d 180.153.93.29 -j DROP
iptables -I OUTPUT -d 180.153.93.30 -j DROP
iptables -I OUTPUT -d 180.153.93.33 -j DROP
iptables -I OUTPUT -d 180.153.93.36 -j DROP
iptables -I OUTPUT -d 180.163.21.41 -j DROP
iptables -I OUTPUT -d 180.163.25.182 -j DROP
iptables -I OUTPUT -d 180.96.0.13 -j DROP
iptables -I OUTPUT -d 180.96.30.15 -j DROP
iptables -I OUTPUT -d 180.96.30.18 -j DROP
iptables -I OUTPUT -d 180.97.10.109 -j DROP
iptables -I OUTPUT -d 180.97.10.110 -j DROP
iptables -I OUTPUT -d 180.97.10.111 -j DROP
iptables -I OUTPUT -d 180.97.10.112 -j DROP
iptables -I OUTPUT -d 180.97.10.119 -j DROP
iptables -I OUTPUT -d 180.97.10.120 -j DROP
iptables -I OUTPUT -d 180.97.10.121 -j DROP
iptables -I OUTPUT -d 180.97.10.14 -j DROP
iptables -I OUTPUT -d 180.97.146.141 -j DROP
iptables -I OUTPUT -d 180.97.146.142 -j DROP
iptables -I OUTPUT -d 180.97.146.143 -j DROP
iptables -I OUTPUT -d 180.97.146.144 -j DROP
iptables -I OUTPUT -d 180.97.146.145 -j DROP
iptables -I OUTPUT -d 180.97.146.237 -j DROP
iptables -I OUTPUT -d 182.107.81.19 -j DROP
iptables -I OUTPUT -d 182.107.81.20 -j DROP
iptables -I OUTPUT -d 182.107.81.22 -j DROP
iptables -I OUTPUT -d 182.107.81.23 -j DROP
iptables -I OUTPUT -d 182.107.81.24 -j DROP
iptables -I OUTPUT -d 182.107.81.25 -j DROP
iptables -I OUTPUT -d 182.107.81.26 -j DROP
iptables -I OUTPUT -d 182.107.81.27 -j DROP
iptables -I OUTPUT -d 182.107.81.29 -j DROP
iptables -I OUTPUT -d 182.107.81.30 -j DROP
iptables -I OUTPUT -d 182.107.81.71 -j DROP
iptables -I OUTPUT -d 182.118.124.168 -j DROP
iptables -I OUTPUT -d 182.118.124.204 -j DROP
iptables -I OUTPUT -d 182.118.124.205 -j DROP
iptables -I OUTPUT -d 182.118.63.179 -j DROP
iptables -I OUTPUT -d 182.131.30.23 -j DROP
iptables -I OUTPUT -d 182.140.167.16 -j DROP
iptables -I OUTPUT -d 182.140.174.174 -j DROP
iptables -I OUTPUT -d 182.140.174.175 -j DROP
iptables -I OUTPUT -d 182.140.185.140 -j DROP
iptables -I OUTPUT -d 182.140.185.185 -j DROP
iptables -I OUTPUT -d 182.140.217.36 -j DROP
iptables -I OUTPUT -d 182.150.10.154 -j DROP
iptables -I OUTPUT -d 182.150.10.157 -j DROP
iptables -I OUTPUT -d 182.150.10.158 -j DROP
iptables -I OUTPUT -d 182.150.10.159 -j DROP
iptables -I OUTPUT -d 182.150.10.160 -j DROP
iptables -I OUTPUT -d 182.150.10.165 -j DROP
iptables -I OUTPUT -d 182.150.10.166 -j DROP
iptables -I OUTPUT -d 182.150.10.167 -j DROP
iptables -I OUTPUT -d 182.150.10.168 -j DROP
iptables -I OUTPUT -d 182.150.10.169 -j DROP
iptables -I OUTPUT -d 182.150.10.170 -j DROP
iptables -I OUTPUT -d 182.150.10.171 -j DROP
iptables -I OUTPUT -d 182.150.10.172 -j DROP
iptables -I OUTPUT -d 182.150.10.182 -j DROP
iptables -I OUTPUT -d 182.150.10.184 -j DROP
iptables -I OUTPUT -d 182.150.10.189 -j DROP
iptables -I OUTPUT -d 182.150.10.207 -j DROP
iptables -I OUTPUT -d 182.150.10.41 -j DROP
iptables -I OUTPUT -d 182.150.10.44 -j DROP
iptables -I OUTPUT -d 182.150.10.46 -j DROP
iptables -I OUTPUT -d 182.150.10.47 -j DROP
iptables -I OUTPUT -d 182.150.10.51 -j DROP
iptables -I OUTPUT -d 182.150.10.53 -j DROP
iptables -I OUTPUT -d 182.150.10.54 -j DROP
iptables -I OUTPUT -d 182.150.10.55 -j DROP
iptables -I OUTPUT -d 182.150.11.163 -j DROP
iptables -I OUTPUT -d 182.254.10.86 -j DROP
iptables -I OUTPUT -d 182.254.11.165 -j DROP
iptables -I OUTPUT -d 182.254.34.45 -j DROP
iptables -I OUTPUT -d 182.254.34.86 -j DROP
iptables -I OUTPUT -d 182.254.48.12 -j DROP
iptables -I OUTPUT -d 182.254.48.215 -j DROP
iptables -I OUTPUT -d 182.254.48.221 -j DROP
iptables -I OUTPUT -d 182.254.48.232 -j DROP
iptables -I OUTPUT -d 182.254.48.233 -j DROP
iptables -I OUTPUT -d 182.254.48.74 -j DROP
iptables -I OUTPUT -d 182.254.48.95 -j DROP
iptables -I OUTPUT -d 182.254.49.111 -j DROP
iptables -I OUTPUT -d 182.254.51.114 -j DROP
iptables -I OUTPUT -d 182.254.52.100 -j DROP
iptables -I OUTPUT -d 182.254.52.101 -j DROP
iptables -I OUTPUT -d 182.254.52.102 -j DROP
iptables -I OUTPUT -d 182.254.52.186 -j DROP
iptables -I OUTPUT -d 182.254.52.196 -j DROP
iptables -I OUTPUT -d 182.254.52.230 -j DROP
iptables -I OUTPUT -d 182.254.56.61 -j DROP
iptables -I OUTPUT -d 182.254.57.52 -j DROP
iptables -I OUTPUT -d 182.254.58.154 -j DROP
iptables -I OUTPUT -d 182.254.59.152 -j DROP
iptables -I OUTPUT -d 182.254.60.52 -j DROP
iptables -I OUTPUT -d 182.254.74.243 -j DROP
iptables -I OUTPUT -d 182.254.76.104 -j DROP
iptables -I OUTPUT -d 182.254.76.116 -j DROP
iptables -I OUTPUT -d 182.254.76.118 -j DROP
iptables -I OUTPUT -d 182.254.86.178 -j DROP
iptables -I OUTPUT -d 182.254.90.189 -j DROP
iptables -I OUTPUT -d 182.254.93.101 -j DROP
iptables -I OUTPUT -d 183.131.53.27 -j DROP
iptables -I OUTPUT -d 183.131.53.72 -j DROP
iptables -I OUTPUT -d 183.134.22.11 -j DROP
iptables -I OUTPUT -d 183.192.163.33 -j DROP
iptables -I OUTPUT -d 183.192.163.34 -j DROP
iptables -I OUTPUT -d 183.192.163.36 -j DROP
iptables -I OUTPUT -d 183.192.163.37 -j DROP
iptables -I OUTPUT -d 183.192.196.188 -j DROP
iptables -I OUTPUT -d 183.192.196.36 -j DROP
iptables -I OUTPUT -d 183.192.202.176 -j DROP
iptables -I OUTPUT -d 183.194.184.101 -j DROP
iptables -I OUTPUT -d 183.194.234.48 -j DROP
iptables -I OUTPUT -d 183.2.192.11 -j DROP
iptables -I OUTPUT -d 183.2.192.12 -j DROP
iptables -I OUTPUT -d 183.2.192.15 -j DROP
iptables -I OUTPUT -d 183.2.192.166 -j DROP
iptables -I OUTPUT -d 183.2.192.25 -j DROP
iptables -I OUTPUT -d 183.2.192.41 -j DROP
iptables -I OUTPUT -d 183.2.192.85 -j DROP
iptables -I OUTPUT -d 183.2.196.141 -j DROP
iptables -I OUTPUT -d 183.2.196.142 -j DROP
iptables -I OUTPUT -d 183.2.196.143 -j DROP
iptables -I OUTPUT -d 183.2.196.144 -j DROP
iptables -I OUTPUT -d 183.2.196.145 -j DROP
iptables -I OUTPUT -d 183.2.196.152 -j DROP
iptables -I OUTPUT -d 183.2.196.154 -j DROP
iptables -I OUTPUT -d 183.2.196.155 -j DROP
iptables -I OUTPUT -d 183.2.196.159 -j DROP
iptables -I OUTPUT -d 183.2.196.160 -j DROP
iptables -I OUTPUT -d 183.2.196.163 -j DROP
iptables -I OUTPUT -d 183.2.196.164 -j DROP
iptables -I OUTPUT -d 183.2.196.167 -j DROP
iptables -I OUTPUT -d 183.2.196.168 -j DROP
iptables -I OUTPUT -d 183.2.196.169 -j DROP
iptables -I OUTPUT -d 183.2.196.170 -j DROP
iptables -I OUTPUT -d 183.2.196.171 -j DROP
iptables -I OUTPUT -d 183.201.224.11 -j DROP
iptables -I OUTPUT -d 183.201.224.13 -j DROP
iptables -I OUTPUT -d 183.201.224.14 -j DROP
iptables -I OUTPUT -d 183.201.224.69 -j DROP
iptables -I OUTPUT -d 183.201.224.75 -j DROP
iptables -I OUTPUT -d 183.201.241.68 -j DROP
iptables -I OUTPUT -d 183.201.241.69 -j DROP
iptables -I OUTPUT -d 183.203.17.71 -j DROP
iptables -I OUTPUT -d 183.214.128.166 -j DROP
iptables -I OUTPUT -d 183.214.42.143 -j DROP
iptables -I OUTPUT -d 183.214.42.144 -j DROP
iptables -I OUTPUT -d 183.214.42.252 -j DROP
iptables -I OUTPUT -d 183.216.179.11 -j DROP
iptables -I OUTPUT -d 183.216.179.112 -j DROP
iptables -I OUTPUT -d 183.216.179.14 -j DROP
iptables -I OUTPUT -d 183.216.179.15 -j DROP
iptables -I OUTPUT -d 183.216.179.97 -j DROP
iptables -I OUTPUT -d 183.230.74.44 -j DROP
iptables -I OUTPUT -d 183.232.119.180 -j DROP
iptables -I OUTPUT -d 183.232.119.187 -j DROP
iptables -I OUTPUT -d 183.232.119.190 -j DROP
iptables -I OUTPUT -d 183.232.119.195 -j DROP
iptables -I OUTPUT -d 183.232.125.212 -j DROP
iptables -I OUTPUT -d 183.232.171.210 -j DROP
iptables -I OUTPUT -d 183.232.171.212 -j DROP
iptables -I OUTPUT -d 183.232.171.55 -j DROP
iptables -I OUTPUT -d 183.232.173.179 -j DROP
iptables -I OUTPUT -d 183.232.173.180 -j DROP
iptables -I OUTPUT -d 183.232.173.181 -j DROP
iptables -I OUTPUT -d 183.232.173.182 -j DROP
iptables -I OUTPUT -d 183.232.173.183 -j DROP
iptables -I OUTPUT -d 183.232.173.184 -j DROP
iptables -I OUTPUT -d 183.232.173.185 -j DROP
iptables -I OUTPUT -d 183.232.173.186 -j DROP
iptables -I OUTPUT -d 183.232.173.187 -j DROP
iptables -I OUTPUT -d 183.232.173.188 -j DROP
iptables -I OUTPUT -d 183.232.175.140 -j DROP
iptables -I OUTPUT -d 183.232.175.142 -j DROP
iptables -I OUTPUT -d 183.232.175.156 -j DROP
iptables -I OUTPUT -d 183.232.175.157 -j DROP
iptables -I OUTPUT -d 183.232.175.162 -j DROP
iptables -I OUTPUT -d 183.232.175.166 -j DROP
iptables -I OUTPUT -d 183.232.175.167 -j DROP
iptables -I OUTPUT -d 183.232.175.168 -j DROP
iptables -I OUTPUT -d 183.232.175.173 -j DROP
iptables -I OUTPUT -d 183.232.175.180 -j DROP
iptables -I OUTPUT -d 183.232.175.187 -j DROP
iptables -I OUTPUT -d 183.232.175.188 -j DROP
iptables -I OUTPUT -d 183.232.224.11 -j DROP
iptables -I OUTPUT -d 183.232.30.18 -j DROP
iptables -I OUTPUT -d 183.232.93.182 -j DROP
iptables -I OUTPUT -d 183.232.93.208 -j DROP
iptables -I OUTPUT -d 183.232.95.160 -j DROP
iptables -I OUTPUT -d 183.232.95.173 -j DROP
iptables -I OUTPUT -d 183.232.95.183 -j DROP
iptables -I OUTPUT -d 183.232.95.189 -j DROP
iptables -I OUTPUT -d 183.232.95.195 -j DROP
iptables -I OUTPUT -d 183.232.95.197 -j DROP
iptables -I OUTPUT -d 183.232.95.79 -j DROP
iptables -I OUTPUT -d 183.232.95.99 -j DROP
iptables -I OUTPUT -d 183.240.118.181 -j DROP
iptables -I OUTPUT -d 183.240.118.241 -j DROP
iptables -I OUTPUT -d 183.240.119.165 -j DROP
iptables -I OUTPUT -d 183.240.119.166 -j DROP
iptables -I OUTPUT -d 183.240.119.168 -j DROP
iptables -I OUTPUT -d 183.240.119.169 -j DROP
iptables -I OUTPUT -d 183.240.59.20 -j DROP
iptables -I OUTPUT -d 183.252.54.144 -j DROP
iptables -I OUTPUT -d 183.252.54.176 -j DROP
iptables -I OUTPUT -d 183.3.225.22 -j DROP
iptables -I OUTPUT -d 183.3.226.41 -j DROP
iptables -I OUTPUT -d 183.3.235.218 -j DROP
iptables -I OUTPUT -d 183.3.235.81 -j DROP
iptables -I OUTPUT -d 183.56.150.153 -j DROP
iptables -I OUTPUT -d 183.56.150.154 -j DROP
iptables -I OUTPUT -d 183.56.150.160 -j DROP
iptables -I OUTPUT -d 183.56.150.161 -j DROP
iptables -I OUTPUT -d 183.56.150.162 -j DROP
iptables -I OUTPUT -d 183.56.150.163 -j DROP
iptables -I OUTPUT -d 183.56.150.164 -j DROP
iptables -I OUTPUT -d 183.56.150.165 -j DROP
iptables -I OUTPUT -d 183.56.150.242 -j DROP
iptables -I OUTPUT -d 183.60.137.148 -j DROP
iptables -I OUTPUT -d 183.60.137.150 -j DROP
iptables -I OUTPUT -d 183.60.15.168 -j DROP
iptables -I OUTPUT -d 183.60.185.101 -j DROP
iptables -I OUTPUT -d 183.60.217.79 -j DROP
iptables -I OUTPUT -d 183.60.23.31 -j DROP
iptables -I OUTPUT -d 183.61.239.14 -j DROP
iptables -I OUTPUT -d 183.61.239.15 -j DROP
iptables -I OUTPUT -d 183.61.239.28 -j DROP
iptables -I OUTPUT -d 183.61.239.32 -j DROP
iptables -I OUTPUT -d 183.61.51.43 -j DROP
iptables -I OUTPUT -d 183.66.103.142 -j DROP
iptables -I OUTPUT -d 183.66.103.161 -j DROP
iptables -I OUTPUT -d 183.66.103.167 -j DROP
iptables -I OUTPUT -d 183.66.103.206 -j DROP
iptables -I OUTPUT -d 183.66.105.231 -j DROP
iptables -I OUTPUT -d 202.102.178.11 -j DROP
iptables -I OUTPUT -d 202.102.178.12 -j DROP
iptables -I OUTPUT -d 202.102.178.121 -j DROP
iptables -I OUTPUT -d 202.102.178.13 -j DROP
iptables -I OUTPUT -d 202.102.178.14 -j DROP
iptables -I OUTPUT -d 202.102.178.15 -j DROP
iptables -I OUTPUT -d 202.102.178.16 -j DROP
iptables -I OUTPUT -d 203.205.128.173 -j DROP
iptables -I OUTPUT -d 203.205.136.105 -j DROP
iptables -I OUTPUT -d 203.205.136.169 -j DROP
iptables -I OUTPUT -d 203.205.136.77 -j DROP
iptables -I OUTPUT -d 203.205.137.232 -j DROP
iptables -I OUTPUT -d 203.205.137.234 -j DROP
iptables -I OUTPUT -d 203.205.137.237 -j DROP
iptables -I OUTPUT -d 203.205.137.238 -j DROP
iptables -I OUTPUT -d 203.205.137.242 -j DROP
iptables -I OUTPUT -d 203.205.137.29 -j DROP
iptables -I OUTPUT -d 203.205.137.76 -j DROP
iptables -I OUTPUT -d 203.205.137.78 -j DROP
iptables -I OUTPUT -d 203.205.138.231 -j DROP
iptables -I OUTPUT -d 203.205.138.73 -j DROP
iptables -I OUTPUT -d 203.205.138.74 -j DROP
iptables -I OUTPUT -d 203.205.140.107 -j DROP
iptables -I OUTPUT -d 203.205.140.109 -j DROP
iptables -I OUTPUT -d 203.205.144.15 -j DROP
iptables -I OUTPUT -d 203.205.144.19 -j DROP
iptables -I OUTPUT -d 203.205.144.22 -j DROP
iptables -I OUTPUT -d 203.205.146.49 -j DROP
iptables -I OUTPUT -d 203.205.147.218 -j DROP
iptables -I OUTPUT -d 203.205.149.240 -j DROP
iptables -I OUTPUT -d 203.205.149.244 -j DROP
iptables -I OUTPUT -d 203.205.150.108 -j DROP
iptables -I OUTPUT -d 203.205.150.110 -j DROP
iptables -I OUTPUT -d 203.205.151.46 -j DROP
iptables -I OUTPUT -d 203.205.158.50 -j DROP
iptables -I OUTPUT -d 203.205.158.52 -j DROP
iptables -I OUTPUT -d 203.205.158.60 -j DROP
iptables -I OUTPUT -d 203.205.158.61 -j DROP
iptables -I OUTPUT -d 203.205.158.62 -j DROP
iptables -I OUTPUT -d 203.205.158.63 -j DROP
iptables -I OUTPUT -d 203.205.158.65 -j DROP
iptables -I OUTPUT -d 203.205.219.229 -j DROP
iptables -I OUTPUT -d 203.205.235.2 -j DROP
iptables -I OUTPUT -d 203.205.235.243 -j DROP
iptables -I OUTPUT -d 203.205.239.141 -j DROP
iptables -I OUTPUT -d 203.205.239.144 -j DROP
iptables -I OUTPUT -d 203.205.239.162 -j DROP
iptables -I OUTPUT -d 203.205.239.166 -j DROP
iptables -I OUTPUT -d 203.205.253.184 -j DROP
iptables -I OUTPUT -d 203.205.254.62 -j DROP
iptables -I OUTPUT -d 210.22.248.141 -j DROP
iptables -I OUTPUT -d 210.22.248.149 -j DROP
iptables -I OUTPUT -d 210.22.248.155 -j DROP
iptables -I OUTPUT -d 210.22.248.164 -j DROP
iptables -I OUTPUT -d 210.22.248.170 -j DROP
iptables -I OUTPUT -d 210.22.248.217 -j DROP
iptables -I OUTPUT -d 210.22.248.232 -j DROP
iptables -I OUTPUT -d 210.22.249.95 -j DROP
iptables -I OUTPUT -d 218.11.11.190 -j DROP
iptables -I OUTPUT -d 218.30.98.17 -j DROP
iptables -I OUTPUT -d 218.30.98.18 -j DROP
iptables -I OUTPUT -d 218.30.98.19 -j DROP
iptables -I OUTPUT -d 218.60.33.148 -j DROP
iptables -I OUTPUT -d 218.75.176.157 -j DROP
iptables -I OUTPUT -d 218.75.176.158 -j DROP
iptables -I OUTPUT -d 218.75.176.167 -j DROP
iptables -I OUTPUT -d 218.75.176.169 -j DROP
iptables -I OUTPUT -d 218.75.176.170 -j DROP
iptables -I OUTPUT -d 218.75.176.171 -j DROP
iptables -I OUTPUT -d 218.75.176.172 -j DROP
iptables -I OUTPUT -d 218.75.177.20 -j DROP
iptables -I OUTPUT -d 218.75.177.22 -j DROP
iptables -I OUTPUT -d 219.133.60.213 -j DROP
iptables -I OUTPUT -d 219.133.60.217 -j DROP
iptables -I OUTPUT -d 219.133.60.218 -j DROP
iptables -I OUTPUT -d 219.133.60.219 -j DROP
iptables -I OUTPUT -d 219.133.60.222 -j DROP
iptables -I OUTPUT -d 219.144.82.209 -j DROP
iptables -I OUTPUT -d 219.146.241.141 -j DROP
iptables -I OUTPUT -d 219.146.241.145 -j DROP
iptables -I OUTPUT -d 219.146.241.146 -j DROP
iptables -I OUTPUT -d 219.146.241.147 -j DROP
iptables -I OUTPUT -d 219.146.241.148 -j DROP
iptables -I OUTPUT -d 219.146.241.149 -j DROP
iptables -I OUTPUT -d 219.146.241.150 -j DROP
iptables -I OUTPUT -d 219.146.241.151 -j DROP
iptables -I OUTPUT -d 219.146.241.152 -j DROP
iptables -I OUTPUT -d 219.146.241.153 -j DROP
iptables -I OUTPUT -d 219.146.241.154 -j DROP
iptables -I OUTPUT -d 219.146.241.155 -j DROP
iptables -I OUTPUT -d 219.146.241.157 -j DROP
iptables -I OUTPUT -d 219.146.241.158 -j DROP
iptables -I OUTPUT -d 219.146.241.159 -j DROP
iptables -I OUTPUT -d 219.146.241.160 -j DROP
iptables -I OUTPUT -d 219.146.241.161 -j DROP
iptables -I OUTPUT -d 219.146.241.162 -j DROP
iptables -I OUTPUT -d 219.146.241.163 -j DROP
iptables -I OUTPUT -d 219.146.241.164 -j DROP
iptables -I OUTPUT -d 219.146.241.172 -j DROP
iptables -I OUTPUT -d 219.146.241.173 -j DROP
iptables -I OUTPUT -d 219.146.241.174 -j DROP
iptables -I OUTPUT -d 219.146.241.175 -j DROP
iptables -I OUTPUT -d 219.151.14.28 -j DROP
iptables -I OUTPUT -d 219.151.17.124 -j DROP
iptables -I OUTPUT -d 219.151.17.15 -j DROP
iptables -I OUTPUT -d 219.151.17.21 -j DROP
iptables -I OUTPUT -d 219.151.17.44 -j DROP
iptables -I OUTPUT -d 220.181.91.148 -j DROP
iptables -I OUTPUT -d 220.181.91.149 -j DROP
iptables -I OUTPUT -d 220.194.111.229 -j DROP
iptables -I OUTPUT -d 220.194.223.11 -j DROP
iptables -I OUTPUT -d 220.194.223.125 -j DROP
iptables -I OUTPUT -d 220.194.223.14 -j DROP
iptables -I OUTPUT -d 220.194.223.15 -j DROP
iptables -I OUTPUT -d 220.194.223.16 -j DROP
iptables -I OUTPUT -d 220.194.223.32 -j DROP
iptables -I OUTPUT -d 220.194.223.35 -j DROP
iptables -I OUTPUT -d 220.194.223.36 -j DROP
iptables -I OUTPUT -d 220.194.223.44 -j DROP
iptables -I OUTPUT -d 220.194.223.60 -j DROP
iptables -I OUTPUT -d 220.194.223.79 -j DROP
iptables -I OUTPUT -d 220.194.224.141 -j DROP
iptables -I OUTPUT -d 220.194.224.142 -j DROP
iptables -I OUTPUT -d 220.194.224.145 -j DROP
iptables -I OUTPUT -d 220.194.224.146 -j DROP
iptables -I OUTPUT -d 220.194.224.147 -j DROP
iptables -I OUTPUT -d 220.194.224.148 -j DROP
iptables -I OUTPUT -d 220.194.224.15 -j DROP
iptables -I OUTPUT -d 220.194.224.17 -j DROP
iptables -I OUTPUT -d 220.194.224.177 -j DROP
iptables -I OUTPUT -d 220.194.224.179 -j DROP
iptables -I OUTPUT -d 220.194.224.18 -j DROP
iptables -I OUTPUT -d 220.194.224.182 -j DROP
iptables -I OUTPUT -d 220.194.224.185 -j DROP
iptables -I OUTPUT -d 220.194.224.19 -j DROP
iptables -I OUTPUT -d 220.194.79.36 -j DROP
iptables -I OUTPUT -d 220.194.87.100 -j DROP
iptables -I OUTPUT -d 220.194.87.11 -j DROP
iptables -I OUTPUT -d 220.194.87.12 -j DROP
iptables -I OUTPUT -d 220.194.87.13 -j DROP
iptables -I OUTPUT -d 220.194.87.14 -j DROP
iptables -I OUTPUT -d 220.194.87.15 -j DROP
iptables -I OUTPUT -d 220.194.87.43 -j DROP
iptables -I OUTPUT -d 220.194.87.52 -j DROP
iptables -I OUTPUT -d 220.194.91.125 -j DROP
iptables -I OUTPUT -d 220.194.91.184 -j DROP
iptables -I OUTPUT -d 220.194.91.190 -j DROP
iptables -I OUTPUT -d 220.194.91.69 -j DROP
iptables -I OUTPUT -d 220.194.91.93 -j DROP
iptables -I OUTPUT -d 220.194.95.218 -j DROP
iptables -I OUTPUT -d 220.194.95.221 -j DROP
iptables -I OUTPUT -d 220.195.17.35 -j DROP
iptables -I OUTPUT -d 220.195.19.22 -j DROP
iptables -I OUTPUT -d 220.195.19.23 -j DROP
iptables -I OUTPUT -d 220.195.19.24 -j DROP
iptables -I OUTPUT -d 220.195.19.25 -j DROP
iptables -I OUTPUT -d 220.195.19.26 -j DROP
iptables -I OUTPUT -d 220.195.19.27 -j DROP
iptables -I OUTPUT -d 220.249.243.177 -j DROP
iptables -I OUTPUT -d 220.249.243.18 -j DROP
iptables -I OUTPUT -d 220.249.243.19 -j DROP
iptables -I OUTPUT -d 220.249.243.43 -j DROP
iptables -I OUTPUT -d 221.180.147.22 -j DROP
iptables -I OUTPUT -d 221.180.213.27 -j DROP
iptables -I OUTPUT -d 221.180.213.37 -j DROP
iptables -I OUTPUT -d 221.181.81.253 -j DROP
iptables -I OUTPUT -d 221.204.165.121 -j DROP
iptables -I OUTPUT -d 221.204.183.93 -j DROP
iptables -I OUTPUT -d 221.204.57.11 -j DROP
iptables -I OUTPUT -d 221.204.57.13 -j DROP
iptables -I OUTPUT -d 221.204.57.14 -j DROP
iptables -I OUTPUT -d 221.204.57.15 -j DROP
iptables -I OUTPUT -d 221.228.218.166 -j DROP
iptables -I OUTPUT -d 221.228.219.112 -j DROP
iptables -I OUTPUT -d 221.228.67.141 -j DROP
iptables -I OUTPUT -d 221.228.67.145 -j DROP
iptables -I OUTPUT -d 221.228.67.151 -j DROP
iptables -I OUTPUT -d 221.228.67.153 -j DROP
iptables -I OUTPUT -d 221.228.67.154 -j DROP
iptables -I OUTPUT -d 221.228.67.155 -j DROP
iptables -I OUTPUT -d 221.228.67.161 -j DROP
iptables -I OUTPUT -d 221.228.67.162 -j DROP
iptables -I OUTPUT -d 221.228.67.163 -j DROP
iptables -I OUTPUT -d 221.228.67.164 -j DROP
iptables -I OUTPUT -d 221.228.67.172 -j DROP
iptables -I OUTPUT -d 221.228.67.186 -j DROP
iptables -I OUTPUT -d 221.228.67.230 -j DROP
iptables -I OUTPUT -d 221.233.41.16 -j DROP
iptables -I OUTPUT -d 221.233.41.17 -j DROP
iptables -I OUTPUT -d 221.233.41.26 -j DROP
iptables -I OUTPUT -d 221.235.252.170 -j DROP
iptables -I OUTPUT -d 221.8.78.15 -j DROP
iptables -I OUTPUT -d 221.8.78.16 -j DROP
iptables -I OUTPUT -d 221.8.78.17 -j DROP
iptables -I OUTPUT -d 221.8.78.18 -j DROP
iptables -I OUTPUT -d 221.8.78.19 -j DROP
iptables -I OUTPUT -d 222.186.49.108 -j DROP
iptables -I OUTPUT -d 222.186.49.11 -j DROP
iptables -I OUTPUT -d 222.186.49.114 -j DROP
iptables -I OUTPUT -d 222.186.49.12 -j DROP
iptables -I OUTPUT -d 222.186.49.124 -j DROP
iptables -I OUTPUT -d 222.186.49.13 -j DROP
iptables -I OUTPUT -d 222.186.49.14 -j DROP
iptables -I OUTPUT -d 222.186.49.15 -j DROP
iptables -I OUTPUT -d 222.186.49.34 -j DROP
iptables -I OUTPUT -d 222.186.49.85 -j DROP
iptables -I OUTPUT -d 222.218.81.11 -j DROP
iptables -I OUTPUT -d 222.218.81.12 -j DROP
iptables -I OUTPUT -d 222.218.81.13 -j DROP
iptables -I OUTPUT -d 222.218.81.52 -j DROP
iptables -I OUTPUT -d 222.218.81.97 -j DROP
iptables -I OUTPUT -d 222.73.133.121 -j DROP
iptables -I OUTPUT -d 223.111.108.141 -j DROP
iptables -I OUTPUT -d 223.111.108.142 -j DROP
iptables -I OUTPUT -d 223.111.108.143 -j DROP
iptables -I OUTPUT -d 223.111.108.144 -j DROP
iptables -I OUTPUT -d 223.111.108.145 -j DROP
iptables -I OUTPUT -d 223.111.108.167 -j DROP
iptables -I OUTPUT -d 223.111.108.168 -j DROP
iptables -I OUTPUT -d 223.111.108.169 -j DROP
iptables -I OUTPUT -d 223.111.108.170 -j DROP
iptables -I OUTPUT -d 223.111.108.196 -j DROP
iptables -I OUTPUT -d 223.111.153.139 -j DROP
iptables -I OUTPUT -d 223.111.153.143 -j DROP
iptables -I OUTPUT -d 223.111.153.147 -j DROP
iptables -I OUTPUT -d 223.111.153.160 -j DROP
iptables -I OUTPUT -d 223.111.153.162 -j DROP
iptables -I OUTPUT -d 223.111.153.165 -j DROP
iptables -I OUTPUT -d 223.111.153.167 -j DROP
iptables -I OUTPUT -d 223.111.153.168 -j DROP
iptables -I OUTPUT -d 223.111.153.169 -j DROP
iptables -I OUTPUT -d 223.111.153.205 -j DROP
iptables -I OUTPUT -d 223.111.154.103 -j DROP
iptables -I OUTPUT -d 223.111.154.104 -j DROP
iptables -I OUTPUT -d 223.111.154.108 -j DROP
iptables -I OUTPUT -d 223.111.154.15 -j DROP
iptables -I OUTPUT -d 223.111.154.17 -j DROP
iptables -I OUTPUT -d 223.111.154.20 -j DROP
iptables -I OUTPUT -d 223.111.154.21 -j DROP
iptables -I OUTPUT -d 223.111.154.22 -j DROP
iptables -I OUTPUT -d 223.111.154.24 -j DROP
iptables -I OUTPUT -d 223.111.154.29 -j DROP
iptables -I OUTPUT -d 223.111.154.33 -j DROP
iptables -I OUTPUT -d 223.111.154.40 -j DROP
iptables -I OUTPUT -d 223.111.154.43 -j DROP
iptables -I OUTPUT -d 223.111.158.11 -j DROP
iptables -I OUTPUT -d 223.111.158.115 -j DROP
iptables -I OUTPUT -d 223.111.158.12 -j DROP
iptables -I OUTPUT -d 223.111.158.13 -j DROP
iptables -I OUTPUT -d 223.111.158.14 -j DROP
iptables -I OUTPUT -d 223.111.158.15 -j DROP
iptables -I OUTPUT -d 223.111.158.16 -j DROP
iptables -I OUTPUT -d 223.111.158.20 -j DROP
iptables -I OUTPUT -d 223.111.158.40 -j DROP
iptables -I OUTPUT -d 223.111.158.41 -j DROP
iptables -I OUTPUT -d 223.111.158.79 -j DROP
iptables -I OUTPUT -d 223.111.158.90 -j DROP
iptables -I OUTPUT -d 223.111.187.141 -j DROP
iptables -I OUTPUT -d 223.111.187.142 -j DROP
iptables -I OUTPUT -d 223.111.187.144 -j DROP
iptables -I OUTPUT -d 223.111.187.145 -j DROP
iptables -I OUTPUT -d 223.111.187.146 -j DROP
iptables -I OUTPUT -d 223.111.187.147 -j DROP
iptables -I OUTPUT -d 223.111.187.167 -j DROP
iptables -I OUTPUT -d 223.111.187.168 -j DROP
iptables -I OUTPUT -d 223.111.187.208 -j DROP
iptables -I OUTPUT -d 223.111.187.233 -j DROP
iptables -I OUTPUT -d 223.111.187.237 -j DROP
iptables -I OUTPUT -d 223.111.194.174 -j DROP
iptables -I OUTPUT -d 223.111.195.78 -j DROP
iptables -I OUTPUT -d 223.111.243.11 -j DROP
iptables -I OUTPUT -d 223.111.243.12 -j DROP
iptables -I OUTPUT -d 223.111.243.126 -j DROP
iptables -I OUTPUT -d 223.111.243.13 -j DROP
iptables -I OUTPUT -d 223.111.243.14 -j DROP
iptables -I OUTPUT -d 223.111.243.15 -j DROP
iptables -I OUTPUT -d 223.111.243.156 -j DROP
iptables -I OUTPUT -d 223.111.243.16 -j DROP
iptables -I OUTPUT -d 223.111.243.218 -j DROP
iptables -I OUTPUT -d 223.111.96.68 -j DROP
iptables -I OUTPUT -d 223.111.97.159 -j DROP
iptables -I OUTPUT -d 223.111.97.172 -j DROP
iptables -I OUTPUT -d 223.111.97.187 -j DROP
iptables -I OUTPUT -d 223.166.152.196 -j DROP
iptables -I OUTPUT -d 223.167.86.70 -j DROP
iptables -I OUTPUT -d 223.82.245.24 -j DROP
iptables -I OUTPUT -d 223.82.245.26 -j DROP
iptables -I OUTPUT -d 223.82.245.27 -j DROP
iptables -I OUTPUT -d 223.82.245.30 -j DROP
iptables -I OUTPUT -d 223.82.245.31 -j DROP
iptables -I OUTPUT -d 223.82.245.33 -j DROP
iptables -I OUTPUT -d 223.82.245.86 -j DROP
iptables -I OUTPUT -d 223.99.231.142 -j DROP
iptables -I OUTPUT -d 223.99.231.145 -j DROP
iptables -I OUTPUT -d 223.99.231.155 -j DROP
iptables -I OUTPUT -d 223.99.231.166 -j DROP
iptables -I OUTPUT -d 223.99.231.171 -j DROP
iptables -I OUTPUT -d 223.99.231.172 -j DROP
iptables -I OUTPUT -d 223.99.231.186 -j DROP
iptables -I OUTPUT -d 223.99.231.238 -j DROP
iptables -I OUTPUT -d 223.99.245.42 -j DROP
iptables -I OUTPUT -d 223.99.245.49 -j DROP
iptables -I OUTPUT -d 27.148.185.86 -j DROP
iptables -I OUTPUT -d 27.152.185.166 -j DROP
iptables -I OUTPUT -d 27.221.15.140 -j DROP
iptables -I OUTPUT -d 27.221.15.186 -j DROP
iptables -I OUTPUT -d 27.221.28.166 -j DROP
iptables -I OUTPUT -d 27.221.81.102 -j DROP
iptables -I OUTPUT -d 27.221.81.104 -j DROP
iptables -I OUTPUT -d 27.221.81.23 -j DROP
iptables -I OUTPUT -d 27.221.81.24 -j DROP
iptables -I OUTPUT -d 27.221.81.25 -j DROP
iptables -I OUTPUT -d 27.221.81.27 -j DROP
iptables -I OUTPUT -d 27.221.81.36 -j DROP
iptables -I OUTPUT -d 27.221.81.38 -j DROP
iptables -I OUTPUT -d 27.221.81.39 -j DROP
iptables -I OUTPUT -d 27.221.81.43 -j DROP
iptables -I OUTPUT -d 27.221.81.44 -j DROP
iptables -I OUTPUT -d 27.221.81.63 -j DROP
iptables -I OUTPUT -d 27.221.81.72 -j DROP
iptables -I OUTPUT -d 27.45.166.11 -j DROP
iptables -I OUTPUT -d 27.45.166.14 -j DROP
iptables -I OUTPUT -d 27.45.166.143 -j DROP
iptables -I OUTPUT -d 27.45.166.146 -j DROP
iptables -I OUTPUT -d 27.45.166.16 -j DROP
iptables -I OUTPUT -d 27.45.166.55 -j DROP
iptables -I OUTPUT -d 36.101.205.15 -j DROP
iptables -I OUTPUT -d 36.101.205.92 -j DROP
iptables -I OUTPUT -d 36.152.2.101 -j DROP
iptables -I OUTPUT -d 36.152.2.102 -j DROP
iptables -I OUTPUT -d 36.152.2.110 -j DROP
iptables -I OUTPUT -d 36.158.210.195 -j DROP
iptables -I OUTPUT -d 36.158.211.17 -j DROP
iptables -I OUTPUT -d 36.159.126.123 -j DROP
iptables -I OUTPUT -d 36.159.126.70 -j DROP
iptables -I OUTPUT -d 36.159.126.86 -j DROP
iptables -I OUTPUT -d 36.248.26.166 -j DROP
iptables -I OUTPUT -d 36.250.8.141 -j DROP
iptables -I OUTPUT -d 36.250.8.142 -j DROP
iptables -I OUTPUT -d 36.250.8.144 -j DROP
iptables -I OUTPUT -d 36.250.8.145 -j DROP
iptables -I OUTPUT -d 36.250.8.146 -j DROP
iptables -I OUTPUT -d 39.130.161.21 -j DROP
iptables -I OUTPUT -d 39.130.161.90 -j DROP
iptables -I OUTPUT -d 39.130.161.98 -j DROP
iptables -I OUTPUT -d 42.101.76.202 -j DROP
iptables -I OUTPUT -d 42.202.141.23 -j DROP
iptables -I OUTPUT -d 42.202.154.11 -j DROP
iptables -I OUTPUT -d 42.202.154.18 -j DROP
iptables -I OUTPUT -d 42.202.154.19 -j DROP
iptables -I OUTPUT -d 42.202.154.42 -j DROP
iptables -I OUTPUT -d 42.202.154.44 -j DROP
iptables -I OUTPUT -d 42.202.154.56 -j DROP
iptables -I OUTPUT -d 42.236.125.36 -j DROP
iptables -I OUTPUT -d 42.236.126.166 -j DROP
iptables -I OUTPUT -d 42.236.126.23 -j DROP
iptables -I OUTPUT -d 42.236.126.25 -j DROP
iptables -I OUTPUT -d 42.236.126.32 -j DROP
iptables -I OUTPUT -d 42.236.126.33 -j DROP
iptables -I OUTPUT -d 42.236.126.36 -j DROP
iptables -I OUTPUT -d 42.236.126.39 -j DROP
iptables -I OUTPUT -d 42.236.95.11 -j DROP
iptables -I OUTPUT -d 42.236.95.23 -j DROP
iptables -I OUTPUT -d 42.236.95.24 -j DROP
iptables -I OUTPUT -d 42.236.95.25 -j DROP
iptables -I OUTPUT -d 42.236.95.26 -j DROP
iptables -I OUTPUT -d 42.236.95.27 -j DROP
iptables -I OUTPUT -d 42.236.95.40 -j DROP
iptables -I OUTPUT -d 42.236.95.41 -j DROP
iptables -I OUTPUT -d 42.236.95.42 -j DROP
iptables -I OUTPUT -d 42.236.95.43 -j DROP
iptables -I OUTPUT -d 42.236.95.44 -j DROP
iptables -I OUTPUT -d 42.48.109.16 -j DROP
iptables -I OUTPUT -d 42.48.109.17 -j DROP
iptables -I OUTPUT -d 42.56.64.30 -j DROP
iptables -I OUTPUT -d 42.56.65.153 -j DROP
iptables -I OUTPUT -d 42.56.65.155 -j DROP
iptables -I OUTPUT -d 42.56.65.157 -j DROP
iptables -I OUTPUT -d 42.56.65.21 -j DROP
iptables -I OUTPUT -d 42.56.65.22 -j DROP
iptables -I OUTPUT -d 42.56.65.23 -j DROP
iptables -I OUTPUT -d 42.56.65.24 -j DROP
iptables -I OUTPUT -d 42.56.76.36 -j DROP
iptables -I OUTPUT -d 42.56.79.11 -j DROP
iptables -I OUTPUT -d 42.56.83.119 -j DROP
iptables -I OUTPUT -d 42.81.85.190 -j DROP
iptables -I OUTPUT -d 42.81.85.191 -j DROP
iptables -I OUTPUT -d 42.81.85.253 -j DROP
iptables -I OUTPUT -d 58.144.143.11 -j DROP
iptables -I OUTPUT -d 58.144.143.12 -j DROP
iptables -I OUTPUT -d 58.144.143.13 -j DROP
iptables -I OUTPUT -d 58.144.143.14 -j DROP
iptables -I OUTPUT -d 58.144.143.16 -j DROP
iptables -I OUTPUT -d 58.205.214.148 -j DROP
iptables -I OUTPUT -d 58.211.85.13 -j DROP
iptables -I OUTPUT -d 58.211.85.14 -j DROP
iptables -I OUTPUT -d 58.211.85.15 -j DROP
iptables -I OUTPUT -d 58.211.85.17 -j DROP
iptables -I OUTPUT -d 58.211.85.19 -j DROP
iptables -I OUTPUT -d 58.211.85.20 -j DROP
iptables -I OUTPUT -d 58.211.85.36 -j DROP
iptables -I OUTPUT -d 58.211.85.37 -j DROP
iptables -I OUTPUT -d 58.211.85.38 -j DROP
iptables -I OUTPUT -d 58.211.85.39 -j DROP
iptables -I OUTPUT -d 58.211.85.41 -j DROP
iptables -I OUTPUT -d 58.211.85.42 -j DROP
iptables -I OUTPUT -d 58.211.85.43 -j DROP
iptables -I OUTPUT -d 58.211.85.44 -j DROP
iptables -I OUTPUT -d 58.215.146.159 -j DROP
iptables -I OUTPUT -d 58.215.146.160 -j DROP
iptables -I OUTPUT -d 58.216.106.166 -j DROP
iptables -I OUTPUT -d 58.216.6.14 -j DROP
iptables -I OUTPUT -d 58.216.6.163 -j DROP
iptables -I OUTPUT -d 58.216.6.17 -j DROP
iptables -I OUTPUT -d 58.216.6.18 -j DROP
iptables -I OUTPUT -d 58.216.6.19 -j DROP
iptables -I OUTPUT -d 58.216.6.27 -j DROP
iptables -I OUTPUT -d 58.216.6.28 -j DROP
iptables -I OUTPUT -d 58.216.96.11 -j DROP
iptables -I OUTPUT -d 58.216.96.111 -j DROP
iptables -I OUTPUT -d 58.216.96.12 -j DROP
iptables -I OUTPUT -d 58.216.96.13 -j DROP
iptables -I OUTPUT -d 58.216.96.14 -j DROP
iptables -I OUTPUT -d 58.216.96.15 -j DROP
iptables -I OUTPUT -d 58.216.96.21 -j DROP
iptables -I OUTPUT -d 58.216.96.38 -j DROP
iptables -I OUTPUT -d 58.216.96.63 -j DROP
iptables -I OUTPUT -d 58.247.206.171 -j DROP
iptables -I OUTPUT -d 58.247.214.113 -j DROP
iptables -I OUTPUT -d 58.250.137.42 -j DROP
iptables -I OUTPUT -d 58.251.116.47 -j DROP
iptables -I OUTPUT -d 58.251.149.11 -j DROP
iptables -I OUTPUT -d 58.251.149.12 -j DROP
iptables -I OUTPUT -d 58.251.149.13 -j DROP
iptables -I OUTPUT -d 58.251.149.14 -j DROP
iptables -I OUTPUT -d 58.251.149.15 -j DROP
iptables -I OUTPUT -d 58.251.149.16 -j DROP
iptables -I OUTPUT -d 58.251.149.17 -j DROP
iptables -I OUTPUT -d 58.251.149.18 -j DROP
iptables -I OUTPUT -d 58.251.149.19 -j DROP
iptables -I OUTPUT -d 58.251.149.20 -j DROP
iptables -I OUTPUT -d 58.251.149.21 -j DROP
iptables -I OUTPUT -d 58.251.149.22 -j DROP
iptables -I OUTPUT -d 58.251.149.23 -j DROP
iptables -I OUTPUT -d 58.251.149.24 -j DROP
iptables -I OUTPUT -d 58.251.149.25 -j DROP
iptables -I OUTPUT -d 58.251.149.26 -j DROP
iptables -I OUTPUT -d 58.251.149.27 -j DROP
iptables -I OUTPUT -d 58.251.149.28 -j DROP
iptables -I OUTPUT -d 58.251.149.29 -j DROP
iptables -I OUTPUT -d 58.251.149.30 -j DROP
iptables -I OUTPUT -d 58.251.149.31 -j DROP
iptables -I OUTPUT -d 58.251.149.32 -j DROP
iptables -I OUTPUT -d 58.251.149.33 -j DROP
iptables -I OUTPUT -d 58.251.149.34 -j DROP
iptables -I OUTPUT -d 58.49.137.107 -j DROP
iptables -I OUTPUT -d 58.49.137.125 -j DROP
iptables -I OUTPUT -d 58.49.137.17 -j DROP
iptables -I OUTPUT -d 58.49.157.141 -j DROP
iptables -I OUTPUT -d 58.49.224.43 -j DROP
iptables -I OUTPUT -d 59.36.113.27 -j DROP
iptables -I OUTPUT -d 59.36.113.41 -j DROP
iptables -I OUTPUT -d 59.36.113.60 -j DROP
iptables -I OUTPUT -d 59.36.113.62 -j DROP
iptables -I OUTPUT -d 59.37.96.149 -j DROP
iptables -I OUTPUT -d 59.37.96.150 -j DROP
iptables -I OUTPUT -d 59.37.96.151 -j DROP
iptables -I OUTPUT -d 59.37.96.152 -j DROP
iptables -I OUTPUT -d 59.37.96.202 -j DROP
iptables -I OUTPUT -d 59.37.96.244 -j DROP
iptables -I OUTPUT -d 59.37.96.25 -j DROP
iptables -I OUTPUT -d 59.37.96.26 -j DROP
iptables -I OUTPUT -d 59.37.96.36 -j DROP
iptables -I OUTPUT -d 59.37.96.37 -j DROP
iptables -I OUTPUT -d 59.49.45.40 -j DROP
iptables -I OUTPUT -d 59.49.91.106 -j DROP
iptables -I OUTPUT -d 59.49.91.13 -j DROP
iptables -I OUTPUT -d 59.49.91.14 -j DROP
iptables -I OUTPUT -d 59.49.91.15 -j DROP
iptables -I OUTPUT -d 59.49.91.82 -j DROP
iptables -I OUTPUT -d 59.57.18.146 -j DROP
iptables -I OUTPUT -d 59.63.235.11 -j DROP
iptables -I OUTPUT -d 59.63.235.113 -j DROP
iptables -I OUTPUT -d 59.63.235.13 -j DROP
iptables -I OUTPUT -d 59.63.235.14 -j DROP
iptables -I OUTPUT -d 59.63.235.15 -j DROP
iptables -I OUTPUT -d 59.63.235.78 -j DROP
iptables -I OUTPUT -d 59.63.237.145 -j DROP
iptables -I OUTPUT -d 59.63.237.146 -j DROP
iptables -I OUTPUT -d 59.63.237.147 -j DROP
iptables -I OUTPUT -d 59.63.237.148 -j DROP
iptables -I OUTPUT -d 59.63.237.16 -j DROP
iptables -I OUTPUT -d 59.63.237.22 -j DROP
iptables -I OUTPUT -d 59.63.237.237 -j DROP
iptables -I OUTPUT -d 59.63.237.243 -j DROP
iptables -I OUTPUT -d 59.63.237.36 -j DROP
iptables -I OUTPUT -d 59.83.218.121 -j DROP
iptables -I OUTPUT -d 59.83.218.15 -j DROP
iptables -I OUTPUT -d 59.83.218.252 -j DROP
iptables -I OUTPUT -d 59.83.218.87 -j DROP
iptables -I OUTPUT -d 60.167.138.26 -j DROP
iptables -I OUTPUT -d 60.167.138.27 -j DROP
iptables -I OUTPUT -d 60.174.156.21 -j DROP
iptables -I OUTPUT -d 60.217.249.40 -j DROP
iptables -I OUTPUT -d 60.217.253.100 -j DROP
iptables -I OUTPUT -d 61.128.150.34 -j DROP
iptables -I OUTPUT -d 61.129.7.18 -j DROP
iptables -I OUTPUT -d 61.140.13.166 -j DROP
iptables -I OUTPUT -d 61.142.166.141 -j DROP
iptables -I OUTPUT -d 61.142.166.168 -j DROP
iptables -I OUTPUT -d 61.142.166.209 -j DROP
iptables -I OUTPUT -d 61.142.166.248 -j DROP
iptables -I OUTPUT -d 61.151.206.42 -j DROP
iptables -I OUTPUT -d 61.151.206.68 -j DROP
iptables -I OUTPUT -d 61.151.206.90 -j DROP
iptables -I OUTPUT -d 61.151.234.32 -j DROP
iptables -I OUTPUT -d 61.151.234.36 -j DROP
iptables -I OUTPUT -d 61.151.234.56 -j DROP
iptables -I OUTPUT -d 61.151.234.57 -j DROP
iptables -I OUTPUT -d 61.151.234.58 -j DROP
iptables -I OUTPUT -d 61.151.234.59 -j DROP
iptables -I OUTPUT -d 61.151.234.60 -j DROP
iptables -I OUTPUT -d 61.155.220.204 -j DROP
iptables -I OUTPUT -d 61.155.220.206 -j DROP
iptables -I OUTPUT -d 61.156.15.27 -j DROP
iptables -I OUTPUT -d 61.156.15.28 -j DROP
iptables -I OUTPUT -d 61.156.15.29 -j DROP
iptables -I OUTPUT -d 61.156.15.30 -j DROP
iptables -I OUTPUT -d 61.156.15.35 -j DROP
iptables -I OUTPUT -d 61.156.15.37 -j DROP
iptables -I OUTPUT -d 61.156.15.38 -j DROP
iptables -I OUTPUT -d 61.156.15.39 -j DROP
iptables -I OUTPUT -d 61.156.15.40 -j DROP
iptables -I OUTPUT -d 61.156.15.41 -j DROP
iptables -I OUTPUT -d 61.156.15.42 -j DROP
iptables -I OUTPUT -d 61.156.15.52 -j DROP
iptables -I OUTPUT -d 61.156.15.71 -j DROP
iptables -I OUTPUT -d 61.156.15.88 -j DROP
iptables -I OUTPUT -d 61.182.131.60 -j DROP
iptables -I OUTPUT -d 61.182.131.62 -j DROP
iptables -I OUTPUT -d 61.182.140.149 -j DROP
iptables -I OUTPUT -d 61.183.164.24 -j DROP
iptables -I OUTPUT -d 61.183.164.25 -j DROP
iptables -I OUTPUT -d 61.183.164.27 -j DROP
iptables -I OUTPUT -d 61.183.164.28 -j DROP
iptables -I OUTPUT -d 61.183.164.29 -j DROP
iptables -I OUTPUT -d 61.183.164.30 -j DROP
iptables -I OUTPUT -d 61.183.164.31 -j DROP
iptables -I OUTPUT -d 61.183.164.34 -j DROP
iptables -I OUTPUT -d 61.183.164.35 -j DROP
iptables -I OUTPUT -d 61.183.164.36 -j DROP
iptables -I OUTPUT -d 61.183.164.37 -j DROP
iptables -I OUTPUT -d 61.183.164.38 -j DROP
iptables -I OUTPUT -d 61.183.164.39 -j DROP
iptables -I OUTPUT -d 61.183.164.41 -j DROP
iptables -I OUTPUT -d 61.183.164.42 -j DROP
iptables -I OUTPUT -d 61.183.164.44 -j DROP
iptables -I OUTPUT -d 61.183.164.81 -j DROP
iptables -I OUTPUT -d 61.184.213.244 -j DROP
iptables -I OUTPUT -d 61.191.60.35 -j DROP
iptables -I OUTPUT -d 61.240.150.33 -j DROP
iptables -I OUTPUT -d 61.54.253.18 -j DROP
iptables -I OUTPUT -d 61.54.253.29 -j DROP
iptables -I OUTPUT -d 61.54.253.33 -j DROP
iptables -I OUTPUT -d 61.54.253.42 -j DROP
iptables -I OUTPUT -d 61.54.253.44 -j DROP
iptables -I OUTPUT -d 61.54.253.92 -j DROP
iptables -A INPUT -p tcp --dport 11375 -j DROP
iptables -A INPUT -p tcp --dport 18429 -j DROP
iptables -A INPUT -p tcp --dport 1883 -j DROP
iptables -A INPUT -p tcp --dport 19332 -j DROP
iptables -A INPUT -p tcp --dport 25050 -j DROP
iptables -A INPUT -p tcp --dport 28362 -j DROP
iptables -A INPUT -p tcp --dport 32575 -j DROP
iptables -A INPUT -p tcp --dport 34984 -j DROP
iptables -A INPUT -p tcp --dport 35875 -j DROP
iptables -A INPUT -p tcp --dport 39613 -j DROP
iptables -A INPUT -p tcp --dport 42825 -j DROP
iptables -A INPUT -p udp --dport 11375 -j DROP
iptables -A INPUT -p udp --dport 18429 -j DROP
iptables -A INPUT -p udp --dport 1883 -j DROP
iptables -A INPUT -p udp --dport 19332 -j DROP
iptables -A INPUT -p udp --dport 25050 -j DROP
iptables -A INPUT -p udp --dport 28362 -j DROP
iptables -A INPUT -p udp --dport 32575 -j DROP
iptables -A INPUT -p udp --dport 34984 -j DROP
iptables -A INPUT -p udp --dport 35875 -j DROP
iptables -A INPUT -p udp --dport 39613 -j DROP
iptables -A INPUT -p udp --dport 42825 -j DROP
iptables -A OUTPUT -p tcp --dport 11375 -j DROP
iptables -A OUTPUT -p tcp --dport 18429 -j DROP
iptables -A OUTPUT -p tcp --dport 1883 -j DROP
iptables -A OUTPUT -p tcp --dport 19332 -j DROP
iptables -A OUTPUT -p tcp --dport 25050 -j DROP
iptables -A OUTPUT -p tcp --dport 28362 -j DROP
iptables -A OUTPUT -p tcp --dport 32575 -j DROP
iptables -A OUTPUT -p tcp --dport 34984 -j DROP
iptables -A OUTPUT -p tcp --dport 35875 -j DROP
iptables -A OUTPUT -p tcp --dport 39613 -j DROP
iptables -A OUTPUT -p tcp --dport 42825 -j DROP
iptables -A OUTPUT -p udp --dport 11375 -j DROP
iptables -A OUTPUT -p udp --dport 18429 -j DROP
iptables -A OUTPUT -p udp --dport 1883 -j DROP
iptables -A OUTPUT -p udp --dport 19332 -j DROP
iptables -A OUTPUT -p udp --dport 25050 -j DROP
iptables -A OUTPUT -p udp --dport 28362 -j DROP
iptables -A OUTPUT -p udp --dport 32575 -j DROP
iptables -A OUTPUT -p udp --dport 34984 -j DROP
iptables -A OUTPUT -p udp --dport 35875 -j DROP
iptables -A OUTPUT -p udp --dport 39613 -j DROP
iptables -A OUTPUT -p udp --dport 42825 -j DROP



su -c iptables -I INPUT -p tcp --dport 8086 -j DROP
su -c iptables -I INPUT -p tcp --dport 8085 -j DROP
su -c iptables -I INPUT -p tcp --dport 90 -j DROP
su -c iptables -I INPUT -p tcp --dport 554 -j DROP
su -c iptables -I INPUT -p tcp --dport 80 -j DROP
su -c iptables -I INPUT -p tcp --dport 443 -j DROP
su -c iptables -I INPUT -p tcp --dport 8013 -j DROP
su -c iptables -I INPUT -p tcp --dport 15692 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 10080 -j DROP
su -c iptables -I INPUT -p tcp --dport 20001 -j DROP
su -c iptables -I INPUT -p tcp --dport 20000 -j DROP
su -c iptables -I INPUT -p tcp --dport 8011 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 20002 -j DROP
su -c iptables -I INPUT -p tcp --dport 17000 -j DROP
su -c iptables -I INPUT -p UDP --dport 8700 -j DROP
su -c iptables -I INPUT -p tcp --dport 20371 -j DROP
su -c iptables -I INPUT -p UDP --dport 9030 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 18600 -j DROP
su -c iptables -I INPUT -p UDP --dport 10013 -j DROP
su -c iptables -I INPUT -p UDP --dport 10012 -j DROP
su -c iptables -I INPUT -p UDP --dport 10019 -j DROP

su -c iptables -I OUTPUT -p tcp --dport 8086 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8085 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 90 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 554 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 80 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 443 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 9031 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10080 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20001 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20002 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 8700 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 9030 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 9031 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18600 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10013 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10012 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10019 -j DROP

su -c iptables -I FORWARD -p tcp --dport 8086 -j DROP
su -c iptables -I FORWARD -p tcp --dport 8085 -j DROP
su -c iptables -I FORWARD -p tcp --dport 90 -j DROP
su -c iptables -I FORWARD -p tcp --dport 554 -j DROP
su -c iptables -I FORWARD -p tcp --dport 80 -j DROP
su -c iptables -I FORWARD -p tcp --dport 443 -j DROP
su -c iptables -I FORWARD -p UDP --dport 443 -j DROP
su -c iptables -I FORWARD -p tcp --dport 8013 -j DROP
su -c iptables -I FORWARD -p tcp --dport 15692 -j DROP
su -c iptables -I FORWARD -p UDP --dport 9031 -j DROP
su -c iptables -I FORWARD -p tcp --dport 10080 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20001 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20000 -j DROP
su -c iptables -I FORWARD -p tcp --dport 8011 -j DROP
su -c iptables -I FORWARD -p tcp --dport 18081 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20002 -j DROP
su -c iptables -I FORWARD -p tcp --dport 17000 -j DROP
su -c iptables -I FORWARD -p UDP --dport 8700 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20371 -j DROP
su -c iptables -I FORWARD -p UDP --dport 9030 -j DROP
su -c iptables -I FORWARD -p UDP --dport 9031 -j DROP
su -c iptables -I FORWARD -p tcp --dport 18600 -j DROP
su -c iptables -I FORWARD -p UDP --dport 10013 -j DROP
su -c iptables -I FORWARD -p UDP --dport 10012 -j DROP
su -c iptables -I FORWARD -p UDP --dport 10019 -j DROP

iptables -t nat -D OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -D OUTPUT -p tcp --destination-port 53 -j DROP
ip6tables -D OUTPUT -p udp --destination-port 53 -j DROP
iptables -D OUTPUT -p tcp --destination-port 53 -j DROP
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -A OUTPUT -p udp --destination-port 53 -j DROP
ip6tables -A OUTPUT -p tcp --destination-port 53 -j DROP
iptables -A OUTPUT -p tcp --destination-port 53 -j DROP

am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity > /dev/null

sleep 5
clear
while true
do
rm -rf /sdcard/Android/data/com.tencent.ig/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.tencent.ig/cache
rm -rf /sdcard/Android/data/com.tencent.ig/files/tbslog
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora


