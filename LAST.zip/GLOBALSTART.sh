
iptables -A FORWARD -m string --algo bm --string "AntiCheatOpenID" -j DROP
iptables -A FORWARD -m string --algo bm --string "COREREPORT" -j DROP
iptables -A FORWARD -m string --algo bm --string "N6TssSDK11ReportQueue" -j DROP
iptables -A FORWARD -m string --algo bm --string "N6TssSDK15FileCrcReporter" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDK.ReportQosByGame" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKDelReportData" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKGetReportData" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKOnRecvData" -j DROP
iptables -A FORWARD -m string --algo bm --string "WB_GetReportStr" -j DROP
iptables -A FORWARD -m string --algo bm --string "_ZN6TssSdk16sdt_report_errorEv" -j DROP
iptables -A FORWARD -m string --algo bm --string "amazonaws.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "asia.csoversea.mbgame.anticheatexpert.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "cs.mbgame.gamesafe.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "dlied1.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "down.anticheatexpert.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "down.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "intldlgs.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "report_apk" -j DROP
iptables -A FORWARD -m string --algo bm --string "res_max_report_missed_cnt" -j DROP
iptables -A FORWARD -m string --algo bm --string "sc_report" -j DROP
iptables -A FORWARD -m string --algo bm --string "tdm_report" -j DROP
iptables -A FORWARD -m string --algo bm --string "tdm_report_sdk_update_config_finish" -j DROP
iptables -A FORWARD -m string --algo bm --string "tencentgames.helpshift.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "tp2_free_anti_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_del_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_enable_get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_sdk_rcv_anti_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "vmp.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "AntiCheatOpenID" -j DROP
iptables -A INPUT -m string --algo bm --string "COREREPORT" -j DROP
iptables -A INPUT -m string --algo bm --string "N6TssSDK11ReportQueue" -j DROP
iptables -A INPUT -m string --algo bm --string "N6TssSDK15FileCrcReporter" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDK.ReportQosByGame" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKDelReportData" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKGetReportData" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKOnRecvData" -j DROP
iptables -A INPUT -m string --algo bm --string "WB_GetReportStr" -j DROP
iptables -A INPUT -m string --algo bm --string "_ZN6TssSdk16sdt_report_errorEv" -j DROP
iptables -A INPUT -m string --algo bm --string "amazonaws.com" -j DROP
iptables -A INPUT -m string --algo bm --string "asia.csoversea.mbgame.anticheatexpert.com" -j DROP
iptables -A INPUT -m string --algo bm --string "cs.mbgame.gamesafe.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "dlied1.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "down.anticheatexpert.com" -j DROP
iptables -A INPUT -m string --algo bm --string "down.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "intldlgs.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "report_apk" -j DROP
iptables -A INPUT -m string --algo bm --string "res_max_report_missed_cnt" -j DROP
iptables -A INPUT -m string --algo bm --string "sc_report" -j DROP
iptables -A INPUT -m string --algo bm --string "tdm_report" -j DROP
iptables -A INPUT -m string --algo bm --string "tdm_report_sdk_update_config_finish" -j DROP
iptables -A INPUT -m string --algo bm --string "tencentgames.helpshift.com" -j DROP
iptables -A INPUT -m string --algo bm --string "tp2_free_anti_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_del_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_enable_get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_sdk_rcv_anti_data" -j DROP
iptables -A INPUT -m string --algo bm --string "vmp.qq.com" -j DROP
iptables -A INPUT -p tcp --dport 10000:10024 -j DROP
iptables -A INPUT -p tcp --dport 22:443 -j DROP
iptables -A INPUT -p tcp --dport 38824 -j DROP
iptables -A INPUT -p tcp --dport 39752 -j DROP
iptables -A INPUT -p tcp --dport 39888 -j DROP
iptables -A INPUT -p tcp --dport 40984 -j DROP
iptables -A INPUT -p tcp --dport 42856 -j DROP
iptables -A INPUT -p tcp --dport 42856:43000 -j DROP
iptables -A INPUT -p tcp --dport 43314 -j DROP
iptables -A INPUT -p tcp --dport 43322 -j DROP
iptables -A INPUT -p tcp --dport 43388 -j DROP
iptables -A INPUT -p tcp --dport 43476 -j DROP
iptables -A INPUT -p tcp --dport 43732 -j DROP
iptables -A INPUT -p tcp --dport 44808 -j DROP
iptables -A INPUT -p tcp --dport 44978:45000 -j DROP
iptables -A INPUT -p tcp --dport 45198 -j DROP
iptables -A INPUT -p tcp --dport 46726 -j DROP
iptables -A INPUT -p tcp --dport 46924 -j DROP
iptables -A INPUT -p tcp --dport 48774 -j DROP
iptables -A INPUT -p tcp --dport 48919 -j DROP
iptables -A INPUT -p tcp --dport 8080:8099 -j DROP
#iptables -A INPUT -p tcp -m multiport ! --dports 17500 -j DROP
iptables -A OUTPUT -m string --algo bm --string "AntiCheatOpenID" -j DROP
iptables -A OUTPUT -m string --algo bm --string "COREREPORT" -j DROP
iptables -A OUTPUT -m string --algo bm --string "N6TssSDK11ReportQueue" -j DROP
iptables -A OUTPUT -m string --algo bm --string "N6TssSDK15FileCrcReporter" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDK.ReportQosByGame" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDKDelReportData" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDKGetReportData" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDKOnRecvData" -j DROP
iptables -A OUTPUT -m string --algo bm --string "WB_GetReportStr" -j DROP
iptables -A OUTPUT -m string --algo bm --string "_ZN6TssSdk16sdt_report_errorEv" -j DROP
iptables -A OUTPUT -m string --algo bm --string "amazonaws.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "asia.csoversea.mbgame.anticheatexpert.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "cs.mbgame.gamesafe.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "dlied1.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "down.anticheatexpert.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "down.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "get_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "intldlgs.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "report_apk" -j DROP
iptables -A OUTPUT -m string --algo bm --string "res_max_report_missed_cnt" -j DROP
iptables -A OUTPUT -m string --algo bm --string "sc_report" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tdm_report" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tdm_report_sdk_update_config_finish" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tencentgames.helpshift.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tp2_free_anti_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_del_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_enable_get_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_get_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_sdk_rcv_anti_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "vmp.qq.com" -j DROP
iptables -I INPUT -p all -m string --string "app.adjust.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cloudconfig.googleapis.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cloudctrl.gcloudsdk.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "compute.amazonaws.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "d.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dl.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "f.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "ig-us-sdkapi.igamecj.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "k.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "mtp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "onezapp.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "proximabeta.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "qcloud.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "report.syzs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "sy.guanjia.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "tencentgames.helpshift.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "tsg.tdatamaster.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "twimg.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '150.109.27.214' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '157.240.16.16' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '192.168.0.103' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '224.0.0.251' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'abs.twimg.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'af-za.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'api.amplitude.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-hk.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-in.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-mb.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-sg.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-th.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'astat.bugly.qcloud.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cdn.wetest.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cdn.wetest.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cloud.gsdk.proximabeta.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cloudsv.ieg.onezapp.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'csi.gstatic.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'eu-fra.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'eu-mo.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'euping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'file.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'filecdn.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'hk.api.unipay.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'hkping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'hkspeed.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'idcconfig.gcloudsdk.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'ig-us-notice.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'in.voice.gcloudcs.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'intldlgs.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'kj-se.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'kj-tk.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'krping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'lh3.googleusercontent.com' --algo kmp -j DROP &>/dev/null
#iptables -I INPUT -p all -m string --string 'lobby.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'me-du.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'meping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'midas.gtimg.cn' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-centra.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-east.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-mx.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-west.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'naping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'napubgm.broker.amsoveasea.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'nawzryhwatm.broker.amsoveasea.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'pandora.game.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'platform-lookaside.fbsbx.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'pubgmobile.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'qos.hk.gcloudcs.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'safebrowsing.googleapis.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'saping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'tpc.googlesyndication.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'usa.csoversea.mbgame.anticheatexpert.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'video.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'youtubei.googleapis.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 1112 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 11443 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 18081 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 3013 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 80 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8080 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8085 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8086 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8088 -j DROP &>/dev/null
#iptables -I INPUT -s krlobby.igamecj.com -j DROP &>/dev/null
#iptables -I INPUT -s lobby.igamecj.com -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d 150.109.248.116 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d 199.59.242.154 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d 58.250.137.36 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -s 150.109.248.116 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -s 199.59.242.154 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -s 58.250.137.36 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d 150.109.248.116 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d 199.59.242.154 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d 58.250.137.36 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -s 150.109.248.116 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -s 199.59.242.154 -j DROP &>/dev/null
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -s 58.250.137.36 -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "app.adjust.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cloudconfig.googleapis.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cloudctrl.gcloudsdk.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "compute.amazonaws.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "d.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dl.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "f.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "ig-us-sdkapi.igamecj.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "k.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "mtp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "onezapp.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "proximabeta.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "qcloud.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "report.syzs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "sy.guanjia.qq.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "tencentgames.helpshift.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "tsg.tdatamaster.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "twimg.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'abs.twimg.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'af-za.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'api.amplitude.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-hk.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-in.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-mb.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-sg.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-th.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'astat.bugly.qcloud.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cdn.wetest.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cdn.wetest.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cloud.gsdk.proximabeta.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cloudsv.ieg.onezapp.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'csi.gstatic.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'eu-fra.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'eu-mo.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'euping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'file.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'filecdn.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'hk.api.unipay.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'hkping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'hkspeed.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'idcconfig.gcloudsdk.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'ig-us-notice.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'in.voice.gcloudcs.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'intldlgs.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'kj-se.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'kj-tk.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'krping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'lh3.googleusercontent.com' --algo bm -j DROP &>/dev/null
#iptables -I OUTPUT -p all -m string --string 'lobby.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'me-du.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'meping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'midas.gtimg.cn' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-centra.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-east.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-mx.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-west.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'naping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'napubgm.broker.amsoveasea.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'nawzryhwatm.broker.amsoveasea.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'pandora.game.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'platform-lookaside.fbsbx.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'pubgmobile.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'qos.hk.gcloudcs.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'safebrowsing.googleapis.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'saping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'tpc.googlesyndication.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'usa.csoversea.mbgame.anticheatexpert.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'video.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'youtubei.googleapis.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 1112 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 11443 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 18081 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 3013 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 80 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8080 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8085 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8086 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8088 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 11038 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 111 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 20001 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 8011 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 81 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 11038 -j DROP
iptables -I OUTPUT -p udp --dport 111 -j DROP
iptables -I OUTPUT -p udp --dport 20001 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 81 -j DROP
#iptables -I OUTPUT -s krlobby.igamecj.com -j DROP &>/dev/nul


su -c iptables -I INPUT -p tcp --dport 8086 -j DROP
su -c iptables -I INPUT -p tcp --dport 8085 -j DROP
su -c iptables -I INPUT -p tcp --dport 90 -j DROP
su -c iptables -I INPUT -p tcp --dport 554 -j DROP
su -c iptables -I INPUT -p tcp --dport 80 -j DROP
#su -c iptables -I INPUT -p tcp --dport 443 -j DROP
su -c iptables -I INPUT -p tcp --dport 8013 -j DROP
su -c iptables -I INPUT -p tcp --dport 15692 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 10080 -j DROP
su -c iptables -I INPUT -p tcp --dport 20001 -j DROP
su -c iptables -I INPUT -p tcp --dport 20000 -j DROP
su -c iptables -I INPUT -p tcp --dport 8011 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 20002 -j DROP
su -c iptables -I INPUT -p tcp --dport 17000 -j DROP
su -c iptables -I INPUT -p UDP --dport 8700 -j DROP
su -c iptables -I INPUT -p tcp --dport 20371 -j DROP
su -c iptables -I INPUT -p UDP --dport 9030 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 18600 -j DROP
su -c iptables -I INPUT -p UDP --dport 10013 -j DROP
su -c iptables -I INPUT -p UDP --dport 10012 -j DROP
su -c iptables -I INPUT -p UDP --dport 10019 -j DROP

su -c iptables -I OUTPUT -p tcp --dport 8086 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8085 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 90 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 554 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 80 -j DROP
#su -c iptables -I OUTPUT -p tcp --dport 443 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 9031 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10080 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20001 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20002 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 8700 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 9030 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 9031 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18600 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10013 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10012 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10019 -j DROP

su -c iptables -I FORWARD -p tcp --dport 8086 -j DROP
su -c iptables -I FORWARD -p tcp --dport 8085 -j DROP
su -c iptables -I FORWARD -p tcp --dport 90 -j DROP
su -c iptables -I FORWARD -p tcp --dport 554 -j DROP
su -c iptables -I FORWARD -p tcp --dport 80 -j DROP
su -c iptables -I FORWARD -p tcp --dport 443 -j DROP
#su -c iptables -I FORWARD -p UDP --dport 443 -j DROP
su -c iptables -I FORWARD -p tcp --dport 8013 -j DROP
su -c iptables -I FORWARD -p tcp --dport 15692 -j DROP
su -c iptables -I FORWARD -p UDP --dport 9031 -j DROP
su -c iptables -I FORWARD -p tcp --dport 10080 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20001 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20000 -j DROP
su -c iptables -I FORWARD -p tcp --dport 8011 -j DROP
su -c iptables -I FORWARD -p tcp --dport 18081 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20002 -j DROP
su -c iptables -I FORWARD -p tcp --dport 17000 -j DROP
su -c iptables -I FORWARD -p UDP --dport 8700 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20371 -j DROP
su -c iptables -I FORWARD -p UDP --dport 9030 -j DROP
su -c iptables -I FORWARD -p UDP --dport 9031 -j DROP
su -c iptables -I FORWARD -p tcp --dport 18600 -j DROP
su -c iptables -I FORWARD -p UDP --dport 10013 -j DROP
su -c iptables -I FORWARD -p UDP --dport 10012 -j DROP
su -c iptables -I FORWARD -p UDP --dport 10019 -j DROP

iptables -t nat -D OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -D OUTPUT -p tcp --destination-port 53 -j DROP
ip6tables -D OUTPUT -p udp --destination-port 53 -j DROP
iptables -D OUTPUT -p tcp --destination-port 53 -j DROP
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -A OUTPUT -p udp --destination-port 53 -j DROP
ip6tables -A OUTPUT -p tcp --destination-port 53 -j DROP
iptables -A OUTPUT -p tcp --destination-port 53 -j DROP

am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity > /dev/null

