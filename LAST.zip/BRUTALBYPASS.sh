chmod 775 /data/media/0/Android/data/com.pakage.upsilon/files/fixban

su -c /data/media/0/Android/data/com.pakage.upsilon/files/fixban
