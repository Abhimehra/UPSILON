rm -rf /data/data/com.pubg.imobile/lib/libBugly
rm -rf /data/data/com.pubg.imobile/lib/libcubehawk.so
rm -rf /data/data/com.pubg.imobile/lib/libgcloud.so
rm -rf /data/data/com.pubg.imobile/lib/libigshare.so
rm -rf /data/data/com.pubg.imobile/lib/libIMSDK.so
rm -rf /data/data/com.pubg.imobile/lib/liblbs.so
rm -rf /data/data/com.pubg.imobile/lib/libTDataMaster.so
rm -rf /data/data/com.pubg.imobile/lib/libtersafe.so
rm -rf /data/data/com.pubg.imobile/lib/libtprt.so
rm -rf /data/data/com.pubg.imobile/lib/libUE4.so

sleep 1

cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/a.so /data/data/com.pubg.imobile/lib/libBugly.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/b.so /data/data/com.pubg.imobile/lib/libcubehawk.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/c.so /data/data/com.pubg.imobile/lib/libgcloud.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/d.so /data/data/com.pubg.imobile/lib/libigshare.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/e.so /data/data/com.pubg.imobile/lib/libIMSDK.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/f.so /data/data/com.pubg.imobile/lib/liblbs.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/g.so /data/data/com.pubg.imobile/lib/libTDataMaster.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/h.so /data/data/com.pubg.imobile/lib/libtersafe.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/i.so /data/data/com.pubg.imobile/lib/libtprt.so
cp -rf /data/media/0/Android/data/com.pakage.upsilon/files/j.so /data/data/com.pubg.imobile/lib/libUE4.so

chmod 755 /data/data/com.pubg.imobile/lib/*
chmod 755 /data/data/com.pubg.imobile/lib*/
