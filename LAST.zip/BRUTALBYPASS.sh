su -c chmod -R 777 /data/media/0/Android/data/com.pakage.upsilon/files/BYPASS
su -c exec /data/media/0/Android/data/com.pakage.upsilon/files/BYPASS BEAST