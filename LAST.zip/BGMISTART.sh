echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events


cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches


rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo '[/Script/Client.GDolphinUpdater]\nDisable=true' > /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini

iptables -I INPUT -s krlobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s krlobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 0euping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 0euping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 14meping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 14meping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 1dd2hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 1dd2hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 127.1hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 127.1hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 1krping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 1krping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 1pay.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 1pay.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 3rdparty.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 4lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s config.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s config.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s gilobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gilobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 4lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 4lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s headshot.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s headshot.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s vn.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s vn.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s tw.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s tw.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s gl.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gl.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s guest.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s guest.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s gl.public.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gl.public.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s pubgm.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s pubgm.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s tencent.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s tencent.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s report.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s report.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s reverse.comsaping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s reverse.comsaping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s free.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s free.igamecj.com -j REJECT &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/TGPA &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs0 /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs1 &>/dev/null
chmod 770 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

su -c iptables -I INPUT -p tcp --dport 8086 -j DROP
su -c iptables -I INPUT -p tcp --dport 8085 -j DROP
su -c iptables -I INPUT -p tcp --dport 90 -j DROP
su -c iptables -I INPUT -p tcp --dport 554 -j DROP
su -c iptables -I INPUT -p tcp --dport 80 -j DROP
su -c iptables -I INPUT -p tcp --dport 443 -j DROP
su -c iptables -I INPUT -p tcp --dport 8013 -j DROP
su -c iptables -I INPUT -p tcp --dport 15692 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 10080 -j DROP
su -c iptables -I INPUT -p tcp --dport 20001 -j DROP
su -c iptables -I INPUT -p tcp --dport 20000 -j DROP
su -c iptables -I INPUT -p tcp --dport 8011 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 20002 -j DROP
su -c iptables -I INPUT -p tcp --dport 17000 -j DROP
su -c iptables -I INPUT -p UDP --dport 8700 -j DROP
su -c iptables -I INPUT -p tcp --dport 20371 -j DROP
su -c iptables -I INPUT -p UDP --dport 9030 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 18600 -j DROP
su -c iptables -I INPUT -p UDP --dport 10013 -j DROP
su -c iptables -I INPUT -p UDP --dport 10012 -j DROP
su -c iptables -I INPUT -p UDP --dport 10019 -j DROP

su -c iptables -I OUTPUT -p tcp --dport 8086 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8085 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 90 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 554 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 80 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 443 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 9031 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10080 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20001 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20002 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 8700 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 9030 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 9031 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18600 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10013 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10012 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10019 -j DROP

su -c iptables -I FORWARD -p tcp --dport 8086 -j DROP
su -c iptables -I FORWARD -p tcp --dport 8085 -j DROP
su -c iptables -I FORWARD -p tcp --dport 90 -j DROP
su -c iptables -I FORWARD -p tcp --dport 554 -j DROP
su -c iptables -I FORWARD -p tcp --dport 80 -j DROP
su -c iptables -I FORWARD -p tcp --dport 443 -j DROP
su -c iptables -I FORWARD -p tcp --dport 8013 -j DROP
su -c iptables -I FORWARD -p tcp --dport 15692 -j DROP
su -c iptables -I FORWARD -p UDP --dport 9031 -j DROP
su -c iptables -I FORWARD -p tcp --dport 10080 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20001 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20000 -j DROP
su -c iptables -I FORWARD -p tcp --dport 8011 -j DROP
su -c iptables -I FORWARD -p tcp --dport 18081 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20002 -j DROP
su -c iptables -I FORWARD -p tcp --dport 17000 -j DROP
su -c iptables -I FORWARD -p UDP --dport 8700 -j DROP
su -c iptables -I FORWARD -p tcp --dport 20371 -j DROP
su -c iptables -I FORWARD -p UDP --dport 9030 -j DROP
su -c iptables -I FORWARD -p UDP --dport 9031 -j DROP
su -c iptables -I FORWARD -p tcp --dport 18600 -j DROP
su -c iptables -I FORWARD -p UDP --dport 10013 -j DROP
su -c iptables -I FORWARD -p UDP --dport 10012 -j DROP
su -c iptables -I FORWARD -p UDP --dport 10019 -j DROP

iptables -t nat -D OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -D OUTPUT -p tcp --destination-port 53 -j DROP
ip6tables -D OUTPUT -p udp --destination-port 53 -j DROP
iptables -D OUTPUT -p tcp --destination-port 53 -j DROP
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -A OUTPUT -p udp --destination-port 53 -j DROP
ip6tables -A OUTPUT -p tcp --destination-port 53 -j DROP
iptables -A OUTPUT -p tcp --destination-port 53 -j DROP


am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity > /dev/null

sleep 5
clear
while true
do
rm -rf /sdcard/Android/data/com.pubg.imobile/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.imobile/cache
rm -rf /sdcard/Android/data/com.pubg.imobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
