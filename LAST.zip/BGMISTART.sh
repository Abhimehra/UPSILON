echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events


cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches


rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo '[/Script/Client.GDolphinUpdater]\nDisable=true' > /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini

iptables -I INPUT -s krlobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s krlobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 0euping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 0euping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 14meping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 14meping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 1dd2hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 1dd2hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 127.1hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 127.1hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 1krping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 1krping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 1pay.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 1pay.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 3rdparty.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 4lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s config.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s config.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s gilobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gilobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s 4lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s 4lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s headshot.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s headshot.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s vn.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s vn.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s tw.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s tw.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s gl.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gl.lobby.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s hkspeed.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s guest.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s guest.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s gl.public.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gl.public.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s pubgm.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s pubgm.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s tencent.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s tencent.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s report.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s report.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s reverse.comsaping.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s reverse.comsaping.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s free.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s free.igamecj.com -j REJECT &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/TGPA &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs0 /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs1 &>/dev/null
chmod 770 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

su -c iptables -A INPUT -p tcp --dport 8086 -j REJECT
su -c iptables -A INPUT -p tcp --dport 8085 -j REJECT
su -c iptables -A INPUT -p tcp --dport 90 -j REJECT
su -c iptables -A INPUT -p tcp --dport 554 -j REJECT
su -c iptables -A INPUT -p tcp --dport 80 -j REJECT
su -c iptables -A INPUT -p tcp --dport 443 -j REJECT
su -c iptables -A INPUT -p tcp --dport 8013 -j REJECT
su -c iptables -A INPUT -p tcp --dport 15692 -j REJECT
su -c iptables -A INPUT -p UDP --dport 9031 -j REJECT
su -c iptables -A INPUT -p tcp --dport 10080 -j REJECT
su -c iptables -A INPUT -p tcp --dport 20001 -j REJECT
su -c iptables -A INPUT -p tcp --dport 20000 -j REJECT
su -c iptables -A INPUT -p tcp --dport 8011 -j REJECT
su -c iptables -A INPUT -p tcp --dport 18081 -j REJECT
su -c iptables -A INPUT -p tcp --dport 20002 -j REJECT
su -c iptables -A INPUT -p tcp --dport 17000 -j REJECT
su -c iptables -A INPUT -p UDP --dport 8700 -j REJECT
su -c iptables -A INPUT -p tcp --dport 20371 -j REJECT
su -c iptables -A INPUT -p UDP --dport 9030 -j REJECT
su -c iptables -A INPUT -p UDP --dport 9031 -j REJECT
su -c iptables -A INPUT -p tcp --dport 18600 -j REJECT
su -c iptables -A INPUT -p UDP --dport 10013 -j REJECT
su -c iptables -A INPUT -p UDP --dport 10012 -j REJECT
su -c iptables -A INPUT -p UDP --dport 10019 -j REJECT

su -c iptables -A OUTPUT -p tcp --dport 8086 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 8085 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 90 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 554 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 80 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 443 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 8013 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 15692 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 9031 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 10080 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 20001 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 20000 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 8011 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 18081 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 20002 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 17000 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 8700 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 20371 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 9030 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 9031 -j REJECT
su -c iptables -A OUTPUT -p tcp --dport 18600 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 10013 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 10012 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 10019 -j REJECT

su -c iptables -A INPUT -p UDP --dport 8086 -j REJECT
su -c iptables -A INPUT -p UDP --dport 8085 -j REJECT
su -c iptables -A INPUT -p UDP --dport 90 -j REJECT
su -c iptables -A INPUT -p UDP --dport 554 -j REJECT
su -c iptables -A INPUT -p UDP --dport 80 -j REJECT
su -c iptables -A INPUT -p UDP --dport 443 -j REJECT
su -c iptables -A INPUT -p UDP --dport 8013 -j REJECT
su -c iptables -A INPUT -p UDP --dport 15692 -j REJECT
su -c iptables -A INPUT -p UDP --dport 9031 -j REJECT
su -c iptables -A INPUT -p UDP --dport 10080 -j REJECT
su -c iptables -A INPUT -p UDP --dport 20001 -j REJECT
su -c iptables -A INPUT -p UDP --dport 20000 -j REJECT
su -c iptables -A INPUT -p UDP --dport 8011 -j REJECT
su -c iptables -A INPUT -p UDP --dport 18081 -j REJECT
su -c iptables -A INPUT -p UDP --dport 20002 -j REJECT
su -c iptables -A INPUT -p UDP --dport 17000 -j REJECT
su -c iptables -A INPUT -p UDP --dport 8700 -j REJECT
su -c iptables -A INPUT -p UDP --dport 20371 -j REJECT
su -c iptables -A INPUT -p UDP --dport 9030 -j REJECT
su -c iptables -A INPUT -p UDP --dport 9031 -j REJECT
su -c iptables -A INPUT -p UDP --dport 18600 -j REJECT
su -c iptables -A INPUT -p UDP --dport 10013 -j REJECT
su -c iptables -A INPUT -p UDP --dport 10012 -j REJECT
su -c iptables -A INPUT -p UDP --dport 10019 -j REJECT

su -c iptables -A OUTPUT -p UDP --dport 8086 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 8085 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 90 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 554 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 80 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 443 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 8013 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 15692 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 9031 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 10080 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 20001 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 20000 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 8011 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 18081 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 20002 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 17000 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 8700 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 20371 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 9030 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 9031 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 18600 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 10013 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 10012 -j REJECT
su -c iptables -A OUTPUT -p UDP --dport 10019 -j REJECT


am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity > /dev/null

sleep 5
clear
while true
do
rm -rf /sdcard/Android/data/com.pubg.imobile/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.imobile/cache
rm -rf /sdcard/Android/data/com.pubg.imobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
