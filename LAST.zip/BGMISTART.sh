

echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events


cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches


chmod 777 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
cp -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15337.pak /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.25337.pak
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
echo '[version]
appversion=1.5.0.15331
srcversion=1.5.0.25337' >> /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 550 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 555 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
echo "  

kkk3o" >> /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
cp /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo "[/Script/Client.GDolphinUpdater]
Disable=true" > /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo DONE

su -c iptables -A INPUT -p tcp --dport 8086 -j DROP
su -c iptables -A INPUT -p tcp --dport 8085 -j DROP
su -c iptables -A INPUT -p tcp --dport 90 -j DROP
su -c iptables -A INPUT -p tcp --dport 554 -j DROP
su -c iptables -A INPUT -p tcp --dport 80 -j DROP
su -c iptables -A INPUT -p tcp --dport 443 -j DROP
su -c iptables -A INPUT -p tcp --dport 8013 -j DROP
su -c iptables -A INPUT -p tcp --dport 15692 -j DROP
su -c iptables -A INPUT -p UDP --dport 9031 -j DROP
su -c iptables -A INPUT -p tcp --dport 10080 -j DROP
su -c iptables -A INPUT -p tcp --dport 20001 -j DROP
su -c iptables -A INPUT -p tcp --dport 20000 -j DROP
su -c iptables -A INPUT -p tcp --dport 8011 -j DROP
su -c iptables -A INPUT -p tcp --dport 18081 -j DROP
su -c iptables -A INPUT -p tcp --dport 20002 -j DROP
su -c iptables -A INPUT -p tcp --dport 17000 -j DROP
su -c iptables -A INPUT -p UDP --dport 8700 -j DROP
su -c iptables -A INPUT -p tcp --dport 20371 -j DROP
su -c iptables -A INPUT -p UDP --dport 9030 -j DROP
su -c iptables -A INPUT -p UDP --dport 9031 -j DROP
su -c iptables -A INPUT -p tcp --dport 18600 -j DROP
su -c iptables -A INPUT -p UDP --dport 10013 -j DROP
su -c iptables -A INPUT -p UDP --dport 10012 -j DROP
su -c iptables -A INPUT -p UDP --dport 10019 -j DROP

su -c iptables -A OUTPUT -p tcp --dport 8086 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 8085 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 90 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 554 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 80 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 443 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 8013 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 15692 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 9031 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 10080 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 20001 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 20000 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 8011 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 20002 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 17000 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 8700 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 20371 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 9030 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 9031 -j DROP
su -c iptables -A OUTPUT -p tcp --dport 18600 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10013 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10012 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10019 -j DROP

su -c iptables -A INPUT -p UDP --dport 8086 -j DROP
su -c iptables -A INPUT -p UDP --dport 8085 -j DROP
su -c iptables -A INPUT -p UDP --dport 90 -j DROP
su -c iptables -A INPUT -p UDP --dport 554 -j DROP
su -c iptables -A INPUT -p UDP --dport 80 -j DROP
su -c iptables -A INPUT -p UDP --dport 443 -j DROP
su -c iptables -A INPUT -p UDP --dport 8013 -j DROP
su -c iptables -A INPUT -p UDP --dport 15692 -j DROP
su -c iptables -A INPUT -p UDP --dport 9031 -j DROP
su -c iptables -A INPUT -p UDP --dport 10080 -j DROP
su -c iptables -A INPUT -p UDP --dport 20001 -j DROP
su -c iptables -A INPUT -p UDP --dport 20000 -j DROP
su -c iptables -A INPUT -p UDP --dport 8011 -j DROP
su -c iptables -A INPUT -p UDP --dport 18081 -j DROP
su -c iptables -A INPUT -p UDP --dport 20002 -j DROP
su -c iptables -A INPUT -p UDP --dport 17000 -j DROP
su -c iptables -A INPUT -p UDP --dport 8700 -j DROP
su -c iptables -A INPUT -p UDP --dport 20371 -j DROP
su -c iptables -A INPUT -p UDP --dport 9030 -j DROP
su -c iptables -A INPUT -p UDP --dport 9031 -j DROP
su -c iptables -A INPUT -p UDP --dport 18600 -j DROP
su -c iptables -A INPUT -p UDP --dport 10013 -j DROP
su -c iptables -A INPUT -p UDP --dport 10012 -j DROP
su -c iptables -A INPUT -p UDP --dport 10019 -j DROP

su -c iptables -A OUTPUT -p UDP --dport 8086 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 8085 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 90 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 554 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 80 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 443 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 8013 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 15692 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 9031 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10080 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 20001 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 20000 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 8011 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 18081 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 20002 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 17000 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 8700 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 20371 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 9030 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 9031 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 18600 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10013 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10012 -j DROP
su -c iptables -A OUTPUT -p UDP --dport 10019 -j DROP


echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
date
export PKG="com.pubg.imobile"
export lib="/data/data/$PKG/lib"
killall $PKG >/dev/null 2>/dev/null
clear
date
sleep 1
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15337.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15339.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15340.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15352.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_1.5.0.15350.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_1.5.0.15351.pak  >/dev/null 2>/dev/null
truncate -s 0 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch_1.5.0.15352.pak  >/dev/null 2>/dev/null
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
rm -rf /storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 755 $lib/*
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
echo "[/Script/Client.GDolphinUpdater]
Disable=true" > /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
rm -rf $lib/libBugly.so 
rm -rf $lib/libgamemaster.so 
rm -rf $lib/libgcloudarch.so 
rm -rf $lib/libhelpshiftlistener.so 
rm -rf $lib/libigshare.so 
rm -rf $lib/liblbs.so 
rm -rf $lib/libst-engine.so 
rm -rf $lib/libtgpa.so 
rm -rf $lib/libzip.so 
rm -rf $lib/libapp.so 
rm -rf $lib/libc++_shared.so 
rm -rf $lib/libflutter.so 
rm -rf $lib/libmarsxlog.so 
rm -rf $lib/libmmkv.so 
rm -rf $lib/libsentry.so 
rm -rf $lib/libsentry-android.so 
rm -rf $lib/libnpps-jni.so 
rm -rf $lib/libImSDK.so 
chmod -R 755 $lib/*
rm -rf /data/data/$PKG/files
touch /data/data/$PKG/files
echo "@BEEASTYT"
cp $lib/libtersafe.so $lib/libtersafe.so.bak
cp $lib/libswappy.so $lib/libswappy.so.bak
cp $lib/libUE4.so $lib/libUE4.so.bak
cp $lib/libtprt.so $lib/libtprt.so.bak
cp $lib/libITOP.so $lib/libITOP.so.bak
cp $lib/libvlink.so $lib/libvlink.so.bak
am start --user 0 -n $PKG/com.epicgames.ue4.SplashActivity >/dev/null 2>/dev/null
sleep 8.5
rm -rf $lib/libtersafe.so
rm -rf $lib/libUE4.so
rm -rf $lib/libtprt.so
rm -rf $lib/libswappy.so
rm -rf $lib/libITOP.so
rm -rf $lib/libvlink.so
mv $lib/libtersafe.so.bak $lib/libtersafe.so
mv $lib/libswappy.so.bak $lib/libswappy.so
mv $lib/libUE4.so.bak $lib/libUE4.so
mv $lib/libtprt.so.bak $lib/libtprt.so
mv $lib/libITOP.so.bak $lib/libITOP.so
mv $lib/libvlink.so.bak $lib/libvlink.so