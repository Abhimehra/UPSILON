iptables -A INPUT -p tcp --dport 17500 -j ACCEPT &>/dev/null 
iptables -A OUTPUT -p tcp --dport 17500 -j ACCEPT &>/dev/null 
iptables -A INPUT -p udp --dport 17500 -j ACCEPT &>/dev/null 
iptables -A OUTPUT -p udp --dport 17500 -j ACCEPT &>/dev/null 
