su -c iptables -A INPUT -p tcp --dport 17500 -j ACCEPT
su -c iptables -A OUTPUT -p tcp --dport 17500 -j ACCEPT

su -c iptables -A INPUT -p tcp --dport 18600 -j ACCEPT
su -c iptables -A OUTPUT -p tcp --dport 18600 -j ACCEPT