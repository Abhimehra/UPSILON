iptables --flush
iptables -F