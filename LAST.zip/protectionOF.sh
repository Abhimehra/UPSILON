iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -j ACCEPT
iptables -I INPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -j ACCEPT

iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -j ACCEPT
iptables -I INPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -j ACCEPT

iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -j ACCEPT
iptables -I INPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -j ACCEPT

