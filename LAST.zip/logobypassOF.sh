

pm install -r /data/app/com.tencent.ig*/base.apk

pm install -r /data/app/com.pubg.krmobile*/base.apk
