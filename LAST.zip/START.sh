 iptables -A INPUT -j REJECT -p icmp --icmp-type echo-request
iptables -A INPUT -p icmp -j DROP --icmp-type echo-request
 iptables -A OUTPUT -p icmp -j DROP --icmp-type echo-reply



su -c iptables -I INPUT -p tcp --dport 8086 -j DROP
su -c iptables -I INPUT -p tcp --dport 8085 -j DROP
su -c iptables -I INPUT -p tcp --dport 90 -j DROP
su -c iptables -I INPUT -p tcp --dport 554 -j DROP
su -c iptables -I INPUT -p tcp --dport 80 -j DROP
su -c iptables -I INPUT -p tcp --dport 443 -j DROP
su -c iptables -I INPUT -p tcp --dport 8013 -j DROP
su -c iptables -I INPUT -p tcp --dport 15692 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 10080 -j DROP
su -c iptables -I INPUT -p tcp --dport 20001 -j DROP
su -c iptables -I INPUT -p tcp --dport 20000 -j DROP
su -c iptables -I INPUT -p tcp --dport 8011 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 20002 -j DROP
su -c iptables -I INPUT -p tcp --dport 17000 -j DROP
su -c iptables -I INPUT -p UDP --dport 8700 -j DROP
su -c iptables -I INPUT -p tcp --dport 20371 -j DROP
su -c iptables -I INPUT -p UDP --dport 9030 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 18600 -j DROP
su -c iptables -I INPUT -p UDP --dport 10013 -j DROP
su -c iptables -I INPUT -p UDP --dport 10012 -j DROP
su -c iptables -I INPUT -p UDP --dport 10019 -j DROP

su -c iptables -I OUTPUT -p tcp --dport 8086 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8085 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 90 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 554 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 80 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 443 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8013 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 15692 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 9031 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 10080 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 20001 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 20000 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8011 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 20002 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 17000 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 8700 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 20371 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 9030 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 9031 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 18600 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 10013 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 10012 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 10019 -j REJECT

iptables -t nat -D OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -D OUTPUT -p tcp --destination-port 53 -j DROP
ip6tables -D OUTPUT -p udp --destination-port 53 -j DROP
iptables -D OUTPUT -p tcp --destination-port 53 -j DROP
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -A OUTPUT -p udp --destination-port 53 -j DROP
ip6tables -A OUTPUT -p tcp --destination-port 53 -j DROP
iptables -A OUTPUT -p tcp --destination-port 53 -j DROP



