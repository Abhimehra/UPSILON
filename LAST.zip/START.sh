echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events


cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches

