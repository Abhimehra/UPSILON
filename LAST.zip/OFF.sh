iptables -F
iptables --flush
iptables -X
iptables -F
iptables -F
iptables --flush
iptables --flush
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -F
iptables -t nat -F
iptables -t mangle -F
iptables -X
iptables --flush
iptables -F
iptables --flush
iptables -F
iptables -X

killall {com.tencent.ig,com.pubg.krmobile} >/dev/null 2>/dev/null
SP 755 /data/data/{com.tencent.ig,com.pubg.krmobile}/lib/* >/dev/null 2>/dev/null
chown 1000:1000 /data/data/{com.tencent.ig,com.pubg.krmobile}/lib/* >/dev/null 2>/dev/null
rm -rf /data/data/{com.tencent.ig,com.pubg.krmobile}/lib/*.bak