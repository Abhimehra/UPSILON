iptables -F
iptables --flush
iptables -X
iptables -F
iptables -F
iptables --flush
iptables --flush
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -F
iptables -t nat -F
iptables -t mangle -F
iptables -X
iptables --flush
iptables -F
iptables --flush
iptables -F
iptables -X

killall com.tencent.ig >/dev/null 2>/dev/null
killall com.pubg.krmobile >/dev/null 2>/dev/null
killall com.pubg.imobile >/dev/null 2>/dev/null

sleep 1

pm install /data/app/com.tencent.ig*/base.apk >/dev/null 2>/dev/null
pm install /data/app/com.pubg.krmobile*/base.apk >/dev/null 2>/dev/null
pm install /data/app/com.pubg.imobile*/base.apk >/dev/null 2>/dev/null

chmod 755 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
chmod 755 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
chmod 755 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
