iptables -F
iptables --flush
iptables -X
iptables -F
iptables -F
iptables --flush
iptables --flush
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -F
iptables -t nat -F
iptables -t mangle -F
iptables -X
iptables --flush
iptables -F
iptables --flush
iptables -F
iptables -X

pm disable $PKG/com.tencent.midas.oversea.newnetwork.service.APNetDetectService  &>/dev/null
pm disable $PKG/com.tencent.ig.wxapi.WXEntryActivity &>/dev/null
pm disable $PKG/com.tencent.connect.common.AssistActivity &>/dev/null
pm disable $PKG/com.tencent.tauth.AuthActivity &>/dev/null
pm disable $PKG/com.tencent.midas.oversea.business.APMallActivity &>/dev/null
pm disable $PKG/com.tencent.midas.oversea.business.pay.APMidasProxyActivity &>/dev/null
pm disable $PKG/com.subao.androidapi.GameMasterActivity &>/dev/null
pm disable $PKG/com.tencent.grobot.lite.GRobotProcessActivity &>/dev/null
pm disable $PKG/com.tencent.grobot.lite.GRobotIsolateActivity &>/dev/null
pm disable $PKG/com.tencent.grobot.lite.ui.container.BridgeActivity &>/dev/null
pm disable $PKG/com.tencent.qcloud.logutils.LogActivity &>/dev/null
pm disable $PKG/com.tencent.quantum.download.GCBGDownloadService &>/dev/null
pm disable $PKG/com.shieldtunnel.svpn.XYVpnService &>/dev/null
pm disable $PKG/com.tencent.gcloud.ApolloProvider &>/dev/null
pm disable $PKG/com.tencent.imsdk.android.friend.IMSDKFileProvider &>/dev/null
pm disable $PKG/android.support.v4.content.FileProvider &>/dev/null
pm disable $PKG/com.tencent.quantum.share.QuantumFileProvider &>/dev/null
pm disable $PKG/io.flutter.plugins.imagepicker.ImagePickerFileProvider &>/dev/null
pm disable $PKG/com.sirius.flutter.im.SNSFlutterActivity &>/dev/null
pm disable $PKG/com.yalantis.ucrop.UCropActivity &>/dev/null
pm disable $PKG/io.flutter.plugins.urllauncher.WebViewActivity &>/dev/null
pm disable $PKG/com.vk.sdk.VKServiceActivity &>/dev/null
pm disable $PKG/com.android.billingclient.api.ProxyBillingActivity &>/dev/null
pm disable $PKG/io.flutter.plugins.share.ShareFileProvider &>/dev/null
pm disable $PKG/com.helpshift.support.providers.HelpshiftFileProvider &>/dev/null
pm disable $PKG/com.helpshift.support.activities.ParentActivity &>/dev/null

iptables -I INPUT -p tcp --dport 443 -j DROP
iptables -I OUTPUT -p tcp --dport 443 -j DROP
iptables -I INPUT -p tcp --dport 80 -j DROP
iptables -I OUTPUT -p tcp --dport 80 -j DROP