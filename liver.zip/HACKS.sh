chmod 777 /data/media/0/BEAST
exec /data/media/0/BEAST BEAST