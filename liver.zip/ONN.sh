iptables -A INPUT -p tcp -m tcp --dport 17500 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p udp -m udp --dport 17500 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 17500 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p udp -m udp --dport 17500 -j REJECT --reject-with icmp-port-unreachable