PKG="com.pubg.imobile"
pm disable $PKG/com.tencent.midas.oversea.newnetwork.service.APNetDetectService  &>/dev/null
pm disable $PKG/com.tencent.ig.wxapi.WXEntryActivity &>/dev/null
pm disable $PKG/com.tencent.connect.common.AssistActivity &>/dev/null
pm disable $PKG/com.tencent.tauth.AuthActivity &>/dev/null
pm disable $PKG/com.tencent.midas.oversea.business.APMallActivity &>/dev/null
pm disable $PKG/com.tencent.midas.oversea.business.pay.APMidasProxyActivity &>/dev/null
pm disable $PKG/com.subao.androidapi.GameMasterActivity &>/dev/null
pm disable $PKG/com.tencent.grobot.lite.GRobotProcessActivity &>/dev/null
pm disable $PKG/com.tencent.grobot.lite.GRobotIsolateActivity &>/dev/null
pm disable $PKG/com.tencent.grobot.lite.ui.container.BridgeActivity &>/dev/null
pm disable $PKG/com.tencent.qcloud.logutils.LogActivity &>/dev/null
pm disable $PKG/com.tencent.quantum.download.GCBGDownloadService &>/dev/null
pm disable $PKG/com.shieldtunnel.svpn.XYVpnService &>/dev/null
pm disable $PKG/com.tencent.gcloud.ApolloProvider &>/dev/null
pm disable $PKG/com.tencent.imsdk.android.friend.IMSDKFileProvider &>/dev/null
pm disable $PKG/android.support.v4.content.FileProvider &>/dev/null
pm disable $PKG/com.tencent.quantum.share.QuantumFileProvider &>/dev/null
pm disable $PKG/io.flutter.plugins.imagepicker.ImagePickerFileProvider &>/dev/null
pm disable $PKG/com.sirius.flutter.im.SNSFlutterActivity &>/dev/null
pm disable $PKG/com.yalantis.ucrop.UCropActivity &>/dev/null
pm disable $PKG/io.flutter.plugins.urllauncher.WebViewActivity &>/dev/null
pm disable $PKG/com.vk.sdk.VKServiceActivity &>/dev/null
pm disable $PKG/com.android.billingclient.api.ProxyBillingActivity &>/dev/null
pm disable $PKG/io.flutter.plugins.share.ShareFileProvider &>/dev/null
pm disable $PKG/com.helpshift.support.providers.HelpshiftFileProvider &>/dev/null
pm disable $PKG/com.helpshift.support.activities.ParentActivity &>/dev/null
E 16384 > /proc/sys/fs/inotify/max_queued_events
E 128 > /proc/sys/fs/inotify/max_user_instances
E 8192 > /proc/sys/fs/inotify/max_user_watches
R src/main/java/com/google/errorprone/annotations
R src/main/java/com/google/errorprone/annotations/concurrent
R third_party.java_src.error_prone.project.annotations.Google_internal

pak="/data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/"

truncate -s 0 $pak/game_patch_*.pak
truncate -s 0 $pak/core_patch_*.pak
truncate -s 0 $pak/res_puffer_*.pak

chmod 555 $pak

am force-stop com.google.android.gms
pkill com.google.android.gms

rm -rf /data/media/0/Android/data/com.pakage.upsilon/files/START.sh
