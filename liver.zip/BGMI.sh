
su -c am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity &> /dev/null

sleep 5

cd /data/data/com.pubg.imobile*/lib/
ls
mv libtersafe.so libtersafe.so.bak
mv libBugly.so libBugly.so.bak
mv libgamemaster.so libgamemaster.so.bak
mv libgcloudarch.so libgcloudarch.so.bak
mv libhelpshiftlistener.so libhelpshiftlistener.so.bak
mv libigshare.so libigshare.so.bak
mv liblbs.so liblbs.so.bak
mv libst-engine.so libst-engine.so.bak
mv libtgpa.so libtgpa.so.bak
mkdir libtersafe.so
sleep 15
rm -rf libtersafe.so
