su -c rm -rf /data/data/com.pubg.imobile/lib/libapp.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libBugly.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libc++_shared.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libcubehawk.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libflutter.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libgamemaster.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libgcloudarch.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libgcloudcore.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libGCloudVoice.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libgnustl_shared.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libhelpshiftlistener.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libigshare.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libijkffmpeg.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libImSDK.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libITOP.so
su -c rm -rf /data/data/com.pubg.imobile/lib/liblbs.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libmarsxlog.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libmmkv.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libnpps-jni.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libPandoraVideo.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libsentry.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libsentry-android.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libst-engine.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libswappy.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libTDataMaster.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libtersafe.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libtgpa.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libtprt.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libUE4.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libvlink.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libzip.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libzlib.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libgcloud.so


su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libapp.so /data/data/com.pubg.imobile/lib/libapp.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libBugly.so /data/data/com.pubg.imobile/lib/libBugly.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libc++_shared.so /data/data/com.pubg.imobile/lib/libc++_shared.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libcubehawk.so /data/data/com.pubg.imobile/lib/libcubehawk.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libflutter.so /data/data/com.pubg.imobile/lib/libflutter.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libapp.so /data/data/com.pubg.imobile/lib/libapp.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libgamemaster.so /data/data/com.pubg.imobile/lib/libgamemaster.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libgcloudarch.so /data/data/com.pubg.imobile/lib/libgcloudarch.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libgcloudcore.so /data/data/com.pubg.imobile/lib/libgcloudcore.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libGCloudVoice.so /data/data/com.pubg.imobile/lib/libGCloudVoice.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libgnustl_shared.so /data/data/com.pubg.imobile/lib/libgnustl_shared.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libhelpshiftlistener.so /data/data/com.pubg.imobile/lib/libhelpshiftlistener.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libigshare.so /data/data/com.pubg.imobile/lib/libigshare.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libijkffmpeg.so /data/data/com.pubg.imobile/lib/libijkffmpeg.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libImSDK.so /data/data/com.pubg.imobile/lib/libImSDK.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libITOP.so /data/data/com.pubg.imobile/lib/libITOP.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/liblbs.so /data/data/com.pubg.imobile/lib/liblbs.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libmarsxlog.so /data/data/com.pubg.imobile/lib/libmarsxlog.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libmmkv.so /data/data/com.pubg.imobile/lib/libmmkv.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libnpps-jni.so /data/data/com.pubg.imobile/lib/libnpps-jni.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libPandoraVideo.so /data/data/com.pubg.imobile/lib/libPandoraVideo.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libsentry.so /data/data/com.pubg.imobile/lib/libsentry.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libsentry-android.so /data/data/com.pubg.imobile/lib/libsentry-android.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libswappy.so /data/data/com.pubg.imobile/lib/libswappy.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libTDataMaster.so /data/data/com.pubg.imobile/lib/libTDataMaster.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libtersafe.so /data/data/com.pubg.imobile/lib/libtersafe.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libtgpa.so /data/data/com.pubg.imobile/lib/libtgpa.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libtprt.so /data/data/com.pubg.imobile/lib/libtprt.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libUE4.so /data/data/com.pubg.imobile/lib/libUE4.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libvlink.so /data/data/com.pubg.imobile/lib/libvlink.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libzip.so /data/data/com.pubg.imobile/lib/libzip.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libzlib.so /data/data/com.pubg.imobile/lib/libzlib.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libgcloud.so /data/data/com.pubg.imobile/lib/libgcloud.so

chmod 775 /data/data/com.pubg.imobile/lib/*



