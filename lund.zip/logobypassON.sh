;su -c rm -rf /data/data/com.pubg.imobile/lib/libtersafe.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libBugly.so
su -c rm -rf /data/data/com.pubg.imobile/lib/libgamemaster.so



su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libapp.so /data/data/com.pubg.imobile/lib/libtersafe.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libBugly.so /data/data/com.pubg.imobile/lib/libBugly.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libc++_shared.so /data/data/com.pubg.imobile/lib/libgamemaster.so


chmod 775 /data/data/com.pubg.imobile/lib/*

su -c rm -rf /data/data/com.pubg.krmobile/lib/libtersafe.so
su -c rm -rf /data/data/com.pubg.krmobile/lib/libBugly.so
su -c rm -rf /data/data/com.pubg.krmobile/lib/libgamemaster.so



su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libapp.so /data/data/com.pubg.krmobile/lib/libtersafe.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libBugly.so /data/data/com.pubg.krmobile/lib/libBugly.so
su -c cp -R /storage/emulated/0/Android/data/com.pakage.upsilon/files/libc++_shared.so /data/data/com.pubg.krmobile/lib/libgamemaster.so


chmod 775 /data/data/com.pubg.krmobile/lib/*











