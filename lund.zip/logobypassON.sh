su -c chmod 1000 /data/data/com.tencent.ig/lib/*
su -c chmod 1000 /data/data/com.pubg.imobile/lib/*
su -c chmod 1000 /data/data/com.pubg.krmobile/lib/*

