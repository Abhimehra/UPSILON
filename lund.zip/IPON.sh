if [ $(pidof com.tencent.ig) ]; then
iptables -A INPUT -p tcp -m tcp --dport 17500 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 17500 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 17500 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p udp -m udp --dport 20001 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 11038 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 111 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 81 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 17500 -j DROP
rm -rf /data/data/com.tencent.ig/code_cache &>/dev/null
touch /data/data/com.tencent.ig/code_cache &>/dev/null
chmod 555 /data/data/com.tencent.ig/code_cache &>/dev/null
rm -rf /data/data/com.tencent.ig/cache/* &>/dev/null
chmod 555 /data/data/com.tencent.ig/cache &>/dev/null
rm -rf /Storage/emulated/0/Tencent/Midas/Log &>/dev/null
rm -rf /Storage/emulated/0/.backups &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/tbslog &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache &>/dev/null
rm -rf /Storage/emulated/0/.backups/com.tencent.ig/helpshift/databases &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/cache &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/tbslog &>/dev/null
rm -rf /data/data/com.tencent.ig/databases/tdm.db &>/dev/null
rm -rf /data/data/com.tencent.ig/databases/beacon_db &>/dev/null
rm -rf /data/data/com.tencent.ig/databases/bugly_db_ &>/dev/null
rm -rf /data/data/com.tencent.ig/databases/config.db &>/dev/null
rm -rf /data/data/com.tencent.ig/databases/iMSDK.db &>/dev/null
rm -rf /Storage/emulated/0/.backups/com.tencent.ig/helpshift/databases/__hs__backup_dao_storage &>/dev/null
rm -rf /Storage/emulated/0/Tencent/beacon/meta.dat &>/dev/null
rm -rf /Storage/emulated/0/MidasOversea/GUID &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/cache &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.tencent.ig/files/tbslog &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs &>/dev/null
touch /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir &>/dev/null
touch /storage/emulated/0/Android/Data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp &>/dev/null
elif [ $(pidof com.pubg.krmobile) ]; then
iptables --flush &> /dev/null
echo -e  -j DROP &>/dev/null
iptables -I INPUT -s www.baidu.com -j DROP &>/dev/null
iptables -I INPUT -s idconfig.gcloud.qq.com -j DROP &>/dev/null
iptables -I INPUT -s qos.twsg.gclouds.com -j DROP &>/dev/null
iptables -I INPUT -s qosidc.gcloud.qq.com -j DROP &>/dev/null
iptables -I INPUT -s qos.hk.gcloudcs.com -j DROP &>/dev/null
iptables -I INPUT -s cdn.cn.gcloudcs.com -j DROP &>/dev/null
iptables -I INPUT -s bugly.qq.com -j DROP &>/dev/null
iptables -I INPUT -s cloudctrl.gcloud.qq.com -j DROP &>/dev/null
iptables -I INPUT -s c.tdm.qq.com -j DROP &>/dev/null
iptables -I INPUT -s pandoragame.qq.com -j DROP &>/dev/null
iptables -I INPUT -s napubgm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I INPUT -s nawzryhwatm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I INPUT -s cdn2.pubgameshowtime.com -j DROP &>/dev/null
iptables -I INPUT -s u.gcloud_manual.com -j DROP &>/dev/null
iptables -I INPUT -s 119.28.184.221 -j DROP &>/dev/null
iptables -I INPUT -s 129.226.3.134 -j DROP &>/dev/null
iptables -I INPUT -s csoversea.mbgame.gamesafe.qq.com -j DROP &>/dev/null
iptables -I INPUT -s usa.csoversea.mbgame.anticheatexpert.com -j DROP &>/dev/null
iptables -I INPUT -s down.anticheatexpert.com -j DROP &>/dev/null
iptables -I INPUT -s tencentgames.helpshift.com -j DROP &>/dev/null
iptables -I OUTPUT -s www.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s www.baidu.com -j DROP &>/dev/null
iptables -I OUTPUT -s idconfig.gcloud.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s qos.twsg.gclouds.com -j DROP &>/dev/null
iptables -I OUTPUT -s qosidc.gcloud.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s qos.hk.gcloudcs.com -j DROP &>/dev/null
iptables -I OUTPUT -s cdn.cn.gcloudcs.com -j DROP &>/dev/null
iptables -I OUTPUT -s bugly.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s cloudctrl.gcloud.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s pandoragame.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s c.tdm.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s napubgm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I OUTPUT -s nawzryhwatm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I OUTPUT -s cdn2.pubgameshowtime.com -j DROP &>/dev/null
iptables -I OUTPUT -s u.gcloud_manual.com -j DROP &>/dev/null
iptables -I OUTPUT -s 119.28.184.221 -j DROP &>/dev/null
iptables -I OUTPUT -s 129.226.3.134 -j DROP &>/dev/null
iptables -I OUTPUT -s csoversea.mbgame.gamesafe.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s usa.csoversea.mbgame.anticheatexpert.com -j DROP &>/dev/null
iptables -I OUTPUT -s down.anticheatexpert.com -j DROP &>/dev/null
iptables -I OUTPUT -s tencentgames.helpshift.com -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'qq.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string '.cn' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string '.net' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'amsoveasea.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'anticheatexpert.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string '.cnzz' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'tencent.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'pubgmobile.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string '.org' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'helpshift.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'fbsbx.com' -j DROP &>/dev/null
awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list > /data/media/0/uidinf
UID=$(cat /data/media/0/uidinf)
iptables -A OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &> /dev/null
rm -rf /data/data/com.pubg.krmobile/code_cache &>/dev/null
touch /data/data/com.pubg.krmobile/code_cache &>/dev/null
chmod 555 /data/data/com.pubg.krmobile/code_cache &>/dev/null
rm -rf /data/data/com.pubg.krmobile/cache/* &>/dev/null
chmod 555 /data/data/com.pubg.krmobile/cache &>/dev/null
rm -rf /Storage/emulated/0/Tencent/Midas/Log &>/dev/null
rm -rf /Storage/emulated/0/.backups &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache &>/dev/null
rm -rf /Storage/emulated/0/.backups/com.pubg.krmobile/helpshift/databases &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/cache &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog &>/dev/null
rm -rf /data/data/com.pubg.krmobile/databases/tdm.db &>/dev/null
rm -rf /data/data/com.pubg.krmobile/databases/beacon_db &>/dev/null
rm -rf /data/data/com.pubg.krmobile/databases/bugly_db_ &>/dev/null
rm -rf /data/data/com.pubg.krmobile/databases/config.db &>/dev/null
rm -rf /data/data/com.pubg.krmobile/databases/iMSDK.db &>/dev/null
rm -rf /Storage/emulated/0/.backups/com.pubg.krmobile/helpshift/databases/__hs__backup_dao_storage &>/dev/null
rm -rf /Storage/emulated/0/Tencent/beacon/meta.dat &>/dev/null
rm -rf /Storage/emulated/0/MidasOversea/GUID &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/ca-bundle.pem &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/cache &>/dev/null
rm -rf /Storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs &>/dev/null
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir &>/dev/null
touch /storage/emulated/0/Android/Data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp &>/dev/null
echo -e  -j DROP &>/dev/null
iptables -I INPUT -s www.baidu.com -j DROP &>/dev/null
iptables -I INPUT -s idconfig.gcloud.qq.com -j DROP &>/dev/null
iptables -I INPUT -s qos.twsg.gclouds.com -j DROP &>/dev/null
iptables -I INPUT -s qosidc.gcloud.qq.com -j DROP &>/dev/null
iptables -I INPUT -s qos.hk.gcloudcs.com -j DROP &>/dev/null
iptables -I INPUT -s cdn.cn.gcloudcs.com -j DROP &>/dev/null
iptables -I INPUT -s bugly.qq.com -j DROP &>/dev/null
iptables -I INPUT -s cloudctrl.gcloud.qq.com -j DROP &>/dev/null
iptables -I INPUT -s c.tdm.qq.com -j DROP &>/dev/null
iptables -I INPUT -s pandoragame.qq.com -j DROP &>/dev/null
iptables -I INPUT -s napubgm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I INPUT -s nawzryhwatm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I INPUT -s cdn2.pubgameshowtime.com -j DROP &>/dev/null
iptables -I INPUT -s u.gcloud_manual.com -j DROP &>/dev/null
iptables -I INPUT -s 119.28.184.221 -j DROP &>/dev/null
iptables -I INPUT -s 129.226.3.134 -j DROP &>/dev/null
iptables -I INPUT -s csoversea.mbgame.gamesafe.qq.com -j DROP &>/dev/null
iptables -I INPUT -s usa.csoversea.mbgame.anticheatexpert.com -j DROP &>/dev/null
iptables -I INPUT -s down.anticheatexpert.com -j DROP &>/dev/null
iptables -I INPUT -s tencentgames.helpshift.com -j DROP &>/dev/null
iptables -I OUTPUT -s www.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s www.baidu.com -j DROP &>/dev/null
iptables -I OUTPUT -s idconfig.gcloud.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s qos.twsg.gclouds.com -j DROP &>/dev/null
iptables -I OUTPUT -s qosidc.gcloud.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s qos.hk.gcloudcs.com -j DROP &>/dev/null
iptables -I OUTPUT -s cdn.cn.gcloudcs.com -j DROP &>/dev/null
iptables -I OUTPUT -s bugly.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s cloudctrl.gcloud.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s pandoragame.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s c.tdm.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s napubgm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I OUTPUT -s nawzryhwatm.broker.amsoveasea.com -j DROP &>/dev/null
iptables -I OUTPUT -s cdn2.pubgameshowtime.com -j DROP &>/dev/null
iptables -I OUTPUT -s u.gcloud_manual.com -j DROP &>/dev/null
iptables -I OUTPUT -s 119.28.184.221 -j DROP &>/dev/null
iptables -I OUTPUT -s 129.226.3.134 -j DROP &>/dev/null
iptables -I OUTPUT -s csoversea.mbgame.gamesafe.qq.com -j DROP &>/dev/null
iptables -I OUTPUT -s usa.csoversea.mbgame.anticheatexpert.com -j DROP &>/dev/null
iptables -I OUTPUT -s down.anticheatexpert.com -j DROP &>/dev/null
iptables -I OUTPUT -s tencentgames.helpshift.com -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'qq.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string '.cn' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string '.net' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'amsoveasea.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'anticheatexpert.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string '.cnzz' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'tencent.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'pubgmobile.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string '.org' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'helpshift.com' -j DROP &>/dev/null
iptables -t filter -A INPUT -m string --algo bm --string 'fbsbx.com' -j DROP &>/dev/null
iptables -A OUTPUT -m owner --uid-owner $UID -p tcp -j DROP &> /dev/null
elif [ $(pidof com.pubg.imobile) ]; then
iptables -A INPUT -p tcp -m tcp --dport 17500 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 17500 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 17500 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p udp -m udp --dport 20001 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 11038 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 111 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 81 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 17500 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18600 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18600 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18600 -j REJECT
iptables -A OUTPUT -p tcp -m tcp --dport 18600 -j REJECT
else
echo "No Process Running"
fi








