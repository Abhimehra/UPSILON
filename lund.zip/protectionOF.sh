iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 0000 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 9030 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 17000 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 9031 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 3013 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 8700 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 8011 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 20001 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 10394 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 8080 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 443 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp ! --dport 80 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -s ig-us-sdkapi.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d ig-us-sdkapi.igamecj.com  -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d down.anticheatexpert.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -s lobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d lobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -s krlobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d krlobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d twlobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.tencent.ig/ {print $2}' /data/system/packages.list) -p tcp -d vnglobby.igamecj.com -j ACCEPT

iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 0000 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 9030 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 17000 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 9031 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 3013 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 8700 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 8011 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 20001 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 10394 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 8080 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 443 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 80 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -s ig-us-sdkapi.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d ig-us-sdkapi.igamecj.com  -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d down.anticheatexpert.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -s lobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d lobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -s krlobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d krlobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d twlobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp -d vnglobby.igamecj.com -j ACCEPT

iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 0000 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 9030 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 17000 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 9031 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 3013 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 8700 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 8011 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 20001 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 10394 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 8080 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 443 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 80 -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp -s ig-us-sdkapi.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp -d ig-us-sdkapi.igamecj.com  -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp -d down.anticheatexpert.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp -s lobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp -d lobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp -s krlobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp -d krlobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp -d twlobby.igamecj.com -j ACCEPT
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.imobile/ {print $2}' /data/system/packages.list) -p tcp -d vnglobby.igamecj.com -j ACCEPT