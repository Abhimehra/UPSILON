KOREA


iptables -I INPUT -s krlobby.igamecj.com -j ACCEPT &>/dev/null 

iptables -I OUTPUT -s krlobby.igamecj.com -j ACCEPT &>/dev/null 




GLOBAL----



iptables -I INPUT -s lobby.igamecj.com -j ACCEPT &>/dev/null 

iptables -I OUTPUT -s lobby.igamecj.com -j ACCEPT &>/dev/null


BGMI----

su -c iptables -I INPUT -p UDP --dport 17500 -j ACCEPT

su -c iptables -I OUTPUT -p UDP --dport 17500 -j ACCEPT