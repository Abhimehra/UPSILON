
su -c iptables -P INPUT ACCEPT
su -c iptables -P FORWARD ACCEPT
su -c iptables -P OUTPUT ACCEPT
su -c iptables -F
su -c iptables -X
su -c iptables -Z 
su -c iptables -t nat -F
su -c iptables -t nat -X
su -c iptables -t mangle -F
su -c iptables -t mangle -X
su -c iptables iptables -t raw -F
su -c iptables -t raw -X