su -c iptables -I INPUT -p tcp --dport 17500 -j ACCEPT &>/dev/null
su -c iptables -I OUTPUT -p tcp --dport 17500 -j ACCEPT &>/dev/null
su -c iptables -I INPUT -p tcp --dport 18600 -j ACCEPT &>/dev/null
su -c iptables -I OUTPUT -p tcp --dport 18600 -j ACCEPT &>/dev/null

