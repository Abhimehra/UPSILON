su -c iptables -X
su -c iptables -F

