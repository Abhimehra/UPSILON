su -c iptables -F
su -c iptables -X
