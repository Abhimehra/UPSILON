rm -rf /sdcard/Android/data/com.pubg.imobile/files/ProgramBinaryCache
rm -rf /sdcard/Android/data/com.pubg.imobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/Paks
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/Cookie
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Download
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/pandora
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RP
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Pet
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Task
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/UnknowPass
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Tencent/beacon
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/blob/mqq
rm -rf /sdcard/Tencent/leqq/Log/com.pubg.imobile
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_live_log/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_audio_data
rm -rf /sdcard/Tencent/tbs/backup/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.TbsReaderTempcom.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.thumbnails
rm -rf /sdcard/Tencent/QQfile_recv/.tmp
rm -rf /sdcard/Tencent/QQfile_recv/.trooptmp
rm -rf /sdcard/Tencent/msflogs/com/tencent/mobileqqu
rm -rf /sdcard/Tencent/MobileQQ/.apollo/game
rm -rf /sdcard/Tencent/MobileQQ/capture_qsvf
rm -rf /sdcard/Tencent/MobileQQ/dov_ptv_template_dov
rm -rf /sdcard/Tencent/MobileQQ/WebViewCheck
rm -rf /sdcard/Tencent/MobileQQ/log
rm -rf /sdcard/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/tencent/XG/Logs/20200109
rm -rf /sdcard/.backups/com.pubg.imobile/helpshift/databases
rm -rf /sdcard/Android/data/com.pubg.imobile/cache
rm -rf /sdcard/Android/data/com.pubg.imobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Season
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /data/data/com.pubg.imobile/databases/tdm.db
rm -rf /data/data/com.pubg.imobile/databases/beacon_db
rm -rf /data/data/com.pubg.imobile/databases/bugly_db_
rm -rf /data/data/com.pubg.imobile/databases/config.db
rm -rf /data/data/com.pubg.imobile/databases/iMSDK.db
rm -rf /sdcard/.backups/com.pubg.imobile/helpshift/databases/__hs__backup_dao_storage
rm -rf /sdcard/Tencent/beacon/meta.dat
rm -rf /sdcard/MidasOversea/GUID
rm -rf /sdcard/Tencent/Midas/Log/com.pubg.imobile
rm -rf /sdcard/Android/data/com.pubg.imobile/files/ca-bundle.pem
rm -rf /sdcard/Android/data/com.pubg.imobile/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.imobile/cache
rm -rf /sdcard/Android/data/com.pubg.imobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/.backups
rm -rf /sdcard/Tencent
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/cache
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/tbslog
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/vmpcloudconfig.json
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/ProgramBinaryCache
echo "Log Cleaning....."
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir

#KOREA

rm -rf /sdcard/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Paks
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/Cookie
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Download
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/pandora
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RP
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Pet
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Task
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/UnknowPass
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Tencent/beacon
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/blob/mqq
rm -rf /sdcard/Tencent/leqq/Log/com.pubg.krmobile
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_live_log/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_audio_data
rm -rf /sdcard/Tencent/tbs/backup/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.TbsReaderTempcom.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.thumbnails
rm -rf /sdcard/Tencent/QQfile_recv/.tmp
rm -rf /sdcard/Tencent/QQfile_recv/.trooptmp
rm -rf /sdcard/Tencent/msflogs/com/tencent/mobileqqu
rm -rf /sdcard/Tencent/MobileQQ/.apollo/game
rm -rf /sdcard/Tencent/MobileQQ/capture_qsvf
rm -rf /sdcard/Tencent/MobileQQ/dov_ptv_template_dov
rm -rf /sdcard/Tencent/MobileQQ/WebViewCheck
rm -rf /sdcard/Tencent/MobileQQ/log
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/tencent/XG/Logs/20200109
rm -rf /sdcard/.backups/com.pubg.krmobile/helpshift/databases
rm -rf /sdcard/Android/data/com.pubg.krmobile/cache
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Season
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /data/data/com.pubg.krmobile/databases/tdm.db
rm -rf /data/data/com.pubg.krmobile/databases/beacon_db
rm -rf /data/data/com.pubg.krmobile/databases/bugly_db_
rm -rf /data/data/com.pubg.krmobile/databases/config.db
rm -rf /data/data/com.pubg.krmobile/databases/iMSDK.db
rm -rf /sdcard/.backups/com.pubg.krmobile/helpshift/databases/__hs__backup_dao_storage
rm -rf /sdcard/Tencent/beacon/meta.dat
rm -rf /sdcard/MidasOversea/GUID
rm -rf /sdcard/Tencent/Midas/Log/com.pubg.krmobile
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/ca-bundle.pem
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.krmobile/cache
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/.backups
rm -rf /sdcard/Tencent
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/vmpcloudconfig.json
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
echo "Log Cleaning....."
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir

#BGMI

rm -rf /sdcard/Android/data/com.tencent.ig/files/ProgramBinaryCache
rm -rf /sdcard/Android/data/com.tencent.ig/files/tbslog
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Paks
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/Cookie
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Download
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/pandora
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RP
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Pet
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Task
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/UnknowPass
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Tencent/beacon
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/blob/mqq
rm -rf /sdcard/Tencent/leqq/Log/com.tencent.ig
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_live_log/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_audio_data
rm -rf /sdcard/Tencent/tbs/backup/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.TbsReaderTempcom.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.thumbnails
rm -rf /sdcard/Tencent/QQfile_recv/.tmp
rm -rf /sdcard/Tencent/QQfile_recv/.trooptmp
rm -rf /sdcard/Tencent/msflogs/com/tencent/mobileqqu
rm -rf /sdcard/Tencent/MobileQQ/.apollo/game
rm -rf /sdcard/Tencent/MobileQQ/capture_qsvf
rm -rf /sdcard/Tencent/MobileQQ/dov_ptv_template_dov
rm -rf /sdcard/Tencent/MobileQQ/WebViewCheck
rm -rf /sdcard/Tencent/MobileQQ/log
rm -rf /sdcard/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/tencent/XG/Logs/20200109
rm -rf /sdcard/.backups/com.tencent.ig/helpshift/databases
rm -rf /sdcard/Android/data/com.tencent.ig/cache
rm -rf /sdcard/Android/data/com.tencent.ig/files/tbslog
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Season
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /data/data/com.tencent.ig/databases/tdm.db
rm -rf /data/data/com.tencent.ig/databases/beacon_db
rm -rf /data/data/com.tencent.ig/databases/bugly_db_
rm -rf /data/data/com.tencent.ig/databases/config.db
rm -rf /data/data/com.tencent.ig/databases/iMSDK.db
rm -rf /sdcard/.backups/com.tencent.ig/helpshift/databases/__hs__backup_dao_storage
rm -rf /sdcard/Tencent/beacon/meta.dat
rm -rf /sdcard/MidasOversea/GUID
rm -rf /sdcard/Tencent/Midas/Log/com.tencent.ig
rm -rf /sdcard/Android/data/com.tencent.ig/files/ca-bundle.pem
rm -rf /sdcard/Android/data/com.tencent.ig/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.tencent.ig/cache
rm -rf /sdcard/Android/data/com.tencent.ig/files/tbslog
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/.backups
rm -rf /sdcard/Tencent
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/tbslog
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/vmpcloudconfig.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
echo "Log Cleaning....."
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir

sleep 60

ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables

ip6tables -I INPUT -p tcp  --dport 10012 -j DROP
ip6tables -I INPUT -p tcp  --dport 3030 -j DROP
ip6tables -I INPUT -p tcp  --dport 3031 -j DROP
ip6tables -I INPUT -p tcp  --dport 443 -j DROP
ip6tables -I INPUT -p tcp  --dport 80 -j DROP
ip6tables -I INPUT -p tcp  --dport 8080 -j DROP
ip6tables -I INPUT -p tcp  --dport 8085 -j DROP
ip6tables -I INPUT -p tcp  --dport 8086 -j DROP
ip6tables -I INPUT -p tcp  --dport 9030 -j ACCEPT

iptables -A FORWARD -m string --algo bm --string "AntiCheatOpenID" -j DROP
iptables -A FORWARD -m string --algo bm --string "COREREPORT" -j DROP
iptables -A FORWARD -m string --algo bm --string "N6TssSDK11ReportQueue" -j DROP
iptables -A FORWARD -m string --algo bm --string "N6TssSDK15FileCrcReporter" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDK.ReportQosByGame" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKDelReportData" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKGetReportData" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKOnRecvData" -j DROP
iptables -A FORWARD -m string --algo bm --string "WB_GetReportStr" -j DROP
iptables -A FORWARD -m string --algo bm --string "_ZN6TssSdk16sdt_report_errorEv" -j DROP
iptables -A FORWARD -m string --algo bm --string "amazonaws.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "asia.csoversea.mbgame.anticheatexpert.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "cs.mbgame.gamesafe.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "dlied1.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "down.anticheatexpert.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "down.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "intldlgs.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "report_apk" -j DROP
iptables -A FORWARD -m string --algo bm --string "res_max_report_missed_cnt" -j DROP
iptables -A FORWARD -m string --algo bm --string "sc_report" -j DROP
iptables -A FORWARD -m string --algo bm --string "tdm_report" -j DROP
iptables -A FORWARD -m string --algo bm --string "tdm_report_sdk_update_config_finish" -j DROP
iptables -A FORWARD -m string --algo bm --string "tencentgames.helpshift.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "tp2_free_anti_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_del_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_enable_get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_sdk_rcv_anti_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "vmp.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "AntiCheatOpenID" -j DROP
iptables -A INPUT -m string --algo bm --string "COREREPORT" -j DROP
iptables -A INPUT -m string --algo bm --string "N6TssSDK11ReportQueue" -j DROP
iptables -A INPUT -m string --algo bm --string "N6TssSDK15FileCrcReporter" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDK.ReportQosByGame" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKDelReportData" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKGetReportData" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKOnRecvData" -j DROP
iptables -A INPUT -m string --algo bm --string "WB_GetReportStr" -j DROP
iptables -A INPUT -m string --algo bm --string "_ZN6TssSdk16sdt_report_errorEv" -j DROP
iptables -A INPUT -m string --algo bm --string "amazonaws.com" -j DROP
iptables -A INPUT -m string --algo bm --string "asia.csoversea.mbgame.anticheatexpert.com" -j DROP
iptables -A INPUT -m string --algo bm --string "cs.mbgame.gamesafe.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "dlied1.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "down.anticheatexpert.com" -j DROP
iptables -A INPUT -m string --algo bm --string "down.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "intldlgs.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "report_apk" -j DROP
iptables -A INPUT -m string --algo bm --string "res_max_report_missed_cnt" -j DROP
iptables -A INPUT -m string --algo bm --string "sc_report" -j DROP
iptables -A INPUT -m string --algo bm --string "tdm_report" -j DROP
iptables -A INPUT -m string --algo bm --string "tdm_report_sdk_update_config_finish" -j DROP
iptables -A INPUT -m string --algo bm --string "tencentgames.helpshift.com" -j DROP
iptables -A INPUT -m string --algo bm --string "tp2_free_anti_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_del_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_enable_get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_sdk_rcv_anti_data" -j DROP
iptables -A INPUT -m string --algo bm --string "vmp.qq.com" -j DROP
iptables -A INPUT -p tcp --dport 10000:10024 -j DROP
iptables -A INPUT -p tcp --dport 22:443 -j DROP
iptables -A INPUT -p tcp --dport 38824 -j DROP
iptables -A INPUT -p tcp --dport 39752 -j DROP
iptables -A INPUT -p tcp --dport 39888 -j DROP
iptables -A INPUT -p tcp --dport 40984 -j DROP
iptables -A INPUT -p tcp --dport 42856 -j DROP
iptables -A INPUT -p tcp --dport 42856:43000 -j DROP
iptables -A INPUT -p tcp --dport 43314 -j DROP
iptables -A INPUT -p tcp --dport 43322 -j DROP
iptables -A INPUT -p tcp --dport 43388 -j DROP
iptables -A INPUT -p tcp --dport 43476 -j DROP
iptables -A INPUT -p tcp --dport 43732 -j DROP
iptables -A INPUT -p tcp --dport 44808 -j DROP
iptables -A INPUT -p tcp --dport 44978:45000 -j DROP
iptables -A INPUT -p tcp --dport 45198 -j DROP
iptables -A INPUT -p tcp --dport 46726 -j DROP
iptables -A INPUT -p tcp --dport 46924 -j DROP
iptables -A INPUT -p tcp --dport 48774 -j DROP
iptables -A INPUT -p tcp --dport 48919 -j DROP
iptables -A INPUT -p tcp --dport 8080:8099 -j DROP
iptables -A OUTPUT -m string --algo bm --string "AntiCheatOpenID" -j DROP
iptables -A OUTPUT -m string --algo bm --string "COREREPORT" -j DROP
iptables -A OUTPUT -m string --algo bm --string "N6TssSDK11ReportQueue" -j DROP
iptables -A OUTPUT -m string --algo bm --string "N6TssSDK15FileCrcReporter" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDK.ReportQosByGame" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDKDelReportData" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDKGetReportData" -j DROP
iptables -A OUTPUT -m string --algo bm --string "TssSDKOnRecvData" -j DROP
iptables -A OUTPUT -m string --algo bm --string "WB_GetReportStr" -j DROP
iptables -A OUTPUT -m string --algo bm --string "_ZN6TssSdk16sdt_report_errorEv" -j DROP
iptables -A OUTPUT -m string --algo bm --string "amazonaws.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "asia.csoversea.mbgame.anticheatexpert.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "cs.mbgame.gamesafe.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "dlied1.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "down.anticheatexpert.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "down.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "get_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "intldlgs.qq.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "report_apk" -j DROP
iptables -A OUTPUT -m string --algo bm --string "res_max_report_missed_cnt" -j DROP
iptables -A OUTPUT -m string --algo bm --string "sc_report" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tdm_report" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tdm_report_sdk_update_config_finish" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tencentgames.helpshift.com" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tp2_free_anti_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_del_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_enable_get_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_get_report_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "tss_sdk_rcv_anti_data" -j DROP
iptables -A OUTPUT -m string --algo bm --string "vmp.qq.com" -j DROP
iptables -I INPUT -p all -m string --string "app.adjust.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cloudconfig.googleapis.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cloudctrl.gcloudsdk.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "compute.amazonaws.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "d.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dl.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "f.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "ig-us-sdkapi.igamecj.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "k.gjacky.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "mtp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "onezapp.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "proximabeta.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "qcloud.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "report.syzs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "sy.guanjia.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "tencentgames.helpshift.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "tsg.tdatamaster.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "twimg.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '150.109.27.214' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '157.240.16.16' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '192.168.0.103' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string '224.0.0.251' --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'abs.twimg.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'af-za.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'api.amplitude.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-hk.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-in.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-mb.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-sg.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'as-th.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'astat.bugly.qcloud.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cdn.wetest.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cdn.wetest.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cloud.gsdk.proximabeta.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'cloudsv.ieg.onezapp.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'csi.gstatic.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'eu-fra.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'eu-mo.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'euping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'file.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'filecdn.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'hk.api.unipay.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'hkping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'hkspeed.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'idcconfig.gcloudsdk.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'ig-us-notice.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'in.voice.gcloudcs.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'intldlgs.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'kj-se.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'kj-tk.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'krping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'lh3.googleusercontent.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'me-du.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'meping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'midas.gtimg.cn' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-centra.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-east.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-mx.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'na-west.shadow.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'naping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'napubgm.broker.amsoveasea.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'nawzryhwatm.broker.amsoveasea.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'pandora.game.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'platform-lookaside.fbsbx.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'pubgmobile.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'qos.hk.gcloudcs.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'safebrowsing.googleapis.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'saping.igamecj.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'tpc.googlesyndication.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'usa.csoversea.mbgame.anticheatexpert.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'video.qq.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string 'youtubei.googleapis.com' --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 1112 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 11443 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 18081 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 3013 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 80 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8080 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8085 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8086 -j DROP &>/dev/null
iptables -I INPUT -p tcp  --dport 8088 -j DROP &>/dev/null

iptables -I OUTPUT -p all -m string --string "app.adjust.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cloudconfig.googleapis.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cloudctrl.gcloudsdk.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "compute.amazonaws.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "d.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dl.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "f.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "ig-us-sdkapi.igamecj.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "k.gjacky.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "mtp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "onezapp.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "proximabeta.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "qcloud.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "report.syzs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "sy.guanjia.qq.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "tencentgames.helpshift.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "tsg.tdatamaster.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "twimg.com" --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'abs.twimg.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'af-za.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'api.amplitude.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-hk.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-in.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-mb.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-sg.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'as-th.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'astat.bugly.qcloud.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cdn.wetest.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cdn.wetest.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cloud.gsdk.proximabeta.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'cloudsv.ieg.onezapp.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'csi.gstatic.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'eu-fra.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'eu-mo.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'euping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'file.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'filecdn.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'hk.api.unipay.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'hkping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'hkspeed.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'idcconfig.gcloudsdk.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'ig-us-notice.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'in.voice.gcloudcs.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'intldlgs.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'kj-se.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'kj-tk.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'krping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'lh3.googleusercontent.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'me-du.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'meping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'midas.gtimg.cn' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-centra.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-east.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-mx.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'na-west.shadow.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'naping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'napubgm.broker.amsoveasea.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'nawzryhwatm.broker.amsoveasea.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'pandora.game.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'platform-lookaside.fbsbx.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'pubgmobile.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'qos.hk.gcloudcs.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'safebrowsing.googleapis.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'saping.igamecj.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'tpc.googlesyndication.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'usa.csoversea.mbgame.anticheatexpert.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'video.qq.com' --algo bm -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string 'youtubei.googleapis.com' --algo bm -j DROP &>/dev/null




#START BUTTON


su -c iptables -I INPUT -p tcp --dport 8086 -j DROP
su -c iptables -I INPUT -p tcp --dport 8085 -j DROP
su -c iptables -I INPUT -p tcp --dport 90 -j DROP
su -c iptables -I INPUT -p tcp --dport 554 -j DROP
su -c iptables -I INPUT -p tcp --dport 80 -j DROP
su -c iptables -I INPUT -p tcp --dport 443 -j DROP
su -c iptables -I INPUT -p tcp --dport 8013 -j DROP
su -c iptables -I INPUT -p tcp --dport 15692 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 10080 -j DROP
su -c iptables -I INPUT -p tcp --dport 20001 -j DROP
su -c iptables -I INPUT -p tcp --dport 20000 -j DROP
su -c iptables -I INPUT -p tcp --dport 8011 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 20002 -j DROP
su -c iptables -I INPUT -p tcp --dport 17000 -j DROP
su -c iptables -I INPUT -p UDP --dport 8700 -j DROP
su -c iptables -I INPUT -p tcp --dport 20371 -j DROP
su -c iptables -I INPUT -p UDP --dport 9030 -j ACCEPT
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 18600 -j DROP
su -c iptables -I INPUT -p UDP --dport 10013 -j DROP
su -c iptables -I INPUT -p UDP --dport 10012 -j DROP
su -c iptables -I INPUT -p UDP --dport 10019 -j DROP

su -c iptables -I OUTPUT -p tcp --dport 8086 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8085 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 90 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 554 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 80 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 443 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 9031 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10080 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20001 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20002 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 8700 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 9030 -j ACCEPT
su -c iptables -I OUTPUT -p UDP --dport 9031 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18600 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10013 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10012 -j DROP
su -c iptables -I OUTPUT -p UDP --dport 10019 -j DROP

iptables -t nat -D OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -D OUTPUT -p tcp --destination-port 53 -j DROP
ip6tables -D OUTPUT -p udp --destination-port 53 -j DROP
iptables -D OUTPUT -p tcp --destination-port 53 -j DROP
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -A OUTPUT -p udp --destination-port 53 -j DROP
ip6tables -A OUTPUT -p tcp --destination-port 53 -j DROP
iptables -A OUTPUT -p tcp --destination-port 53 -j DROP

rm -rf /data/data/com.pubg.imobile/lib/libBugly.so
rm -rf /data/data/com.pubg.imobile/lib/libgamemaster.so
rm -rf /data/data/com.pubg.imobile/lib/libgcloudarch.so
rm -rf /data/data/com.pubg.imobile/lib/libhelpshiftlistener.so
rm -rf /data/data/com.pubg.imobile/lib/libigshare.so
rm -rf /data/data/com.pubg.imobile/lib/liblbs.so
rm -rf /data/data/com.pubg.imobile/lib/libst-engine.so
rm -rf /data/data/com.pubg.imobile/lib/libtgpa.so
rm -rf /data/data/com.pubg.imobile/lib/libzip.so

rm -rf /data/data/com.tencent.ig/lib/libBugly.so
rm -rf /data/data/com.tencent.ig/lib/libgamemaster.so
rm -rf /data/data/com.tencent.ig/lib/libgcloudarch.so
rm -rf /data/data/com.tencent.ig/lib/libhelpshiftlistener.so
rm -rf /data/data/com.tencent.ig/lib/libigshare.so
rm -rf /data/data/com.tencent.ig/lib/liblbs.so
rm -rf /data/data/com.tencent.ig/lib/libst-engine.so
rm -rf /data/data/com.tencent.ig/lib/libtgpa.so
rm -rf /data/data/com.tencent.ig/lib/libzip.so

rm -rf /data/data/com.pubg.krmobile/lib/libBugly.so
rm -rf /data/data/com.pubg.krmobile/lib/libgamemaster.so
rm -rf /data/data/com.pubg.krmobile/lib/libgcloudarch.so
rm -rf /data/data/com.pubg.krmobile/lib/libhelpshiftlistener.so
rm -rf /data/data/com.pubg.krmobile/lib/libigshare.so
rm -rf /data/data/com.pubg.krmobile/lib/liblbs.so
rm -rf /data/data/com.pubg.krmobile/lib/libst-engine.so
rm -rf /data/data/com.pubg.krmobile/lib/libtgpa.so
rm -rf /data/data/com.pubg.krmobile/lib/libzip.so

iptables -A INPUT -s 129.226.3.250,157.240.16.16,69.171.250.15,157.240.16.35,157.240.16.20 -j ACCEPT

iptables -A INPUT -s 104.244.40.0/21 -j ACCEPT

sleep 60



iptables -I OUTPUT -p tcp  --dport 1112 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 11443 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 18081 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 3013 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 80 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8080 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8085 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8086 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp  --dport 8088 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 11038 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 111 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 20001 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 8011 -j DROP &>/dev/null
iptables -I OUTPUT -p udp  --dport 81 -j DROP &>/dev/null
iptables -I OUTPUT -p udp --dport 11038 -j DROP
iptables -I OUTPUT -p udp --dport 111 -j DROP
iptables -I OUTPUT -p udp --dport 20001 -j DROP
iptables -I OUTPUT -p udp --dport 8011 -j DROP
iptables -I OUTPUT -p udp --dport 81 -j DROP