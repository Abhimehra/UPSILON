#START BUTTON

su -c iptables -F
su -c iptables -F
su -c iptables --flush
su -c iptables --flush
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F

su -c iptables -I INPUT -p tcp --dport 8086 -j DROP
su -c iptables -I INPUT -p tcp --dport 8085 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 35000 -j DROP
su -c iptables -I INPUT -p tcp --dport 5038 -j DROP
su -c iptables -I INPUT -p tcp --dport 5555 -j DROP
su -c iptables -I INPUT -p tcp --dport 6044 -j DROP
su -c iptables -I INPUT -p tcp --dport 10085 -j DROP
su -c iptables -I INPUT -p tcp --dport 80 -j DROP
su -c iptables -I INPUT -p tcp --dport 54384 -j DROP
su -c iptables -I INPUT -p tcp --dport 10086 -j DROP
su -c iptables -I INPUT -p tcp --dport 24296 -j DROP
su -c iptables -I INPUT -p tcp --dport 54817 -j DROP
su -c iptables -I INPUT -p tcp --dport 50887 -j DROP
su -c iptables -I INPUT -p tcp --dport 50877 -j DROP
su -c iptables -I INPUT -p tcp --dport 50904 -j DROP
su -c iptables -I INPUT -p tcp --dport 50906 -j DROP
su -c iptables -I INPUT -p tcp --dport 50926 -j DROP
su -c iptables -I INPUT -p tcp --dport 51915 -j DROP
su -c iptables -I INPUT -p tcp --dport 51962 -j DROP
su -c iptables -I INPUT -p tcp --dport 51965 -j DROP
su -c iptables -I INPUT -p tcp --dport 54652 -j DROP
su -c iptables -I INPUT -p tcp --dport 54655 -j DROP
su -c iptables -I INPUT -p tcp --dport 54675 -j DROP
su -c iptables -I INPUT -p tcp --dport 54740 -j DROP
su -c iptables -I INPUT -p tcp --dport 54825 -j DROP
su -c iptables -I INPUT -p tcp --dport 54840 -j DROP
su -c iptables -I INPUT -p tcp --dport 54841 -j DROP
su -c iptables -I INPUT -p tcp --dport 57448 -j DROP
su -c iptables -I INPUT -p tcp --dport 55817 -j DROP
su -c iptables -I INPUT -p tcp --dport 57447 -j DROP
su -c iptables -I INPUT -p tcp --dport 57459 -j DROP
su -c iptables -I INPUT -p tcp --dport 57460 -j DROP
su -c iptables -I INPUT -p tcp --dport 57756 -j DROP
su -c iptables -I INPUT -p tcp --dport 57823 -j DROP
su -c iptables -I INPUT -p tcp --dport 58048 -j DROP
su -c iptables -I INPUT -p tcp --dport 58140 -j DROP
su -c iptables -I INPUT -p tcp --dport 58141 -j DROP
su -c iptables -I INPUT -p tcp --dport 58235 -j DROP
su -c iptables -I INPUT -p tcp --dport 58236 -j DROP
su -c iptables -I INPUT -p tcp --dport 58238 -j DROP
su -c iptables -I INPUT -p tcp --dport 58242 -j DROP
su -c iptables -I INPUT -p tcp --dport 58243 -j DROP
su -c iptables -I INPUT -p tcp --dport 58244 -j DROP
su -c iptables -I INPUT -p tcp --dport 58245 -j DROP
su -c iptables -I INPUT -p tcp --dport 58246 -j DROP
su -c iptables -I INPUT -p tcp --dport 58247 -j DROP
su -c iptables -I INPUT -p tcp --dport 58259 -j DROP
su -c iptables -I INPUT -p tcp --dport 58262 -j DROP
su -c iptables -I INPUT -p tcp --dport 58273 -j DROP
su -c iptables -I INPUT -p tcp --dport 54856 -j DROP
su -c iptables -I INPUT -p tcp --dport 54861 -j DROP
su -c iptables -I INPUT -p tcp --dport 15692 -j DROP
su -c iptables -I INPUT -p tcp --dport 20371 -j DROP
su -c iptables -I INPUT -p tcp --dport 13003 -j DROP
su -c iptables -I INPUT -p tcp --dport 8081 -j DROP
su -c iptables -I INPUT -p tcp --dport 50324 -j DROP
su -c iptables -I INPUT -p tcp --dport 51703 -j DROP
su -c iptables -I INPUT -p tcp --dport 10012 -j DROP
su -c iptables -I INPUT -p tcp --dport 8080 -j DROP
su -c iptables -I INPUT -p tcp --dport 3013 -j DROP
su -c iptables -I INPUT -p tcp --dport 9030 -j DROP
su -c iptables -I INPUT -p tcp --dport 8011 -j DROP
su -c iptables -I INPUT -p tcp --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 20002 -j DROP
su -c iptables -I INPUT -p tcp --dport 20001 -j DROP
su -c iptables -I INPUT -p tcp --dport 90 -j DROP
su -c iptables -I INPUT -p tcp --dport 10371 -j DROP
su -c iptables -I INPUT -p tcp --dport 8013 -j DROP
su -c iptables -I INPUT -p tcp --dport 10614 -j DROP
su -c iptables -I INPUT -p tcp --dport 20000 -j DROP
su -c iptables -I INPUT -p tcp --dport 10259 -j DROP
su -c iptables -I INPUT -p tcp --dport 10538 -j DROP
su -c iptables -I INPUT -p tcp --dport 10013 -j DROP
su -c iptables -I INPUT -p tcp --dport 8088 -j DROP
su -c iptables -I INPUT -p tcp --dport 8700 -j DROP
su -c iptables -I INPUT -p tcp --dport 10205 -j DROP
su -c iptables -I INPUT -p tcp --dport 443-j DROP
su -c iptables -I INPUT -p tcp --dport 17000 -j DROP
su -c iptables -I INPUT -p tcp --dport 554 -j DROP
su -c iptables -I INPUT -p tcp --dport 10099 -j DROP

su -c iptables -I OUTPUT -p tcp --dport 8086 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8085 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 35000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 5038 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 5555 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 6044 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10085 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 80 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 54384 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10086 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 24296 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 54817 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 50887 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 50877 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 50904 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 50906 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 50926 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 51915 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 51962 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 51965 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 54652 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 54655 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 54675 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 54740 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 54825 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 54840 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 54841 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 57448 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 55817 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 57447 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 57459 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 57460 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 57756 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 57823 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58048 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58140 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58141 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58235 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58236 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58238 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58242 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58243 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58244 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58245 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58246 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58247 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58259 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58262 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 58273 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 54856 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 54861 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 15692 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20371 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 13003 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8081 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 50324 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 51703 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10012 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8080 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 3013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 9030 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8011 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 9031 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20002 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20001 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 443-j DROP
su -c iptables -I OUTPUT -p tcp --dport 10371 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10614 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 20000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10259 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10538 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10013 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8088 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 8700 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 90 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10205 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17000 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 554 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 10099 -j DRO



