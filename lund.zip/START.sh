export MISAKI="com.pubg.imobile"

#change permission #misaki
chmod -R 777 /data/data/$MISAKI/files/ano_tmp
chmod -R 777 /data/data/$MISAKI/files/ano_tmp/*
sleep 2
chmod -R 777 /data/media/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

#remove class #misaki
rm -rf /sdcard/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload
rm -rf /sdcard/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
rm -rf /sdcard/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /sdcard/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
rm -rf /sdcard/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /sdcard/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
rm -rf /sdcard/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/$MISAKI/files/TGPA
rm -rf /sdcard/Android/data/$MISAKI/cache
rm -rf /sdcard/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
cp -rf /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15337.pak /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.89898.pak
rm -rf /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null

#echo for version up #misaki
echo '[version]
appversion=1.5.0.15331
srcversion=1.5.0.89898' >> /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
rm -rf /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null

#echo for disable update #misaki
echo "[/Script/Client.GDolphinUpdater]
Disable=true" > /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini

chmod 550 /data/media/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 555 /data/media/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
echo "  

#lightdata modification #misaki
kkk3o" >> /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
cp /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /storage/emulated/0/Android/data/$MISAKI/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz#Login Page
rm -rf /data/data/$MISAKI/databases
echo "Complete"
sleep 1

#
ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables

uptime
#====================================
iptables -I INPUT -p all -m string --string "images.metaservices.microsoft.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "images.metaservices.microsoft.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "pandoracdn.itop.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "pandoracdn.itop.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "na.pandora.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "na.pandora.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "pay.igamecj.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "pay.igamecj.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "rov.proximabeta.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "rov.proximabeta.com" --algo kmp -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "gp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "gp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.0.38" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.0.38" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.29.150" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.29.150" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "150.109.0.45" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "150.109.0.45" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "119.28.121.174" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "119.28.121.174" --algo kmp -j DROP &>/dev/null
su - c iptables --flush
iptables --flush

rm -rf /data/cache/magisk.log
rm -rf /data/cache/magisk.log.bak

echo 'I1NUQVJUIEJVVFRPTgoKCnN1IC1jIGlwdGFibGVzIC1JIElOUFVUIC1wIHRjcCAtLWRwb3J0IDgwODYgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBJTlBVVCAtcCB0Y3AgLS1kcG9ydCA4MDg1IC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgSU5QVVQgLXAgdGNwIC0tZHBvcnQgOTAgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBJTlBVVCAtcCB0Y3AgLS1kcG9ydCA1NTQgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBJTlBVVCAtcCB0Y3AgLS1kcG9ydCA4MCAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIElOUFVUIC1wIHRjcCAtLWRwb3J0IDQ0MyAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIElOUFVUIC1wIHRjcCAtLWRwb3J0IDgwMTMgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBJTlBVVCAtcCB0Y3AgLS1kcG9ydCAxNTY5MiAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIElOUFVUIC1wIHRjcCAtLWRwb3J0IDkwMzEgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBJTlBVVCAtcCB0Y3AgLS1kcG9ydCAxMDA4MCAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIElOUFVUIC1wIHRjcCAtLWRwb3J0IDIwMDAxIC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgSU5QVVQgLXAgdGNwIC0tZHBvcnQgMjAwMDAgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBJTlBVVCAtcCB0Y3AgLS1kcG9ydCA4MDExIC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgSU5QVVQgLXAgdGNwIC0tZHBvcnQgMTgwODEgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBJTlBVVCAtcCB0Y3AgLS1kcG9ydCAyMDAwMiAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIElOUFVUIC1wIHRjcCAtLWRwb3J0IDE3MDAwIC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgSU5QVVQgLXAgVURQIC0tZHBvcnQgODcwMCAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIElOUFVUIC1wIHRjcCAtLWRwb3J0IDIwMzcxIC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgSU5QVVQgLXAgVURQIC0tZHBvcnQgOTAzMCAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIElOUFVUIC1wIFVEUCAtLWRwb3J0IDkwMzEgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBJTlBVVCAtcCB0Y3AgLS1kcG9ydCAxODYwMCAtaiBEUk9QCgpzdSAtYyBpcHRhYmxlcyAtSSBPVVRQVVQgLXAgdGNwIC0tZHBvcnQgODA4NiAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIE9VVFBVVCAtcCB0Y3AgLS1kcG9ydCA4MDg1IC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgT1VUUFVUIC1wIHRjcCAtLWRwb3J0IDkwIC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgT1VUUFVUIC1wIHRjcCAtLWRwb3J0IDU1NCAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIE9VVFBVVCAtcCB0Y3AgLS1kcG9ydCA4MCAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIE9VVFBVVCAtcCB0Y3AgLS1kcG9ydCA0NDMgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBPVVRQVVQgLXAgdGNwIC0tZHBvcnQgODAxMyAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIE9VVFBVVCAtcCB0Y3AgLS1kcG9ydCAxNTY5MiAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIE9VVFBVVCAtcCB0Y3AgLS1kcG9ydCA5MDMxIC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgT1VUUFVUIC1wIHRjcCAtLWRwb3J0IDEwMDgwIC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgT1VUUFVUIC1wIHRjcCAtLWRwb3J0IDIwMDAxIC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgT1VUUFVUIC1wIHRjcCAtLWRwb3J0IDIwMDAwIC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgT1VUUFVUIC1wIHRjcCAtLWRwb3J0IDgwMTEgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBPVVRQVVQgLXAgdGNwIC0tZHBvcnQgMTgwODEgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBPVVRQVVQgLXAgdGNwIC0tZHBvcnQgMjAwMDIgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBPVVRQVVQgLXAgdGNwIC0tZHBvcnQgMTcwMDAgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBPVVRQVVQgLXAgVURQIC0tZHBvcnQgODcwMCAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIE9VVFBVVCAtcCB0Y3AgLS1kcG9ydCAyMDM3MSAtaiBEUk9QCnN1IC1jIGlwdGFibGVzIC1JIE9VVFBVVCAtcCBVRFAgLS1kcG9ydCA5MDMwIC1qIERST1AKc3UgLWMgaXB0YWJsZXMgLUkgT1VUUFVUIC1wIFVEUCAtLWRwb3J0IDkwMzEgLWogRFJPUApzdSAtYyBpcHRhYmxlcyAtSSBPVVRQVVQgLXAgdGNwIC0tZHBvcnQgMTg2MDAgLWogRFJPUAoKcm0gLXJmIC9kYXRhL2RhdGEvY29tLnRlbmNlbnQuaWcvbGliL2xpYkJ1Z2x5LnNvCnJtIC1yZiAvZGF0YS9kYXRhL2NvbS5wdWJnLmtybW9iaWxlL2xpYi9saWJCdWdseS5zbwpybSAtcmYgL2RhdGEvZGF0YS9jb20ucHViZy5pbW9iaWxlL2xpYkJ1Z2x5LnNvCgoKCg==' | base64 -d | sh
