iptables -A FORWARD -m string --algo bm --string "AntiCheatOpenID" -j DROP
iptables -A FORWARD -m string --algo bm --string "COREREPORT" -j DROP
iptables -A FORWARD -m string --algo bm --string "N6TssSDK11ReportQueue" -j DROP
iptables -A FORWARD -m string --algo bm --string "N6TssSDK15FileCrcReporter" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDK.ReportQosByGame" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKDelReportData" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKGetReportData" -j DROP
iptables -A FORWARD -m string --algo bm --string "TssSDKOnRecvData" -j DROP
iptables -A FORWARD -m string --algo bm --string "WB_GetReportStr" -j DROP
iptables -A FORWARD -m string --algo bm --string "_ZN6TssSdk16sdt_report_errorEv" -j DROP
iptables -A FORWARD -m string --algo bm --string "amazonaws.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "asia.csoversea.mbgame.anticheatexpert.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "cs.mbgame.gamesafe.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "dlied1.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "down.anticheatexpert.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "down.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "intldlgs.qq.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "report_apk" -j DROP
iptables -A FORWARD -m string --algo bm --string "res_max_report_missed_cnt" -j DROP
iptables -A FORWARD -m string --algo bm --string "sc_report" -j DROP
iptables -A FORWARD -m string --algo bm --string "tdm_report" -j DROP
iptables -A FORWARD -m string --algo bm --string "tdm_report_sdk_update_config_finish" -j DROP
iptables -A FORWARD -m string --algo bm --string "tencentgames.helpshift.com" -j DROP
iptables -A FORWARD -m string --algo bm --string "tp2_free_anti_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_del_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_enable_get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_get_report_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "tss_sdk_rcv_anti_data" -j DROP
iptables -A FORWARD -m string --algo bm --string "vmp.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "AntiCheatOpenID" -j DROP
iptables -A INPUT -m string --algo bm --string "COREREPORT" -j DROP
iptables -A INPUT -m string --algo bm --string "N6TssSDK11ReportQueue" -j DROP
iptables -A INPUT -m string --algo bm --string "N6TssSDK15FileCrcReporter" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDK.ReportQosByGame" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKDelReportData" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKGetReportData" -j DROP
iptables -A INPUT -m string --algo bm --string "TssSDKOnRecvData" -j DROP
iptables -A INPUT -m string --algo bm --string "WB_GetReportStr" -j DROP
iptables -A INPUT -m string --algo bm --string "_ZN6TssSdk16sdt_report_errorEv" -j DROP
iptables -A INPUT -m string --algo bm --string "amazonaws.com" -j DROP
iptables -A INPUT -m string --algo bm --string "asia.csoversea.mbgame.anticheatexpert.com" -j DROP
iptables -A INPUT -m string --algo bm --string "cs.mbgame.gamesafe.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "dlied1.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "down.anticheatexpert.com" -j DROP
iptables -A INPUT -m string --algo bm --string "down.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "intldlgs.qq.com" -j DROP
iptables -A INPUT -m string --algo bm --string "report_apk" -j DROP
iptables -A INPUT -m string --algo bm --string "res_max_report_missed_cnt" -j DROP
iptables -A INPUT -m string --algo bm --string "sc_report" -j DROP
iptables -A INPUT -m string --algo bm --string "tdm_report" -j DROP
iptables -A INPUT -m string --algo bm --string "tdm_report_sdk_update_config_finish" -j DROP
iptables -A INPUT -m string --algo bm --string "tencentgames.helpshift.com" -j DROP
iptables -A INPUT -m string --algo bm --string "tp2_free_anti_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_del_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_enable_get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_get_report_data" -j DROP
iptables -A INPUT -m string --algo bm --string "tss_sdk_rcv_anti_data" -j DROP
iptables -A INPUT -m string --algo bm --string "vmp.qq.com" -j DROP


iptables -I INPUT -s game.anticheatexpert.com -j DROP &>/dev/null 
iptables -I OUTPUT -s game.anticheatexpert.com -j DROP &>/dev/null 

iptables -I OUTPUT -s down.anticheatexpert.com -j DROP &>/dev/null 
iptables -I INPUT -s down.anticheatexpert.com -j DROP &>/dev/null 

iptables -I INPUT -s shadow.igamecj.com -j DROP &>/dev/null 
iptables -I OUTPUT -s shadow.igamecj.com -j DROP &>/dev/null 

iptables -I INPUT -s pubgm.broker.amsoveasea.com -j DROP &>/dev/null 
iptables -I OUTPUT -s pubgm.broker.amsoveasea.com -j DROP &>/dev/null 



rm -rf /sdcard/Android/data/com.pubg.imobile/files/ProgramBinaryCache
rm -rf /sdcard/Android/data/com.pubg.imobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/Paks
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/Cookie
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Download
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/pandora
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RP
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Pet
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Task
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/UnknowPass
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Tencent/beacon
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/blob/mqq
rm -rf /sdcard/Tencent/leqq/Log/com.pubg.imobile
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_live_log/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_audio_data
rm -rf /sdcard/Tencent/tbs/backup/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.TbsReaderTempcom.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.thumbnails
rm -rf /sdcard/Tencent/QQfile_recv/.tmp
rm -rf /sdcard/Tencent/QQfile_recv/.trooptmp
rm -rf /sdcard/Tencent/msflogs/com/tencent/mobileqqu
rm -rf /sdcard/Tencent/MobileQQ/.apollo/game
rm -rf /sdcard/Tencent/MobileQQ/capture_qsvf
rm -rf /sdcard/Tencent/MobileQQ/dov_ptv_template_dov
rm -rf /sdcard/Tencent/MobileQQ/WebViewCheck
rm -rf /sdcard/Tencent/MobileQQ/log
rm -rf /sdcard/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/tencent/XG/Logs/20200109
rm -rf /sdcard/.backups/com.pubg.imobile/helpshift/databases
rm -rf /sdcard/Android/data/com.pubg.imobile/cache
rm -rf /sdcard/Android/data/com.pubg.imobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Season
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/.backups/com.pubg.imobile/helpshift/databases/__hs__backup_dao_storage
rm -rf /sdcard/Tencent/beacon/meta.dat
rm -rf /sdcard/MidasOversea/GUID
rm -rf /sdcard/Tencent/Midas/Log/com.pubg.imobile
rm -rf /sdcard/Android/data/com.pubg.imobile/files/ca-bundle.pem
rm -rf /sdcard/Android/data/com.pubg.imobile/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.imobile/cache
rm -rf /sdcard/Android/data/com.pubg.imobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/.backups
rm -rf /sdcard/Tencent
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/cache
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/tbslog
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/vmpcloudconfig.json
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/ProgramBinaryCache
echo "Log Cleaning....."
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir

#KOREA

rm -rf /sdcard/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Paks
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/Cookie
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Download
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/pandora
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RP
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Pet
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Task
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/UnknowPass
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Tencent/beacon
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/blob/mqq
rm -rf /sdcard/Tencent/leqq/Log/com.pubg.krmobile
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_live_log/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_audio_data
rm -rf /sdcard/Tencent/tbs/backup/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.TbsReaderTempcom.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.thumbnails
rm -rf /sdcard/Tencent/QQfile_recv/.tmp
rm -rf /sdcard/Tencent/QQfile_recv/.trooptmp
rm -rf /sdcard/Tencent/msflogs/com/tencent/mobileqqu
rm -rf /sdcard/Tencent/MobileQQ/.apollo/game
rm -rf /sdcard/Tencent/MobileQQ/capture_qsvf
rm -rf /sdcard/Tencent/MobileQQ/dov_ptv_template_dov
rm -rf /sdcard/Tencent/MobileQQ/WebViewCheck
rm -rf /sdcard/Tencent/MobileQQ/log
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/tencent/XG/Logs/20200109
rm -rf /sdcard/.backups/com.pubg.krmobile/helpshift/databases
rm -rf /sdcard/Android/data/com.pubg.krmobile/cache
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Season
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/.backups/com.pubg.krmobile/helpshift/databases/__hs__backup_dao_storage
rm -rf /sdcard/Tencent/beacon/meta.dat
rm -rf /sdcard/MidasOversea/GUID
rm -rf /sdcard/Tencent/Midas/Log/com.pubg.krmobile
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/ca-bundle.pem
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.krmobile/cache
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/.backups
rm -rf /sdcard/Tencent
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/vmpcloudconfig.json
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
echo "Log Cleaning....."
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir

#BGMI

rm -rf /sdcard/Android/data/com.tencent.ig/files/ProgramBinaryCache
rm -rf /sdcard/Android/data/com.tencent.ig/files/tbslog
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Paks
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/Cookie
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Download
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/pandora
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RP
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Pet
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Task
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/UnknowPass
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Tencent/beacon
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/blob/mqq
rm -rf /sdcard/Tencent/leqq/Log/com.tencent.ig
rm -rf /sdcard/Tencent/wtlogin/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_live_log/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs_audio_data
rm -rf /sdcard/Tencent/tbs/backup/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/tbs/com.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.TbsReaderTempcom.tencent.mobileqqu
rm -rf /sdcard/Tencent/QQfile_recv/.thumbnails
rm -rf /sdcard/Tencent/QQfile_recv/.tmp
rm -rf /sdcard/Tencent/QQfile_recv/.trooptmp
rm -rf /sdcard/Tencent/msflogs/com/tencent/mobileqqu
rm -rf /sdcard/Tencent/MobileQQ/.apollo/game
rm -rf /sdcard/Tencent/MobileQQ/capture_qsvf
rm -rf /sdcard/Tencent/MobileQQ/dov_ptv_template_dov
rm -rf /sdcard/Tencent/MobileQQ/WebViewCheck
rm -rf /sdcard/Tencent/MobileQQ/log
rm -rf /sdcard/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/tencent/XG/Logs/20200109
rm -rf /sdcard/.backups/com.tencent.ig/helpshift/databases
rm -rf /sdcard/Android/data/com.tencent.ig/cache
rm -rf /sdcard/Android/data/com.tencent.ig/files/tbslog
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Season
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Character
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/.backups/com.tencent.ig/helpshift/databases/__hs__backup_dao_storage
rm -rf /sdcard/Tencent/beacon/meta.dat
rm -rf /sdcard/MidasOversea/GUID
rm -rf /sdcard/Tencent/Midas/Log/com.tencent.ig
rm -rf /sdcard/Android/data/com.tencent.ig/files/ca-bundle.pem
rm -rf /sdcard/Android/data/com.tencent.ig/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.tencent.ig/cache
rm -rf /sdcard/Android/data/com.tencent.ig/files/tbslog
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /sdcard/.backups
rm -rf /sdcard/Tencent
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/tbslog
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/vmpcloudconfig.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir

su -c iptables -I INPUT -p tcp --dport 8086 -j DROP
su -c iptables -I INPUT -p tcp --dport 8085 -j DROP
su -c iptables -I INPUT -p tcp --dport 90 -j DROP
su -c iptables -I INPUT -p tcp --dport 554 -j DROP
su -c iptables -I INPUT -p tcp --dport 80 -j DROP
#su -c iptables -I INPUT -p tcp --dport 443 -j DROP
su -c iptables -I INPUT -p tcp --dport 8013 -j DROP
su -c iptables -I INPUT -p tcp --dport 15692 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 10080 -j DROP
su -c iptables -I INPUT -p tcp --dport 20001 -j DROP
su -c iptables -I INPUT -p tcp --dport 20000 -j DROP
su -c iptables -I INPUT -p tcp --dport 8011 -j DROP
su -c iptables -I INPUT -p tcp --dport 18081 -j DROP
su -c iptables -I INPUT -p tcp --dport 20002 -j DROP
su -c iptables -I INPUT -p tcp --dport 17000 -j DROP
su -c iptables -I INPUT -p UDP --dport 8700 -j DROP
su -c iptables -I INPUT -p tcp --dport 20371 -j DROP
su -c iptables -I INPUT -p UDP --dport 9030 -j DROP
su -c iptables -I INPUT -p UDP --dport 9031 -j DROP
su -c iptables -I INPUT -p tcp --dport 18600 -j DROP
su -c iptables -I INPUT -p UDP --dport 10013 -j DROP
su -c iptables -I INPUT -p UDP --dport 10012 -j DROP
su -c iptables -I INPUT -p UDP --dport 10019 -j DROP

su -c iptables -I OUTPUT -p tcp --dport 8086 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8085 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 90 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 554 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 80 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 443 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8013 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 15692 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 9031 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 10080 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 20001 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 20000 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 8011 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 18081 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 20002 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 17000 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 8700 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 20371 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 9030 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 9031 -j REJECT
su -c iptables -I OUTPUT -p tcp --dport 18600 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 10013 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 10012 -j REJECT
su -c iptables -I OUTPUT -p UDP --dport 10019 -j REJECT
#su -c iptables -I OUTPUT -p UDP --dport 17500 -j REJECT
su -c iptables -I FORWARD -p UDP --dport 17500 -j REJECT
su -c iptables -I FORWARD -p UDP --dport 443 -j REJECT

iptables -t nat -D OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -D OUTPUT -p tcp --destination-port 53 -j DROP
ip6tables -D OUTPUT -p udp --destination-port 53 -j DROP
iptables -D OUTPUT -p tcp --destination-port 53 -j DROP
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 127.0.0.1:5300
ip6tables -A OUTPUT -p udp --destination-port 53 -j DROP
ip6tables -A OUTPUT -p tcp --destination-port 53 -j DROP
iptables -A OUTPUT -p tcp --destination-port 53 -j DROP

su -c iptables -I OUTPUT -p ICMP -j DROP
su -c iptables -I INPUT -p ICMP -j DROP

