chmod 000 /data/data/com.pubg.krmobile/lib*/
chmod 000 /data/data/com.pubg.krmobile/lib/*
chmod 000 /data/data/com.tencent.ig/lib*/
chmod 000 /data/data/com.tencent.ig/lib/*
chmod 000 /data/data/com.pubg.imobile/lib*/
chmod 000 /data/data/com.pubg.imobile/lib/*