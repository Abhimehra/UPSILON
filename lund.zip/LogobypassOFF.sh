pm install -r /data/app/com.pubg.imobile*/base.apk  &> /dev/null
pm install -r /data/app/com.pubg.krmobile*/base.apk  &> /dev/null
#pm install -r /data/app/com.tencent.ig*/base.apk  &> /dev/null