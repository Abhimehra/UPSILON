su -c chmod 775 /data/data/com.pubg.krmobile/lib/*
su -c chmod 775 /data/data/com.pubg.imobile/lib/*
su -c chmod 775 /data/data/com.tencent.ig/lib/*

su -c chmod 775 /data/data/com.pubg.krmobile/lib*/
su -c chmod 775 /data/data/com.pubg.imobile/lib*/
su -c chmod 775 /data/data/com.tencent.ig/lib*/

su -c chmod 771 /data/data/com.tencent.ig/databases/*
su -c chmod 771 /data/data/com.pubg.imobile/databases/*
su -c chmod 771 /data/data/com.pubg.krmobile/databases/*