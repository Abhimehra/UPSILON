


iptables -I INPUT -s lobby.globh.com -j REJECT &>/dev/null 
iptables -I OUTPUT -s lobby.globh.com -j REJECT &>/dev/null

su -c iptables -I INPUT -p tcp --dport 18600 -j DROP
su -c iptables -I INPUT -p tcp --dport 18600 -j DROP
su -c iptables -I INPUT -p tcp --dport 17500 -j DROP
su -c iptables -I INPUT -p tcp --dport 17500 -j DROP


su -c iptables -I OUTPUT -p tcp --dport 18600 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 18600 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17500 -j DROP
su -c iptables -I OUTPUT -p tcp --dport 17500 -j DROP