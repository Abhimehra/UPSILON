#iptables -I INPUT -p tcp --dport 17500 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 18600 -j DROP &>/dev/null
#iptables -I OUTPUT -p tcp --dport 17500 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 18600 -j DROP &>/dev/null
