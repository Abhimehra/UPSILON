[ OUTPUT RULE ]

iptables -I OUTPUT -p tcp --dport http-alt -j DROP
iptables -I OUTPUT -p tcp --dport 10012 -j DROP
iptables -I OUTPUT -p tcp --dport 20371 -j DROP
iptables -I OUTPUT -p tcp --dport 15692 -j DROP
iptables -I OUTPUT -p tcp --dport 18081 -j DROP
iptables -I OUTPUT -p tcp --dport 8085 -j DROP
iptables -I OUTPUT -p tcp --dport https -j DROP
iptables -I OUTPUT -p tcp --dport 49514 -j DROP
iptables -I OUTPUT -p tcp --dport 8086 -j DROP
iptables -I OUTPUT -p tcp --dport 90 -j DROP
iptables -I OUTPUT -p tcp --dport 554 -j DROP
iptables -I OUTPUT -p tcp --dport 18600 -j DROP


[ INPUT RULE ]

iptables -I INPUT -p tcp --dport http-alt -j DROP
iptables -I INPUT -p tcp --dport 10012 -j DROP
iptables -I INPUT -p tcp --dport 20371 -j DROP
iptables -I INPUT -p tcp --dport 15692 -j DROP
iptables -I INPUT -p tcp --dport 18081 -j DROP
iptables -I INPUT -p tcp --dport 8085 -j DROP
iptables -I INPUT -p tcp --dport https -j DROP
iptables -I INPUT -p tcp --dport 49514 -j DROP
iptables -I INPUT -p tcp --dport 8086 -j DROP
iptables -I INPUT -p tcp --dport 90 -j DROP
iptables -I INPUT -p tcp --dport 554 -j DROP
iptables -I INPUT -p tcp --dport 18600 -j DROP