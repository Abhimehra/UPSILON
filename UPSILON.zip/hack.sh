PKG=/data/media/0/Android/data/com.pakage.upsilon/files/

chmod 777 $PKG/test

cd $PKG

./test & >/dev/null
