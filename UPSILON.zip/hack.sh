PKG=/data/media/0/Android/data/com.pakagae.upsilon/files/

chmod 777 $PKG/test

cd $PKG

./test & >/dev/null
