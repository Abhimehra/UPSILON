mkdir $lib/libst-engine.so
#mkdir $lib/libUE4.so
mkdir $lib/libtprt.so
mkdir $lib/libTDataMaster.so
mkdir $lib/libgcloud.so