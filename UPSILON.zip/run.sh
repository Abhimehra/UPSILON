#cd /data/app/~~*==/com.pubg.imobile*/lib/arm64/
cd /data/data/com.pubg.imobile/lib/
rm -rf {libTDataMaster.so,libanogs.so}
mv {1,libanogs.so}
mv {2,libUE4.so}
mv {3,libtprt.so}
mv {4,libTDataMaster.so}
mv {5,libgcloud.so}

for PID in $(pidof com.pubg.imobile | awk '{print $1}');do busybox mount --bind path to ur cpuinfo file /proc/cpuinfo;done;