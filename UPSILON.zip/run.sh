cd /data/app/~~*==/com.pubg.imobile*/lib/arm64/

rm -rf {libTDataMaster.so,libanogs.so}
mv {1,libanogs.so}
mv {2,libUE4.so}
mv {3,libtprt.so}
mv {4,libTDataMaster.so}
mv {5,libgcloud.so}