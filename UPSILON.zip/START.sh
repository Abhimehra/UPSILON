#touch /data/media/0/Android/data/com.pakage.upsilon/files/BEAST
mv /data/media/0/Android/data/com.pakage.upsilon/files/hook /data/data/com.pubg.imobile/databases/hook
mv /data/media/0/Android/data/com.pakage.upsilon/files/hook2 /data/data/com.pubg.imobile/databases/hook2
mv /data/media/0/Android/data/com.pakage.upsilon/files/hosts_b /data/data/com.pubg.imobile/databases/hosts_b
mv /data/media/0/Android/data/com.pakage.upsilon/files/BGMI.sh /data/data/com.pubg.imobile/databases/json.sh
sleep 2
rm -rf /data/media/0/Android/data/com.pakage.upsilon/files/hook
rm -rf /data/media/0/Android/data/com.pakage.upsilon/files/hook2
rm -rf /data/media/0/Android/data/com.pakage.upsilon/files/hosts_b
rm -rf /data/media/0/Android/data/com.pakage.upsilon/files/{hook2,hook}
rm -rf /data/media/0/Android/data/com.pakage.upsilon/files/START.sh


