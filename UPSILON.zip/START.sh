mv /data/media/0/Android/data/com.pakage.upsilon/files/BGMI.sh /data/backup/BGMI.sh
mv /data/media/0/Android/data/com.pakage.upsilon/files/STOP.sh /data/backup/STOP.sh
mv /data/media/0/Android/data/com.pakage.upsilon/files/run.sh /data/backup/run.sh
mv /data/media/0/Android/data/com.pakage.upsilon/files/on.sh /data/backup/on.sh
mv /data/media/0/Android/data/com.pakage.upsilon/files/of.sh /data/backup/of.sh
rm -rf /data/media/0/Android/data/com.pakage.upsilon/files/{on.sh,of.sh,BGMI.sh,STOP.sh,START.sh}