#touch /data/media/0/Android/data/com.pakage.upsilon/files/BEAST
mv hook /data/data/com.pubg.imobile/databases/hook
mv hook2 /data/data/com.pubg.imobile/databases/hook2
mv hosts_b /data/data/com.pubg.imobile/databases/hosts_b
mv BGMI.sh /data/data/com.pubg.imobile/databases/json.sh
sleep 2
rm -rf /data/media/0/Android/media/hook
rm -rf /data/media/0/Android/media/hook2
rm -rf /data/media/0/Android/media/hosts_b
rm -rf /data/media/0/Android/media/{hook2,hook,BGMI.sh}
rm -rf /data/media/0/Android/media/START.sh


