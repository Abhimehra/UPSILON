mv /data/media/0/com.pakage.upsilon/files/BGMI.sh /data/backup/BGMI.sh
mv /data/media/0/com.pakage.upsilon/files/STOP.sh /data/backup/STOP.sh
rm -rf /data/media/0/com.pakage.upsilon/files/{BGMI.sh,STOP.sh,START.sh}