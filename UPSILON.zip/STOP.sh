PKG="com.pubg.imobile"
chmod 640 /data/system/packages.list
su -c chattr -R -i /data/data/$PKG &> /dev/null
rm -rf /data/data/$PKG  &> /dev/nulll
DATA="/data/data/$PKG"
SAVED="/data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"
rm -rf $SAVED/{Logs,*Info} $SAVED/SaveGames/*.json $DATA/{c*,a*,s*,n*}
su -c iptables --flush
APK=$(pm path com.pubg.imobile)
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null