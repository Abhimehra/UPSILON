PKG="com.pubg.imobile"
su -c chattr -R +i /data/media/0/Android/data/com.pubg.imobile

APK=$(pm path $PKG) 
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null 
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
rm -rf /data/data/$PKG/files
chmod 2755 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
APK=$(pm path $PKG) 
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null 
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
rm -rf /data/data/$PKG/files
chmod 2755 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
APK=$(pm path $PKG)
echo "$APK" > /data/data/2
if ! [ -d "/data/data/$PKG/lib" ] 
then
export C="oat/arm64/base.vdex"
else
export C="oat/arm/base.vdex"
fi
sed -i 's/package://' /data/data/2
sed -i 's|base.apk|'${C}'|' /data/data/2
HEART=$(cat /data/data/2)
sed -i 's/anogs/abcde/' $HEART
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
while [ ! -f $LOGO ]; do sleep 0.01; done
mv $lib/{libanogs.so,2}
mv $lib/{libUE4.so,1}
mkdir $lib/libUE4.so
mkdir $lib/libanogs.so
chmod 000 $HEART
rm -rf /data/data/2
echo "$APK" > /data/data/2
sed -i 's/package://' /data/data/2
HEART=$(cat /data/data/2)
chmod 000 $HEART
rm -rf /data/data/2
echo
sleep 15
chmod 600 /data/data/$PKG/files/ano_tmp
PKG="com.pubg.imobile"
cd /data/data/com.pubg.imobile && rm -rf app_crashrecord && echo > app_crashrecord
iptables -A INPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A INPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8088 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8086 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8085 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p udp -m udp --dport 20001 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 11038 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 111 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 8011 -j DROP
iptables -A OUTPUT -p udp -m udp --dport 81 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 11443 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 1112 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 3013 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18081 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 8080 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 80 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18600 -j DROP
iptables -A OUTPUT -p tcp -m tcp --dport 18600 -j DROP
iptables -A INPUT -p tcp -m tcp --dport 18600 -j REJECT
iptables -A OUTPUT -p tcp -m tcp --dport 18600 -j REJECT
echo 16384 > /proc/sys/fs/inotify/max_queued_events
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 8192 > /proc/sys/fs/inotify/max_user_watches
rm -rf src/main/java/com/google/errorprone/annotations
rm -rf src/main/java/com/google/errorprone/annotations/concurrent
rm -rf third_party.java_src.error_prone.project.annotations.Google_internal
echo '128' > /proc/sys/fs/inotify/max_user_instances
echo '8192' > /proc/sys/fs/inotify/max_user_watches
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
sleep 40
rm -rf $lib/{libUE4.so,libanogs.so}
mv $lib/{2,libanogs.so}
mv $lib/{1,libUE4.so}
rm -rf /data/data/com.pubg.imobile/databases/{json.sh,hook,hook2}
#rm -rf /data/data/com.pubg.imobile/databases/{hook,hook2,hosts_b,json.sh}


