clear
mv /system/usr/abcd/hosts_b /system/etc/hosts_b
gl=/data/data/com.tencent.ig/
kr=/data/data/com.pubg.krmobile/
vn=/data/data/com.vng.pubgmobile/
tw=/data/data/com.rekoo.pubgm/
bgmi=/data/data/com.pubg.imobile/

if [ -d "$gl" ]; then
    PKG="com.tencent.ig"
fi
 
if [ -d "$kr" ]; then
    PKG="com.pubg.krmobile"
fi

if [ -d "$vn" ]; then
    PKG="com.vng.pubgmobile"
fi

if [ -d "$tw" ]; then
    PKG="com.rekoo.pubgm"
fi

if [ -d "$bgmi" ]; then
    PKG="com.pubg.imobile"
fi

pm path $PKG &> /dev/null || {
  echo "\nPUBGM not installed!"
  exit
}

echo "\n\nLOADING 1.9.0 BSILENT BYPASS"
sleep 2
data=/data/data/$PKG
eval `pm dump $PKG | grep LibraryDir`
arm=$(ls $lib | grep arm)
M=/data/data
Saved=/storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
rm -rf /data/data/$PKG/{app_bugly,app_crashrecord}
touch /data/data/$PKG/{app_bugly,app_crashrecord}
chmod 4000 /data/data/$PKG/{app_bugly,app_crashrecord}
cp hook2 $M/;
chmod 777 $M/hook2;
L=/data/data/com.pubg.imobile/app_valac_files/libvalac.so
if [ ! -e "$L" ]; then
    mkdir cp  /data/data/com.pubg.imobile/app_valac_files/
    cp  $M/hook2 $L
fi
am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null

rm -rf /system/usr/abcd/{hook,hook2,START.sh}
rm -rf /data/data/hook2

