rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_*.pak

iptables -A INPUT -p tcp -j DROP
iptables -A OUTPUT -p tcp -j DROP
iptables -A FORWARD -p tcp -j DROP

rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mkdir /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini

PKG="com.pubg.imobile"
APK=$(pm path $PKG) 
cat ${APK#*:} | pm install -r -S $(stat -c%s ${APK#*:}) &> /dev/null 
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
rm -rf /data/data/$PKG/files
chmod 2755 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
APK=$(pm path $PKG)
echo "$APK" > /data/data/2
if ! [ -d "/data/data/$PKG/lib" ] 
then
export C="oat/arm64/base.vdex"
else
export C="oat/arm/base.vdex"
fi
sed -i 's/package://' /data/data/2
sed -i 's|base.apk|'${C}'|' /data/data/2
HEART=$(cat /data/data/2)
sed -i 's/anogs/abcde/' $HEART
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
while [ ! -f $LOGO ]; do sleep 0.01; done
cp $lib/{libanogs.so,2}
mv $lib/{libanogs.so,libabcde.so}
mv $lib/{2,libanogs.so}
mv $lib/{libUE4.so,1}
chmod 000 $HEART
rm -rf /data/data/2
echo "$APK" > /data/data/2
sed -i 's/package://' /data/data/2
HEART=$(cat /data/data/2)
chmod 000 $HEART
rm -rf /data/data/2
echo
sleep 15
chmod 600 /data/data/$PKG/files/ano_tmp
sleep 30
mv $lib/{1,libUE4.so}
su -c iptables --flush