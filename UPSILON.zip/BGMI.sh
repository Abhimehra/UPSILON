clear
PKG="com.pubg.imobile"
ver(){
chmod 555 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks &> /dev/null
}
su -c iptables --flush
APK=$(pm path $PKG)
echo "$APK" > /data/data/2
if ! [ -d "/data/data/$PKG/lib" ] 
then
export C="oat/arm64/base.vdex"
else
export C="oat/arm/base.vdex"
fi
sed -i 's/package://' /data/data/2
sed -i 's|base.apk|'${C}'|' /data/data/2
HEART=$(cat /data/data/2)
sed -i 's/anogs/abcde/' $HEART
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
echo -e "$XYELLOW DEMOLISHING CLIENTSIDE ANTICHEAT"
echo
rm -rf /data/data/$PKG/{f*,a*,c*}
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
while [ ! -f $LOGO ]; do sleep 0.01; done
mv $lib/{libanogs.so,1}
mv $lib/{libUE4.so,2}
mv $lib/{libtprt.so,3}
mv $lib/{libTDataMaster.so,4}
mv $lib/{libgcloud.so,5}
mkdir $lib/libanogs.so
mkdir $lib/libTDataMaster.so
chmod 000 $HEART
rm -rf /data/data/2
echo "$APK" > /data/data/2
sed -i 's/package://' /data/data/2
HEART=$(cat /data/data/2)
chmod 000 $HEART
rm -rf /data/data/2
echo
sleep 15
chmod 600 /data/data/$PKG/files/ano_tmp