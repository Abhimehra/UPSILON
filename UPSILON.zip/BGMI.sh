#su -c iptables -I INPUT -p tcp --dport 443 -j DROP
#su -c iptables -I OUTPUT -p tcp --dport 443 -j DROP
#su -c iptables -I INPUT -p tcp --dport 443 -j REJECT
#su -c iptables -I OUTPUT -p tcp --dport 443 -j REJECT

PKG="com.pubg.imobile"
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_*.pak
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mkdir  /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
rm -rf /cache/magisk.log
rm -rf /cache/magisk.log.bak
ver(){
chmod 2555 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks &> /dev/null
}
APK=$(pm path $PKG)
echo "$APK" > /data/data/2
if ! [ -d "/data/data/$PKG/lib" ] 
then
export C="oat/arm64/base.vdex"
else
export C="oat/arm/base.vdex"
fi
sed -i 's/package://' /data/data/2
sed -i 's|base.apk|'${C}'|' /data/data/2
HEART=$(cat /data/data/2)
sed -i 's/anogs/abcde/' $HEART
LOGO="/data/data/$PKG/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP $PKG legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
echo -e "$XYELLOW DEMOLISHING CLIENTSIDE ANTICHEAT"
echo
rm -rf /data/data/$PKG/{f*,a*,c*}
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity &> /dev/null
while [ ! -f $LOGO ]; do sleep 0.01; done
cp $lib/{libanogs.so,2}
mv $lib/{libanogs.so,libabcde.so}
mv $lib/{2,libanogs.so}
mv $lib/{libUE4.so,1}
chmod 000 $HEART
rm -rf /data/data/2
echo "$APK" > /data/data/2
sed -i 's/package://' /data/data/2
HEART=$(cat /data/data/2)
chmod 000 $HEART
rm -rf /data/data/2
sleep 15
chmod 600 /data/data/$PKG/files/ano_tmp
sleep 30
mv $lib/{1,libUE4.so}
