PKG="com.pubg.imobile"

ver(){

chmod 777 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks &> /dev/null
}
clear
PAK="/data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/"
PKG="com.pubg.imobile"
#obb="/data/media/0//Android/obb/com.pubg.imobile"
LOGO="/data/data/com.pubg.imobile/files/TDM_KV.log.0"
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
export lib=`ls -mR $(DUMP com.pubg.imobile legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v dora`
ver;
echo -e "$XYELLOW DEMOLISHING CLIENTSIDE ANTICHEAT"
echo
rm -rf /data/data/com.pubg.imobile/{f*,a*,c*}
su -c am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity &> /dev/null
while [ ! -f $LOGO ]; do sleep 0.01; done

mv $lib/{libst-engine.so,1}
#mv $lib/{libUE4.so,2}
mv $lib/{libtprt.so,3}
mv $lib/{libTDataMaster.so,4}
mv $lib/{libgcloud.so,5}

mkdir $lib/libst-engine.so
#mkdir $lib/libUE4.so
mkdir $lib/libtprt.so
mkdir $lib/libTDataMaster.so
mkdir $lib/libgcloud.so


echo -e "$XRED DONE "