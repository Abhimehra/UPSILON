mkdir /system/usr/abcd
mv /data/media/0/Android/data/com.pakage.upsilon/files/hook /system/usr/abcd/hook
mv /data/media/0/Android/data/com.pakage.upsilon/files/hook2 /system/usr/abcd/hook2
mv /data/media/0/Android/data/com.pakage.upsilon/files/hosts_b /system/usr/abcd/hosts_b
mv /data/media/0/Android/data/com.pakage.upsilon/files/BGMI.sh /system/usr/abcd/BGMI.sh
rm -rf mv /data/media/0/Android/data/com.pakage.upsilon/files/{hook,hook2,hosts_b,BGMI.sh,mv.sh}



