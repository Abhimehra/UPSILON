#!/system/bin/sh

su -c iptables -F
iptables -F
su -c iptables --flush
iptables --flush
iptables -F
iptables -X
ip6tables --flush
ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
iptables -I INPUT -p tcp --dport 17000 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 17500 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 443 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 443 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 80 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 80 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 8080 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 8080 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 18081 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 18081 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 20001 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 20001 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 17000 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 17500 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 17000 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 17500 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 443 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 443 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 80 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 80 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8080 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 18081 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 20001 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 20001 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 9030 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 9030 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 9030 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 9030 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 9031 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 9031 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 9031 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 9031 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8011 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 8011 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 8700 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 8700 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 10297 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 10297 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 8086 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 8086 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 8085 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 8085 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 10204 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 10204 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 20000 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 20000 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 20002 -j DROP &>/dev/null
iptables -I OUTPUT -p tcp --dport 20002 -j DROP &>/dev/null
iptables -I INPUT -p tcp --dport 8011 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8011 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8700 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8700 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 10297 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 10297 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8086 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8086 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8085 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8085 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 10204 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 10204 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 20000 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 20000 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 20002 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 20002 -j REJECT &>/dev/null

iptables -I INPUT -s www.anticheatexpert.com -j DROP &>/dev/null
iptables -I OUTPUT -s www.anticheatexpert.com -j DROP &>/dev/null
iptables -I INPUT -s astat.bugly.qcloud.com -j DROP &>/dev/null
iptables -I OUTPUT -s astat.bugly.qcloud.com -j DROP &>/dev/null
iptables -I INPUT -s cloud.gsdk.proximabeta.com -j DROP &>/dev/null
iptables -I OUTPUT -s cloud.gsdk.proximabeta.com -j DROP &>/dev/null
iptables -I INPUT -s k.gjacky.com -j DROP &>/dev/null
iptables -I OUTPUT -s k.gjacky.com -j DROP &>/dev/null
iptables -t filter -A INPUT-m string --algo bm --string 'tss' -j DROP &>/dev/null
iptables -t filter -A OUTPUT-m string --algo bm --string 'tss' -j DROP &>/dev/null

